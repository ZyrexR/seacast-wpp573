const fs = require('fs');
['web/src/components/public/DynamicOceanManagementVisualizer.tsx', 'web/src/components/public/HeroOceanIntelligence.tsx'].forEach(f => {
  let c = fs.readFileSync(f, 'utf8');
  c = c.replace(/fontSize="(8|9|10|11)"/g, 'fontSize="12"');
  fs.writeFileSync(f, c, 'utf8');
});
console.log('SVG font sizes updated to 12.');

