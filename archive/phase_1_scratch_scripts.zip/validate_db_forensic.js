const path = require('path');
const { Pool } = require(path.resolve(__dirname, '../web/node_modules/pg'));

const pool = new Pool({
  connectionString: 'postgresql://postgres:postgres@localhost:5432/seacast_prigi',
});

async function runQueries() {
  const client = await pool.connect();
  try {
    console.log('===============================================================');
    console.log('SEACAST PRIGI V3 — FORENSIC DATABASE & POSTGIS QUERY VALIDATION');
    console.log('===============================================================\n');

    // 1. Version Check
    const q1 = "SELECT version();";
    const res1 = await client.query(q1);
    console.log('QUERY 1:', q1);
    console.log('RESULT 1:', res1.rows[0].version, '\n');

    // 2. PostGIS Version Check
    const q2 = "SELECT PostGIS_Full_Version();";
    const res2 = await client.query(q2);
    console.log('QUERY 2:', q2);
    console.log('RESULT 2:', res2.rows[0].postgis_full_version, '\n');

    // 3. Canonical grids count, validity, SRID, geom type
    const q3 = `
      SELECT 
        COUNT(*) as total_cells,
        COUNT(*) FILTER (WHERE ST_IsValid(geom)) as valid_geometries,
        COUNT(*) FILTER (WHERE NOT ST_IsValid(geom)) as invalid_geometries,
        ST_SRID(geom) as srid,
        GeometryType(geom) as geom_type
      FROM canonical_grids
      GROUP BY ST_SRID(geom), GeometryType(geom);
    `;
    const res3 = await client.query(q3);
    console.log('QUERY 3:', q3.trim());
    console.log('RESULT 3:', res3.rows[0], '\n');

    // 4. Geographic Bounds & Centroid Range
    const q4 = `
      SELECT 
        MIN(center_lon) as min_center_lon,
        MAX(center_lon) as max_center_lon,
        MIN(center_lat) as min_center_lat,
        MAX(center_lat) as max_center_lat,
        ST_XMin(ST_Extent(geom)) as bbox_min_lon,
        ST_YMin(ST_Extent(geom)) as bbox_min_lat,
        ST_XMax(ST_Extent(geom)) as bbox_max_lon,
        ST_YMax(ST_Extent(geom)) as bbox_max_lat
      FROM canonical_grids;
    `;
    const res4 = await client.query(q4);
    console.log('QUERY 4:', q4.trim());
    console.log('RESULT 4:', res4.rows[0], '\n');

    // 5. Grid Resolution Verification (Delta Lon & Delta Lat)
    const q5 = `
      WITH cell_steps AS (
        SELECT 
          cell_id,
          center_lon,
          center_lat,
          ROUND((center_lon - LAG(center_lon) OVER (PARTITION BY center_lat ORDER BY center_lon))::numeric, 4) as lon_step,
          ROUND((center_lat - LAG(center_lat) OVER (PARTITION BY center_lon ORDER BY center_lat))::numeric, 4) as lat_step
        FROM canonical_grids
      )
      SELECT 
        MODE() WITHIN GROUP (ORDER BY lon_step) as modal_lon_step,
        MODE() WITHIN GROUP (ORDER BY lat_step) as modal_lat_step,
        MIN(lon_step) FILTER (WHERE lon_step > 0) as min_positive_lon_step,
        MAX(lon_step) as max_lon_step,
        MIN(lat_step) FILTER (WHERE lat_step > 0) as min_positive_lat_step,
        MAX(lat_step) as max_lat_step
      FROM cell_steps;
    `;
    const res5 = await client.query(q5);
    console.log('QUERY 5:', q5.trim());
    console.log('RESULT 5:', res5.rows[0], '\n');

    // 6. Spatial Indexes Verification
    const q6 = `
      SELECT 
        tablename,
        indexname,
        indexdef
      FROM pg_indexes 
      WHERE tablename IN ('canonical_grids', 'daily_predictions', 'grid_monthly_predictions')
      ORDER BY tablename, indexname;
    `;
    const res6 = await client.query(q6);
    console.log('QUERY 6:', q6.trim());
    console.log('RESULT 6 (Indexes):');
    res6.rows.forEach(r => console.log(` [${r.tablename}] ${r.indexname} -> ${r.indexdef}`));
    console.log('\n');

    // 7. Table counts & Historical ranges
    const q7 = `
      SELECT 'canonical_grids' as table_name, COUNT(*)::text as row_count, '8129 sel WPP 573' as notes FROM canonical_grids
      UNION ALL
      SELECT 'daily_predictions', COUNT(*)::text, 'Terkini: ' || MAX(prediction_date)::text FROM daily_predictions
      UNION ALL
      SELECT 'grid_monthly_predictions', COUNT(*)::text, 'Periode: ' || MIN(year_month) || ' s.d. ' || MAX(year_month) FROM grid_monthly_predictions
      UNION ALL
      SELECT 'prigi_port_landings', COUNT(*)::text, 'Periode: ' || MIN(year_month) || ' s.d. ' || MAX(year_month) || ' (' || COUNT(*) || ' bulan)' FROM prigi_port_landings
      UNION ALL
      SELECT 'prigi_fleet_by_gt', COUNT(*)::text, 'Total Kapal: ' || SUM(vessel_count) FROM prigi_fleet_by_gt;
    `;
    const res7 = await client.query(q7);
    console.log('QUERY 7:', q7.trim());
    console.log('RESULT 7:');
    console.table(res7.rows);

  } catch (err) {
    console.error('Error running forensic queries:', err);
  } finally {
    client.release();
    await pool.end();
  }
}

runQueries();

