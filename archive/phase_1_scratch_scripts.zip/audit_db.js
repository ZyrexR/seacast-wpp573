const path = require('path');
const { Pool } = require(path.resolve(__dirname, '../web/node_modules/pg'));

const pool = new Pool({
  connectionString: 'postgresql://postgres:postgres@localhost:5432/seacast_prigi',
});

async function auditDB() {
  const client = await pool.connect();
  try {
    console.log('=== DATABASE & POSTGIS AUDIT ===');
    
    // 1. Version
    const verRes = await client.query('SELECT version();');
    console.log('PostgreSQL Version:', verRes.rows[0].version);
    
    const postgisRes = await client.query('SELECT PostGIS_Full_Version();');
    console.log('PostGIS Version:', postgisRes.rows[0].postgis_full_version);

    // 2. Tables & Row counts
    const tables = ['canonical_grids', 'daily_predictions', 'grid_monthly_predictions', 'prigi_port_landings', 'prigi_fleet_by_gt'];
    console.log('\n=== TABLE ROW COUNTS ===');
    for (const t of tables) {
      const c = await client.query(`SELECT COUNT(*) FROM ${t}`);
      console.log(` - ${t}: ${c.rows[0].count} rows`);
    }

    // 3. Canonical grids extent & resolution
    console.log('\n=== CANONICAL GRIDS AUDIT ===');
    const extentRes = await client.query(`
      SELECT 
        MIN(center_lon) as min_lon, MAX(center_lon) as max_lon,
        MIN(center_lat) as min_lat, MAX(center_lat) as max_lat,
        ST_SRID(geom) as srid,
        GeometryType(geom) as geom_type,
        COUNT(*) FILTER (WHERE ST_IsValid(geom)) as valid_geoms
      FROM canonical_grids
      GROUP BY ST_SRID(geom), GeometryType(geom);
    `);
    console.log(extentRes.rows[0]);

    // Grid step calculation
    const stepRes = await client.query(`
      SELECT 
        ROUND((center_lon - LAG(center_lon) OVER (ORDER BY center_lat, center_lon))::numeric, 4) as lon_step,
        ROUND((center_lat - LAG(center_lat) OVER (ORDER BY center_lon, center_lat))::numeric, 4) as lat_step
      FROM canonical_grids
      LIMIT 10;
    `);
    console.log('Sample grid steps:', stepRes.rows.filter(r => r.lon_step > 0 || r.lat_step > 0).slice(0, 3));

    // Sector breakdown
    const sectorRes = await client.query(`SELECT sector, COUNT(*) FROM canonical_grids GROUP BY sector;`);
    console.log('Sectors:', sectorRes.rows);

    // 4. Daily predictions dates
    console.log('\n=== DAILY PREDICTIONS AUDIT ===');
    const datesRes = await client.query(`SELECT prediction_date, COUNT(*) FROM daily_predictions GROUP BY prediction_date ORDER BY prediction_date;`);
    console.log('Dates in daily_predictions:', datesRes.rows);

    // Sample daily prediction summary
    const samplePred = await client.query(`
      SELECT 
        AVG(sst_c) as avg_sst, AVG(chla_mg_m3) as avg_chla, AVG(wave_height_m) as avg_wave,
        COUNT(*) FILTER (WHERE is_hotspot = true) as hotspots,
        dom_zone, COUNT(*) as count_zone
      FROM daily_predictions
      GROUP BY dom_zone;
    `);
    console.log('Daily predictions by DOM zone:', samplePred.rows);

    // 5. Grid monthly predictions dates
    console.log('\n=== MONTHLY PREDICTIONS AUDIT ===');
    const ymRes = await client.query(`SELECT year, COUNT(DISTINCT year_month) as months, COUNT(*) as total_rows FROM grid_monthly_predictions GROUP BY year ORDER BY year;`);
    console.log('Monthly predictions by year:', ymRes.rows);

    // 6. Landings range
    console.log('\n=== PRIGI PORT LANDINGS AUDIT ===');
    const landRes = await client.query(`
      SELECT 
        MIN(year_month) as min_ym, MAX(year_month) as max_ym,
        COUNT(*) as total_months,
        SUM(total_pelagic_tons) as total_tons,
        AVG(cpue_proxy) as avg_cpue
      FROM prigi_port_landings;
    `);
    console.log(landRes.rows[0]);

    // 7. Fleet by GT
    console.log('\n=== FLEET BY GT AUDIT ===');
    const fleetRes = await client.query(`SELECT * FROM prigi_fleet_by_gt ORDER BY year, gt_class;`);
    console.log(fleetRes.rows);

  } catch (err) {
    console.error('Audit Error:', err);
  } finally {
    client.release();
    await pool.end();
  }
}

auditDB();
