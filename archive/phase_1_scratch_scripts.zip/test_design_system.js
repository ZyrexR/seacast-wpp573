const http = require('http');

http.get('http://localhost:3000/design-system', (res) => {
  let data = '';
  res.on('data', chunk => data += chunk);
  res.on('end', () => {
    console.log('HTTP Status:', res.statusCode);
    console.log('Contains Theme Toggle:', data.includes('Mode:'));
    console.log('Contains Tab 1 (Brand & Tokens):', data.includes('1. Brand & Tokens'));
    console.log('Contains Tab 2 (Tipografi):', data.includes('2. Tipografi & Skala'));
    console.log('Contains Tab 3 (Komponen UI):', data.includes('3. Komponen UI'));
    console.log('Contains Tab 4 (Tabel & Data):', data.includes('4. Tabel & Data'));
    console.log('Contains Tab 5 (Standar Saintifik):', data.includes('5. Standar Saintifik'));
    console.log('Contains Interactive Modal Button:', data.includes('Uji Buka Modal Detail Sel'));
    console.log('Contains Interactive Tooltip trigger:', data.includes('Arahkan Kursor ke Sini'));
    console.log('React 19 script bundle included:', data.includes('/_next/static/chunks/'));
    console.log('HTML size:', data.length, 'bytes');
  });
}).on('error', err => console.error(err));

