const fs = require('fs');
const path = require('path');

const srcDir = path.resolve(__dirname, '../web/src');

function getAllFiles(dir, exts = ['.ts', '.tsx']) {
  let files = [];
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      files = files.concat(getAllFiles(fullPath, exts));
    } else if (exts.includes(path.extname(entry.name))) {
      files.push(fullPath);
    }
  }
  return files;
}

const files = getAllFiles(srcDir);
let totalReplacements = 0;
const modifiedFiles = [];

files.forEach(file => {
  let content = fs.readFileSync(file, 'utf8');
  let countInFile = 0;

  // Regex to match text-[9px], text-[10px], text-[11px], text-[8px]
  const pattern = /text-\[(8|9|10|11)px\]/g;
  
  if (pattern.test(content)) {
    content = content.replace(pattern, (match) => {
      countInFile++;
      totalReplacements++;
      return 'text-xs';
    });
    fs.writeFileSync(file, content, 'utf8');
    modifiedFiles.push({ file: path.relative(path.resolve(__dirname, '..'), file), count: countInFile });
  }
});

console.log(`Total replacements: ${totalReplacements}`);
console.log(`Modified files (${modifiedFiles.length}):`);
modifiedFiles.forEach(m => console.log(` - ${m.file} (${m.count} replacements)`));

