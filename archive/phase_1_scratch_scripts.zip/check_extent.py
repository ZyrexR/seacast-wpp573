import json

with open('data/geojson/canonical_grid_8129_cells.geojson', 'r') as f:
    gj = json.load(f)

lons = [feat['geometry']['coordinates'][0][0][0] for feat in gj['features']]
lats = [feat['geometry']['coordinates'][0][0][1] for feat in gj['features']]
dists = [feat['properties']['dist_nm'] for feat in gj['features']]

print(f"Longitude range: {min(lons):.2f} E to {max(lons):.2f} E")
print(f"Latitude range : {min(lats):.2f} S to {max(lats):.2f} S")
print(f"Distance to Prigi: {min(dists):.1f} NM to {max(dists):.1f} NM ({min(dists)*1.852:.1f} km to {max(dists)*1.852:.1f} km)")
print(f"Total cells: {len(gj['features'])}")

