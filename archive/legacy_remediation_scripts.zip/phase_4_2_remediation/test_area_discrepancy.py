import json
import pyproj
import pandas as pd
import shapely
from shapely.geometry import shape, box
from shapely.ops import transform

transformer_to_ease = pyproj.Transformer.from_crs('EPSG:4326', 'EPSG:6933', always_xy=True).transform

with open('data/aoi/processed/AOI_WPP573_MASTER.geojson') as f:
    gj = json.load(f)

geom_wgs = shape(gj['features'][0]['geometry'])
geom_ease = transform(transformer_to_ease, geom_wgs)
total_master = geom_ease.area / 1e6
print(f"Master AOI exact area: {total_master:.6f} km^2")

df = pd.read_csv('data/qa/phase_1_1/grid/GRID_010_REGIONAL_CELLS_QA.csv')
sum_csv = df['aoi_intersection_area_km2'].sum()
print(f"CSV sum aoi_intersection: {sum_csv:.6f} km^2")
print(f"Discrepancy: {total_master - sum_csv:.6f} km^2")

# Check boundary cells
boundary_cells = df[df['cell_classification'] != 'PURE_OCEAN'].head(10)
for _, r in boundary_cells.iterrows():
    cid = r['cell_id']
    lon = r['lon_center']
    lat = r['lat_center']
    c_wgs = box(lon - 0.05, lat - 0.05, lon + 0.05, lat + 0.05)
    c_ease = transform(transformer_to_ease, c_wgs)
    
    inter = c_ease.intersection(geom_ease)
    inter_km2 = inter.area / 1e6
    csv_val = r['aoi_intersection_area_km2']
    diff = inter_km2 - csv_val
    c_class = r['cell_classification']
    print(f"{cid} ({c_class}): CSV={csv_val:.4f}, Exact={inter_km2:.4f}, Diff={diff:.4f}")

