import json
import pyproj
import numpy as np
import shapely
from shapely.geometry import shape, box
from shapely.ops import transform

transformer_to_ease = pyproj.Transformer.from_crs('EPSG:4326', 'EPSG:6933', always_xy=True).transform

with open('data/aoi/processed/AOI_WPP573_MASTER.geojson') as f:
    gj = json.load(f)

geom_wgs = shape(gj['features'][0]['geometry'])
geom_ease = transform(transformer_to_ease, geom_wgs)
total_master = geom_ease.area / 1e6
print(f"Master AOI exact EPSG:6933 area: {total_master:.4f} km^2")

# Grid definition from run_grid_reproduction_audit.py
xmin, ymin, xmax, ymax = 102.5, -14.0, 126.5, -6.80
res_deg = 0.10
cols = int(round((xmax - xmin) / res_deg))
rows = int(round((ymax - ymin) / res_deg))

xs = np.linspace(xmin, xmax, cols + 1)
ys = np.linspace(ymin, ymax, rows + 1)

total_intersect_all = 0.0
outside_cells_with_area = []

prep_master = shapely.prepared.prep(geom_ease)

for r in range(rows):
    lat_min, lat_max = ys[r], ys[r+1]
    for c in range(cols):
        lon_min, lon_max = xs[c], xs[c+1]
        c_wgs = box(lon_min, lat_min, lon_max, lat_max)
        c_ease = transform(transformer_to_ease, c_wgs)
        
        if prep_master.intersects(c_ease):
            # Calculate intersection
            inter = c_ease.intersection(geom_ease)
            total_intersect_all += inter.area / 1e6
        else:
            # Check if actual intersection is not empty
            inter = c_ease.intersection(geom_ease)
            if not inter.is_empty and inter.area > 0:
                outside_cells_with_area.append((r, c, inter.area / 1e6))

print(f"Total intersection area across all intersecting cells: {total_intersect_all:.4f} km^2")
print(f"Difference from master AOI: {total_master - total_intersect_all:.4f} km^2")
print(f"Cells where prep_master said FALSE but area > 0: {len(outside_cells_with_area)}")

