import os
import csv
from collections import Counter
import json

MONTHS = [f"2015_{m:02d}" for m in range(1, 13)]
BASE_DIR = "data/oceanographic/monthly_csv"

results = []

for m_str in MONTHS:
    filename = f"SEACAST_PRIGI_GRID_8129_{m_str}.csv"
    filepath = os.path.join(BASE_DIR, filename)
    if not os.path.exists(filepath):
        results.append({"month": m_str, "status": "MISSING"})
        continue
    
    with open(filepath, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        rows = list(reader)
    
    row_count = len(rows)
    cell_ids = [r["cell_id"] for r in rows]
    unique_ids = len(set(cell_ids))
    cell_classes = Counter(r["cell_class"] for r in rows)
    
    # Stats extractor
    def get_stats(col):
        vals = []
        nulls = 0
        for r in rows:
            v = r.get(col, "")
            if v == "" or v is None or v == "null":
                nulls += 1
            else:
                try:
                    vals.append(float(v))
                except:
                    nulls += 1
        if not vals:
            return {"count": 0, "nulls": nulls, "min": None, "mean": None, "max": None}
        return {
            "count": len(vals),
            "nulls": nulls,
            "min": round(min(vals), 4),
            "mean": round(sum(vals) / len(vals), 4),
            "max": round(max(vals), 4)
        }
    
    sst = get_stats("sst_mean_c_mean")
    grad = get_stats("sst_gradient_deg_km_mean")
    front = get_stats("thermal_front_flag_mean")
    chla = get_stats("chla_mg_m3_mean")
    chla_modis = get_stats("chla_modis_flag_mean")
    curr = get_stats("current_speed_m_s_mean")
    wind = get_stats("wind_speed_mean_m_s_mean")
    stress = get_stats("wind_stress_tau_mag_mean")
    ekman = get_stats("ekman_w_e_m_s")
    depth = get_stats("depth_m_mean")
    precip = get_stats("precip_mm_day_mean")
    
    results.append({
        "month": m_str,
        "status": "OK",
        "rows": row_count,
        "unique_ids": unique_ids,
        "classes": dict(cell_classes),
        "sst": sst,
        "grad": grad,
        "front": front,
        "chla": chla,
        "chla_modis": chla_modis,
        "curr": curr,
        "wind": wind,
        "stress": stress,
        "ekman": ekman,
        "depth": depth,
        "precip": precip
    })

print(json.dumps(results, indent=2))

