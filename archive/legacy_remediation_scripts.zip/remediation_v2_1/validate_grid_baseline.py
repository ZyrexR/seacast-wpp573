# -*- coding: utf-8 -*-
"""
Validation Script: Canonical Grid Baseline & Master AOI Integrity (v2.1)
"""

import os
import sys
import json
import hashlib
import pyproj
import pandas as pd
from shapely.geometry import shape

WORKSPACE = r"C:\Users\ThinkPad\.gemini\antigravity\scratch\prigi-pelagis"
MASTER_AOI_PATH = os.path.join(WORKSPACE, "data", "aoi", "processed", "AOI_WPP573_MASTER.geojson")
GRID_CSV_PATH = os.path.join(WORKSPACE, "data", "qa", "phase_1_1", "grid", "GRID_010_REGIONAL_CELLS_QA.csv")
OUT_DIR = os.path.join(WORKSPACE, "reports", "phase_4_2_v2_1_remediation")
os.makedirs(OUT_DIR, exist_ok=True)

def validate_grid():
    print("=" * 80)
    print("VALIDATION: CANONICAL GRID BASELINE & MASTER AOI INTEGRITY (v2.1)")
    print("=" * 80)

    # 1. Validate Master AOI
    with open(MASTER_AOI_PATH, "r", encoding="utf-8") as f:
        master_gj = json.load(f)

    master_feat = master_gj["features"][0]
    geom_wgs = shape(master_feat["geometry"])
    
    # Calculate area in EPSG:6933
    transformer = pyproj.Transformer.from_crs("EPSG:4326", "EPSG:6933", always_xy=True).transform
    from shapely.ops import transform
    geom_ease = transform(transformer, geom_wgs)
    area_km2 = geom_ease.area / 1e6
    
    # Holes count
    n_holes = len(geom_wgs.interiors) if hasattr(geom_wgs, "interiors") else sum(len(p.interiors) for p in geom_wgs.geoms)

    print(f"[Master AOI] Geometry Type: {geom_wgs.geom_type}")
    print(f"[Master AOI] Interior Island Holes: {n_holes}")
    print(f"[Master AOI] Area EPSG:6933: {area_km2:.2f} km² (Reference: 933,749.49 km²)")
    assert abs(area_km2 - 933749.49) < 0.1, f"AOI area discrepancy: {area_km2}"
    assert n_holes == 1400, f"Holes count discrepancy: {n_holes}"

    # 2. Validate Canonical Grid
    df_grid = pd.read_csv(GRID_CSV_PATH)
    n_cells = len(df_grid)
    unique_ids = df_grid["cell_id"].nunique()
    pure_ocean = (df_grid["cell_classification"] == "PURE_OCEAN").sum()
    coastal = (df_grid["cell_classification"] == "COASTAL_BOUNDARY").sum()
    outer_aoi = (df_grid["cell_classification"] == "OUTER_AOI_BOUNDARY").sum()

    print(f"\n[Canonical Grid] File: {GRID_CSV_PATH}")
    print(f"[Canonical Grid] Total Rows: {n_cells}")
    print(f"[Canonical Grid] Unique Cell IDs: {unique_ids}")
    print(f"[Canonical Grid] Pure Ocean Cells: {pure_ocean}")
    print(f"[Canonical Grid] Coastal Boundary Cells: {coastal}")
    print(f"[Canonical Grid] Outer AOI Boundary Cells: {outer_aoi}")

    assert n_cells == 8129, f"Cell count error: {n_cells}"
    assert unique_ids == 8129, f"Duplicate cell IDs: {unique_ids}"
    assert pure_ocean == 7166, f"Pure ocean error: {pure_ocean}"
    assert coastal == 501, f"Coastal boundary error: {coastal}"
    assert outer_aoi == 462, f"Outer boundary error: {outer_aoi}"

    # 3. Candidate Bounding Box Relation
    candidate_bbox = 17280
    outside_cells = candidate_bbox - n_cells
    assert outside_cells == 9151, f"Outside cell calculation error: {outside_cells}"
    print(f"\n[Matrix Relation] Candidate BBox (240x72): {candidate_bbox} = Active ({n_cells}) + Outside ({outside_cells})")
    print("[Verification] 17,280 is strictly pre-clipping candidate matrix; 8,129 is canonical active grid.")
    print("\nSTATUS: PASS — CANONICAL GRID AND MASTER AOI 100% VERIFIED")

if __name__ == "__main__":
    validate_grid()

