# -*- coding: utf-8 -*-
"""
Generate SHA256 manifest for Phase 4.2 v2.1 remediation deliverables
"""

import os
import hashlib

WORKSPACE = r"C:\Users\ThinkPad\.gemini\antigravity\scratch\prigi-pelagis"
REPORT_DIR = os.path.join(WORKSPACE, "reports", "phase_4_2_v2_1_remediation")
SCRIPT_PATH = os.path.join(WORKSPACE, "gee", "SEACAST_PRIGI_GEE_PRODUCTION_2015_2025_v2_1.js")
MANIFEST_PATH = os.path.join(REPORT_DIR, "SHA256_MANIFEST.txt")

def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while chunk := f.read(65536):
            h.update(chunk)
    return h.hexdigest()

def main():
    files = []
    
    # Target GEE script
    rel_script = os.path.relpath(SCRIPT_PATH, WORKSPACE).replace("\\", "/")
    files.append((rel_script, sha256_file(SCRIPT_PATH)))
    
    # Reports
    report_files = sorted(os.listdir(REPORT_DIR))
    for fname in report_files:
        if fname == "SHA256_MANIFEST.txt":
            continue
        full_path = os.path.join(REPORT_DIR, fname)
        if os.path.isfile(full_path):
            rel_path = os.path.relpath(full_path, WORKSPACE).replace("\\", "/")
            files.append((rel_path, sha256_file(full_path)))
            
    with open(MANIFEST_PATH, "w", encoding="utf-8") as f:
        f.write("# SEACAST PRIGI - PHASE 4.2 v2.1 REMEDIATION SHA256 MANIFEST\n")
        f.write("# Generated: 2026-11-02\n")
        f.write("# Classification: REMEDIATED_DEVELOPMENT_CANDIDATE\n\n")
        for rel_path, h in files:
            f.write(f"{h}  {rel_path}\n")
            
    print(f"[Manifest Generated] {MANIFEST_PATH}")
    for rel_path, h in files:
        print(f"  {h}  {rel_path}")

if __name__ == "__main__":
    main()

