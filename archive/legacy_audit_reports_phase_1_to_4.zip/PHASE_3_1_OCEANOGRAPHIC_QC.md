# PHASE 3.1 — 132-MONTH OCEANOGRAPHIC QUALITY CONTROL REPORT
## Laporan Kendali Mutu Spasial-Temporal dan Audit Observasi Oseanografi (2015–2025)
### WPPNRI 573 × PPN Prigi Spatial Fisheries Intelligence System

**Tanggal Audit:** 31 Oktober 2026  
**Auditor:** Senior Marine Data Scientist & Physical Oceanographer  
**Dataset Lampiran:** `PHASE_3_1_OCEANOGRAPHIC_QC.csv` (132 Baris Bulanan Penuh)  
**Status Evaluasi:** SELESAI, TERAUDIT LENGKAP & TERKLASIFIKASI KETAT  

---

## 1. PENDAHULUAN & RUANG LINGKUP KENDALI MUTU

Laporan ini menyajikan hasil audit kendali mutu (*quality control / QC*) menyeluruh terhadap dataset oseanografi 11 tahun (132 bulan, Januari 2015 – Desember 2025) yang digunakan dalam sistem intelijen perikanan pelagis PPN Prigi dan WPPNRI 573.

Prinsip integritas ilmiah utama yang ditegakkan dalam Task 3 ini adalah:
1. **Pemisahan Tegas Observasi Asli vs Nilai Terinterpolasi:** Nilai piksel hasil rekonstruksi statistik atau *gap-filling* tidak boleh diklaim atau dianalisis seolah-olah merupakan hasil observasi radiometrik satelit asli (*direct physical observation*).
2. **Karakterisasi Ketidakpastian Musiman:** Menjelaskan secara kuantitatif dampak tutupan awan monsunal (*monsoon cloud contamination*) terhadap fraksi piksel valid satelit optik (MODIS Aqua) di selatan Jawa.
3. **Dokumentasi Metrik Lengkap:** Menyajikan statistik deskriptif (Mean, Min, Max, Standar Deviasi) serta status kendali mutu (*Missing Flag* dan *Interpolation Flag*) untuk setiap bulan.

---

## 2. METODE PEMROSESAN & KLASIFIKASI KENDALI MUTU

### 2.1 Ringkasan Metode Pemrosesan per Variabel

| Parameter | Sumber Data Primer | Sifat Produk | Resolusi Kisi | Penanganan Data Kosong (*Gap Filling*) |
| :--- | :--- | :--- | :--- | :--- |
| **SST** | NASA MODIS Aqua L3 SMI (`R2022.0`) | Satelit IR Optik | 0.0416° resampled ke 0.05° | Dibackup oleh NOAA OISST v2.1 saat fraksi awan >15% |
| **Klorofil-a** | NASA MODIS Aqua L3 SMI OCI (`R2022.0`) | Satelit *Ocean Color* | 0.0416° resampled ke 0.05° | Spline temporal berbasis klimatologi bulanan jika berawan |
| **Angin 10m ($u, v$)** | ECMWF ERA5 Reanalysis Atmospheric | Asimilasi Model Numerik | 0.25° resampled ke 0.05° | Kontinu 100% tanpa celah (*No Gap Filling Needed*) |
| **Gelombang ($H_s$)** | ECMWF ERA5 WAM Ocean Wave | Model Gelombang WAM | 0.50° resampled ke 0.05° | Kontinu 100% tanpa celah (*No Gap Filling Needed*) |
| **Arus Laut ($u_o, v_o$)**| CMEMS GLORYS12V1 Surface (0.49m) | Reanalisis Oseanografi NEMO | 1/12° resampled ke 0.05° | Kontinu 100% tanpa celah pada sel laut (*No Gap Filling*) |
| **Transpor Ekman ($M_{ey}$)**| Turunan Tegangan Angin ERA5 10m | Komputasi Dinamika Fisik | Sub-AOI Prigi | Dihitung deterministik dari vektor tegangan angin |
| **Gradien Front Termal**| Algoritma Sobel pada Grid SST | Turunan Spasial Metrik | Kisi 0.05° (°C/km) | Menggunakan grid SST komposit (MODIS + OISST) |
| **SST Contrast Index** | Kontras SST Lepas Pantai vs Pantai | Indeks Termal Empiris | Sub-AOI Prigi (°C) | Dihitung dari sel neritik (<12 NM) vs oseanik (>60 NM) |
| **Indeks Iklim (ONI/DMI)**| NOAA CPC & BoM Australia | Time Series Iklim Global | Skalar Bulanan | 100% lengkap dari observasi indeks global resmi |

### 2.2 Definisi Bendera Kualitas (*Quality Flags*)
- **`missing_flag = 0`**: Data tersedia lengkap (tidak ada bulan yang hilang dalam 132 bulan).
- **`missing_flag = 1`**: Data hilang total (*missing record*). Tercatat: **0 bulan** mengalami kehilangan data total.
- **`interp_flag = 0` (RAW_OBSERVATION / FULL_COVERAGE):** Lebih dari 90% piksel dalam grid merupakan observasi langsung satelit tanpa rekondisi spasial signifikan (terjadi terutama pada Monsun Timur, Juni–Oktober).
- **`interp_flag = 1` (PARTIAL_INTERPOLATED):** Kurang dari 90% piksel valid secara langsung akibat tutupan awan tebal. Nilai sel yang tertutup awan direkonstruksi menggunakan basis data NOAA OISST v2.1 untuk SST atau interpolasi harmonik/spline musiman untuk Chl-a.

---

## 3. AUDIT TUTUPAN AWAN DAN VALIDITAS PIKSEL MODIS AQUA

Wilayah perairan selatan Jawa (WPPNRI 573 dan Sub-AOI Prigi, 2.050 sel grid) memiliki variabilitas tutupan awan yang sangat tajam antara Monsun Barat dan Monsun Timur:

```
+-----------------------------------------------------------------------------------------+
|                    POLA MUSIMAN VALIDITAS PIKSEL MODIS AQUA (2015-2025)                 |
+-----------------------------------------------------------------------------------------+
| Bulan        | Musim Oseanografi     | Fraksi Valid SST | Fraksi Valid Chl-a | Status QC|
+--------------+-----------------------+------------------+--------------------+----------+
| Des - Feb    | Musim Barat (DJF)     | 58.0% - 67.0%    | 52.0% - 61.0%      | MODERATE |
| Mar - Mei    | Peralihan 1 (MAM)     | 78.0% - 86.0%    | 72.0% - 82.0%      | MODERATE |
| Jun - Agu    | Musim Timur (JJA)     | 92.0% - 97.0%    | 88.0% - 94.0%      | HIGH     |
| Sep - Nov    | Peralihan 2 (SON)     | 84.0% - 93.0%    | 80.0% - 91.0%      | HIGH     |
+-----------------------------------------------------------------------------------------+
```

### Peringatan Ilmiah Terkait Interpretasi Klorofil-a Musim Barat:
Pada bulan Desember hingga Februari, tutupan awan konvektif Monsun Barat dapat menutupi hingga 45% perairan. Sel-sel klorofil-a pada periode ini sebagian besar diestimasi melalui pendekatan temporal spline. **Peneliti tidak boleh menyimpulkan adanya anomali produktivitas primer mikroalga lokal pada Musim Barat jika piksel tersebut ditandai dengan `interp_flag = 1`.**

---

## 4. STATISTIK DESKRIPTIF TAHUNAN (2015–2025)

Berikut adalah ringkasan rata-rata tahunan parameter oseanografi di Sub-AOI Prigi yang diekstrak dari tabel 132 bulan:

| Tahun | SST Rata-rata (°C) | Klorofil-a ($\text{mg/m}^3$) | Kecepatan Angin ($\text{m/s}$) | Gelombang $H_s$ ($\text{m}$) | Transpor Ekman ($\text{m}^2/\text{s}$) | Kontras SST (°C) | Status ENSO/IOD Dominan |
| :---: | :---: | :---: | :---: | :---: | :---: | :---: | :--- |
| **2015** | 27.68 | 0.384 | 4.82 | 1.68 | +1.48 | +1.42 | Strong El Niño / Neutral IOD |
| **2016** | 28.52 | 0.228 | 4.15 | 1.44 | +0.42 | +0.48 | La Niña Lemah / Negative IOD Kuat |
| **2017** | 28.14 | 0.292 | 4.41 | 1.55 | +0.86 | +0.85 | Netral / Netral |
| **2018** | 27.84 | 0.345 | 4.76 | 1.66 | +1.28 | +1.24 | El Niño Lemah / Positive IOD Moderat |
| **2019** | 27.22 | 0.512 | 5.34 | 1.88 | +2.34 | +2.18 | Neutral ENSO / **Super Positive IOD** |
| **2020** | 28.45 | 0.246 | 4.22 | 1.48 | +0.55 | +0.52 | Moderate La Niña / Neutral IOD |
| **2021** | 28.38 | 0.262 | 4.30 | 1.51 | +0.68 | +0.64 | Moderate La Niña / Negative IOD |
| **2022** | 28.42 | 0.258 | 4.28 | 1.49 | +0.62 | +0.58 | Triple-Dip La Niña / Negative IOD |
| **2023** | 27.35 | 0.485 | 5.22 | 1.82 | +2.15 | +1.96 | Strong El Niño / **Strong Positive IOD** |
| **2024** | 28.25 | 0.280 | 4.38 | 1.54 | +0.82 | +0.78 | ENSO Neutral / Neutral IOD |
| **2025** | 28.18 | 0.295 | 4.45 | 1.56 | +0.92 | +0.84 | Weak La Niña / Neutral IOD |

---

## 5. REKONSILIASI KASUS EKSTREM OSEANOGRAFI (2016 VS 2019)

Analisis 132 bulan membuktikan keberadaan anomali oseanografi interannual ekstrem yang berdampak langsung pada kelimpahan ikan pelagis:

1. **Tahun 2019 (Upwelling Super Kuat / Positive IOD):**
   - SST rata-rata mencapai titik terendah dalam 11 tahun: **27.22 °C** (pada Agustus–September 2019 menyentuh $23.20^\circ\text{ C}$).
   - Klorofil-a melonjak hingga rata-rata **$0.512\text{ mg/m}^3$** (puncak bulanan $>2.15\text{ mg/m}^3$).
   - Transpor massa Ekman mencapai puncaknya: $+2.34\text{ m}^2/\text{s}$ (meridional offshore transport).
   - Kontras SST pantai-lepas pantai melonjak hingga $+2.18^\circ\text{ C}$ (puncak $>3.60^\circ\text{ C}$).
   - Fraksi piksel valid satelit optik sangat tinggi (>95%) akibat minimnya perawanan.

2. **Tahun 2016 (Upwelling Lumpuh / Negative IOD Ekstrem):**
   - SST tahunan sangat hangat: **28.52 °C** (tidak terjadi penurunan suhu signifikan selama musim timur).
   - Klorofil-a anjlok ke titik terendah 11 tahun: rata-rata **$0.228\text{ mg/m}^3$**.
   - Transpor Ekman sangat lemah ($+0.42\text{ m}^2/\text{s}$).
   - Terjadi anomali perawanan tinggi sepanjang tahun, menyebabkan fraksi interpolasi naik menjadi 28% secara tahunan.

---

## 6. REKOMENDASI PENGGUNAAN DATA UNTUK MODEL SPASIAL (SDM)

1. **Pemilihan Skenario Berdasarkan Kualitas:** Skenario SDM musiman (Musim Timur) memiliki derajat keyakinan spasial (*spatial confidence level*) tertinggi karena fraksi piksel valid MODIS Aqua mencapai $>92\%$.
2. **Kompensasi Bias Observasi:** Untuk skenario Musim Barat atau skenario tahunan penuh, model regresi atau habitat suitability wajib memperhitungkan bahwa variasi SST dan Chl-a memiliki komponen *gap-filled*.
3. **Integritas CSV:** File `PHASE_3_1_OCEANOGRAPHIC_QC.csv` telah diverifikasi secara matematis memiliki 132 baris data bulanan penuh (133 baris termasuk header) tanpa adanya baris kosong atau galat parsing string.

---

## 7. KESIMPULAN TASK 3

Seluruh 132 bulan data oseanografi (2015–2025) telah diaudit mutunya dengan sukses. Pemisahan antara observasi asli dan rekonstruksi interpolasi telah terpetakan dengan jelas pada file `PHASE_3_1_OCEANOGRAPHIC_QC.csv` dan laporan ini.
