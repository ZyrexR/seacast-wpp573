# PHASE 3.1 — SPECIES DISTRIBUTION MODELING (SDM) VALIDITY REVIEW
## Tinjauan Ilmiah Kritis terhadap Validitas Pemodelan Distribusi Spesies, Metrik Kinerja, dan Kalibrasi Probabilitas
### WPPNRI 573 × PPN Prigi Spatial Fisheries Intelligence System

**Tanggal Audit:** 31 Oktober 2026  
**Auditor:** Senior Fisheries Geospatial Analyst, Marine Ecological Modeler & Scientific Auditor  
**Status Evaluasi:** SELESAI & TEREVISI SECARA EPISTEMOLOGIS (100% REVIEWED)  
**Dokumen Induk:** Proyek Intelijen Geospasial Perikanan Pelagis PPN Prigi — WPPNRI 573  

---

## 1. PENDAHULUAN & RUANG LINGKUP EVALUASI

Tinjauan ini melakukan evaluasi menyeluruh terhadap arsitektur pemodelan distribusi spesies (*Species Distribution Modeling / SDM*) yang telah dibangun pada Phase 3, yang mencakup tiga model individual (**MaxEnt**, **Random Forest**, **GLM**) serta integrasi **AUC-weighted Ensemble** untuk tiga komoditas pelagis besar (Cakalang, Madidihang, Albakor).

Berdasarkan temuan audit eksternal independen, evaluasi ini bertujuan untuk:
1. Mengoreksi klaim metodologis berlebihan (*overclaiming*), khususnya anggapan bahwa *Target-Group Background (TGB)* dapat sepenuhnya melenyapkan *sampling bias*.
2. Membakukan interpretasi ilmiah model menjadi **Exploratory Proxy-Based Habitat Suitability Model**.
3. Membakukan indeks kesesuaian habitat (HSI) menjadi **Relative Habitat Suitability Index (RHSI)** karena tidak adanya data prevalensi empiris untuk kalibrasi probabilitas absolut.
4. Mendokumentasikan keterbatasan metrik diskriminasi (AUC dan TSS) tanpa mengubah nilai numerik yang telah dicapai.

---

## 2. AUDIT DEFINISI VARIABEL RESPON & KONSTRUKSI LATAR BELAKANG (TGB)

### 2.1 Definisi Variabel Respon ($Y$)
Model SDM Phase 3 memperlakukan variabel respon sebagai data biner pseudo-kehadiran ($Y \in \{0, 1\}$):
- **$Y = 1$ (Presensi Proxy):** Titik persimpangan heuristik antara toleransi lingkungan dan jangkauan armada penangkapan ($N_{\text{SKJ}} = 405$, $N_{\text{YFT}} = 387$, $N_{\text{ALB}} = 189$). Variabel ini **bukan observasi biologis kehadiran riil di alam**.
- **$Y = 0$ (Target-Group Background / TGB):** $1.000$ titik latar belakang yang ditarik dari kandidat $5.000$ titik berbobot pada *Effort Bias Surface*.

### 2.2 Dekonstruksi Target-Group Background (TGB) & Bias Surface
- **Hipotesis Phillips et al. (2009):** Metode TGB mengasumsikan bahwa jika titik latar belakang (*background*) disampel dengan pola bias spasial yang sama persis dengan bias upaya penangkapan nelayan (*fishing effort bias*), maka rasio peluang presensi terhadap latar belakang akan membatalkan efek bias aksesibilitas.
- **Koreksi Ilmiah:** **Klaim bahwa TGB sepenuhnya melenyapkan sampling bias adalah TIDAK BENAR.**
  1. *Effort Bias Surface* dibangun secara teoretis berdasarkan fungsi peluruhan jarak dermaga:
     $$B(d) = 0.85 e^{-0.04 d} \quad (d \le 12\text{ NM}), \quad 0.50 e^{-0.03 (d-12)} \quad (12 < d \le 60\text{ NM})$$
     Fungsi ini merupakan aproksimasi jarak geometris sederhana, bukan data densitas trip GPS observasi riil nelayan Prigi.
  2. Karena baik presensi proxy maupun titik latar belakang sama-sama dibatasi pada radius jangkauan kapal $\le 60\text{ NM}$, perairan oseanik lepas pantai ($>60\text{ NM}$) kurang terwakili (*undersampled*), sehingga bias spasial tetap eksis.

---

## 3. AUDIT FORMULASI MODEL & HIPERPARAMETER

Tabel berikut mendokumentasikan spesifikasi teknis dan parameter regulasi masing-masing algoritma:

| Algoritma | Tipe Pendekatan | Parameter Regulasi & Fitur | Kelemahan / Keterbatasan yang Ditemukan |
| :--- | :--- | :--- | :--- |
| **MaxEnt** | *Maximum Entropy (Presence-Background)* | Regulasi L1 lasso ($\beta = 1.0$), Linear + Quadratic features | Mengalami degradasi performa pada Albakor ($\text{AUC} = 0.507$) akibat sebaran titik dingin yang terfragmentasi. |
| **Random Forest** | *Non-parametric Machine Learning Ensemble* | 100 *decision trees*, $\text{max\_depth} = 8$, $\text{min\_samples\_split} = 5$, bootstrap | Rentan terhadap *overfitting* batas ambang heuristik, menghasilkan kurva batas yang sangat tajam (*step-wise*). |
| **GLM** | *Parametric Logistic Regression* | Logit link, suku polinomial orde 2 pada SST dan Klorofil | Kurang fleksibel memodelkan interaksi non-linear multi-faktor di zona upwelling yang dinamis. |
| **Ensemble** | *Consensus Multi-Model Model Averaging* | Bobot berbasis $(\text{AUC} - 0.5)^2$ dengan threshold $\text{AUC} > 0.60$ | Bobot MaxEnt pada Albakor dipaksa menjadi 0.000 karena performanya setara tebakan acak. |

---

## 4. AUDIT MULTIKOLINIERITAS & SPATIAL CROSS-VALIDATION

### 4.1 Pengendalian Multikolinieritas Prediktor (VIF)
- **Deteksi Korelasi:** Variabel SST dan SST Anomaly memiliki korelasi linier sangat tinggi ($r > 0.90$). Demikian pula Chl-a dan $\log_{10}(\text{Chl-}a)$ ($r = 0.94$).
- **Isolasi Prediktor:** Selama fitting model, variabel-variabel kolinier dipisahkan secara ketat. Prediktor simultan final dibatasi pada:
  $$\text{Model Inputs} = \{\text{SST}, \, \text{Chlorophyll-}a, \, \text{Thermal Front (Sobel)}, \, \text{Depth}, \, \text{Slope}\}$$
  Nilai Variance Inflation Factor (VIF) tertinggi pada set prediktor ini tercatat sebesar **$3.42$** (lolos batas kritis $\text{VIF} < 5.0$).

### 4.2 Keterbatasan Validasi Silang Spasial (*Spatial CV*)
- Sistem menerapkan 5-fold cross-validation. Namun, pembagian lipatan (*fold allocation*) dilakukan secara semi-acak terstratifikasi, bukan menggunakan metode *Spatial Block Buffering* (Roberts et al., 2017).
- **Risiko Spatial Autocorrelation:** Adanya ketergantungan spasial antar sel bertetangga berukuran 0.05° (~5.5 km) dapat menyebabkan informasi lingkungan dari data latih bocor ke data uji (*spatial data leakage*), yang berkontribusi menaikkan nilai metrik AUC secara semu.

---

## 5. AUDIT METRIK DISKRIMINASI: AUC, TSS & KALIBRASI PROBABILITAS

Berdasarkan arsip `models/sdm/ensemble/model_evaluations_summary.json`, nilai numerik metrik kinerja model dicatat secara resmi tanpa perubahan:

```
+-----------------------------------------------------------------------------------------+
|                  MATRIKS EVALUASI RESMI MODEL SDM PHASE 3                               |
+-----------------------------------------------------------------------------------------+
| Komoditas      | Model           | AUC   | TSS   | Ambang Optimal | Status Evaluasi     |
+----------------+-----------------+-------+-------+----------------+---------------------+
| Cakalang (SKJ) | MaxEnt          | 0.774 | 0.084 | 0.75           | Fair                |
|                | Random Forest   | 0.805 | 0.610 | 0.75           | Good                |
|                | GLM             | 0.750 | 0.473 | 0.70           | Fair                |
|                | **Ensemble**    | 0.795 | 0.630 | -              | **Moderately Good** |
+----------------+-----------------+-------+-------+----------------+---------------------+
| Madidihang(YFT)| MaxEnt          | 0.722 | 0.000 | 0.20           | Poor Discrimination |
|                | Random Forest   | 0.804 | 0.586 | 0.75           | Good                |
|                | GLM             | 0.755 | 0.422 | 0.70           | Fair                |
|                | **Ensemble**    | 0.784 | 0.606 | -              | **Moderately Good** |
+----------------+-----------------+-------+-------+----------------+---------------------+
| Albakor (ALB)  | MaxEnt          | 0.507 | 0.143 | 0.75           | Failed (Random)     |
|                | Random Forest   | 0.862 | 0.723 | 0.75           | Very Good           |
|                | GLM             | 0.825 | 0.000 | 0.20           | Good (TSS uncal.)   |
|                | **Ensemble**    | 0.860 | 0.743 | -              | **Good (RF+GLM)**   |
+----------------+-----------------+-------+-------+----------------+---------------------+
```

### 5.1 Koreksi Salah Label Evaluasi
- Dalam file JSON awal, Cakalang Ensemble ($\text{AUC} = 0.795$) dan Madidihang Ensemble ($\text{AUC} = 0.784$) diberi label string `"status": "HIGHLY_ACCURATE (AUC > 0.85)"`.
- **Koreksi Ilmiah:** Label tersebut merupakan galat teks tipografi. Nilai $0.784$ dan $0.795$ secara ilmiah berada pada kategori **"Moderately Accurate" ($0.70 \le \text{AUC} < 0.80$)**, sedangkan kategori "Highly Accurate" ($\text{AUC} \ge 0.85$) hanya dicapai oleh Albakor Ensemble ($0.860$) yang didorong oleh performa Random Forest.

### 5.2 Masalah Nilai TSS = 0.000 pada MaxEnt dan GLM
- Pada Madidihang MaxEnt ($\text{TSS} = 0.000$) dan Albakor GLM ($\text{TSS} = 0.000$), algoritma optimasi ambang batas (*threshold*) memilih nilai cutoff yang terlalu ekstrem ($0.20$), menyebabkan seluruh piksel diprediksi sebagai presensi (sensitivitas 1.0, spesifisitas 0.0), sehingga:
  $$\text{TSS} = \text{Sensitivitas} + \text{Spesifisitas} - 1 = 1.0 + 0.0 - 1 = 0.000$$
- Hal ini menunjukkan bahwa model-model tunggal tersebut gagal membedakan latar belakang dari presensi tanpa ambang batas yang disesuaikan secara manual.

---

## 6. PEMBAKUAN ISTILAH DAN INTERPRETASI MODEL

Sebagai tindak lanjut kepatuhan terhadap kaidah ekologi spasial:

### 6.1 Pembakuan Istilah Model
Model ini tidak boleh disebut sebagai "Model Prediksi Distribusi Spesies Terverifikasi". Istilah baku yang wajib digunakan adalah:

$$\mathbf{Exploratory\text{ }Proxy\text{-}Based\text{ }Habitat\text{ }Suitability\text{ }Model}$$

### 6.2 Pembakuan Istilah Luaran (HSI $\to$ RHSI)
Luaran model berskala $0.00\text{–}1.00$ tidak boleh diartikan sebagai probabilitas keterjadian absolut (*absolute probability of occurrence*). Istilah resmi luaran adalah:

$$\mathbf{Relative\text{ }Habitat\text{ }Suitability\text{ }Index\text{ }(RHSI)}$$

- Nilai RHSI merepresentasikan kesesuaian habitat relatif antar sel spasial dalam kondisi oseanografi tertentu, bukan peluang persentase seorang nelayan pasti menemukan ikan di titik koordinat tersebut.

---

## 7. KESIMPULAN TASK 6

Evaluasi validitas SDM telah menempatkan seluruh algoritma dan metrik performa pada koridor ilmiah yang benar. Keterbatasan TGB, sirkularitas heuristik, serta masalah kalibrasi probabilitas telah diakui secara transparan. Nilai numerik AUC ($0.784\text{–}0.860$) dan TSS dipertahankan tanpa manipulasi, namun interpretasinya telah dibakukan menjadi indeks kesesuaian habitat relatif eksploratif (RHSI).
