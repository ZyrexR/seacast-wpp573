# PHASE 4 — IMPLEMENTATION PLAN & TECHNICAL ARCHITECTURE
## Dynamic Ocean Management & Decision Support System (DOM-DSS)
### Sistem Intelijen Geospasial Perikanan Pelagis PPN Prigi — WPPNRI 573

- **Tanggal Penyusunan:** 1 November 2026
- **Fase Saat Ini:** PHASE 4.0 — Pre-Implementation Audit & Planning (Menunggu Persetujuan Eksekusi Phase 4.1–4.7)
- **Workspace:** `C:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis`

---

## 1. PRINSIP ARSITEKTUR & PENDEKATAN INTEGRASI (NON-DESTRUCTIVE EVOLUTION)

Sesuai dengan prinsip utama Master Implementation Prompt, pengembangan **PHASE 4 (DOM-DSS)** dilakukan dengan mempertahankan arsitektur, struktur folder, skema data, dan desain dashboard yang telah ada tanpa melakukan *rewrite* total:

1. **Single Source of Truth (Data Layer):**
   - Seluruh file CSV di `data/`, file JSON di `data/oceanographic/` & `models/sdm/`, serta GeoJSON di `outputs/sdm/zones/` tetap menjadi sumber data kanonik.
   - Seluruh diskrepansi yang ditemukan pada audit Phase 4.0 (typo +200 kg April 2022, simpangan baku tak-berbobot vs $\sigma_w$, overhang poligon $0.025^\circ$, batas `-10.5°S` vs `-10.45°S`, dan 5 vs 8 atribut CITES) diperbaiki secara deterministik melalui skrip pipeline terpadu sehingga **100% konsisten dari CSV/JSON sumber hingga ke bundel UI**.
2. **Backend & Data Service Layer (Python Module & Local API):**
   - Membangun modul layanan terpusat `dom_dss_engine.py` (dan endpoint API ringan berbasis Python `http.server` / FastAPI-compatible handler serta integrasi langsung ke `utils.py` / `app.py`) yang mengekspose fungsi independen untuk ke-6 modul DOM-DSS dan memperbaiki aplikasi Streamlit (`app.py`, `utils.py`, `pages/1..7_*.py`) agar membaca data riil Phase 1–4 (bukan `_make_dummy()`).
3. **Frontend Web GIS Layer (`html/index.html` + Zero-CORS JS Bundles):**
   - Mempertahankan dan memperluas aplikasi utama [`html/index.html`](file:///c:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis/html/index.html) beserta [`html/oceanographic_data.js`](file:///c:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis/html/oceanographic_data.js), [`html/sdm_data.js`](file:///c:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis/html/sdm_data.js), dan bundel tambahan [`html/dom_dss_data.js`](file:///c:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis/html/dom_dss_data.js) agar tetap dapat berjalan secara *standalone* (bebas CORS, baik melalui file lokal maupun HTTP server) sekaligus menyertakan ke-7 modul wajib Phase 4.

---

## 2. GRAFIK DEPENDENSI SISTEM & TAHAPAN IMPLEMENTASI

```mermaid
flowchart TD
    P40["PHASE 4.0: Initial Codebase Audit<br/>(Audit Report, Asset Inventory, Implementation Plan)"]
    P41["PHASE 4.1: Module 1 — Data Integration, Provenance & Remediation<br/>(Fix Apr 2022 +200kg, Sub-AOI Clipping -10.45S, 21-Field Provenance, Freshness Gate, Data Service)"]
    P42["PHASE 4.2: Module 2 — Dynamic Ocean Condition Monitoring<br/>(9 Ocean/Meteo Layers, Temporal/Scenario Selector, Freshness Badge, Non-Causal Guardrails)"]
    P43["PHASE 4.3: Module 3 — Pelagic Fishing Ground Advisory Screening<br/>(Weighted RHSI_w & sigma_w, Dual Scores Raw/Clipped, Lambda & Weight Sensitivity, Export)"]
    P44["PHASE 4.4: Module 4 — Maritime Risk Assessment<br/>(4-Tier Internal Risk Matrix, BMKG Wave Legend, Sustained vs Gust, Freeboard vs Draft, Stale Banner)"]
    P45["PHASE 4.5: Module 5 — Shark Bycatch Mitigation Screening<br/>(123 Clipped Polygons 150-1200m, Bathy/Thermo/Upwelling Split, Gear-Specific Education, 8-Field CITES)"]
    P46["PHASE 4.6: Module 6 — Integrated Decision Support Dashboard<br/>(7 Unified Views, 3 Operational Modes, System Status Panel, Statutory Legal Footer)"]
    P47["PHASE 4.7: Validation, Automated Testing & Final Deliverables<br/>(6 Test Suites + 11 Mandatory Documentation Reports)"]

    P40 --> P41
    P41 --> P42
    P41 --> P43
    P41 --> P44
    P41 --> P45
    P42 --> P46
    P43 --> P46
    P44 --> P46
    P45 --> P46
    P46 --> P47
```

---

## 3. RENCANA EKSEKUSI BERTAHAP (PHASE 4.1 – 4.7)

### PHASE 4.1 — Module 1: Data Integration, Provenance & Baseline Remediation

#### 4.1.1 Remediasi Integritas Data Phase 1–3 (`REM-01` & `REM-03`)
1. **Koreksi Typo Produksi April 2022 (+200 kg):**
   - Pada [`data/master_prigi_all_inclusive.csv`](file:///c:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis/data/master_prigi_all_inclusive.csv#L88) baris `2022-04-01`, ubah `total_pelagis_kg` dari `198446` menjadi `198246` (sesuai jumlah eksak 12 kolom spesies pada baris tersebut dan sesuai [`FINAL_FISHERIES_RECONCILIATION.csv`](file:///c:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis/FINAL_FISHERIES_RECONCILIATION.csv)).
   - Perbarui [`data/oceanographic/statistics/monthly/ocean_fisheries_master_132m.json`](file:///c:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis/data/oceanographic/statistics/monthly/ocean_fisheries_master_132m.json) dan [`html/oceanographic_data.js`](file:///c:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis/html/oceanographic_data.js) agar total kumulatif 132 bulan menjadi tepat **`18.405.261 kg`**.
   - Pastikan pemisahan eksplisit antara upaya tangkap periode studi 11 tahun (`189.334 trip`, 2015–2025) dan total historis 14 tahun (`249.257 trip`, 2012–2025).
2. **Harmonisasi Batas Sub-AOI Prigi (`-10.45° LS`) & Spatial Clipping:**
   - Seragamkan batas selatan Sub-AOI Prigi ke `-10.45° LS` (`[111.00, 113.00] BT` $\times$ `[-10.45, -8.00] LS`, `2.050` titik pusat grid $0.05^\circ$, luas elipsoidal WGS84 $59.550,43\text{ km}^2$ atau $4,18\%$ dari WPPNRI 573) di [`data/spatial_config_aoi.json`](file:///c:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis/data/spatial_config_aoi.json), [`data/oceanographic/metadata/data_sources.json`](file:///c:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis/data/oceanographic/metadata/data_sources.json), [`data/oceanographic/metadata/quality_control_report.json`](file:///c:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis/data/oceanographic/metadata/quality_control_report.json), dan [`data/manifests/processing_manifest.json`](file:///c:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis/data/manifests/processing_manifest.json) (koreksi `2091` menjadi `2050`).
   - Lakukan *exact geometric clipping* pada seluruh poligon di 5 file GeoJSON (`outputs/sdm/zones/*.geojson`) terhadap poligon batas Sub-AOI Prigi sehingga tidak ada koordinat yang meluber keluar $[111.00^\circ, 113.00^\circ\text{ BT}] \times [-10.45^\circ, -8.00^\circ\text{ LS}]$.
   - Hitung ulang luas setiap poligon ter-*clip* (`area_km2`) menggunakan rumus permukaan elipsoidal WGS84 / proyeksi metrik `EPSG:32749` (UTM Zone 49S), bukan aproksimasi kotak derajat.

#### 4.1.2 Katalog Data Provenance & Freshness/Latency Engine
1. **Skema Provenance 21+16 Field (`data/oceanographic/metadata/data_provenance_phase4.json`):**
   - Setiap dataset/layer wajib menyimpan seluruh **21 atribut Bagian 4.7** dan **16 atribut Protocol 5**:
     1. `dataset_id`
     2. `parameter_name` / `layer_name`
     3. `source_institution` / `source_provider`
     4. `product_name` / `dataset_product_id`
     5. `data_category` (`OBSERVATION`, `HISTORICAL`, `REANALYSIS`, `FORECAST`, `DERIVED_MODEL`)
     6. `spatial_resolution`
     7. `temporal_resolution`
     8. `crs` (`EPSG:4326` / `EPSG:32749`)
     9. `vertical_datum` (khusus GEBCO 2023: *"Multi-source composite grid (satellite radar altimetry gravity inversion + shipborne multibeam soundings); no single uniform hydrographic chart datum"*)
     10. `acquisition_time`
     11. `publication_time` (`published_timestamp_utc`)
     12. `retrieval_time` (`ingested_timestamp_utc`)
     13. `valid_time_start` (`validity_window_start_utc`)
     14. `valid_time_end` (`validity_window_end_utc`)
     15. `freshness_latency_status` (`FRESH`, `DELAYED`, `STALE_DATA`, `STATIC_HISTORICAL_CLIMATOLOGY`, `DATA_UNAVAILABLE`)
     16. `processing_level`
     17. `interpolation_flag` & `interpolation_method`
     18. `missing_data_flag` & `missing_data_handling`
     19. `quality_control_status`
     20. `model_version` / `processing_script_reference`
     21. `scientific_limitations_note`
2. **Modul Layanan Data & API (`dom_dss_engine.py` & `utils.py`):**
   - Menyediakan fungsi pembacaan tervalidasi untuk seluruh dataset, pengecekan *freshness/latency*, penanganan *missing data* tanpa interpolasi diam-diam, serta perbaikan `utils.py` agar `app.py` menggunakan data rekonsiliasi asli (`dummy = False`).

---

### PHASE 4.2 — Module 2: Dynamic Ocean Condition Monitoring

1. **Parameter yang Ditampilkan pada Grid Sub-AOI Prigi (`2.050` sel):**
   - **Sea Surface Temperature (SST)** ($^\circ\text{C}$) — Kondisi suhu permukaan laut (Observasi Satelit / Klimatologi).
   - **SST Anomaly** ($^\circ\text{C}$) — Simpangan suhu terhadap klimatologi bulanan 2015–2025.
   - **Chlorophyll-a** ($\text{mg/m}^3$) — Indikator produktivitas primer fitoplankton (*bukan bukti langsung keberadaan mangsa/ikan*).
   - **Thermal Front Intensity** ($^\circ\text{C/km}$, operator gradien Sobel) — Gradien suhu horizontal (*bukan otomatis feeding ground*).
   - **Significant Wave Height ($H_s$)** ($\text{m}$) — Tinggi gelombang signifikan (Reanalisis / Simulasi Skenario).
   - **Wind Speed & Vectors ($u_{10}, v_{10}$)** ($\text{m/s}$ dan $\text{knots}$) — Kecepatan dan arah angin permukaan 10 m.
   - **Ocean Surface Current** ($\text{m/s}$) — Kecepatan arus permukaan laut.
   - **Meridional Ekman Transport ($M_{ey}$) & SST Contrast ($\Delta T_{\text{coast-offshore}}$)** — Transport massa air berdasarkan tegangan angin ($\tau_x$) dan parameter Coriolis ($f < 0$ untuk Belahan Bumi Selatan $\phi \in [-10.45^\circ, -8.00^\circ\text{ LS}]$) serta kontras suhu pesisir-lepas pantai (tanpa menggunakan istilah lama `CUI` dan tanpa mengklaim $\partial T/\partial z$ sebagai indikator langsung upwelling).
   - **Bathymetry & Seafloor Slope** ($\text{m}$ dan derajat) — Kedalaman dasar laut GEBCO 2023 dan kemiringan lereng, menggunakan jarak aktual `dist_to_200m_isobath_km` pada setiap sel.
2. **Fitur Antarmuka:**
   - Pemilih lapisan (Layer Selector), pemilih waktu/skenario (132 bulan historis + 6 skenario sinoptik/iklim), legenda dinamis dengan satuan, badge kategori data (`Observasi Satelit`, `Reanalisis`, `Klimatologi Historis`, `Simulasi Skenario`), indikator status kesegaran data, dan panel *Provenance Metadata* per variabel.

---

### PHASE 4.3 — Module 3: Pelagic Fishing Ground Advisory Screening

1. **Implementasi Matematis Wajib ($\overline{RHSI}_w$, $\sigma_w$, dan $PFG_{\text{advisory}}$):**
   - Untuk ketiga spesies target (**Cakalang** / *Katsuwonus pelamis*, **Madidihang** / *Thunnus albacares*, **Albakor** / *Thunnus alalunga*):
     \[
     \overline{RHSI}_w = \sum_{i \in \{\text{MaxEnt, RF, GLM}\}} w_i \, RHSI_i, \qquad w_i \geq 0, \quad \sum_i w_i = 1
     \]
     \[
     \sigma_w = \sqrt{\sum_i w_i \left(RHSI_i - \overline{RHSI}_w\right)^2}
     \]
     \[
     PFG_{\text{advisory}}^{\text{raw}} = \overline{RHSI}_w - \lambda \sigma_w, \qquad PFG_{\text{advisory}}^{\text{vis}} = \min\left(1, \max\left(0, PFG_{\text{advisory}}^{\text{raw}}\right)\right)
     \]
   - Baseline $\lambda = 0,50$.
2. **Penyimpanan Skor Ganda & Perbaikan Pipeline (`REM-02`):**
   - Perbarui [`outputs/sdm/hsi/hsi_all_scenarios_projections.json`](file:///c:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis/outputs/sdm/hsi/hsi_all_scenarios_projections.json) dan [`html/sdm_data.js`](file:///c:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis/html/sdm_data.js) agar setiap sel menyimpan: `hsi_maxent`, `hsi_rf`, `hsi_glm`, `rhsi_w`, `sigma_w`, `raw_advisory_score` (untuk $\lambda = 0,50$ tanpa clipping), dan `visualization_score` (clipped $[0,1]$).
3. **Analisis Sensitivitas ($\lambda$, Bobot, dan Ambang Batas):**
   - Sediakan matriks dan kontrol interaktif untuk:
     - **Sensitivitas Penalti Ketidakpastian ($\lambda$):** $\lambda \in \{0.00, 0.25, 0.50, 0.75, 1.00\}$ beserta metrik perubahan luas kandidat area dan jumlah sel.
     - **Sensitivitas Skema Bobot ($w_i$):** Bobot Baseline (AUC-weighted), Bobot Sama Rata (*Equal Weights* $1/3$ atau $1/2$ untuk Albakor), dan Bobot Konservatif (RF-dominant).
     - **Sensitivitas Ambang Batas Screening ($\tau$):** $\tau \in \{0.50, 0.55, 0.60, 0.65, 0.70\}$ dengan penjelasan bahwa $0,60$ adalah *exploratory screening cutoff*, **bukan batas ilmiah universal**.
4. **Guardrails Ilmiah & Ekspor:**
   - Gunakan judul: **`Pelagic Fishing Ground Advisory Screening`**.
   - Tampilkan $\overline{RHSI}_w$ dan $\sigma_w$ secara terpisah (peta mode ganda / side-by-side toggle) dan jelaskan bahwa $\sigma_w$ hanya merepresentasikan *weighted ensemble disagreement* antar-algoritma, **bukan total ecological uncertainty**.
   - Jangan pernah menampilkan titik GPS penangkapan ikan sintetis.
   - Tampilkan disclaimer wajib secara permanen:
     > *"Area yang ditampilkan merupakan hasil screening kesesuaian habitat relatif berdasarkan indikator lingkungan dan pemodelan. Area ini bukan lokasi penangkapan aktual atau jaminan keberadaan ikan."*
   - Sediakan tombol ekspor hasil screening (`GeoJSON` dan `CSV`) yang menyertakan nilai `rhsi_w`, `sigma_w`, `raw_advisory_score`, `visualization_score`, parameter $\lambda$, dan teks disclaimer di dalam metadata file ekspor.

---

### PHASE 4.4 — Module 4: Maritime Risk Assessment

1. **Klasifikasi Risiko Internal 4-Tier (Tanpa Kata `"AMAN"` / `"SAFE"`):**
   - Sistem hanya menyajikan klasifikasi skrining risiko internal:
     1. **`TINGKAT RISIKO EKSPLORATIF RENDAH (LOW EXPLORATORY RISK)`** — *Tetap Waspada & Periksa Kondisi Aktual*
     2. **`TINGKAT RISIKO EKSPLORATIF SEDANG (MODERATE EXPLORATORY RISK)`** — *Perhatikan Karakteristik Kapal, Muatan & Perkembangan Cuaca*
     3. **`TINGKAT RISIKO EKSPLORATIF TINGGI (HIGH EXPLORATORY RISK)`** — *Risiko Dinamika Gelombang/Angin Signifikan terhadap Armada Kecil-Menengah*
     4. **`TINGKAT RISIKO EKSPLORATIF EKSTREM (EXTREME EXPLORATORY RISK)`** — *Kondisi Laut Berbahaya; Rujuk Peringatan Dini Resmi BMKG & Otoritas Syahbandar*
2. **Integrasi Kategori Gelombang Resmi BMKG & Metadata Produk:**
   - Menggunakan klasifikasi tinggi gelombang signifikan ($H_s$) referensi BMKG:
     - *Tenang:* $0,1 - 0,5\text{ m}$
     - *Rendah:* $0,5 - 1,25\text{ m}$
     - *Sedang:* $1,25 - 2,50\text{ m}$
     - *Tinggi:* $2,50 - 4,00\text{ m}$
     - *Sangat Tinggi:* $4,00 - 6,00\text{ m}$
     - *Ekstrem:* $6,00 - 9,00\text{ m}$
     - *Sangat Ekstrem:* $> 9,00\text{ m}$
   - Mencantumkan: **Nama Produk / Product ID BMKG**, **Waktu Penerbitan (UTC/WIB)**, **Masa Berlaku (Validity Window)**, dan **Versi Legenda BMKG**.
3. **Pemisahan Parameter Fisik Angin & Kapal (Multivariate Vessel Risk Evaluator):**
   - **Angin:** Memisahkan input/tampilan **Sustained Wind Speed** ($\text{knots}$) dan **Wind Gust** ($\text{knots}$).
   - **Geometri Lambung Kapal:** Memisahkan **Freeboard / Lambung Timbul (`freeboard_m`)** dan **Draft / Sarat Air (`draft_m`)** secara eksplisit.
   - **Profil Kapal Multivariat (GT Bukan Penentu Tunggal):** Mengevaluasi kombinasi kelas armada PPN Prigi (Perahu Motor Tempel / Jukung $< 5\text{ GT}$, Sekoci / Handline $5\text{–}10\text{ GT}$, Purse Seine Mini / Rawai $10\text{–}30\text{ GT}$), `loa_m` (panjang kapal), `beam_m` (lebar), `freeboard_m`, `draft_m`, kondisi muatan palka (`loading_ratio`), jenis alat tangkap, dan profil jarak rute (`nearshore_shelf` $< 25\text{ km}$ vs `offshore_deep_basin` $> 25\text{ km}$).
   - **Worst-Case Precautionary Trigger:** Tingkat risiko akhir ditentukan oleh komponen paling berisiko ($\max(\text{Risk}_{H_s}, \text{Risk}_{\text{SustainedWind}}, \text{Risk}_{\text{WindGust}}, \text{Risk}_{\text{FreeboardStability}}, \text{Risk}_{\text{RouteExposure}})$), bukan rata-rata sederhana.
4. **Mekanisme Stale / Disconnected Weather Feed:**
   - Apabila umpan cuaca real-time BMKG tidak terhubung atau melebihi batas validitas waktu, sistem otomatis menampilkan banner peringatan merah/kuning mencolok:
     **`STATUS UMPAN CUACA WAKTU-NYATA: DATA UNAVAILABLE / STALE DATA — MENAMPILKAN SIMULASI SKENARIO HISTORIS (BUKAN PRAKIRAAN OPERASIONAL HARI INI)`**
   - Tampilkan disclaimer wajib:
     > *"Informasi risiko maritim ini hanya merupakan pendukung keputusan awal dan bukan pengganti peringatan resmi BMKG atau keputusan Syahbandar."*

---

### PHASE 4.5 — Module 5: Shark Bycatch Mitigation Screening

1. **Nomenklatur & Validasi Spasial 123 Poligon:**
   - Gunakan nama resmi layer: **`Candidate Bathymetric Screening Polygons for Voluntary Shark Bycatch Review`**.
   - Gunakan nama rentang kedalaman: **`Exploratory Bathymetric Screening Band (150–1,200 m)`** (dengan penjelasan bahwa rentang `-150 m` s/d `-1.200 m` merupakan batas skrining eksploratif di selatan Jawa, bukan batas universal lereng benua).
   - Seluruh 123 poligon di [`outputs/sdm/zones/dynamic_bycatch_mitigation_zones.geojson`](file:///c:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis/outputs/sdm/zones/dynamic_bycatch_mitigation_zones.geojson) di-*clip* ketat terhadap Sub-AOI Prigi, divalidasi bebas self-intersection/overlap/duplikat, dan dirender di peta Leaflet sebagai **poligon aktual (`L.geoJSON`)**, bukan sekadar titik.
2. **Pemisahan Tiga Konsep Oseanografi:**
   - Di dalam struktur data dan tampilan UI, pisahkan secara tegas:
     1. **Indeks Batimetri & Topografi Statis:** Kedalaman (`depth_m`, GEBCO 2023 multi-source vertical datum) dan kemiringan lereng (`slope_deg`).
     2. **Indeks Termoklin Sub-permukaan (Proxy/Model):** Kedalaman isoterm $20^\circ\text{C}$ ($Z_{20}$, hanya jika berasal dari profil temperatur model) dan gradien vertikal ($\partial T/\partial z$), dengan catatan bahwa $\partial T/\partial z$ bukan bukti langsung upwelling.
     3. **Indeks Dinamika Upwelling Permukaan:** Kontras SST pesisir-lepas pantai ($\Delta T_{\text{coast-offshore}}$) dan Transport Ekman Meridional ($M_{ey}$).
3. **Panduan Mitigasi Sukarela Spesifik Alat Tangkap (Tanpa Klaim Universal & Tanpa Zona Larangan):**
   - **Rawai Tuna (*Longline*) & Pancing Ulur (*Handline*):** Edukasi penggunaan *Circle Hooks* (ukuran 16/0–18/0, offset $\leq 10^\circ$) dan penggunaan *monofilament leader* dengan mempertimbangkan target spesies dan selektivitas alat, disertai catatan bahwa efektivitas bergantung pada kondisi operasional dan bukan klaim pengurangan absolut universal.
   - **Pukat Cincin Mini (*Mini Purse Seine*):** Penggunaan *Non-Entangling FADs (NEFADs)* / rumpon ramah lingkungan tanpa jaring pembungkus, teknik pelepasan aman (*Safe Release*) di atas dek menggunakan *de-hooker* / pemotong tali dari jarak aman dengan **mengutamakan keselamatan awak kapal di atas segalanya**, serta pencatatan/pelaporan mandiri dan peningkatan *observer* / *electronic monitoring*.
4. **Kepatuhan CITES (Efektif 5 Maret 2026) & 8 Atribut Taksonomi:**
   - Setiap poligon dan tabel catatan pendaratan wajib memuat 8 field:
     1. `identified_taxon_name`: `"Carcharhinus spp. / Elasmobranchii (Unresolved Port Landing Group)"`
     2. `taxonomic_resolution_level`: `"GENUS_OR_FAMILY_COMPLEX"`
     3. `taxonomic_uncertainty_notes`: Penjelasan agregasi pencatatan pelabuhan pada tingkat genus/famili.
     4. `identification_verification_status`: **`"NEEDS_VERIFICATION"`**
     5. `cites_appendix`: `"Appendix II (Family Carcharhinidae spp. blanket listing; with specific taxa in Appendix I/II per CoP20)"`
     6. `cites_taxonomic_scope`: `"Family Carcharhinidae (Requiem sharks) and associated pelagic elasmobranchs"`
     7. `cites_reference_date`: **`"2026-03-05"`**
     8. `cites_verification_source`: `"CITES Appendices I, II and III valid from 5 March 2026"`
   - Tampilkan disclaimer wajib:
     > *"Area ini merupakan kandidat kajian mitigasi sukarela berdasarkan karakteristik batimetri dan indikator lingkungan. Area ini bukan zona larangan penangkapan atau penetapan kawasan konservasi."*

---

### PHASE 4.6 — Module 6: Integrated Decision Support Dashboard

1. **Integrasi 7 Modul pada Dashboard (`html/index.html` & `app.py`):**
   - **Tab 1 — Overview & Fleet Reconciliation:** Ringkasan eksekutif WPPNRI 573 & Sub-AOI Prigi ($59.550,43\text{ km}^2$), KPI produksi tereinkonsiliasi (`18.405.261 kg`, `189.334 trip` 2015–2025; `249.257 trip` 2012–2025), profil armada & CPUE/LPUE terstandarisasi.
   - **Tab 2 — Dynamic Ocean Monitoring (Module 2):** Peta interaktif 9 parameter oseanografi/meteorologi, pemilih bulan/skenario, grafik deret waktu 132 bulan, indikator kesegaran data (`Freshness Status`), dan metadata provenance per layer.
   - **Tab 3 — Pelagic Advisory Screening (Module 3):** Peta `Pelagic Fishing Ground Advisory Screening` (perbaikan bug `initSdmMap()`), mode tampilan terpisah $\overline{RHSI}_w$, $\sigma_w$, `raw_advisory_score`, dan `visualization_score`, kalkulator sensitivitas $\lambda \in \{0.00, 0.25, 0.50, 0.75, 1.00\}$ & bobot, kurva respons ekologis, dan fitur ekspor.
   - **Tab 4 — Maritime Risk Assessment (Module 4):** Peta & matriks risiko maritim 4-tier (BMKG wave categories), simulator profil kapal multivariat (`freeboard_m` vs `draft_m`, `sustained_wind_kt` vs `wind_gust_kt`, LOA, muatan, rute), *worst-case trigger*, dan banner `DATA UNAVAILABLE / STALE DATA`.
   - **Tab 5 — Shark Bycatch Mitigation Screening (Module 5):** Peta 123 poligon ter-*clip* `Candidate Bathymetric Screening Polygons for Voluntary Shark Bycatch Review`, matriks perbandingan Batimetri vs Termoklin vs Upwelling, panduan mitigasi sukarela spesifik alat tangkap, dan tabel 8 atribut CITES (`2026-03-05`, `NEEDS_VERIFICATION`).
   - **Tab 6 — Data Provenance & Governance (Module 1):** Tabel interaktif 21 atribut provenance untuk seluruh dataset, log rekonsiliasi April 2022, dan dokumentasi metodologi ilmiah.
   - **Tab 7 — System Status & Readiness Verification:** Status kesehatan seluruh modul, validasi integritas file, status latensi/kesegaran data, dan hasil unit test real-time di dalam browser.
2. **Tiga Mode Tampilan Terpadu (View Mode Switcher di Header Dashboard):**
   - `Academic Mode`: Menampilkan detail rumus matematis ($\overline{RHSI}_w, \sigma_w, PFG_{\text{advisory}}$), catatan ketidakpastian, dan tabel sensitivitas lengkap.
   - `Operational Screening Mode`: Menyoroti peta screening kesesuaian, klasifikasi risiko maritim 4-tier, panduan mitigasi bycatch, dan status kesegaran data beserta seluruh disclaimer wajib.
   - `Methodology Mode`: Menampilkan alur pemrosesan data, provenance 21 field, batasan ilmiah, dan kerangka regulasi.
3. **Footer Kepatuhan Hukum & Kewenangan Kelembagaan:**
   - Mencantumkan sitasi regulasi yang berlaku: **Permen-KP No. 7 Tahun 2026**, **UU No. 31/2004 jo. UU No. 6/2023**, **UU No. 17/2008 jo. UU No. 66/2024**, serta nomenklatur resmi: **`Syahbandar di Pelabuhan Perikanan yang berwenang sesuai peraturan perundang-undangan`**.

---

### PHASE 4.7 — Comprehensive Testing, Validation & Final Documentation

#### 4.7.1 Rangkaian Pengujian Otomatis (`tests/run_phase4_validation_suite.py`)
1. **Data Tests:** Verifikasi eksistensi file, validitas skema JSON/CSV/GeoJSON, kelengkapan 21 field provenance, rekonsiliasi tepat `18.405.261 kg` di seluruh file, dan deteksi *missing/stale data*.
2. **RHSI & Advisory Unit Tests:** Uji kasus wajib `RHSI = [0.8, 0.6, 0.4]`, `weights = [0.5, 0.3, 0.2]`, `lambda = 0.5` ($\overline{RHSI}_w = 0,6600$, $\sigma_w \approx 0,156205$, $PFG_{\text{advisory}}^{\text{raw}} \approx 0,581898$), uji $\sum w_i = 1,0$ (`Albaker` $w_{\text{maxent}} = 0$), uji pemisahan `raw_advisory_score` vs `visualization_score` pada seluruh `2.050` sel $\times$ 6 skenario, dan uji matriks sensitivitas $\lambda$.
3. **Geospatial Tests:** Verifikasi CRS `EPSG:4326`, uji ketercakupan 100% titik dan simpul poligon di dalam Sub-AOI Prigi ($[111.00^\circ, 113.00^\circ\text{ BT}] \times [-10.45^\circ, -8.00^\circ\text{ LS}]$ — **0 overhang**), uji topologi 123 poligon bycatch (0 invalid, 0 self-intersection, 0 overlap), dan verifikasi luas elipsoidal $59.550,43\text{ km}^2$.
4. **Maritime Risk Tests:** Uji determinisme klasifikasi 4-tier, uji ketiadaan kata `"AMAN"` / `"SAFE"` sebagai status pelayaran, uji pemisahan `sustained_wind_kt` vs `wind_gust_kt` dan `freeboard_m` vs `draft_m`, uji *worst-case precautionary trigger*, dan uji pemicu banner `STALE DATA` / `DATA UNAVAILABLE`.
5. **Frontend & Guardrail Compliance Tests:** Pemindaian otomatis DOM/HTML dan bundel JS untuk memastikan `initSdmMap()` terpanggil saat tab dibuka, ketiadaan istilah terlarang (`CUI`, `EMPIRICAL PROOF`, `no-take zone`, `shark hotspot`), keberadaan ke-4 disclaimer wajib, dan keberadaan sitasi hukum (`Permen-KP No. 7 Tahun 2026`, `Syahbandar di Pelabuhan Perikanan yang berwenang sesuai peraturan perundang-undangan`).
6. **Integration Tests:** Uji alur ujung-ke-ujung dari file CSV/JSON sumber $\rightarrow$ mesin Python `dom_dss_engine.py` $\rightarrow$ bundel JS Web GIS & aplikasi Streamlit `app.py`.

#### 4.7.2 Dokumen Deliverables Akhir Phase 4 (11 Dokumen Wajib)
1. `PHASE_4_INITIAL_CODEBASE_AUDIT.md` *(Selesai pada Phase 4.0)*
2. `PHASE_4_EXISTING_ASSET_INVENTORY.json` *(Selesai pada Phase 4.0)*
3. `PHASE_4_IMPLEMENTATION_PLAN.md` *(Dokumen ini — Selesai pada Phase 4.0)*
4. `PHASE_4_DATA_DICTIONARY.md` *(Dibuat pada Phase 4.1/4.7)*
5. `PHASE_4_DATA_PROVENANCE.md` *(Dibuat pada Phase 4.1/4.7)*
6. `PHASE_4_API_DOCUMENTATION.md` *(Dibuat pada Phase 4.1/4.7)*
7. `PHASE_4_SCIENTIFIC_METHODOLOGY.md` *(Dibuat pada Phase 4.3–4.5/4.7)*
8. `PHASE_4_TESTING_REPORT.md` *(Dibuat pada Phase 4.7)*
9. `PHASE_4_VALIDATION_REPORT.md` *(Dibuat pada Phase 4.7)*
10. `PHASE_4_CHANGELOG.md` *(Dibuat pada Phase 4.7)*
11. `PHASE_4_FINAL_IMPLEMENTATION_REPORT.md` *(Dibuat pada Phase 4.7)*

---

## 4. DAFTAR PERIKSA KESIAPAN EKSEKUSI PHASE 4.1

- [x] Seluruh file kode, data, GeoJSON, dan dokumentasi Phase 1–3 serta prasyarat Phase 4 telah diperiksa secara langsung.
- [x] Tidak ada file kode atau data proyek eksisting yang dimodifikasi selama Phase 4.0.
- [x] Seluruh 10 poin verifikasi wajib telah diuji secara empiris dan didokumentasikan di [`PHASE_4_INITIAL_CODEBASE_AUDIT.md`](file:///c:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis/PHASE_4_INITIAL_CODEBASE_AUDIT.md).
- [x] Inventarisasi lengkap aset eksisting telah disimpan dalam [`PHASE_4_EXISTING_ASSET_INVENTORY.json`](file:///c:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis/PHASE_4_EXISTING_ASSET_INVENTORY.json).
- [x] Rencana arsitektur dan urutan implementasi bertahap Phase 4.1–4.7 telah didokumentasikan dalam [`PHASE_4_IMPLEMENTATION_PLAN.md`](file:///c:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis/PHASE_4_IMPLEMENTATION_PLAN.md).

