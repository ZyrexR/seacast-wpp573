# PHASE 4 PRECONDITIONS & OPERATIONAL CONSTRAINTS
## Ketentuan Wajib, Prasyarat Ilmiah, dan Batasan Operasional Sebelum Memulai Phase 4 (DOM-DSS)
### WPPNRI 573 × PPN Prigi Spatial Fisheries Intelligence System

**Dokumen Rujukan:** `PHASE_4_READINESS_GATE.json`  
**Tanggal Pemutakhiran:** 1 November 2026  
**Status Otorisasi:** BINDING / MENGIKAT PENUH UNTUK PENGEMBANGAN PHASE 4  

---

## 1. PENDAHULUAN

Laporan audit saintifik dan remediasi menyeluruh (Phase 3.1 dan Gerbang Validasi Final) telah menetapkan bahwa sistem intelijen geospasial perikanan PPN Prigi beroperasi di atas fondasi data yang telah terekonsiliasi. Namun, audit juga mengidentifikasi **empat keterbatasan empiris mendasar (*fundamental empirical constraints*)** yang tidak boleh dilanggar selama pengembangan **Phase 4: Dynamic Ocean Management & Decision Support System (DOM-DSS)**.

Dokumen ini memuat prasyarat (*preconditions*), lima protokol saintifik operasional yang telah disempurnakan, dan batasan implementasi hukum yang wajib dipatuhi oleh setiap pengembang, analis, dan modeler sebelum dan selama implementasi Phase 4.

---

## 2. EMPAT KETERBATASAN UTAMA YANG MENGHALANGI IMPLEMENTASI BEBAS (*BLOCKING CONSTRAINTS*)

```
+-----------------------------------------------------------------------------------------------------------------+
|                        EMPAT ISU PEMBATAS UTAMA SEBELUM PELAKSANAAN PHASE 4                                     |
+---+--------------------+----------------------------+-----------------------------------------------------------+
|No | Isu Pembatas       | Status Ketersediaan Data   | Mitigasi Wajib dalam Sistem Phase 4                       |
+---+--------------------+----------------------------+-----------------------------------------------------------+
| 1 | Ketiadaan Data GPS | UNRESOLVED                 | Seluruh luaran PFG harus berformat "Advisory Screening",  |
|   | Tangkap Empiris    | (Tidak ada VMS/e-Logbook)  | bukan kepastian koordinat titik jatuh jaring nelayan.     |
+---+--------------------+----------------------------+-----------------------------------------------------------+
| 2 | Sirkularitas Relung| UNRESOLVED                 | Nilai model wajib disajikan sebagai Relative HSI (RHSI),  |
|   | Ekologis SDM       | (Presensi dari heuristik)  | dilarang diklaim sebagai probabilitas absolut menangkap.  |
+---+--------------------+----------------------------+-----------------------------------------------------------+
| 3 | Batasan Spasial    | UNRESOLVED                 | Seluruh rekomendasi DSS dibatasi pada Sub-AOI Prigi       |
|   | Sub-AOI Prigi      | (Hanya 4.16% WPPNRI 573)   | (111-113° E, -8 s/d -10.45° S); dilarang diekstrapolasi. |
+---+--------------------+----------------------------+-----------------------------------------------------------+
| 4 | Ketiadaan Survei   | UNRESOLVED                 | 123 poligon berstatus kandidat penapisan batimetri,       |
|   | Lapangan Bycatch   | (Hanya pendaratan TPI)     | bukan larangan penangkapan ikan tertutup (no-take zone).  |
+---+--------------------+----------------------------+-----------------------------------------------------------+
```

---

## 3. LIMA PROTOKOL OPERASIONAL WAJIB PADA SISTEM PHASE 4 (MANDATORY DSS PROTOCOLS)

Setiap modul DSS yang dibangun pada Phase 4 wajib mengimplementasikan lima protokol saintifik berikut secara utuh dan taat asas:

---

### 3.1 Protokol 1: Relative Habitat Suitability and Uncertainty-Penalized Advisory Scoring

1. **Pelabelan dan Skala Baku:**
   - Seluruh indeks kesesuaian habitat wajib diberi label resmi **Relative Habitat Suitability Index (RHSI)** dengan rentang skala numerik $0,00\text{–}1,00$.
   - Nilai tersebut merupakan **indeks kesesuaian spasial relatif**, **BUKAN** probabilitas absolut keberadaan ikan ($P(Y=1)$) dan **BUKAN** probabilitas keberhasilan penangkapan nelayan.
2. **Penyajian Terpisah pada Antarmuka:**
   - Sistem wajib menampilkan nilai RHSI dan nilai ketidaksepakatan/ketidakpastian model secara terpisah pada antarmuka pengguna agar tingkat keandalan estimasi dapat diinspeksi secara independen.
3. **Formulasi Matematis Ketidakpastian Ensemble:**
   - Bobot model individual ($w_i$) wajib dinormalisasi secara ketat sehingga:
     $$w_i \ge 0, \quad \sum_{i=1}^M w_i = 1$$
   - Rata-rata RHSI berbobot ensemble dihitung sebagai:
     $$\overline{RHSI}_w = \sum_{i=1}^M w_i \, RHSI_i$$
   - Ukuran ketidaksepakatan antar-model (*weighted ensemble disagreement*) dihitung sebagai deviasi standar berbobot:
     $$\sigma_w = \sqrt{\sum_{i=1}^M w_i \, \left(RHSI_i - \overline{RHSI}_w\right)^2}$$
4. **Formulasi Skor Advisory Gabungan:**
   Jika digunakan skor gabungan untuk mendukung penyaringan daerah potensial penangkapan ikan (*Potential Fishing Ground / PFG*), sistem menerapkan pendekatan eksploratif:

   $$\mathbf{PFG_{\text{advisory}} = \overline{RHSI}_w - \lambda\sigma_w}$$

   dengan ketentuan:
   - $\overline{RHSI}_w$: rata-rata indeks kesesuaian habitat relatif berbobot;
   - $\sigma_w$: ukuran ketidaksepakatan antar-model (*weighted ensemble disagreement*);
   - $\lambda$: koefisien penalti ketidakpastian (*uncertainty penalty coefficient*) yang nilainya harus didokumentasikan dan diuji melalui analisis sensitivitas (rentang uji $\lambda \in [0,0, 1,0]$, nilai dasar $\lambda = 0,5$).
5. **Nomenklatur dan Batasan Interpretasi Ilmiah:**
   - Nilai $\sigma_w$ secara sah merupakan **`weighted ensemble disagreement`** dan **DILARANG** ditafsirkan sebagai keseluruhan ketidakpastian biologis atau *confidence interval* statistik formal.
   - Skor gabungan tersebut resmi disebut sebagai **`Uncertainty-Penalized Advisory Score`**, dan **DILARANG** disebut sebagai *probabilitas keberhasilan penangkapan*.
6. **Penyimpanan Data Ganda (Dual-Score Storage):**
   - Sistem wajib menyimpan **nilai skor mentah sebelum pemotongan (*raw score before clipping*)** yang dapat bernilai negatif ($\overline{RHSI}_w - \lambda\sigma_w < 0$), serta **nilai skor yang digunakan untuk visualisasi (*visualization score*)** setelah perlakuan *clipping* ke rentang $[0,00, 1,00]$.
   - Ambang klasifikasi dan koefisien penalti wajib melalui analisis sensitivitas terdokumentasi dalam metadata model.
7. **Status Luaran Sistem:**
   - Seluruh keluaran modul ini tetap berstatus **`Advisory Screening`** (penapisan saran spasial) dan **tidak boleh ditafsirkan sebagai koordinat aktual keberadaan ikan atau lokasi pasti penangkapan nelayan**.

---

### 3.2 Protokol 2: Tiered Maritime Risk Screening

Sistem Phase 4 menyediakan instrumen penapisan risiko maritim eksploratif dengan memperhatikan parameter meteorologi-oseanografi dan armada yang komprehensif:

1. **Kepatuhan Legenda Produk BMKG:**
   Kategori gelombang harus mengikuti legenda produk BMKG yang menjadi sumber integrasi data cuaca maritim. Sistem wajib menyimpan identitas produk (*Product ID*) dan versi legenda BMKG yang digunakan dalam basis data.
2. **Status Klasifikasi Internal:**
   Klasifikasi internal Phase 4 merupakan instrumen penapisan risiko eksploratif (*exploratory risk screening instrument*) dan **bukan klasifikasi resmi BMKG**, serta **tidak menggantikan peringatan dini maupun informasi keselamatan resmi dari otoritas maritim**.
3. **Pemisahan Parameter Angin dan Hembusan (*Wind Gust*):**
   Kecepatan angin rata-rata (*sustained wind speed*) dan hembusan angin (*wind gust*) **wajib disimpan dan ditampilkan sebagai dua parameter berbeda secara eksplisit**, tidak boleh digabungkan atau disamakan.
4. **Penilaian Multivariat Non-Tunggal:**
   Penilaian risiko keselamatan pelayaran harus mempertimbangkan karakteristik teknis kapal, lambung timbul (*freeboard draft*), kondisi muatan (saat berangkat kosong vs saat kembali bermuatan ikan/es), dan profil perjalanan (*day-trip* pesisir vs *multi-day* samudra). **Gross Tonnage (GT) tidak boleh digunakan sebagai satu-satunya penentu kelayakan atau keselamatan pelayaran.**
5. **Prinsip Indikator Risiko Tertinggi (*Worst-Case Precautionary Principle*):**
   Indikator risiko tertinggi yang relevan harus ditampilkan bersama faktor pemicunya secara spesifik. Penggabungan indikator harus menggunakan aturan penapisan yang terdokumentasi dan **tidak boleh menyamakan variabel yang berbeda satuan atau karakteristik fisiknya** (misal: tinggi gelombang dalam meter tidak boleh dirata-ratakan dengan kecepatan angin dalam knot).
6. **Larangan Label Jaminan Keselamatan "Aman":**
   Sistem **DILARANG MENGGUNAKAN LABEL "AMAN"** sebagai jaminan keselamatan pelayaran. Sebagai gantinya, sistem wajib menggunakan istilah bergradasi:
   - *Level 1 (Hijau):* **Risiko Rendah / Kondisi Relatif Kondusif**
   - *Level 2 (Kuning):* **Risiko Sedang / Waspada Operasional**
   - *Level 3 (Oranye):* **Risiko Tinggi / Peringatan Cuaca Buruk**
   - *Level 4 (Merah):* **Bahaya Ekstrem / Kondisi Sangat Tidak Kondusif**
7. **Larangan Larangan Melaut Otomatis:**
   Sistem **dilarang menerbitkan larangan melaut otomatis (*automated sea bans*)** atau bertindak seolah-olah menggantikan keputusan nakhoda serta otoritas Kesyahbandaran di pelabuhan perikanan.
8. **Protokol Penanganan Data Cuaca Kedaluwarsa:**
   Apabila data BMKG tidak tersedia, gagal diperbarui melalui koneksi feed, atau telah melewati periode validitas operasionalnya, sistem **wajib menampilkan status `DATA KEDALUWARSA`**, **`FEED TERPUTUS`**, atau **`TIDAK TERSEDIA`**. Sistem **dilarang mempertahankan status keselamatan sebelumnya seolah-olah masih aktual**.

---

### 3.3 Protokol 3: Voluntary Shark Bycatch Mitigation Screening

Lapisan 123 poligon batimetri wajib ditampilkan secara resmi dengan nama:

$$\mathbf{Candidate\text{ }Bathymetric\text{ }Screening\text{ }Polygons\text{ }for\text{ }Voluntary\text{ }Shark\text{ }Bycatch\text{ }Review}$$

1. **Definisi Instrumen Spasial:**
   Lapisan ini merupakan instrumen penyaringan spasial berdasarkan parameter batimetri dan parameter oseanografi yang definisi, sumber data, serta metode perhitungannya terdokumentasi secara terbuka.
2. **Justifikasi Eksploratif Kedalaman 150–1.200 Meter:**
   Rentang kedalaman $150\text{–}1.200\text{ meter}$ merupakan kriteria eksploratif yang mencerminkan mintakat lereng tubir benua (*continental slope*). Kriteria ini wajib disertai dasar ilmiah literatur kelautan, definisi pengukuran batimetri (GEBCO 2023 relatif terhadap MSL), dan versi metode pembentukan poligon.
3. **Pemisahan Parameter Termoklin dan Upwelling:**
   Parameter termoklin dan upwelling **harus didefinisikan secara terpisah**. Kedalaman lapisan termoklin ($Z_{20}$ atau gradien suhu vertikal $\partial T / \partial z$) dan indikator upwelling permukaan (seperti $\Delta T_{c-o}$ atau transpor Ekman $M_{ey}$) **tidak boleh dipertukarkan tanpa justifikasi metodologis**.
4. **Bukan Hotspot, Bukan Habitat Kritis, Bukan Zona Larangan:**
   Poligon-poligon ini **bukan peta distribusi hiu, bukan hotspot bycatch terverifikasi, bukan habitat kritis yang telah divalidasi secara biologis, dan bukan zona larangan penangkapan ikan (*no-take marine reserves*)**.
5. **Spesifisitas Rekomendasi Alat Tangkap:**
   Rekomendasi penggunaan mata kail melingkar (*circle hooks* ukuran 16/0 atau 18/0 non-offset), konfigurasi tali pancing (*wire leader vs monofilament*), kedalaman penurunan pancing, dan prosedur penanganan pelepasan hiu **harus spesifik terhadap jenis alat tangkap, spesies sasaran, dan kondisi operasi di laut**, serta didukung bukti literatur ilmiah yang relevan.
6. **Larangan Klaim Efektivitas Universal Circle Hooks:**
   Penggunaan *circle hooks* **tidak boleh diklaim secara otomatis mengurangi seluruh jenis bycatch hiu**, karena efektivitasnya sangat bervariasi bergantung pada morfologi rahang, cara menyambar umpan, dan ukuran kait.
7. **Materi Edukasi Mitigasi Sukarela Armada Pukat Cincin (*Purse Seine*):**
   Untuk armada pukat cincin mini, penggunaan rumpon ramah lingkungan tanpa jaring bergantung (*Non-Entangling FADs*) dan praktik pelepasan hiu secara aman (*safe shark release practices*) ditampilkan murni sebagai **materi edukasi mitigasi sukarela** berdasarkan pedoman teknis yang relevan, dengan senantiasa memprioritaskan keselamatan awak kapal (*crew safety*).
8. **Diferensiasi Status Taksonomi CITES:**
   - Identifikasi status CITES wajib menggunakan **Appendices CITES yang berlaku pada tanggal pemrosesan data**.
   - Untuk kelompok hiu famili Carcharhinidae, sistem **wajib membedakan pencantuman tingkat famili (*Carcharhinidae spp.*) pada Appendix II dan spesies yang secara khusus tercantum dalam Appendix I**.
   - Sebagai contoh spesifik: ***Carcharhinus longimanus* (Oceanic whitetip shark) tercantum dalam Appendix I pada Appendices yang berlaku sejak 5 Maret 2026**, sedangkan pencantuman *Carcharhinidae spp.* pada Appendix II berlaku dengan pengecualian spesies yang termasuk Appendix I.
   - **Data pendaratan yang hanya teridentifikasi sebagai *Carcharhinus* spp. tidak boleh otomatis diberi status Appendix I atau Appendix II pada tingkat spesies tanpa identifikasi taksonomi lebih lanjut.**
9. **Penyimpanan Lima Atribut Taksonomi Wajib:**
   Sistem wajib menyimpan lima atribut taksonomi berikut dalam basis data dan GeoJSON:
   - `identified_taxon_name`: Nama takson hasil pencatatan asli (misal: *Carcharhinus spp.* / Cucut).
   - `taxonomic_resolution_level`: Tingkat resolusi taksonomi (misal: Genus).
   - `cites_status_and_appendices_date`: Status CITES dan tanggal referensi Appendices resmi (misal: *CITES Appendix II Carcharhinidae spp. Family listing; Reference Date: 5 Maret 2026*).
   - `identification_verification_status`: Status verifikasi identifikasi (misal: *Unverified Landing Record / Genus-Level Only*).
   - `taxonomic_uncertainty_notes`: Catatan ketidakpastian taksonomi apabila identifikasi hanya sampai tingkat genus atau famili tanpa bukti morfometrik gigi/sirip atau uji DNA.
10. **Status Tetap sebagai Kandidat Penapisan:**
    Sampai tersedia data empiris pemantauan *bycatch* (dari *scientific observer on-board*, kamera pemantau elektronik, atau penandaan satelit) yang memiliki informasi taksa spesies, waktu kejadian, titik koordinat lintang-bujur, jenis alat tangkap, dan upaya penangkapan riil, **seluruh 123 poligon tetap berstatus kandidat penyaringan batimetri (*candidate bathymetric screening polygons*)**.

---

### 3.4 Protokol 4: Supremasi Regulasi dan Otoritas Resmi

1. **Status Informasi Pendukung Keputusan Akademis:**
   Seluruh hasil analisis, prediksi spasial, dan skor pada sistem Phase 4 merupakan **informasi pendukung keputusan akademis (*academic decision-support information*)** dan **TIDAK MEMPUNYAI KEKUATAN HUKUM SEBAGAI INSTRUMEN PERIZINAN, PENGATURAN PELAYARAN, ATAU PENETAPAN KAWASAN KONSERVASI**.
2. **Dasar Hukum Perundang-undangan Terbaru:**
   Rujukan hukum sistem perikanan dan pelayaran wajib memperhatikan perubahan peraturan perundang-undangan Republik Indonesia yang berlaku, sekurang-kurangnya:
   - **Peraturan Menteri Kelautan dan Perikanan Nomor 7 Tahun 2026 tentang Kesyahbandaran di Pelabuhan Perikanan**.
   - **Undang-Undang Nomor 31 Tahun 2004 tentang Perikanan** sebagaimana telah diubah, termasuk melalui **Undang-Undang Nomor 45 Tahun 2009** dan **Undang-Undang Nomor 6 Tahun 2023** (UU Penetapan Perppu Cipta Kerja menjadi Undang-Undang).
   - **Undang-Undang Nomor 17 Tahun 2008 tentang Pelayaran** sebagaimana telah diubah terakhir dengan **Undang-Undang Nomor 66 Tahun 2024** (Perubahan Ketiga atas UU Pelayaran).
3. **Kewenangan Mutlak Kesyahbandaran:**
   Pelaksanaan kewenangan penerbitan **Surat Persetujuan Berlayar (SPB)**, pemeriksaan kelaiklautan kapal penangkap ikan, dan pengawasan keselamatan pelayaran dilakukan secara sah oleh **Syahbandar di Pelabuhan Perikanan yang berwenang sesuai peraturan perundang-undangan**. Sistem DSS dilarang bertindak seolah-olah menggantikan fungsi Syahbandar.
4. **Rujukan Informasi Meteorologi dan Peringatan Dini Maritim:**
   Seluruh parameter cuaca laut, tinggi gelombang, kecepatan angin, dan peringatan dini cuaca ekstrem maritim wajib merujuk secara resmi pada **Badan Meteorologi, Klimatologi, dan Geofisika (BMKG)** melalui Stasiun Meteorologi Maritim yang berwenang.

---

### 3.5 Protokol 5: Data Provenance, Freshness, and Validity

1. **Metadata Wajib Setiap Lapisan (Layer DSS):** Setiap lapisan spasial dan keluaran DSS pada Phase 4 wajib menampilkan metadata dinamis yang mencakup:
   - `data_source`: Nama institusi/sensor penyedia data asli.
   - `observation_timestamp`: Waktu perekaman citra/pengukuran fisik asli.
   - `processing_timestamp`: Waktu pemrosesan data oleh pipeline sistem.
   - `spatial_temporal_resolution`: Resolusi kisi spasial dan interval waktu.
   - `freshness_latency_status`: Status jeda waktu data terhadap waktu riil.
   - `interpolation_flag`: Penandaan eksplisit data observasi langsung vs estimasi/gap-fill.
   - `model_version`: Nomor versi algoritma SDM atau mesin pendukung keputusan.
   - `validity_boundaries`: Batasan domain operasional spasial (Sub-AOI Prigi).
2. **Pemisahan Data Historis/Reanalisis vs Data Prakiraan Operasional:**
   - **DILARANG KERAS** memperlakukan data reanalisis historis (seperti ERA5 atau GLORYS) seolah-olah merupakan data prakiraan operasional harian (*operational weather forecasts*).
   - Data historis hanya boleh ditampilkan sebagai rujukan tren klimatologis musiman.
3. **Penandaan Data Kedaluwarsa (*Stale Data Tagging*):**
   - Data lingkungan yang telah melewati batas usia validitas operasionalnya atau gagal terhubung dengan feed satelit/BMKG wajib ditandai secara visual dengan status **`DATA KEDALUWARSA`**, **`FEED TERPUTUS`**, atau **`TIDAK TERSEDIA`**.
   - Sistem dilarang melakukan ekstrapolasi semu saat data real-time tidak tersedia.

---

## 4. LARANGAN MUTLAK PENGEMBANGAN PHASE 4 (*PROHIBITED ACTIONS*)

1. **DILARANG MEMBUAT DATA GPS PRESENSI TANGKAP FIKTIF:** Jangan mengarang koordinat lintang-bujur posisi kapal untuk melatih modul rute kapal (*vessel routing*) Phase 4.
2. **DILARANG MENETAPKAN LARANGAN ZONASI ATAU KEDALAMAN MANDIRI:** Jangan membuat zona larangan tangkap (*no-take marine reserves*) atau larangan kedalaman 200m tanpa dasar Kepmen-KP dan bukti ilmiah empiris.
3. **DILARANG MENGEKSTRAPOLASI MODEL KE LUAR SUB-AOI PRIGI:** Model tidak boleh diterapkan untuk memprediksi penangkapan ikan di luar batas bujur $111^\circ\text{–}113^\circ\text{ E}$ dan lintang $-8.0^\circ\text{–}-10.45^\circ\text{ S}$.
4. **DILARANG MENGGUNAKAN LABEL "AMAN" SEBAGAI JAMINAN MUTLAK:** Keselamatan di laut bersifat dinamis dan bergantung pada evaluasi multivariat kapal dan nakhoda.
5. **DILARANG MEROMBAK DESAIN DASBOR TANPA DASAR ILMIAH:** Struktur dasbor mandiri bebas CORS yang telah teruji (*standalone zero-CORS*) wajib dipertahankan.

---

## 5. KESIMPULAN

Pelaksanaan Phase 4 hanya dapat dimulai apabila seluruh modul yang dirancang mematuhi kelima protokol di atas. Dengan mematuhi batasan ini, Phase 4 akan menghasilkan sistem pendukung keputusan yang kredibel, menjunjung keselamatan nelayan, melindungi spesies laut terancam, dan selaras dengan hukum perikanan Republik Indonesia.
