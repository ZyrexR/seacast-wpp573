# PHASE 3.1 — ECOLOGICAL ZONATION & BYCATCH MITIGATION REVIEW
## Tinjauan Ilmiah Zonasi Ekologis Fungsional, Validitas Taksonomi Cucut (*Carcharhinus spp.*), dan Efektivitas Mitigasi
### WPPNRI 573 × PPN Prigi Spatial Fisheries Intelligence System

**Tanggal Audit:** 31 Oktober 2026  
**Auditor:** Senior Fisheries Ecologist, Marine Protected Area (MPA) Specialist & Scientific Auditor  
**Status Evaluasi:** SELESAI & TEREVISI SECARA BIOLOGIS (100% COMPLIANT)  
**Dokumen Induk:** Proyek Intelijen Geospasial Perikanan Pelagis PPN Prigi — WPPNRI 573  

---

## 1. PENDAHULUAN & RUANG LINGKUP EVALUASI ZONASI

Evaluasi ini dilakukan untuk mereview produk zonasi fungsional ekologis (`outputs/sdm/zones/functional_ecological_zones.geojson`) dan zonasi mitigasi tangkapan sampingan dinamis (`outputs/sdm/zones/dynamic_bycatch_mitigation_zones.geojson`) yang dihasilkan pada Phase 3.

Fokus peninjauan mencakup empat aspek kritis:
1. Menegaskan batasan bahwa seluruh zona fungsional (PFG, Feeding, Nursery, Spawning) merupakan **proksi spasial (*screening advisory proxies*)**, bukan verifikasi empiris lapangan.
2. Membakukan klasifikasi taksonomi hiu cucut pada tingkat genus **`Carcharhinus spp.`** dan mengeliminasi spekulasi tingkat spesies.
3. Memisahkan secara tegas antara data pendaratan pelabuhan (*landing statistics*) dengan lokasi kejadian *bycatch* aktual di laut lepas.
4. Mendekonstruksi 123 poligon *bycatch* sebagai **lapisan penapisan hipotetis (*spatial screening overlay*)**, bukan *verified hotspots*, serta mengevaluasi validitas teknis penerapan *circle hooks*.

---

## 2. DEKONSTRUKSI ZONASI FUNGSIONAL EKOLOGIS

Berdasarkan analisis file `functional_ecological_zones.geojson` (1.920 sel fitur), model membagi perairan Sub-AOI Prigi ke dalam lima kelas fungsional. Auditor menetapkan interpretasi resmi berikut:

```
+-----------------------------------------------------------------------------------------+
|                  INTERPRETASI RESMI KELAS ZONASI FUNGSIONAL                             |
+-----------------------------------------------------------------------------------------+
| Kelas Fitur                      | Basis Algoritma Spasial     | Status Interpretasi Baku|
+----------------------------------+-----------------------------+-------------------------+
| Potential Fishing Ground (PFG)   | RHSI >= 0.70 & Buffer Armada| PROKSI ADVISORI (Bukan  |
| - Inshore (<10 GT, <=12 NM)      |                             | koordinat tangkap pasti)|
| - Offshore (20-30 GT, <=60 NM)   |                             |                         |
+----------------------------------+-----------------------------+-------------------------+
| Potential Feeding Ground         | Front Sobel >= 0.08°C/km &  | PROKSI BIOFISIK (Bukan  |
|                                  | Chlorophyll-a >= 0.40 mg/m³ | bedah lambung / mangsa) |
+----------------------------------+-----------------------------+-------------------------+
| Potential Nursery Ground Proxy   | Kedalaman < 50m, Jarak <12NM| PROKSI RETENSI HIDRO-   |
|                                  | Perairan Teluk Terlindung   | DINAMIKA (Bukan larva)  |
+----------------------------------+-----------------------------+-------------------------+
| Potential Spawning Ground Proxy  | SST 26-28°C, Oseanotropis   | PROKSI KLIMATOLOGIS     |
|                                  | Jarak Lepas Pantai > 25 NM  | (Bukan gonad / telur)   |
+----------------------------------+-----------------------------+-------------------------+
```

### Mandat Nomenklatur Laporan:
- **DILARANG MENGGUNAKAN KATA:** *"Verified Fishing Ground"*, *"Confirmed Nursery Area"*, atau *"Proven Spawning Sanctuary"*.
- **WAJIB MENGGUNAKAN KATA:** *"Potential Fishing Ground Advisory"*, *"Nursery Habitat Proxy"*, dan *"Spawning Environmental Envelope"*.

---

## 3. AUDIT TAKSONOMI DAN RISIKO BYCATCH HIU CUCUT

### 3.1 Pembakuan Taksonomi Genus: *Carcharhinus spp.*
- **Kondisi Sumber Data:** Buku statistik PPN Prigi (Sheet 5) mencatat komoditas tangkapan hanya dengan nama lokal **"Cucut"** atau **"Cucut Tikus"** (total pendaratan 2015–2025: $171.196\text{ kg}$).
- **Koreksi Ilmiah:** Di pelabuhan perikanan Indonesia, nelayan sering menggunakan nama "cucut" untuk berbagai hiu dari famili Carcharhinidae (*requiem sharks*) dan Sphyrnidae (*hammerhead sharks*). 
- Tanpa adanya bukti dokumentasi taksonomi morfometrik (jumlah celah insang, struktur dentisi rahang, posisi sirip punggung pertama relatif terhadap sirip dada) atau analisis genetik DNA barcoding, **identifikasi spesies tunggal (misalnya *Carcharhinus falciformis* atau *Carcharhinus obscurus*) secara ilmiah TIDAK DAPAT DITERIMA**.
- **Keputusan:** Taksonomi resmi sistem **DIBEKUKAN PADA TINGKAT GENUS: `Carcharhinus spp.`**.

### 3.2 Pemisahan Statistik Pendaratan dari Titik Tangkap
- Catatan pendaratan cucut di dermaga PPN Prigi menunjukkan volume kumulatif yang didaratkan oleh kapal motor pancing ulur atau jaring insang dasar.
- **Peringatan Integritas Data:** Mencocokkan angka kilogram pendaratan di dermaga Prigi dengan koordinat laut lepas tertentu adalah *ecological fallacy*. Nelayan dapat menangkap cucut pada jarak 10 NM hingga 50 NM di berbagai lintang dan bujur. Titik tangkap sesungguhnya tidak pernah dicatat dalam logbook pelabuhan.

---

## 4. DEKONSTRUKSI 123 POLIGON PENAPISAN BYCATCH

Arsip `outputs/sdm/zones/dynamic_bycatch_mitigation_zones.geojson` memuat **123 poligon penapisan spasial**:

```
+-----------------------------------------------------------------------------------------+
|                  KARAKTERISTIK 123 POLIGON SCREENING BYCATCH                            |
+-----------------------------------------------------------------------------------------+
| Total Poligon     | 123 Fitur GeoJSON (Kisi 0.05°)                                      |
| Rentang Kedalaman | -150 meter s/d -1.200 meter (Zona Tubir / Continental Slope)        |
| Karakteristik Suhu| 24.5°C - 26.0°C (Lapisan Termoklin Dangkal Monsun Timur)            |
| Interaksi Spesies | Tumpang tindih dengan RHSI Tinggi Cakalang/Madidihang (> 0.85)      |
| Status Ilmiah     | SPATIAL SCREENING OVERLAY (Bukan Verified Bycatch Hotspot)          |
+-----------------------------------------------------------------------------------------+
```

### 4.1 Koreksi Status "Hotspot"
123 poligon ini **BUKAN** titik kejadian interaksi hiu yang telah diverifikasi di lapangan (*field-verified bycatch incidents*). Poligon ini semata-mata merupakan zona bertemunya kesesuaian habitat pelagis target dengan batas fisiologis hiu carcharhinid berdasarkan preferensi kedalaman lereng benua (*continental slope*).

---

## 5. EVALUASI KELAYAKAN TEKNIS CIRCLE HOOKS

Dalam metadata awal, direkomendasikan penggunaan *Circle Hooks* untuk seluruh mitigasi tangkapan sampingan. Evaluasi ilmiah menetapkan batasan ketat berikut:

### 5.1 Validitas Ilmiah Circle Hooks (Gilman et al., 2006; Serafy et al., 2012)
- **Alat Tangkap yang Tepat:** *Circle Hooks* (ukuran 16/0 atau 18/0 dengan *non-offset* atau *offset* $<10^\circ$) **HANYA EFEKTIF DAN RELEVAN pada alat tangkap Pancing Rawai Tuna (*Tuna Longline*) dan Pancing Ulur Kedalaman (*Deep Handline*)**.
- **Mekanisme Biologis:** Desain melingkar menyebabkan mata pancing tergelincir dari kerongkongan atau lambung ikan hiu dan hanya mengait pada bibir atau sudut rahang (*jaw hooking*). Hal ini mengurangi pendarahan internal organ vital, menurunkan mortalitas pasca-tangkap (*post-release mortality*), dan memudahkan nelayan memotong tali (*wire leader*) untuk melepas hiu dalam kondisi hidup.

### 5.2 Alat Tangkap yang TIDAK RELEVAN untuk Circle Hooks
- **Pukat Cincin (*Purse Seine*):** Pukat cincin adalah jaring lingkar tanpa mata pancing! Merekomendasikan circle hooks untuk kapal pukat cincin adalah kesalahan fatal konseptual.
  * Mitigasi Pukat Cincin yang Benar: Penggunaan rumpon ramah lingkungan tanpa jaring gantung (*Non-Entangling FADs*), penyortiran cepat sebelum penarikan jaring ke geladak (*brailing*), dan pelepasan hidup-hidup menggunakan kanvas tandu (*shark scoop net*).
- **Jaring Insang (*Drift Gillnet*):** Tidak menggunakan kait pancing. Mitigasi yang tepat adalah penurunan tali ris atas di bawah 3 meter dari permukaan laut untuk menghindari paparan permukaan, atau pemasangan perangkat akustik pengusir (*pingers*).

---

## 6. KESIMPULAN TASK 8

1. Seluruh zona fungsional ekologis telah dikonfirmasi statusnya sebagai **proksi spasial eksploratif (*exploratory screening advisories*)**.
2. Taksonomi hiu cucut dibakukan secara ketat pada tingkat genus: **`Carcharhinus spp.`**.
3. Hubungan antara catatan pendaratan dermaga dengan titik tangkap laut telah dipisahkan secara tegas guna mencegah penyesatan spasial.
4. Keberadaan 123 poligon diakui sebagai lapisan penapisan risiko kedalaman-suhu (*screening overlay*), bukan *verified hotspots*.
5. Rekomendasi *Circle Hooks* dibatasi secara ilmiah hanya untuk armada pancing rawai/ulur, dengan panduan alternatif mitigasi yang sesuai bagi armada pukat cincin dan jaring insang.
