# PHASE 4 REVISION CHANGELOG
## Dokumentasi Riwayat Perubahan, Justifikasi Ilmiah, Landasan Regulasi, dan Pemeliharaan Keterbatasan Empiris
### Sistem Intelijen Geospasial Perikanan Pelagis PPN Prigi — WPPNRI 573

---

| Informasi Dokumen | Catatan Formal |
| :--- | :--- |
| **Versi Dokumen** | 2.0.0 (Final Revision Gate) |
| **Tanggal Pemutakhiran** | 1 November 2026 |
| **Penyusun** | Tim Auditor Saintifik, Geospatial Data Engineer, Oseanografer Fisik, dan Arsitek Sistem |
| **Dokumen yang Direvisi** | `PHASE_4_PRECONDITIONS.md` $\rightarrow$ `PHASE_4_PRECONDITIONS_FINAL.md` |
| **Konfigurasi Mesin** | `PHASE_4_READINESS_GATE.json` |
| **Status Otorisasi** | **BINDING / RESMI DITERAPKAN** |

---

## 1. RINGKASAN EKSEKUTIF REVISI

Revisi final dokumen prasyarat Phase 4 dilaksanakan untuk menyempurnakan ketepatan matematis, ketelitian terminologi kelautan/perkapalan, kepatuhan taksonomi konservasi internasional (CITES), dan penyelarasan peraturan perundang-undangan nasional Republik Indonesia yang berlaku per 1 November 2026.

Revisi ini **sama sekali tidak mengubah, melemahkan, atau memanipulasi empat keterbatasan empiris mendasar (*fundamental empirical constraints*)**, tidak merekayasa data baru, tidak mengubah batas koordinat Sub-AOI Prigi, serta tidak mengubah total volume produksi perikanan terekonsiliasi (**18.405.261 kg**) dan trip masa studi (**189.334 trip**). 

---

## 2. MATRIKS PERUBAHAN KOMPREHENSIF (SEBELUM VS SESUDAH)

Berikut adalah tabel perbandingan antara draft pendahuluan dengan dokumen revisi final beserta dasar pemikiran ilmiah, teknis, dan hukumnya:

```
+=======================================================================================================================================+
|                                    MATRIKS PERBANDINGAN REVISI DOKUMEN DAN KONFIGURASI PHASE 4                                        |
+----+-----------------------------+-------------------------------+-----------------------------------+-------------------------------+
| No | Komponen Sistem             | Kondisi Sebelum Revisi        | Kondisi Setelah Revisi Final      | Dasar Pemikiran & Rujukan     |
+----+-----------------------------+-------------------------------+-----------------------------------+-------------------------------+
| 1  | Formulasi Bobot Ensemble    | Bobot model belum dirumuskan  | Dinormalisasi secara ketat:       | Mencegah pembiasan skala dan  |
|    | (PROT-01)                   | secara matematis tegas.       | w_i >= 0 dan sum(w_i) = 1.        | distorsi kontribusi model.    |
+----+-----------------------------+-------------------------------+-----------------------------------+-------------------------------+
| 2  | Ukuran Ketidaksepakatan     | sigma_w belum diberi batasan  | sigma_w = sqrt(sum(w_i*(RHSI_i -  | Menegaskan sigma_w BUKAN      |
|    | Ensemble (PROT-01)          | definisi statistik formal.    | RHSI_bar_w)^2)); didefinisikan sbg| biological uncertainty dan    |
|    |                             |                               | weighted ensemble disagreement.   | BUKAN confidence interval.    |
+----+-----------------------------+-------------------------------+-----------------------------------+-------------------------------+
| 3  | Rentang Penalti & Skenario  | Nilai lambda hanya disebut    | lambda in [0, 1], baseline = 0.5; | Menjamin objektivitas dan     |
|    | Sensitivitas (PROT-01)      | dasar 0.5 tanpa skenario uji. | 5 skenario sensitivitas wajib:    | transparansi perilaku skor    |
|    |                             |                               | {0.00, 0.25, 0.50, 0.75, 1.00}.   | terhadap penalti ketidakpastian|
+----+-----------------------------+-------------------------------+-----------------------------------+-------------------------------+
| 4  | Ambang Klasifikasi Skor     | Nilai 0.60 sempat diasumsikan | Ambang 0.60 didefinisikan sebagai | Standar ambang batas habitat  |
|    | PFG (PROT-01)               | standar universal.            | nilai eksploratif; wajib dievaluasi| sangat bergantung pada wilayah|
|    |                             |                               | thd fraksi area dan musim.        | dan spesies sasaran.          |
+----+-----------------------------+-------------------------------+-----------------------------------+-------------------------------+
| 5  | Arsitektur Penyimpanan Skor | Hanya menyimpan skor akhir    | Dual-Score Storage:               | Menjaga audit trail matematis |
|    | PFG (PROT-01)               | setelah clipping.             | raw_advisory_score (unclipped) &  | sekaligus keamanan visualisasi|
|    |                             |                               | visualization_score (clipped [0,1)| pengguna akhir.               |
+----+-----------------------------+-------------------------------+-----------------------------------+-------------------------------+
| 6  | Terminologi Lambung Kapal   | Tercampur istilah rancu       | Dipisahkan mutlak:                | Istilah 'freeboard draft'     |
|    | (PROT-02)                   | "freeboard draft".            | freeboard_m (lambung timbul) dan  | adalah kekeliruan terminologi |
|    |                             |                               | draft_m (sarat kapal).            | arsitektur perkapalan (naval).|
+----+-----------------------------+-------------------------------+-----------------------------------+-------------------------------+
| 7  | Parameter Angin (PROT-02)   | Kadang hanya kecepatan angin  | Wajib memisahkan sustained wind   | Hembusan sesaat (gust) sering |
|    |                             | rata-rata.                    | speed dan wind gust secara nyata. | memicu pembalikan kapal kecil.|
+----+-----------------------------+-------------------------------+-----------------------------------+-------------------------------+
| 8  | Evaluasi Risiko Armada      | Bergantung dominan pada       | Multivariat: stabilitas, muatan   | GT bukan penentu tunggal      |
|    | (PROT-02)                   | Gross Tonnage (GT).           | (berangkat vs pulang), trip prof. | kelaiklautan cuaca laut.      |
+----+-----------------------------+-------------------------------+-----------------------------------+-------------------------------+
| 9  | Prinsip Pemicu Risiko       | Agregasi berpotensi mengabur- | Prinsip Indikator Tertinggi       | Precautionary principle:      |
|    | (PROT-02)                   | kan variabel ekstrem.         | (Worst-Case Trigger) aktif.       | satu bahaya ekstrem cukup.    |
+----+-----------------------------+-------------------------------+-----------------------------------+-------------------------------+
| 10 | Penanganan Feed Terputus    | Status keselamatan berisiko   | Wajib tampilkan: DATA KEDALUWARSA,| Mencegah persepsi aman palsu  |
|    | BMKG (PROT-02)              | dipertahankan saat offline.   | FEED TERPUTUS, TIDAK TERSEDIA.    | (false sense of security).    |
+----+-----------------------------+-------------------------------+-----------------------------------+-------------------------------+
| 11 | Nomenklatur Zona Kedalaman  | Rentang lereng tubir benua    | Nomenklatur resmi: Exploratory    | Standarisasi peristilahan     |
|    | Batimetri (PROT-03)         | disebut beragam.              | Bathymetric Screening Band        | akademik dan oseanografi.     |
|    |                             |                               | (150–1,200 m).                    |                               |
+----+-----------------------------+-------------------------------+-----------------------------------+-------------------------------+
| 12 | Asumsi Datum GEBCO 2023     | Sempat diasumsikan MSL seragam| Penegasan: GEBCO adalah sintesis  | Koreksi ilmiah geodesi laut;  |
|    | (PROT-03)                   | pada seluruh sel kisi.        | multi-sumber dgn datum bervariasi | grid global memadukan sounding|
|    |                             |                               | yang diselaraskan secara aproks.  | dan altimetri gravitasi.      |
+----+-----------------------------+-------------------------------+-----------------------------------+-------------------------------+
| 13 | Distingsi Termoklin vs      | Sempat tumpang tindih dalam   | Dipisahkan: thermocline_depth /   | Menghindari kekeliruan fisik; |
|    | Upwelling (PROT-03)         | penarikan kesimpulan.         | Z20 vs Delta T_co & Ekman Mey.    | termoklin = stratifikasi;     |
|    |                             |                               | Klorofil bukan bukti mangsa instan| upwelling = proses adveksi.   |
+----+-----------------------------+-------------------------------+-----------------------------------+-------------------------------+
| 14 | Rekomendasi Alat Tangkap    | Circle hooks sempat terkesan  | Khusus rawai/pancing ulur; pukat  | Circle hooks tidak efektif    |
|    | Mitigasi Hiu (PROT-03)      | direkomendasikan umum.        | cincin diarahkan ke edukasi NEFAD | untuk jaring; utamakan crew   |
|    |                             |                               | & safe release (crew safety utuh).| safety nelayan.               |
+----+-----------------------------+-------------------------------+-----------------------------------+-------------------------------+
| 15 | Status Regulasi CITES       | Referensi Appendices belum    | CITES Appendices berlaku per 5    | CoP CITES menetapkan          |
|    | Famili Hiu (PROT-03)        | rinci per tanggal dan takson. | Maret 2026: Carcharhinidae App II | C. longimanus di Appendix I,  |
|    |                             |                               | kecuali C. longimanus di App I.   | sedangkan famili di App II.   |
+----+-----------------------------+-------------------------------+-----------------------------------+-------------------------------+
| 16 | Klasifikasi Cucut Pelabuhan | Berpotensi dispekulasikan ke  | Data Cucut dilarang diklasifikasi | Integritas taksonomi empiris; |
|    | (PROT-03)                   | spesies terancam punah.       | otomatis ke spesies tanpa DNA/foto| diberi status NEEDS_VERIF.    |
+----+-----------------------------+-------------------------------+-----------------------------------+-------------------------------+
| 17 | Atribut Taksonomi GeoJSON   | Sebelumnya 5 atribut taksonomi| Disempurnakan menjadi 8 atribut   | Standarisasi basis data       |
|    | (PROT-03)                   | pada draf awal.               | terstruktur lengkap dgn rujukan.  | biodiversitas global (GBIF).  |
+----+-----------------------------+-------------------------------+-----------------------------------+-------------------------------+
| 18 | Rujukan Hukum Nasional      | Masih merujuk UU 17/2008 &    | Dimutakhirkan: Permen-KP 7/2026,  | Sinkronisasi regulasi         |
|    | (PROT-04)                   | UU 31/2004 versi lama.        | UU 6/2023 (Ciptaker), dan UU      | maritim dan perikanan yang    |
|    |                             |                               | 66/2024 (Perubahan III Pelayaran).| berkekuatan hukum aktif.      |
+----+-----------------------------+-------------------------------+-----------------------------------+-------------------------------+
| 19 | Nomenklatur Kesyahbandaran  | "Syahbandar Perikanan" atau   | Wajib: "Syahbandar di Pelabuhan   | Mengikuti klausul legal formal|
|    | (PROT-04)                   | sebutan singkat lainnya.      | Perikanan yang berwenang sesuai   | Permen-KP No. 7 Tahun 2026.   |
|    |                             |                               | peraturan perundang-undangan".    |                               |
+----+-----------------------------+-------------------------------+-----------------------------------+-------------------------------+
| 20 | Pembatasan Data Reanalisis  | Belum ada klausul tegas       | ERA5/GLORYS diizinkan utk analisis| Mencegah kekeliruan fatal     |
|    | (PROT-05)                   | pemanfaatan reanalisis.       | retrospektif/training/klimatologi;| antara data masa lalu dan     |
|    |                             |                               | dilarang sbg prakiraan masa depan.| prakiraan cuaca operasional.  |
+----+-----------------------------+-------------------------------+-----------------------------------+-------------------------------+
| 21 | Klasifikasi data_type       | Kategori tipe data belum      | 4 Tipe Resmi: HISTORICAL,         | Standarisasi arsitektur data  |
|    | (PROT-05)                   | dibakukan dalam skema.        | REANALYSIS, OBSERVATION, FORECAST.| spasial kelautan.             |
+----+-----------------------------+-------------------------------+-----------------------------------+-------------------------------+
| 22 | Metadata Provenance         | Draf awal menyebut 8 field    | Disempurnakan menjadi 16 atribut  | Transparansi saintifik dan    |
|    | (PROT-05)                   | metadata.                     | provenance wajib secara lengkap.  | auditabilitas menyeluruh.     |
+----+-----------------------------+-------------------------------+-----------------------------------+-------------------------------+
| 23 | Gerbang Kesiapan Mesin      | Draf awal menggunakan matriks | Distandarisasi ke 12 Machine-     | Evaluasi gerbang otomatis yang|
|    | JSON (PG-01 s/d PG-12)      | evaluasi umum.                | Readable Checks (PG-01 s/d PG-12).| sinkron 1:1 dengan Markdown.  |
+----+-----------------------------+-------------------------------+-----------------------------------+-------------------------------+
```

---

## 3. RINCIAN KETENTUAN FUNDAMENTAL YANG DIPERTAHANKAN TANPA PERUBAHAN (*PRESERVED PROVISIONS*)

Revisi ini secara sadar mempertahankan pilar-pilar saintifik dan batasan empiris yang telah divalidasi pada Phase 1, Phase 2, dan Phase 3.1:

1. **Empat Keterbatasan Empiris Mendasar (*The Four Blocking Constraints*):**
   - Ketiadaan koordinat GPS titik tangkap empiris (VMS/AIS/e-Logbook) tetap diakui sebagai realitas data sekunder pelabuhan;
   - Sirkularitas heuristik 981 titik proksi tetap diakui sehingga luaran model diwajibkan menggunakan terminologi RHSI;
   - Batasan domain spasial Sub-AOI Prigi ($111,0^\circ\text{–}113,0^\circ\text{ E}$, $-8,00^\circ\text{–}-10,45^\circ\text{ S}$, mencakup 4,16% WPPNRI 573) tetap dipertahankan dan dilarang diekstrapolasi;
   - Ketiadaan survei lapangan in-situ hiu tetap dipertahankan, sehingga 123 poligon lereng batimetri berstatus murni sebagai instrumen penapisan sukarela, bukan kawasan konservasi atau zona larangan tangkap (*no-take zone*).

2. **Angka Produksi dan Trip Perikanan Hasil Rekonsiliasi Definitif:**
   - Total produksi kumulatif pelagis besar (2015–2025): **18.405.261 kg** (setelah koreksi galat tipografi +200 kg pada April 2022 di sel P96);
   - Total trip penangkapan ikan masa studi (2015–2025): **189.334 trip**;
   - Total trip historis keseluruhan dalam buku statistik (2012–2025): **249.257 trip** (di mana 59.923 trip pra-studi 2012–2014 diisolasi secara transparan).

3. **Integritas Deret Waktu Oseanografi:**
   - Kontinuitas 132 bulan data oseanografi lingkungan (Januari 2015 s/d Desember 2025) tanpa kekosongan kalender tetap dipertahankan;
   - Pelabelan bulan-bulan dengan tutupan awan tinggi (DJF) yang diisi melalui interpolasi spasial/temporal tetap dipertahankan secara jujur.

4. **Arsitektur Antarmuka Bebas Hambatan Jaringan (*Zero-CORS Standalone*):**
   - Desain dasbor mandiri berbasis HTML5/JS (`html/index.html`, `html/sdm_data.js`, `html/oceanographic_data.js`) yang dapat dijalankan secara luring (*offline*) tanpa memerlukan server web atau mengalami pemblokiran CORS tetap dipertahankan.

---

## 4. DOKUMENTASI MENDALAM ITEM BERSTATUS `NEEDS_VERIFICATION`

Pada dokumen konfigurasi `PHASE_4_READINESS_GATE.json`, parameter **`PG-09` (CITES taxonomy verification)** ditetapkan dengan status **`NEEDS_VERIFICATION`**. Keputusan ini mencerminkan kejujuran akademis dan standar verifikasi ilmiah yang ketat:

### 4.1 Identifikasi Masalah Empiris pada Data Pendaratan Pelabuhan
1. **Pencatatan Agregat Tingkat Genus / Nama Lokal:**
   Di Tempat Pelelangan Ikan (TPI) dan buku statistik PPN Prigi, pendaratan elasmobranchii dicatat di bawah kategori nama lokal "Cucut" atau kategori taksonomi umum *Carcharhinus spp.* (Family Carcharhinidae).
2. **Ketiadaan Bukti Taksonomi Primer:**
   Pencatatan statistik pelabuhan tidak disertai:
   - Pengukuran morfometrik diagnostik (seperti rasio panjang moncong terhadap lebar mulut, bentuk lekukan cuping sirip dada, atau rumus gigi);
   - Koleksi fotodokumentasi spesimen segar dari berbagai sudut (*dorsal, ventral, lateral*);
   - Pengambilan sampel jaringan sirip atau otot untuk pengujian genetik (*DNA barcoding* mitokondria COI).
3. **Risiko Ilmiah dan Konsekuensi Hukum Regulasi:**
   - Dalam Appendices CITES yang berlaku efektif sejak 5 Maret 2026, satu spesies dari genus ini, yaitu ***Carcharhinus longimanus* (Oceanic whitetip shark), tercantum dalam CITES Appendix I**, yang melarang secara mutlak pemanfaatan komersial internasional dari hasil tangkapan di laut bebas.
   - Spesies anggota famili Carcharhinidae lainnya tercantum dalam **CITES Appendix II (*Family listing*)**, yang memerlukan dokumen verifikasi legalitas (*Non-Detriment Findings / NDF*) untuk perdagangan internasional.
   - Apabila sistem secara sepihak dan otomatis mengasumsikan data *Carcharhinus spp.* pendaratan Prigi sebagai *C. longimanus* (Appendix I), sistem melakukan kesalahan estimasi konservasi yang tidak berdasar. Sebaliknya, apabila sistem mengasumsikan seluruh pendaratan Cucut adalah Appendix II tanpa verifikasi, ada kemungkinan spesimen Appendix I terabaikan.

### 4.2 Tindakan Mitigasi yang Diterapkan pada Sistem Phase 4
1. **Penyimpanan Skema 8 Atribut Taksonomi Terstruktur:**
   Sistem telah menyediakan delapan bidang metadata taksonomi terstruktur dalam basis data dan GeoJSON dengan nilai bawaan:
   - `identified_taxon_name`: "Carcharhinus spp. (Cucut)"
   - `taxonomic_resolution_level`: "Genus"
   - `taxonomic_uncertainty_notes`: "Identifikasi terbatas pada tingkat genus; tidak ada catatan morfometrik atau DNA"
   - `identification_verification_status`: "NEEDS_VERIFICATION"
   - `cites_appendix`: "Undetermined at Species Level (Family Carcharhinidae listed on Appendix II, except C. longimanus on Appendix I)"
   - `cites_taxonomic_scope`: "Family Carcharhinidae spp. with exception of Appendix I species"
   - `cites_reference_date`: "2026-03-05"
   - `cites_verification_source`: "CITES Appendices in effect from 5 March 2026"
2. **Rencana Verifikasi Lapangan Jangka Panjang:**
   Status `NEEDS_VERIFICATION` hanya dapat ditingkatkan menjadi `PASS` apabila program enumerasi ilmiah, penempatan observer terlatih di pelabuhan, dan uji DNA barcoding telah dilaksanakan dan dipublikasikan secara resmi.

---

## 5. KESIMPULAN

Seluruh modifikasi yang didokumentasikan dalam changelog ini telah diintegrasikan secara utuh ke dalam:
1. `PHASE_4_PRECONDITIONS_FINAL.md`
2. `PHASE_4_READINESS_GATE.json`

Tidak ada kontradiksi, ketidakselarasan istilah, maupun perbedaan formulasi antara dokumen teks Markdown dan dokumen konfigurasi JSON. Sistem telah siap melangkah ke tahap perancangan prototipe Phase 4 dengan landasan sains yang kukuh.

---
*Disahkan oleh Tim Auditor Saintifik dan Arsitek Sistem Geospasial Perikanan pada tanggal 1 November 2026.*
