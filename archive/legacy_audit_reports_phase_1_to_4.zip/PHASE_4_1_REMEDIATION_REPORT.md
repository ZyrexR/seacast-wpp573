# PHASE 4.1 — BASELINE INTEGRITY REMEDIATION REPORT
## Sistem Intelijen Geospasial Perikanan Pelagis PPN Prigi — WPPNRI 573

- **Project:** Sistem Intelijen Geospasial Perikanan Pelagis PPN Prigi — WPPNRI 573
- **Phase:** Phase 4.1 — Baseline Integrity Remediation & Scientific Consistency
- **Date:** 2026-11-01
- **Status:** COMPLETED & PROGRAMMATICALLY VERIFIED (`7/7` Test Suites `PASS`)

---

## 1. Executive Summary

Phase 4.1 was executed strictly as a baseline integrity remediation and scientific consistency stage prior to any Phase 4.2–4.7 module construction. Every contradiction recorded in `PHASE_4_VALIDATION_PACKAGE/08_DATA_CONTRADICTION_REGISTER.md` (`CONF-01` through `CONF-18`) and all four runtime application defects (`BUG-01` through `BUG-04`) were remediated across data pipelines, derived JSON/CSV datasets, GeoJSON vector layers, JavaScript WebGIS bundles (`html/oceanographic_data.js`, `html/sdm_data.js`), the standalone WebGIS application (`html/index.html`), and the Streamlit application (`utils.py`, `pages/2_Iklim_dan_Laut.py`, `pages/5_Spesies_dan_Pengelolaan.py`).

---

## 2. Stage-by-Stage Remediation Summary

| Stage | Scope | Key Actions Executed | Verification Status |
| :--- | :--- | :--- | :--- |
| **Stage 0** | Read-Only Baseline Audit & Backup | Snapshotted 48 pre-remediation files with SHA-256 hashes in `backups/phase_4_1_pre_remediation/backup_manifest.json`; added `CONF-17` and `CONF-18` to Contradiction Register; produced `PHASE_4_1_BASELINE_AUDIT.md`. | `VERIFIED` |
| **Stage 1** | Data Integrity | Reconciled April 2022 (`198,246 kg`) and 132-month cumulative catch (`18,405,261 kg`) across `data/master_prigi_all_inclusive.csv`, `data/master.csv`, `monthly_stats_prigi.csv`, `ocean_fisheries_master_132m.json`, `annual_climatology.json`, `seasonal_climatology.json`, `html/oceanographic_data.js`, and `html/index.html`. Generated canonical `data/prigi_elasmobranch_bycatch_records.csv` (`127,452 kg`) and `data/species_traits.csv`. Disambiguated trips (`189,334` for 2015–2025 vs `249,257` for 2012–2025) and fleet (`443` active vessels in 2025). | `PASS (T-01, T-02)` |
| **Stage 2** | Spatial Integrity | Harmonized canonical Sub-AOI Prigi to `[111.00, 113.00]° BT × [-10.45, -8.00]° LS` (`50 × 41 = 2,050` grid centers at `0.05°` step; `59,550.43 km²` WGS84 equal-area; `4.18%` of WPPNRI 573). Clipped `prigi_shelf_break_200m.geojson` strictly to `[111.00, 113.00]° BT`. Synchronized `sst_mean`, `chl_mean`, `hs_mean` across master CSVs and HTML `masterData` with Sub-AOI Prigi series. Renamed `CUI` to `SST Contrast (ΔT coast-offshore)` and Ekman transport to `Meridional Ekman Transport (Mey)` with non-causal framing. | `PASS (T-03, T-04)` |
| **Stage 3** | Scientific Model Integrity | Documented heuristic equations honestly (`ml_training_executed_in_code = false`, `spatial_cv_executed_in_code = false`). Clamped 93 jittered background points in `target_group_background.geojson` strictly inside Sub-AOI (`0` out-of-bounds points). Implemented true weighted ensemble disagreement $\sigma_w = \sqrt{\sum_i w_i (RHSI_i - \overline{RHSI}_w)^2}$ across all `36,900` cell projections (`w_i = 0` contributes `0`), stored dual advisory scores (`raw_advisory_score` and `visualization_score`), and generated `outputs/sdm/hsi/rhsi_sensitivity_analysis.json`. | `PASS (T-05)` |
| **Stage 4** | Geospatial Bycatch Data | Clipped all 5 GeoJSON zone layers in `outputs/sdm/zones/` strictly to `[111.00, 113.00]° BT × [-10.45, -8.00]° LS` (`dynamic_bycatch_mitigation_zones.geojson`: `123` polygons, `3,653.23 km²` equal-area, `0` out-of-bounds vertices, `0` self-intersections, `0` overlaps). Embedded all 8 CITES fields (`identification_verification_status = "NEEDS_VERIFICATION"`, `cites_reference_date = "2026-03-05"`), preserved full polygon rings in `html/sdm_data.js`, and replaced `L.circleMarker` with `L.polygon` in `html/index.html`. | `PASS (T-06)` |
| **Stage 5** | Application Integrity | Fixed `switchView('view-sdm')` in `html/index.html` to initialize and resize `sdmMapInstance` and render Plotly charts; guarded legacy static chart calls; replaced hardcoded correlation matrix in `html/index.html` with verified `window.oceanCrossCorrelation` values; created `data/master.csv` and `data/species_traits.csv` so Streamlit `utils.get_master()` loads real canonical data (`dummy = False`). | `PASS (T-07)` |
| **Stage 6** | Readiness Gate Reconstruction | Built and executed `scratch/test_phase_4_1_integrity.py` to reconstruct `PHASE_4_1_READINESS_GATE.json` (`14` gate items: `11 PASS`, `2 PARTIAL`, `1 NEEDS_VERIFICATION`, `0 FAIL`). | `VERIFIED` |

---

## 3. Resolution Matrix for All 18 Contradictions (`CONF-01` .. `CONF-18`)

| ID | Contradiction Summary | Canonical Resolution Applied | Status |
| :--- | :--- | :--- | :--- |
| `CONF-01` | April 2022 landing discrepancy (`198,446` vs `198,246` kg) | Reconciled to audited Sheet 5 value `198,246 kg` across all CSV, JSON, JS, and HTML files. | `RESOLVED` |
| `CONF-02` | Cumulative 2015–2025 total discrepancy (`18,827,401` / `18,405,461` / `18,405,261` kg) | Reconciled to `18,405,261 kg` across all 8 data and UI files; `2022` annual total updated to `1,992,432 kg`; `Peralihan 1 (MAM)` seasonal total updated to `4,027,022 kg`. | `RESOLVED` |
| `CONF-03` | Trip totals (`249,257` vs `189,334` vs `166,731`) | Explicitly disambiguated `189,334` trips (2015–2025 study period, 132 months) vs `249,257` trips (2012–2025 all-inclusive archive). | `RESOLVED` |
| `CONF-04` | Active vessel count (`855` vs `443` units) | Standardized 2025 active fleet to `443` units (`296` `<10 GT`, `55` `10–20 GT`, `91` `20–30 GT`, `1` `>30 GT`) and labeled `855` as 2021 peak historical archive. | `RESOLVED` |
| `CONF-05` | Sub-AOI southern boundary (`-10.50°` vs `-10.45°` vs `-11.00°`) | Harmonized to `-10.45° LS` (`[111.00, 113.00]° BT × [-10.45, -8.00]° LS`) across `utils.py`, `html/index.html`, and all spatial configs. | `RESOLVED` |
| `CONF-06` | Grid cell count (`2,091` vs `2,050` vs `1,960`) | Harmonized to `50 × 41 = 2,050` grid centers (`49 × 40` intervals at `0.05°` step) across `processing_manifest.json`, `quality_control_report.json`, and `spatial_config_aoi.json`. | `RESOLVED` |
| `CONF-07` | Sub-AOI area (`59,206 km²` vs `59,550.43 km²`) | Documented exact WGS84 authalic/equal-area integral `59,550.43 km²` (`4.18%` of WPPNRI 573) alongside legacy spherical approximation note (`59,206 km²`). | `RESOLVED` |
| `CONF-08` | Dual SST/Chl-a series (WPP 573 broad vs Sub-AOI Prigi) | Synchronized `sst_mean`, `chl_mean`, `hs_mean` in `master_prigi_all_inclusive.csv`, `master.csv`, and `html/index.html` `masterData` to Sub-AOI Prigi series; added explicit `wpp573_*` columns to QC CSVs. | `RESOLVED` |
| `CONF-09` | Upwelling terminology (`CUI` vs `SST Contrast ΔT` and `Meridional Ekman Mey`) | Renamed to `SST Contrast (ΔT coast-offshore)` and `Meridional Ekman Transport (Mey)` across `variable_dictionary.json`, `ocean_fisheries_correlation.json`, and `html/index.html`; replaced hardcoded UI correlation matrix with actual verified values (`r = +0.365` to `+0.410`). | `RESOLVED` |
| `CONF-10` | Unweighted SD vs weighted ensemble disagreement $\sigma_w$ | Recomputed all `36,900` cell projections using $\sigma_w = \sqrt{\sum_i w_i (RHSI_i - \overline{RHSI}_w)^2}$ where $w_i = 0$ contributes $0$; stored `raw_advisory_score` and `visualization_score`. | `RESOLVED` |
| `CONF-11` | Claimed ML fitting & 5-fold spatial block CV vs heuristic curves | Set `ml_training_executed_in_code = false` and `spatial_cv_executed_in_code = false` across all metadata and UI labels; framed outputs strictly as heuristic `RHSI`. | `RESOLVED` |
| `CONF-12` | Species scope (`12` taxa vs `6` vs `3` vs `4`) | Clarified 3-tier scope: `12` canonical port landing taxa, `4` Streamlit macro-groups (`cakalang_kg`, `tuna_kg`, `tongkol_kg`, `tenggiri_kg`), and `3` SDM heuristic target species (`Cakalang`, `Madidihang`, `Albakor`). Synchronized IUCN statuses in `html/index.html`. | `RESOLVED` |
| `CONF-13` | Bycatch geometry degraded from `123` polygons to `circleMarker` points | Preserved full polygon rings in `html/sdm_data.js` and rendered all `123` features via `L.polygon` in `html/index.html`. | `RESOLVED` |
| `CONF-14` | Polygon edge overshoot (`0.025°` outside AOI) | Clipped all 5 SDM GeoJSON layers in `outputs/sdm/zones/` strictly to `[111.00, 113.00] × [-10.45, -8.00]` (`dynamic_bycatch_mitigation_zones.geojson`: `3,653.23 km²`, `6` clipped western-edge cells). | `RESOLVED` |
| `CONF-15` | Missing `data/master.csv` & `data/species_traits.csv` causing dummy fallback | Generated canonical `data/master.csv` (`132` rows, `18,405,261 kg`) and `data/species_traits.csv` (`6` rows); verified `utils.get_master()` returns `dummy = False`. | `RESOLVED` |
| `CONF-16` | Bathymetry source (`ETOPO 2022` vs `GEBCO 2023 & ETOPO1`) | Standardized to `GEBCO 2023 Grid & NOAA ETOPO1 Bedrock (multi-source composite without single uniform vertical datum)` across all metadata and UI labels. | `RESOLVED` |
| `CONF-17` | Stale April 2022 value (`198,446 kg`) in `monthly_stats_prigi.csv` | Updated `2022-04` row in `data/oceanographic/statistics/monthly/monthly_stats_prigi.csv` to `198,246 kg` (132-month sum = `18,405,261 kg`). | `RESOLVED` |
| `CONF-18` | Unclipped `prigi_shelf_break_200m.geojson` (`110.95°`–`113.05°`) & `bounds.south = -10.5` in seasonal grids | Interpolated and clipped `prigi_shelf_break_200m.geojson` strictly to `[111.00, 113.00]° BT` and updated `bounds.south` to `-10.45` across all 4 seasonal grid JSONs and pilot JSONs. | `RESOLVED` |
