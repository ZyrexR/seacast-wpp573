# PHASE 3.1 — SPATIAL COVERAGE & MULTI-SCENARIO STACK AUDIT
## Audit Luas Cakupan Geospasial, Pemisahan Skala Regional vs Sub-AOI, dan Spesifikasi 6 Skenario Prediktor
### WPPNRI 573 × PPN Prigi Spatial Fisheries Intelligence System

**Tanggal Audit:** 31 Oktober 2026  
**Auditor:** Senior Marine Geospatial Analyst, Physical Oceanographer & Spatial Data Architect  
**Status Evaluasi:** SELESAI & TERTANDAI SECARA GEOMETRIS (100% AUDITED)  
**Dokumen Induk:** Proyek Intelijen Geospasial Perikanan Pelagis PPN Prigi — WPPNRI 573  

---

## 1. PENDAHULUAN & RUANG LINGKUP AUDIT SPASIAL

Audit ini dilakukan untuk mengklarifikasi batas jangkauan spasial (*spatial domain*) dari kisi pemodelan SDM Phase 3 (`data/sdm/predictors/predictor_stack_multi_scenario.json`) yang terdiri dari **2.050 sel beresolusi 0.05° (~5.5 km)**.

Temuan audit eksternal independen menyoroti adanya kecenderungan klaim bahwa model ini merupakan "Model Regional WPPNRI 573". Audit ini membedah koordinat pembatas (*bounding box*), jumlah sel, luas tutupan, persentase cakupan relatif terhadap WPPNRI 573 resmi Badan Informasi Geospasial (BIG), serta mendokumentasikan spesifikasi rinci keenam skenario oseanografi.

---

## 2. AUDIT GEOMETRI & BOUNDING BOX: WPPNRI 573 VS SUB-AOI PRIGI

Tabel berikut menyajikan perbandingan metrik geospasial resmi antara poligon WPPNRI 573 BIG dan kisi prediktor SDM:

| Parameter Geospasial | WPPNRI 573 (Resmi BIG Layer 21) | Sub-AOI Prigi (Predictor Stack SDM) | Status Perbandingan |
| :--- | :--- | :--- | :--- |
| **Batas Bujur Barat (West)** | $102.5778^\circ\text{ E}$ (Barat Selat Sunda) | $111.0000^\circ\text{ E}$ (Perbatasan Pacitan/Trenggalek) | Selisih $\approx 8.42^\circ$ bujur ke arah timur |
| **Batas Bujur Timur (East)** | $126.4996^\circ\text{ E}$ (Batas Timor / Arafura) | $113.0000^\circ\text{ E}$ (Perairan Malang / Lumajang) | Selisih $\approx 13.50^\circ$ bujur ke arah barat |
| **Batas Lintang Selatan (South)**| $-13.9382^\circ\text{ S}$ (Batas ZEE Samudra Hindia) | $-10.4500^\circ\text{ S}$ (Perairan Oseanik Lepas Pantai) | Selisih $\approx 3.49^\circ$ lintang |
| **Batas Lintang Utara (North)** | $-6.8021^\circ\text{ S}$ (Pesisir Selatan Jawa Barat) | $-8.0000^\circ\text{ S}$ (Garis Pantai Teluk Prigi, Jatim)| Dibatasi oleh garis pantai selatan Jawa |
| **Rentang Bujur ($\Delta \lambda$)**| $23.92^\circ$ bujur ($\approx 2.660\text{ km}$) | **$2.00^\circ$ bujur ($\approx 220\text{ km}$)** | **Sub-AOI hanya 8.3% dari bentang zonal** |
| **Rentang Lintang ($\Delta \phi$)**| $7.14^\circ$ lintang ($\approx 790\text{ km}$) | **$2.45^\circ$ lintang ($\approx 270\text{ km}$)** | **Sub-AOI hanya 34.3% dari bentang meridional**|
| **Estimasi Luas Laut** | $\approx 1.500.000\text{ km}^2$ | $\approx 59.400\text{ km}^2$ | **Sub-AOI hanya $\approx 3.96\%$ dari WPPNRI 573** |
| **Jumlah Sel Laut (0.05°)** | $\approx 52.000\text{ sel}$ | **$2.050\text{ sel}$** | Kisi hanya merepresentasikan Sub-AOI |

```
+-----------------------------------------------------------------------------------------+
|                SKETSA PERBANDINGAN CAKUPAN SPASIAL WPPNRI 573                           |
+-----------------------------------------------------------------------------------------+
| 102.5° E                                                                       126.5° E |
| [=========================== WPPNRI 573 (Resmi BIG) ==================================] |
|                                   | 111.0° E  113.0° E |                                |
|                                   | [Sub-AOI Prigi]    |                                |
|                                   |  (2.050 Sel / ~4%) |                                |
|                                   | -8.0° S  -10.45° S |                                |
+-----------------------------------------------------------------------------------------+
```

### Mandat Nomenklatur Spasial:
1. **DILARANG** menyebut model SDM 2.050 sel sebagai "Model Spasial Regional WPPNRI 573".
2. Istilah resmi yang wajib digunakan adalah:
   $$\mathbf{Sub\text{-}AOI\text{ }Prigi\text{ }Local\text{ }Fleet\text{ }Operational\text{ }Domain\text{ }Model}$$
3. Poligon WPPNRI 573 resmi BIG tetap berfungsi sebagai konteks makro-regional dan batas administrasi pengelolaan perikanan, namun domain komputasi SDM dibatasi secara eksplisit pada Sub-AOI Prigi.

---

## 3. AUDIT SPESIFIKASI 6 SKENARIO PREDIKTOR SDM

Predictor stack mengemas kondisi oseanografi ke dalam enam skenario spasial yang masing-masing mencakup 2.050 sel. Hasil audit statistik menunjukkan diferensiasi lingkungan yang sangat tajam antar-skenario:

```
+-----------------------------------------------------------------------------------------+
|                  KARAKTERISTIK FISIK 6 SKENARIO PREDIKTOR SDM                           |
+-----------------------------------------------------------------------------------------+
| Skenario          | SST (°C)| Chl-a (mg/m³)| Front (°C/km)| Ekman (m²/s)| Kontras (°C)  |
+-------------------+---------+--------------+--------------+-------------+---------------+
| 1. East Monsoon   |  26.58  |    0.526     |    0.084     |    -5.60    |     +1.88     |
| 2. West Monsoon   |  29.44  |    0.142     |    0.050     |    +1.38    |     +0.33     |
| 3. Transition 1   |  28.78  |    0.276     |    0.060     |    -0.51    |     +0.33     |
| 4. Transition 2   |  28.17  |    0.315     |    0.071     |    -2.38    |     +0.96     |
| 5. Super IOD 2019 |  25.50  |    0.774     |    0.098     |    -7.50    |     +3.20     |
| 6. Negative 2016  |  28.23  |    0.247     |    0.056     |    +0.25    |     -0.15     |
+-----------------------------------------------------------------------------------------+
```

### 3.1 Rincian Definisi dan Peran Ekologis Setiap Skenario

1. **Skenario 1 — East Monsoon (JJA / Juni–Agustus):**
   - **Karakteristik:** Angin Monsun Tenggara bertiup kencang memicu transpor massa Ekman lepas pantai ($-5.60\text{ m}^2/\text{s}$). SST rata-rata turun hingga $26.58^\circ\text{C}$ dan klorofil-a melonjak ke $0.526\text{ mg/m}^3$.
   - **Peran Model:** Skenario acuan utama untuk melatih presensi proxy penangkapan musim puncak (*peak fishing season*).

2. **Skenario 2 — West Monsoon (DJF / Desember–Februari):**
   - **Karakteristik:** Angin Monsun Barat Laut mendominasi, transpor Ekman berbalik menuju pantai ($+1.38\text{ m}^2/\text{s}$), mematikan upwelling. SST sangat hangat ($29.44^\circ\text{C}$), klorofil-a sangat rendah ($0.142\text{ mg/m}^3$), dan front termal melemah ($0.050^\circ\text{C/km}$).
   - **Peran Model:** Mensimulasikan penyusutan habitat pelagis besar ke kantung-kantung perairan tertentu selama musim paceklik penangkapan.

3. **Skenario 3 — Transition 1 (MAM / Maret–Mei):**
   - **Karakteristik:** Kondisi atmosfer tenang, gelombang laut rendah ($H_s = 1.02\text{ m}$), SST mulai menghangat ($28.78^\circ\text{C}$) pasca monsun barat, transpor Ekman lemah ($-0.51\text{ m}^2/\text{s}$).
   - **Peran Model:** Menggambarkan habitat masa awal operasi armada penangkapan sebelum upwelling terbentuk sempurna.

4. **Skenario 4 — Transition 2 (SON / September–November):**
   - **Karakteristik:** Transisi pendinginan akhir, transpor Ekman moderat ($-2.38\text{ m}^2/\text{s}$), gradien front termal masih terdeteksi ($0.071^\circ\text{C/km}$).
   - **Peran Model:** Menguji daya tahan zona potensi penangkapan ikan pelagis saat upwelling mulai memudar.

5. **Skenario 5 — Super Positive IOD (Kasus Ekstrem 2019):**
   - **Karakteristik:** Anomali iklim ekstrem kopel Samudra Hindia. Transpor Ekman mencapai rekor tertinggi ($-7.50\text{ m}^2/\text{s}$), SST anjlok hingga $25.50^\circ\text{C}$ (sel pesisir mencapai $<23.5^\circ\text{C}$), klorofil-a melonjak hingga $0.774\text{ mg/m}^3$, dan kontras suhu pantai-lepas pantai mencapai $+3.20^\circ\text{C}$.
   - **Peran Model:** Simulasi skenario *stress test* upwelling maksimum dan ekspansi habitat pelagis sub-permukaan (seperti Albakor).

6. **Skenario 6 — Extreme Negative IOD (Kasus Ekstrem 2016):**
   - **Karakteristik:** Kegagalan total upwelling musiman akibat anomali pemanasan Samudra Hindia timur. Indeks kontras bernilai negatif ($-0.15^\circ\text{C}$), klorofil-a tertekan rendah ($0.247\text{ mg/m}^3$), dan dinamika Ekman lumpuh ($+0.25\text{ m}^2/\text{s}$).
   - **Peran Model:** Simulasi dampak krisis iklim laut hangat terhadap potensi kelaparan habitat (*thermal habitat compression*).

---

## 4. KESIMPULAN TASK 7

Batas wilayah model SDM telah dibuktikan secara matematis mencakup **hanya Sub-AOI Prigi (2.050 sel berukuran 0.05°, luas $\approx 59.400\text{ km}^2$, setara ~4% dari WPPNRI 573)**. Klaim sebagai model regional WPPNRI 573 resmi dicabut dan digantikan dengan definisi *Sub-AOI Prigi Local Fleet Operational Domain Model*. Keenam skenario lingkungan multi-temporal telah terdokumentasi secara lengkap dan konsisten.
