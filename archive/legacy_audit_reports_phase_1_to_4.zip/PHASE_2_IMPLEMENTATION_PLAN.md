# PHASE 2 IMPLEMENTATION PLAN & TECHNICAL PIPELINE
## Oceanographic Data Integration & Harmonization (2015–2025)
### Rencana Eksekusi Bertahap, Pipeline Komputasi, Quality Control, dan Skema Integrasi

---

### 1. TAHAPAN EKSEKUSI UTAMA (STAGES 2 S.D. 7)

Sesuai arahan Master Prompt, implementasi Phase 2 dilaksanakan secara bertahap tanpa melompat ke tahap berikutnya sebelum tahap sebelumnya terverifikasi:

```
[ STAGE 1 (SELESAI): AUDIT ARSITEKTUR & PENETAPAN SUMBER DATA ]
  ├── PHASE_2_ARCHITECTURE_AUDIT.md
  ├── PHASE_2_DATA_SOURCE_COMPARISON.md
  └── PHASE_2_IMPLEMENTATION_PLAN.md
                        │
                        ▼
[ STAGE 2: INFRASTRUKTUR AKUISISI & MANAJEMEN MANIFEST ]
  ├── Direktori Modular: data/oceanographic/{raw, processed, derived, statistics, metadata}
  ├── Registri Sumber Data: metadata/data_sources.json
  ├── Kamus Variabel: metadata/variable_dictionary.json
  └── Sistem Pengendali Unduhan: manifests/download_manifest.json & processing_manifest.json
                        │
                        ▼
[ STAGE 3: UJI COBA PERINTIS (PILOT PROCESSING) ]
  ├── Variabel Pilot: SST, Klorofil-a, dan Angin 10m
  ├── Periode Sampel: Musim Timur (Juli 2024) vs Musim Barat (Januari 2024)
  └── Verifikasi Mutu: CRS WGS 84, Clipping WPP 573, Nilai Fisik Valid, NoData Terisolasi
                        │
                        ▼
[ STAGE 4: AKUISISI & KOMPOSIT LENGKAP 132 BULAN (2015–2025) ]
  ├── 132 Bulan Deret Waktu: Januari 2015 s.d. Desember 2025
  ├── Harmonisasi Spasial: Resampling ke Common Grid 4 km, Clipping Poligon BIG
  └── Harmonisasi Temporal: Agregasi Bulanan, 4 Fase Monsun, dan Rata-rata Tahunan
                        │
                        ▼
[ STAGE 5: REKAYASA FITUR OSEANOGRAFI (FEATURE ENGINEERING) ]
  ├── Anomali SST Relatif (Baseline 2015–2025)
  ├── Anomali Klorofil-a (Log-transformed)
  ├── Deteksi Thermal Front (Kernel Gradien Sobel dalam °C/km)
  ├── Perhitungan Coastal Upwelling Index (CUI Thermal & Ekman Mass Transport)
  └── Klasifikasi Batimetri (Neritik <200m, Tubir Benua 200–1000m, Oseanik >1000m)
                        │
                        ▼
[ STAGE 6: PENGUJIAN MUTU LENGKAP (QUALITY CONTROL & VALIDASI) ]
  ├── Deteksi Nilai Ekstrem (Outliers di Luar Rentang Fisik)
  ├── Laporan Kelengkapan (Completeness Report 132 Bulan)
  └── Penerbitan: quality_control_report.json & processing_metadata.json
                        │
                        ▼
[ STAGE 7: INTEGRASI VISUALISASI KE DASHBOARD & LAPORAN TEKNIS ]
  ├── Pembaruan Tab Oceanographic Analysis di html/index.html
  ├── Layer Selector, Temporal Slider (Tahun, Bulan, Musim), dan AOI Switcher
  └── Penerbitan Laporan Akhir: PHASE_2_TECHNICAL_REPORT.md
```

---

### 2. ARSITEKTUR PIPELINE DATA (BACKEND & PROCESSING MODULES)

Pipeline data oseanografi dirancang modular menggunakan pustaka Python dan Node.js:

1. **`Data Source Registry (`data_sources.json`)`:**
   Menyimpan konfigurasi URL, dataset ID, provider, resolusi asli, dan parameter autentikasi untuk setiap variabel.
2. **`Data Acquisition Manager (`ocean_acquisition.py` / Colab)`:**
   Mengelola koneksi ke Google Earth Engine API dan Copernicus Marine Toolbox, mengeksekusi unduhan berbasis batch per tahun/bulan, dan melacak status ke dalam `download_manifest.json`.
3. **`Spatial Harmonization Manager`:**
   * Memotong raster menggunakan poligon master kanonikal BIG (`wppnri_573_big.geojson`).
   * Melakukan masking otomatis sel daratan Indonesia dan pulau-pulau kecil.
   * Menstandarisasi resolusi sel ke grid resolusi standar 4 km (`EPSG:4326`).
4. **`Temporal Aggregation Manager`:**
   * Menghasilkan komposit 132 bulan penuh.
   * Menghasilkan 4 komposit musiman dengan aturan penamaan lintas tahun untuk Musim Barat (`YYYY/YYYY+1`).
5. **`Feature Engineering Manager`:**
   * Menghitung gradien thermal front ($\|\nabla SST\|$) dalam satuan terstandar °C/km.
   * Menghitung indeks anomali suhu dan transpor massa Ekman.
6. **`Quality Control Manager`:**
   * Menguji rentang fisik: SST harus berada pada rentang $20,0^\circ\text{C} \le SST \le 34,0^\circ\text{C}$.
   * Klorofil-a harus berada pada rentang $0,01 \le Chl \le 20,0\text{ mg/m}^3$.
   * Menghitung persentase piksel valid per bulan dan mendokumentasikannya ke `quality_control_report.json`.

---

### 3. SKEMA BERKAS MANIFEST & METADATA

#### A. Skema `download_manifest.json`
```json
{
  "manifest_version": "1.0",
  "project": "SEACAST PRIGI - Phase 2 Oceanography",
  "total_expected_files": 132,
  "last_updated": "2026-10-31T08:30:00Z",
  "files": [
    {
      "variable": "sst",
      "year": 2015,
      "month": 1,
      "dataset_id": "MODIS-Aqua/L3SMI/SST",
      "local_filename": "data/oceanographic/processed/monthly/sst/sst_2015_01.tif",
      "file_size_bytes": 1450200,
      "md5_hash": "a1b2c3d4...",
      "status": "COMPLETED",
      "valid_pixel_percentage": 98.4
    }
  ]
}
```

#### B. Skema `variable_dictionary.json`
Mendokumentasikan secara rinci nama variabel, satuan, rentang fisik normal, metode analisis, dan referensi ilmiah rujukan.

#### C. Skema `quality_control_report.json`
Merekam ringkasan kelengkapan 132 bulan (Januari 2015 s.d. Desember 2025) per variabel, jumlah bulan hilang (*missing months*), dan catatan penanganan *NoData*.

---

### 4. RENCANA INTEGRASI KE ANTARMUKA WEB (`index.html`)

Pada antarmuka [index.html](file:///C:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis/html/index.html), modul `view-ocean` akan ditingkatkan menjadi **Pusat Analisis Oseanografi Multitemporal Terpadu**:
* **Layer Control Terpadu:**
  * Variabel: SST (°C), Klorofil-a (mg/m³), Thermal Front (°C/km), dan Indeks Upwelling.
* **Filter Temporal Fleksibel:**
  * Selector Tahun: 2015 s.d. 2025.
  * Selector Bulan: Januari s.d. Desember (132 bulan).
  * Selector Musim: Musim Timur (Puncak Panen), Musim Barat (Paceklik), Peralihan I, dan Peralihan II.
* **Statistik Spasial Terhubung:**
  * Menampilkan rata-rata bulanan, nilai minimum, maksimum, dan anomali terhadap rata-rata 11 tahun secara dinamis.
  * Tetap mempertahankan batas resmi WPPNRI 573 dari BIG, Sub-AOI Prigi, dan skenario jangkauan armada 12 NM dan 60 NM.
