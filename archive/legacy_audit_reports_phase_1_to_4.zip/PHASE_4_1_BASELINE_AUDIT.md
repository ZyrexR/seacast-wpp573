# PHASE 4.1 — STAGE 0: READ-ONLY BASELINE AUDIT & DEPENDENCY MAP
## Sistem Intelijen Geospasial Perikanan Pelagis PPN Prigi — WPPNRI 573

- **Tanggal Eksekusi:** 1 November 2026
- **Tahap:** STAGE 0 — Read-Only Baseline Audit & Pre-Remediation Snapshot
- **Direktori Backup Snapshot:** [`backups/phase_4_1_pre_remediation/`](file:///c:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis/backups/phase_4_1_pre_remediation/backup_manifest.json) (**44 file** dicadangkan lengkap dengan checksum `SHA-256` sebelum modifikasi apa pun dilakukan).

---

## 1. PENETAPAN SUMBER DATA KANONIS (CANONICAL DATA SOURCES)

Untuk menghilangkan duplikasi dan divergensi nilai antar-file, ditetapkan **satu sumber data kanonis untuk setiap domain** yang menjadi acuan reproduksi otomatis seluruh file turunan:

| Domain Data | File Sumber Kanonis (Single Source of Truth) | Spesifikasi & Nilai Kanonis Terverifikasi | File Turunan yang Wajib Disinkronkan dari Sumber Kanonis |
|---|---|---|---|
| **1. Produksi Bulanan 12 Spesies Pelagis (2015–2025)** | [`data/master_prigi_all_inclusive.csv`](file:///c:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis/data/master_prigi_all_inclusive.csv) *(diverifikasi terhadap [`FINAL_FISHERIES_RECONCILIATION.csv`](file:///c:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis/FINAL_FISHERIES_RECONCILIATION.csv))* | - **Periode:** 2015-01 s/d 2025-12 (**132 bulan**)<br>- **Jumlah Taksa Pendaratan:** **12 taksa** (`cakalang_kg`, `madidihang_kg`, `tongkol_krai_kg`, `tongkol_kenyar_kg`, `tongkol_como_kg`, `gulamah_kg`, `tenggiri_kg`, `cucut_kg`, `marlin_kg`, `julung_kg`, `tuna_mata_besar_kg`, `albakor_kg`)<br>- **Rumus Kanonis:** $\text{total\_pelagis\_kg}_t = \sum_{s=1}^{12} \text{catch}_{s,t}$<br>- **Nilai April 2022 (`2022-04-01`):** **`198.246 kg`** (bukan `198.446 kg`)<br>- **Total Kumulatif 132 Bulan:** **`18.405.261 kg`** (bukan `18.405.461 kg`) | - [`data/oceanographic/statistics/monthly/ocean_fisheries_master_132m.json`](file:///c:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis/data/oceanographic/statistics/monthly/ocean_fisheries_master_132m.json)<br>- [`data/oceanographic/statistics/monthly/monthly_stats_prigi.csv`](file:///c:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis/data/oceanographic/statistics/monthly/monthly_stats_prigi.csv)<br>- [`data/master.csv`](file:///c:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis/data/master.csv) *(dibuat otomatis untuk Streamlit `utils.py`)*<br>- [`html/oceanographic_data.js`](file:///c:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis/html/oceanographic_data.js)<br>- [`html/index.html`](file:///c:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis/html/index.html) (KPI & array `MONTHLY`) |
| **2. Profil Armada & Upaya Tangkap (2012–2025)** | [`data/prigi_fleet_trips_2012_2025.csv`](file:///c:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis/data/prigi_fleet_trips_2012_2025.csv) & [`data/spatial_readiness_report.json`](file:///c:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis/data/spatial_readiness_report.json) | - **Total Trip 14 Tahun (2012–2025, Sheet 3 Alat Tangkap):** **`249.257 trip`**<br>- **Total Trip Periode Studi 11 Tahun (2015–2025):** **`189.334 trip`**<br>- **Armada Tahun 2025 (4 Kelas GT di Sheet 2):** **`443 unit kapal`** (`<10 GT`: 296, `10–20 GT`: 53, `20–30 GT`: 91, `>30 GT`: 3) | - [`html/index.html`](file:///c:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis/html/index.html) (Kartu KPI menampilkan `189.334 Trip (2015–2025)` dan `249.257 Trip (2012–2025)` secara eksplisit) |
| **3. Konfigurasi Geospasial Sub-AOI Prigi & Batimetri** | [`data/oceanographic/spatial/prigi_static_bathymetry_grid.json`](file:///c:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis/data/oceanographic/spatial/prigi_static_bathymetry_grid.json) & [`data/spatial_config_aoi.json`](file:///c:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis/data/spatial_config_aoi.json) | - **Batas Sub-AOI Prigi:** Bujur **`111.00°E` s/d `113.00°E`**, Lintang **`-8.00°S` s/d `-10.45°S`**<br>- **Dimensi Grid:** **50 baris $\times$ 41 kolom = `2.050` titik pusat sel** pada resolusi **$0.05^\circ \times 0.05^\circ$**<br>- **CRS:** `EPSG:4326` (Geografis), `EPSG:32749` (UTM 49S), `EPSG:6933` / Elipsoid WGS84 untuk luas<br>- **Luas Sub-AOI Prigi:** **`59.550,43 km²`** (`4,18%` dari `1.425.000 km²` WPPNRI 573)<br>- **Sumber Batimetri:** **`GEBCO 2023`** (*multi-source composite grid without single uniform chart datum*) | - `data/spatial_config_aoi.json`<br>- `data/spatial_readiness_report.json`<br>- `data/manifests/processing_manifest.json` (`2091` $\rightarrow$ `2050`)<br>- `data/oceanographic/metadata/*.json`<br>- `data/oceanographic/processed/seasonal/grid_*.json` (4 file)<br>- `outputs/sdm/zones/*.geojson` (5 file — *exact clipping*)<br>- `prigi_shelf_break_200m.geojson` (*exact clipping*) |
| **4. Pemodelan Skrining Kesesuaian Habitat Heuristik (RHSI)** | [`models/sdm/ensemble/model_evaluations_summary.json`](file:///c:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis/models/sdm/ensemble/model_evaluations_summary.json) & [`data/sdm/predictors/predictor_stack_multi_scenario.json`](file:///c:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis/data/sdm/predictors/predictor_stack_multi_scenario.json) | - **3 Spesies Target:** Cakalang (`w = [0.326, 0.403, 0.271]`), Madidihang (`w = [0.238, 0.447, 0.315]`), Albakor (`w = [0.000, 0.554, 0.446]`)<br>- **Rumus Wajib:** `weighted_mean_rhsi` ($\overline{RHSI}_w$), `weighted_ensemble_disagreement` ($\sigma_w$), `raw_advisory_score` ($\overline{RHSI}_w - \lambda \sigma_w$), dan `visualization_score` ($\text{clip}[0,1]$) | - [`outputs/sdm/hsi/hsi_all_scenarios_projections.json`](file:///c:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis/outputs/sdm/hsi/hsi_all_scenarios_projections.json)<br>- [`outputs/sdm/hsi/rhsi_sensitivity_analysis.json`](file:///c:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis/outputs/sdm/hsi/rhsi_sensitivity_analysis.json)<br>- [`html/sdm_data.js`](file:///c:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis/html/sdm_data.js)<br>- [`html/index.html`](file:///c:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis/html/index.html) |
| **5. Skrining Batimetri Mitigasi Bycatch Hiu & CITES** | [`data/prigi_elasmobranch_bycatch_records.csv`](file:///c:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis/data/prigi_elasmobranch_bycatch_records.csv) & [`outputs/sdm/zones/dynamic_bycatch_mitigation_zones.geojson`](file:///c:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis/outputs/sdm/zones/dynamic_bycatch_mitigation_zones.geojson) | - **Nama Layer:** `Candidate Bathymetric Screening Polygons for Voluntary Shark Bycatch Review`<br>- **Jumlah Fitur:** **123 poligon** ter-*clip* di dalam Sub-AOI (`-242 m` s/d `-950 m`)<br>- **8 Field Taksonomi & CITES:** Terpisah antara `identification_verification_status = "NEEDS_VERIFICATION"` dan status CITES (`cites_reference_date = "2026-03-05"`) | - [`outputs/sdm/zones/dynamic_bycatch_mitigation_zones.geojson`](file:///c:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis/outputs/sdm/zones/dynamic_bycatch_mitigation_zones.geojson)<br>- [`html/sdm_data.js`](file:///c:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis/html/sdm_data.js) (menyimpan geometri poligon penuh)<br>- [`html/index.html`](file:///c:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis/html/index.html) (merender `L.polygon` bukan `L.circleMarker`) |

---

## 2. PETA DEPENDENSI ANTAR-FILE (DEPENDENCY GRAPH)

```mermaid
flowchart TD
    CSV_MASTER["data/master_prigi_all_inclusive.csv<br/>(Kanonis 132 bln: 18.405.261 kg)"]
    CSV_RECON["FINAL_FISHERIES_RECONCILIATION.csv"]
    CSV_FLEET["data/prigi_fleet_trips_2012_2025.csv<br/>(189.334 trip 11th / 249.257 trip 14th)"]
    CSV_CITES["data/prigi_elasmobranch_bycatch_records.csv<br/>(8 Atribut Taksonomi & CITES)"]
    GRID_BATHY["data/oceanographic/spatial/prigi_static_bathymetry_grid.json<br/>(2.050 sel, [111,113]x[-10.45,-8.0], GEBCO 2023)"]

    OCN_132["data/oceanographic/statistics/monthly/ocean_fisheries_master_132m.json"]
    OCN_CSV["data/oceanographic/statistics/monthly/monthly_stats_prigi.csv"]
    GRIDS_SEAS["data/oceanographic/processed/seasonal/grid_*.json (4 file)"]
    PRED_STACK["data/sdm/predictors/predictor_stack_multi_scenario.json"]
    EVAL_JSON["models/sdm/ensemble/model_evaluations_summary.json"]
    PROJ_JSON["outputs/sdm/hsi/hsi_all_scenarios_projections.json<br/>(weighted_mean_rhsi, weighted_ensemble_disagreement,<br/>raw_advisory_score, visualization_score)"]
    SENS_JSON["outputs/sdm/hsi/rhsi_sensitivity_analysis.json"]
    ZONES_GEO["outputs/sdm/zones/*.geojson (5 file ter-clip ke Sub-AOI)"]

    BUNDLE_OCN["html/oceanographic_data.js"]
    BUNDLE_SDM["html/sdm_data.js"]
    WEBGIS["html/index.html"]
    ST_MASTER["data/master.csv & data/species_traits.csv"]
    ST_APP["app.py + utils.py + pages/1..7_*.py"]

    CSV_RECON --> CSV_MASTER
    CSV_MASTER --> OCN_132
    CSV_MASTER --> OCN_CSV
    CSV_MASTER --> ST_MASTER
    OCN_132 --> ST_MASTER
    ST_MASTER --> ST_APP
    OCN_132 --> BUNDLE_OCN
    GRID_BATHY --> GRIDS_SEAS
    GRIDS_SEAS --> PRED_STACK
    PRED_STACK --> PROJ_JSON
    EVAL_JSON --> PROJ_JSON
    PROJ_JSON --> SENS_JSON
    PROJ_JSON --> ZONES_GEO
    CSV_CITES --> ZONES_GEO
    PROJ_JSON --> BUNDLE_SDM
    ZONES_GEO --> BUNDLE_SDM
    BUNDLE_OCN --> WEBGIS
    BUNDLE_SDM --> WEBGIS
    CSV_FLEET --> WEBGIS
```

---

## 3. TEMUAN KONFLIK BARU PADA STAGE 0 (DITAMBAHKAN KE CONTRADICTION REGISTER)

Selain 16 konflik (`CONF-01` s/d `CONF-16`) yang telah tercatat di [`PHASE_4_VALIDATION_PACKAGE/08_DATA_CONTRADICTION_REGISTER.md`](file:///c:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis/PHASE_4_VALIDATION_PACKAGE/08_DATA_CONTRADICTION_REGISTER.md), pemindaian menyeluruh pada Stage 0 menemukan **2 konflik tambahan** yang telah ditambahkan ke register tersebut:

1. **`CONF-17` — Propagasi Typo April 2022 (`198446`) di `data/oceanographic/statistics/monthly/monthly_stats_prigi.csv`:**
   - Baris 89 (`2022-04`) pada `monthly_stats_prigi.csv` masih menyimpan `198446` pada kolom `total_pelagis_kg`.
2. **`CONF-18` — Propagasi Batas Selatan `south: -10.5` pada Header File Grid Musiman & Pilot JSON:**
   - Objek `bounds` di dalam ke-4 file `data/oceanographic/processed/seasonal/grid_*.json`, `pilot_ocean_2024_01.json`, `pilot_ocean_2024_07.json`, `pilot_verification_report.json`, `monthly_stats_wpp573.csv`, `PHASE_3_1_OCEANOGRAPHIC_QC.csv`, dan `data/spatial_readiness_report.json` masih mencantumkan `-10.5`, meskipun titik pusat sel di dalamnya berhenti pada `-10.45`.

---

## 4. DAFTAR FILE YANG AKAN DIUBAH & ALASAN TEKNISNYA

Seluruh 44 file target telah dicadangkan di `backups/phase_4_1_pre_remediation/`. Berikut adalah daftar file yang akan dimodifikasi pada Stage 1–6 beserta alasan teknisnya:

| Stage | File yang Diubah / Dibuat | Alasan Teknis Remediasi |
|---|---|---|
| **Stage 1 (Data Integrity)** | `data/master_prigi_all_inclusive.csv`, `data/oceanographic/statistics/monthly/ocean_fisheries_master_132m.json`, `data/oceanographic/statistics/monthly/monthly_stats_prigi.csv`, `FINAL_OCEANOGRAPHIC_MONTHLY_QC.csv`, `PHASE_3_1_OCEANOGRAPHIC_QC.csv` | Mengoreksi `total_pelagis_kg` bulan April 2022 dari `198446` menjadi `198246` (sehingga jumlah 132 bulan tepat `18.405.261 kg` sesuai jumlah 12 spesies) dan menyinkronkan metadata kualitas data. |
| **Stage 2 (Spatial Integrity)** | `data/spatial_config_aoi.json`, `data/spatial_readiness_report.json`, `data/manifests/processing_manifest.json`, `data/oceanographic/metadata/data_sources.json`, `quality_control_report.json`, `pilot_verification_report.json`, `pilot_ocean_2024_01.json`, `pilot_ocean_2024_07.json`, `data/oceanographic/processed/seasonal/grid_*.json` (4 file), `monthly_stats_wpp573.csv`, `prigi_shelf_break_200m.geojson`, `target_group_background.geojson`, `outputs/sdm/zones/*.geojson` (5 file) | Menyeragamkan batas selatan Sub-AOI Prigi ke `-10.45°S` (`2.050` sel, luas equal-area/elipsoidal `59.550,43 km²`), melakukan *exact geometric clipping* terhadap poligon/garis/titik yang meluber keluar `[111.00, 113.00] E x [-10.45, -8.00] S`, dan menghitung luas metrik (`area_km2`) untuk setiap poligon. |
| **Stage 3 (Scientific Model Integrity)** | `scratch/execute_stage_3_1_to_3_3.js`, `scratch/execute_stage_3_4_to_3_7.js`, `data/sdm/predictors/predictor_stack_metadata.json`, `data/sdm/predictors/predictor_stack_multi_scenario.json`, `PHASE_3_MODEL_METADATA.json`, `models/sdm/ensemble/model_evaluations_summary.json`, `outputs/sdm/hsi/hsi_all_scenarios_projections.json`, `outputs/sdm/hsi/rhsi_sensitivity_analysis.json` | Menghitung `weighted_mean_rhsi` ($\overline{RHSI}_w$), `weighted_ensemble_disagreement` ($\sigma_w$ berbobot, di mana bobot $0$ tidak berkontribusi), `raw_advisory_score` ($\overline{RHSI}_w - \lambda \sigma_w$), dan `visualization_score` ($\text{clip}[0,1]$) sambil mempertahankan ketiga skor komponen individual, membuat analisis sensitivitas ($\lambda$, bobot, threshold), serta melabeli model secara jujur sebagai *Heuristic Habitat Suitability Screening*. |
| **Stage 4 (Geospatial Bycatch Data)** | `outputs/sdm/zones/dynamic_bycatch_mitigation_zones.geojson`, `scratch/optimize_sdm_web_bundle.js`, `html/sdm_data.js` | Mempertahankan geometri `Polygon` ter-*clip* untuk ke-123 poligon (tidak direduksi menjadi titik `CircleMarker`), menyematkan 8 atribut taksonomi & CITES terpisah (`identification_verification_status = "NEEDS_VERIFICATION"`, `cites_reference_date = "2026-03-05"`), dan menggunakan nama resmi `Candidate Bathymetric Screening Polygons for Voluntary Shark Bycatch Review`. |
| **Stage 5 (Application Integrity)** | `html/index.html`, `html/oceanographic_data.js`, `html/sdm_data.js`, `data/oceanographic/derived/upwelling/ocean_fisheries_correlation.json`, `data/oceanographic/metadata/variable_dictionary.json`, `utils.py`, `data/master.csv`, `data/species_traits.csv`, `pages/2_Iklim_dan_Laut.py`, `pages/5_Spesies_dan_Pengelolaan.py` | Memperbaiki bug `switchView('view-sdm')`, menampilkan $\overline{RHSI}_w$, $\sigma_w$, dan $PFG_{\text{advisory}}$ secara terpisah, merender 123 poligon bycatch sebagai `L.polygon`, mengganti istilah `CUI` menjadi `SST Contrast (ΔT coast-offshore)` & `Ekman Transport (Mey)`, menghapus klaim `EMPIRICAL PROOF`, menyinkronkan angka `18.405.261 kg` & trip, serta memperbaiki sumber data nyata pada aplikasi Streamlit (`dummy = False`). |
| **Stage 6 (Readiness Gate Reconstruction)** | `scratch/reconstruct_phase_4_1_readiness_gate.py`, `PHASE_4_1_READINESS_GATE.json` | Membangun pemeriksa terprogram untuk `PG-01` s/d `PG-12` yang menghasilkan status (`PASS`, `PARTIAL`, `FAIL`, `NOT_APPLICABLE`, `NEEDS_VERIFICATION`) dari hasil pengujian aktual, bukan nilai hardcoded. |
