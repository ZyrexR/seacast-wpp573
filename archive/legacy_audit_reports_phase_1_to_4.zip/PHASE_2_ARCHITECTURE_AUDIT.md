# PHASE 2 ARCHITECTURE AUDIT & INTEGRATION SPECIFICATION
## Oceanographic Data Infrastructure for WPPNRI 573 × PPN Prigi (2015–2025)
### Dokumen Audit Sistem, Runtime, Penyimpanan Geospasial, dan Rencana Integrasi Modul

---

### 1. RINGKASAN AUDIT WORKSPACE EKSISTING

Audit menyeluruh terhadap direktori `C:\Users\ThinkPad\.gemini\antigravity\scratch\prigi-pelagis\` dilakukan untuk memastikan bahwa seluruh modul baru pada Phase 2 terintegrasi secara modular tanpa mengubah desain visual, tata letak, skema database, atau merusak artefak Phase 1.

#### A. Inventaris Berkas dan Artefak Kunci
| Kategori Berkas | Lokasi Relatif | Status & Integritas | Ukuran | Peran dalam Sistem |
| :--- | :--- | :--- | :---: | :--- |
| **Batas Kanonikal WPP** | `data/boundaries/wppnri_573_big.geojson` | Valid (Resmi BIG) | 65.019.505 B | Master boundary geoprocessing & clipping WPPNRI 573 |
| **Batas Web Teroptimasi** | `data/boundaries/wppnri_573_web.geojson` | Valid (Resmi BIG) | 211.773 B | Tampilan vektor interaktif Leaflet di dashboard |
| **Konfigurasi Spasial** | `data/spatial_config_aoi.json` | Valid (Source of Truth) | 5.161 B | Definisi Primary AOI, Sub-AOI Prigi, Buffer, & CRS |
| **Kamus Taksonomi** | `data/spatial_species_dictionary.json` | Valid (Tervalidasi) | 15.040 B | 12 taksa, 18.405.261 kg, preferensi & provenance |
| **Laporan Kesiapan Spasial**| `data/spatial_readiness_report.json` | Valid (Skor 10.0/10.0)| 4.234 B | Status audit formal Phase 1 revisi |
| **Cetak Biru Analitik** | `SPATIAL_ANALYSIS_ROADMAP.md` | Valid (Dokumentasi) | 9.085 B | Roadmap 7 fase komputasi spasial |
| **Laporan Revisi Phase 1**| `PHASE_1_REVISION_REPORT.md` | Valid (Dokumentasi) | 9.779 B | Catatan rekonsiliasi audit data & geometri BIG |
| **Antarmuka Utama Web** | `html/index.html` | Aktif (Leaflet + Plotly) | 294.332 B | Frontend mandiri, dark-mode, zero-dependency |
| **Data Induk Statistik** | `data/master_prigi_all_inclusive.csv` | Valid (132 Bulan) | 17.228 B | Data pendaratan 12 spesies, alat, GT, & cuaca |
| **Data Kunjungan Armada** | `data/prigi_fleet_trips_2012_2025.csv` | Valid (168 Bulan) | 5.027 B | Deret waktu trip 5 alat tangkap (2012–2025) |

---

### 2. ANALISIS RUNTIME, BAHASA PEMROGRAMAN & DEPENDENSI

#### A. Lingkungan Komputasi Lokal (Windows Host)
* **Node.js:** Versi **v24.19.0** aktif. Sangat andal untuk pemrosesan teks, manipulasi JSON, parsing GeoJSON, dan pembangunan server API lokal/pipeline asinkron.
* **PowerShell:** Windows PowerShell 5.1 aktif. Digunakan untuk otomasi tugas sistem operasi dan background task management.
* **Python Runtime:**
  * Di lingkungan lokal host Windows, shortcut Microsoft Store stub terdeteksi.
  * **Strategi Komputasi Ilmiah Berat:** Sesuai kesepakatan desain, pemrosesan citra satelit skala besar (rasters 4 km seluruh WPPNRI 573) dan pemodelan machine learning spasial akan dijalankan menggunakan **Google Colab (Cloud Python 3.10+ dengan GEE API, Rasterio, Geopandas, Xarray, dan Elapid)**, sedangkan penggabungan data, agregasi statistik, manajemen manifest, dan integrasi visualisasi dijalankan secara mandiri di workspace lokal dan VPS.

#### B. Arsitektur Frontend & Pustaka GIS
* **Peta Interaktif:** Leaflet.js v1.9.4 terintegrasi di `html/index.html`.
* **Visualisasi Statistik & Time-Series:** Plotly.js v2.35.2 mandiri (tersedia lokal di `html/plotly.min.js` dengan fallback CDN).
* **Identitas Visual UI:**
  * Background Utama: Dark Maritime Palette (`#0a0f1d`, `#0f172a`, `#1e293b`).
  * Tipografi: Sans-serif modern (`Inter, system-ui, sans-serif`) dan Monospace untuk nilai metrik numerik.
  * Aksen Status: Cyan (`#00f2fe`), Emerald (`#10b981`), Amber (`#f59e0b`), Rose/Crimson (`#f43f5e`), Purple (`#a855f7`).
* **Preservasi UI:** Modul baru Phase 2 ("Radar & Analisis Oseanografi Multitemporal") akan memperluas tab `view-ocean` yang sudah tersedia tanpa mengubah tata letak navbar atau skema warna yang telah disetujui.

---

### 3. ARSITEKTUR PENYIMPANAN DATA (STORAGE ARCHITECTURE)

Mengingat volume data oseanografi bulanan selama 11 tahun (132 bulan) untuk multiple variabel (SST, Chl-a, Arus, Angin, Gelombang, Batimetri) dapat mencapai beberapa gigabyte, sistem menerapkan **Arsitektur Penyimpanan Hibrida Tiga Lapisan**:

```
prigi-pelagis/
├── data/
│   ├── boundaries/                      # Batas Administratif & Spasial Resmi
│   │   ├── wppnri_573_big.geojson       # Master Polygon BIG (65 MB) - Master Clipping
│   │   └── wppnri_573_web.geojson       # Simplified Web GeoJSON (211 KB) - Leaflet
│   │
│   ├── oceanographic/                   # Basis Data Oseanografi Phase 2
│   │   ├── raw/                         # Arsip Data Mentah Asli (NetCDF/HDF/GeoTIFF)
│   │   │   ├── sst/                     # Citra MODIS Aqua / NOAA SST
│   │   │   ├── chlorophyll/             # Citra MODIS Aqua Chl-a
│   │   │   ├── bathymetry/              # Batimetri GEBCO / ETOPO1 (Statis)
│   │   │   ├── currents/                # Vektor Arus U & V
│   │   │   ├── wind/                    # Vektor Angin U10 & V10 ERA5
│   │   │   └── waves/                   # Tinggi Gelombang Signifikan Hs ERA5
│   │   │
│   │   ├── processed/                   # Komposit Bulanan Terharmonisasi (WPP & Sub-AOI)
│   │   │   ├── monthly/                 # 132 Bulan (2015-01 s.d. 2025-12)
│   │   │   ├── seasonal/                # Komposit 4 Fase Monsun (Barat, Peralihan I, Timur, Peralihan II)
│   │   │   └── annual/                  # Komposit Rata-rata Tahunan (11 Tahun)
│   │   │
│   │   ├── derived/                     # Variabel Turunan (Feature Engineering)
│   │   │   ├── sst_anomaly/             # Anomali Suhu Relatif (2015-2025 Baseline)
│   │   │   ├── chlorophyll_anomaly/     # Anomali Klorofil-a
│   │   │   ├── thermal_front/           # Magnitudo Gradien Sobel (deg C / km)
│   │   │   ├── upwelling_indices/       # Indeks Upwelling Berbasis SST & Angin
│   │   │   └── bathymetry_features/     # Slope, Shelf-break (200-1000m), & Deep Trench
│   │   │
│   │   ├── statistics/                  # Ringkasan Statistik Spasial (Zonal Stats CSV/JSON)
│   │   │   ├── monthly_stats_wpp573.csv # Mean, Min, Max, Std per bulan di WPPNRI 573
│   │   │   ├── monthly_stats_prigi.csv  # Mean, Min, Max, Std per bulan di Sub-AOI Prigi
│   │   │   └── seasonal_climatology.json# Matriks Klimatologi 4 Fase Monsun
│   │   │
│   │   └── metadata/                    # Katalog Metadata Ilmiah & Quality Control
│   │       ├── data_sources.json        # Registri Sumber Data Resmi
│   │       ├── variable_dictionary.json # Kamus Variabel Oseanografi
│   │       ├── processing_metadata.json # Riwayat Pemrosesan & Parameter Resampling
│   │       └── quality_control_report.json # Laporan Pengujian Mutu (QC)
│   │
│   └── manifests/                       # Audit Trail & Pengendali Unduhan
│       ├── download_manifest.json       # Status File, Hash, Timestamp, & Ukuran
│       └── processing_manifest.json     # Status Eksekusi Pipeline Pemrosesan
```

---

### 4. STRATEGI INTEGRASI DENGAN FRONTEND WEB (`index.html`)

Untuk mencegah kelebihan beban memori pada browser pengguna saat menampilkan data spasial multitemporal:
1. **Pemisahan Jalur Raster Berat vs Ringan:**
   * Raster GeoTIFF resolusi tinggi (4 km) disimpan untuk analisis di server / Google Drive / GIS Desktop (ArcGIS Pro / QGIS).
   * Untuk visualisasi web di dashboard, sistem menggunakan **Cloud-Optimized GeoTIFF (COG)** via tile service atau **GeoJSON Poligon Kontur/Heatmap Terkompresi** dan **Matriks Nilai Grid JSON**.
2. **Dynamic Layer & Temporal Controls:**
   * Menambahkan kontrol interaktif di tab `view-ocean` pada `index.html`:
     * *Selector Variabel:* SST, SST Anomaly, Chl-a, Chl-a Anomaly, Thermal Front, Upwelling Index, Arus Laut, Angin, dan Batimetri.
     * *Selector Temporal:* Tahun (2015–2025), Bulan (Januari–Desember), dan 4 Fase Monsun.
     * *Selector AOI:* Toggle antara Primary AOI (WPPNRI 573) dan Secondary AOI (Sub-AOI Prigi).
3. **Panel Informasi Sains & Provenance:**
   * Setiap layer yang aktif otomatis menampilkan legenda warna baku, satuan resmi, resolusi spasial, sumber instansi, dan status kualitas (QC Passed).

---

### 5. ATURAN INTEGRITAS DAN PENCEGAHAN REGRESI SISTEM

1. **Prinsip Non-Destruktif:** Seluruh berkas Phase 1 (`spatial_config_aoi.json`, `spatial_species_dictionary.json`, `spatial_readiness_report.json`, dan batas BIG) dilindungi sebagai *Source of Truth* dan tidak akan ditimpa atau dihapus.
2. **Kredensial Aman:** Token API Copernicus Marine atau Google Earth Engine dikelola melalui environment variables (`.env`) atau parameter konfigurasi runtime, tanpa di-hardcode ke source code.
3. **Ketegasan Definisi Oseanografi:**
   * Klorofil-a dicatat tegas sebagai indikator produktivitas primer, bukan bukti langsung keberadaan ikan.
   * Thermal front dicatat sebagai zona gradien termal massa air, bukan lokasi pasti berkumpulnya kapal.
   * Upwelling didefinisikan dengan ambang matematis yang transparan dan terdokumentasi.
