# PHASE 3.1 — OCEANOGRAPHIC DATA SOURCE AUDIT
## Laporan Audit Forensik & Verifikasi Provenance Data Oseanografi (2015–2025)
### WPPNRI 573 × PPN Prigi Spatial Fisheries Intelligence System

**Tanggal Audit:** 31 Oktober 2026  
**Auditor:** Senior Marine Data Scientist, Physical Oceanographer & Geospatial Data Architect  
**Status Audit:** SELESAI & TERDOKUMENTASI KETAT (100% AUDITED)  
**Dokumen Induk:** Proyek Intelijen Geospasial Perikanan Pelagis PPN Prigi — WPPNRI 573  

---

## 1. PENDAHULUAN

Laporan ini merupakan bagian dari implementasi **Phase 3.1: Scientific & Technical Remediation (Task 2)**. Audit eksternal independen sebelumnya mengidentifikasi adanya ambiguitas katalog, tumpang tindih penamaan dataset satelit antara katalog cloud (Google Earth Engine) dan pusat data primer (NASA OBPG, NOAA NCEI, ECMWF Copernicus, CMEMS, GEBCO), serta pencampuran resolusi spasial dan versi grid batimetri.

Audit ini menetapkan identitas teknis resmi, struktur layer, resolusi kisi spasial dan temporal, metode agregasi, versi pemrosesan, serta batasan operasional dari seluruh data oseanografi 11 tahun (132 bulan: Januari 2015 – Desember 2025).

---

## 2. MODIS AQUA: DISTINCTION GEE VS NASA OCEANCOLOR

Terdapat kerancuan nomenklatur dalam dokumentasi awal antara katalog cloud Google Earth Engine (GEE) dan katalog NASA Ocean Biology Processing Group (OBPG). Tabel berikut mendokumentasikan pemetaan resmi kedua katalog tersebut:

| Parameter Teknis | Google Earth Engine (GEE) | NASA OceanColor (OBPG Primary) |
| :--- | :--- | :--- |
| **Asset / Collection ID** | `NASA/OCEANDATA/MODIS-Aqua/L3SMI` | `MODISA_L3m_SST_Monthly_4km_R2022.0` (SST)<br>`MODISA_L3m_CHL_Monthly_4km_R2022.0` (Chl-a) |
| **Satelit & Sensor** | EOS PM-1 (Aqua) / MODIS Sensor | EOS PM-1 (Aqua) / MODIS Sensor |
| **Orbit Satelit** | Sun-synchronous, Equator crossing ~13:30 LT (Ascending) | Sun-synchronous, Equator crossing ~13:30 LT (Ascending) |
| **Reprocessing Baseline** | Reprocessing 2022.0 (R2022.0) | Reprocessing 2022.0 (R2022.0) |
| **Tingkat Pemrosesan** | Level-3 Standard Mapped Image (SMI) | Level-3 Standard Mapped Image (SMI) |
| **Variabel Utama** | `sst` (11 µm Day SST), `chlor_a` (OCI Chlorophyll-a) | `sst` (Daytime SST), `chlor_a` (Chlorophyll-a OCI algorithm) |
| **Resolusi Spasial** | 4.63 km pada ekuator (~0.0416667° kisi ekuirektangular) | 4.63 km pada ekuator (Grid 4320 × 8640 sel global) |
| **Temporal Cadence** | **Direct Monthly SMI Composite** (Bukan agregasi harian manual) | **Direct Monthly SMI Composite** (Bukan agregasi harian manual) |
| **Format Asli** | Cloud GeoTIFF / Earth Engine Image | NetCDF-4 / HDF5 CF-compliant |
| **CRS / Proyeksi** | EPSG:4326 (WGS 84 Geographic 2D) | Plate Carrée (Equirectangular WGS 84) |

### 2.1 Verifikasi Temporal Cadence (Monthly Direct Ingestion)
- **Konfirmasi Metode Agregasi:** Dalam pipeline SEACAST Prigi, data MODIS Aqua **TIDAK diagregasi dari data harian (Level-3 Daily / L3BIN Daily)** oleh pengguna secara manual di client side. Sebaliknya, pipeline mengekstrak langsung produk **Standard Mapped Image (SMI) Bulanan resmi NASA OBPG** yang telah dibersihkan secara radiometrik oleh NASA OBPG dengan penolakan piksel berawan (*cloud-masking* ketat berbasis bendera kualitas bitwise `l2_flags` $\le 1$).
- **Implikasi Kualitas:** Penggunaan komposit bulanan resmi NASA meminimalkan galat komputasi lokal, tetapi meninggalkan piksel *missing data* (NaN) pada puncak Monsun Barat (Desember–Februari) akibat liputan awan tebal konvektif di Samudra Hindia bagian timur.

---

## 3. NOAA OPTIMUM INTERPOLATION SST (OISST v2.1)

Untuk mengatasi keterbatasan tutupan awan MODIS Aqua pada analisis tren interannual dan perhitungan anomali, sistem memanfaatkan dataset NOAA OISST.

| Parameter Teknis | Rincian Spesifikasi |
| :--- | :--- |
| **Nama Resmi Produk** | NOAA Daily 1/4° Optimum Interpolation Sea Surface Temperature (OISST) Version 2.1 |
| **Penyedia / Sumber** | NOAA National Centers for Environmental Information (NCEI) |
| **Dataset Identifier** | GEE: `NOAA/CDR/OISST/V2_1` / NOAA THREDDS: `oisst-avhrr-v02r01` |
| **Referensi Ilmiah** | Huang et al. (2021), Journal of Climate |
| **Resolusi Spasial** | 0.25° × 0.25° (~27.75 km pada ekuator) |
| **Resolusi Asli Data** | Harian (Daily at 12:00:00 UTC) |
| **Metode Agregasi Bulanan** | Agregasi rata-rata aritmetika per bulan kalender: $\bar{T}_{m} = \frac{1}{N}\sum_{d=1}^N T_d$ di mana $N \in [28, 31]$ hari, diproses via GEE ImageCollection reducer (`ee.Reducer.mean()`). |
| **Sensor & Masukan In-Situ** | Satelit AVHRR (NOAA-19, MetOp-A, MetOp-B, MetOp-C) + Pengukuran in situ dari kapal (*ship*) dan pelampung tertambat/hanyut (*drifting and moored buoys*) dengan koreksi bias *satellite-to-in-situ*. |
| **Validitas Spasial** | 100% kontinu tanpa celah spasial (*gap-free spatial analysis*) berkat teknik interpolasi optimal spasial-temporal (*kriging-based statistical blend*). |
| **Peran dalam Sistem** | Baseline klimatologi 11 tahun (2015–2025), validasi anomali SST termal WPPNRI 573, dan pengisian nilai lingkungan pendukung jika MODIS Aqua mengalami tutupan awan >70%. |

---

## 4. ECMWF ERA5 REANALYSIS: ATMOSFER VS GELOMBANG

Terdapat perbedaan mendasar dalam resolusi kisi antara komponen atmosfer dan komponen gelombang laut dalam reanalisis ERA5. Keduanya tidak boleh digeneralisasi sebagai 0.25°.

```
+-----------------------------------------------------------------------------------------+
|                                    ECMWF ERA5 REANALYSIS                                |
+---------------------------------------------+-------------------------------------------+
| 1. Atmospheric Dynamics (0.25° ~27.75 km)   | 2. Marine Surface Waves (0.50° ~55.5 km)  |
| - Variables: u10, v10 (10m neutral wind)    | - Variable: swh (Significant Wave Height) |
| - Source Model: ECMWF IFS (Cy41r2)          | - Source Model: ECMWF WAM Cycle 4         |
| - GEE Asset: ECMWF/ERA5/MONTHLY             | - CDS: reanalysis-era5-single-levels-m... |
+---------------------------------------------+-------------------------------------------+
```

### 4.1 Spesifikasi Rinci Dua Komponen ERA5

1. **Komponen Angin Permukaan (Atmospheric 10m Wind):**
   - **Variabel:** `u10` (vektor kecepatan zonal ke arah timur) dan `v10` (vektor kecepatan meridional ke arah utara).
   - **Resolusi Asli:** T639 spectral (~31 km), diproyeksikan pada kisi reguler **0.25° × 0.25°**.
   - **Satuan Asli:** Meter per detik ($\text{m/s}$).
   - **Konversi Sistem:**
     $$\text{Wind Speed } (W_{10}) = \sqrt{u_{10}^2 + v_{10}^2}$$
     $$\text{Wind Direction } (\theta) = \left(270 - \text{atan2}(v_{10}, u_{10}) \times \frac{180}{\pi}\right) \pmod{360}$$
   - **Peran:** Perhitungan tegangan angin (*wind stress* $\boldsymbol{\tau}$), analisis monsun musiman, dan kalkulasi transpor massa Ekman tegak lurus pantai.

2. **Komponen Gelombang Laut (Ocean Wave Dynamics):**
   - **Variabel:** `swh` (*Significant wave height of combined wind waves and swell* / $H_s$).
   - **Resolusi Asli:** Natively dihitung oleh ECMWF Standalone Wave Model (WAM) pada kisi **0.50° × 0.50° (~55.5 km)**.
   - **Satuan Asli:** Meter ($\text{m}$).
   - **Peran:** Penentuan status laut (*sea state*), verifikasi keselamatan armada penangkapan PPN Prigi (<10 GT rawan pada $H_s > 2.0\text{ m}$), dan korelasi musiman terhadap aksesibilitas penangkapan.

---

## 5. COPERNICUS GLORYS12: OCEAN SURFACE CURRENTS

Arus laut permukaan diekstrak dari pemodelan reanalisis hidrodinamika global Copernicus Marine Service (CMEMS).

| Parameter Teknis | Rincian Spesifikasi |
| :--- | :--- |
| **Product Identifier** | `GLOBAL_MULTIYEAR_PHY_001_030` (GLORYS12V1 Reanalysis) |
| **Dataset Splicing (2021–2025)** | Disambung dengan `GLOBAL_ANALYSISFORECAST_PHY_001_024` untuk data Near Real-Time setelah periode historis reanalisis berakhir pada pertengahan 2020. |
| **Pusat Pemrosesan** | Mercator Ocean International (Toulouse, Prancis) / CMEMS |
| **Model Dinamika** | NEMO (Nucleus for European Modelling of the Ocean) coupled with LIM2 sea-ice model |
| **Asimilasi Data** | Asimilasi Kalman Filter (SEEK) untuk data altimetri satelit, SST, sea ice, dan profil vertikal in-situ (Argo floats, CTD, XBT). |
| **Variabel yang Digunakan** | `uo` (kecepatan arus horizontal ke arah timur), `vo` (kecepatan arus horizontal ke arah utara). |
| **Kedalaman Lapisan (Depth Level)** | **Level 0 (Surface Bin):** Nominal center depth **0.494 meter** (rentang integrasi 0.00 – 1.05 meter). Arus lapisan dalam (>1.0 m) tidak digunakan dalam model permukaan ini. |
| **Resolusi Spasial** | 1/12° (~0.0833333° atau ~9.25 km pada ekuator) pada kisi regular ORCA12. |
| **Temporal Cadence** | Monthly Mean Reanalysis Product. |
| **Satuan & Kalkulasi** | Kecepatan arus permukaan: $V_{\text{current}} = \sqrt{uo^2 + vo^2}$ ($\text{m/s}$). |
| **Peran dalam Sistem** | Analisis Arus Pantai Jawa (*South Java Current / SJC*), Arus Lintas Indonesia (*ITF outflow*), dan adveksi larva/nutrisi. |

---

## 6. GEBCO BATHYMETRY: STANDARISASI KISI TUNGGAL

Dalam audit awal, tercatat adanya ketidakkonsistenan rujukan antara `GEBCO 2023 Grid`, `GEBCO 2024`, dan `NOAA ETOPO1`. Audit ini menetapkan satu-satunya sumber kisi batimetri operasional:

### 6.1 Penetapan Sumber Tunggal: GEBCO 2023 Grid
- **Produk Resmi:** GEBCO 2023 Grid (dipublikasikan April 2023 oleh IHO/IOC Sub-Committee on Undersea Feature Names & GEBCO Guiding Committee).
- **Resolusi Asli:** 15 arc-seconds (~450 meter pada ekuator).
- **Cakupan Spasial Operasional:** $111.00^\circ\text{–}113.00^\circ\text{ E}$, $-10.45^\circ\text{–}-8.00^\circ\text{ S}$ (Sub-AOI Prigi) dan batas poligon WPPNRI 573.
- **Satuan:** Meter elevasi (ketinggian relatif terhadap Mean Sea Level, bernilai negatif di bawah permukaan laut).

### 6.2 Eliminasi Kerancuan Dataset Lain
1. **NOAA ETOPO1 (1 arc-minute ~1.8 km):**
   - *Status:* **DIDEPREKASI DARI PIPELINE ANALISIS**. ETOPO1 hanya digunakan pada pengujian awal Phase 1 sebelum batas resmi WPPNRI 573 diintegrasikan. ETOPO1 memiliki resolusi terlalu kasar di dekat teluk Prigi (kontur 200 m dan 1000 m mengalami distorsi signifikan).
2. **GEBCO 2024 Grid:**
   - *Status:* **TIDAK DIGUNAKAN (OUT OF SCOPE)**. GEBCO 2024 dirilis setelah arsitektur Phase 2 dibekukan. Untuk menjamin reproduktifitas komputasi yang deterministik, sistem tetap membekukan penggunaan pada GEBCO 2023.

### 6.3 Resampling & Pembuatan Turunan Morfologi
- **Kisi SDM Predictor Stack:** GEBCO 2023 di-resample menggunakan interpolasi bilinear menjadi **0.05° × 0.05° (~5.5 km)** agar cocok secara spasial (*pixel-aligned*) dengan kisi variabel oseanografi bulanan.
- **Turunan Kedalaman:**
  - Kemiringan Lereng Batimetri (*Slope* dalam derajat): dihitung menggunakan algoritma Horn 8-arah tetangga pada resolusi 0.05°.
  - Klasifikasi Zona Kedalaman: Neritik ($0\text{–}-200\text{ m}$), Shelf-Break ($-200\text{ s/d }-1000\text{ m}$), dan Oseanotropis Batial/Abisal ($<-1000\text{ m}$).

---

## 7. MATRIKS HARMONISASI SUMBER DATA OSEANOGRAFI RESMI

Berikut adalah tabel definitif parameter data oseanografi yang digunakan dalam sistem intelijen geospasial PPN Prigi:

| Parameter Oseanografi | Produk & Koleksi Primer | Provider / Repositori | Resolusi Asli | Resolusi Harmonisasi | Cadence Waktu | Satuan Baku |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **SST (Primary)** | NASA MODIS Aqua L3 SMI (`R2022.0`) | NASA OBPG / GEE | ~4.63 km (0.0416°) | 0.05° Bilinear | Monthly SMI | °C |
| **SST (Baseline/Gapfill)** | NOAA OISST v2.1 (`CDR/OISST/V2_1`) | NOAA NCEI / GEE | 0.25° (~27.75 km) | 0.05° Bilinear | Monthly Mean | °C |
| **Klorofil-a (Chl-a)** | NASA MODIS Aqua L3 SMI OCI (`R2022.0`)| NASA OBPG / GEE | ~4.63 km (0.0416°) | 0.05° Bilinear | Monthly SMI | $\text{mg/m}^3$ |
| **Angin Permukaan (10m)** | ECMWF ERA5 Atmospheric (`u10, v10`) | ECMWF / Copernicus CDS| 0.25° (~27.75 km) | 0.05° Bilinear | Monthly Mean | $\text{m/s}$ |
| **Tinggi Gelombang ($H_s$)**| ECMWF ERA5 WAM Wave (`swh`) | ECMWF / Copernicus CDS| 0.50° (~55.5 km) | 0.05° Bilinear | Monthly Mean | $\text{m}$ |
| **Arus Laut ($uo, vo$)** | CMEMS GLORYS12V1 (`PHY_001_030`) | Mercator Ocean / CMEMS | 1/12° (~0.0833°) | 0.05° Bilinear | Monthly Mean | $\text{m/s}$ (Depth: 0.49m) |
| **Batimetri & Slope** | GEBCO 2023 Grid (15 arc-sec) | IHO-IOC GEBCO | 15 arc-sec (~450 m) | 0.05° Bilinear | Grid Statis | $\text{m}$ & Derajat |

---

## 8. KESIMPULAN TASK 2

Audit provenance data oseanografi telah berhasil mengklarifikasi seluruh tumpang tindih penamaan dan ketidaksesuaian resolusi. Seluruh dataset telah memiliki dokumen silsilah (*provenance tree*) yang jelas, tidak ada lagi pencampuran resolusi atmosfer 0.25° dan gelombang 0.5°, serta batimetri telah dibakukan 100% menggunakan GEBCO 2023.
