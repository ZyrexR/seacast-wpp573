# FINAL SCIENTIFIC AUDIT: EKMAN DYNAMICS & UPWELLING INTERPRETATION
## Audit Metodologi Dinamika Ekman, Vektor Tegangan Angin, Parameter Coriolis, dan Pemisahan Transpor vs Pumping
### Pre-Phase 4 Scientific Validation Gate | Task 3 Deliverable

**Auditor:** Senior Physical Oceanographer & Marine Fluid Dynamics Specialist  
**Tanggal Audit:** 31 Oktober 2026  
**Status Evaluasi:** SELESAI, TERAUDIT LENGKAP & KONSISTEN SECARA DINAMIKA FLUIDA (100% AUDITED)  

---

## 1. PENDAHULUAN & TUJUAN AUDIT FISIKA OSEANOGRAFI

Audit ini bertujuan membedah formulasi komputasi dinamika laut permukaan di perairan selatan Jawa (Sub-AOI Prigi, WPPNRI 573), dengan fokus pada:
1. Ketelitian formulasi parameter Coriolis ($f$) di Belahan Bumi Selatan (*Southern Hemisphere*).
2. Dekomposisi vektor tegangan angin permukaan (*wind stress* $\boldsymbol{\tau}$).
3. Penentuan arah transpor massa Ekman berdasarkan perpaduan vektor angin dan tanda $f$ (bukan dari tanda $f$ semata).
4. Pemisahan konseptual dan matematis antara **Transpor Ekman Pantai (*Coastal Ekman Transport*)** dan **Pemompaan Ekman Lepas Pantai (*Ekman Pumping / Suction*)**.
5. Pembakuan istilah **`Coastal-Offshore SST Contrast Index`** serta penetapan batasan bahwa kontras suhu semata tidak boleh diklaim sebagai bukti tunggal terjadinya upwelling.

---

## 2. FORMULASI PARAMETER CORIOLIS ($f$) DI BELAHAN BUMI SELATAN

Parameter Coriolis merepresentasikan efek rotasi bumi terhadap gerak fluida dalam kerangka acuan berputar:
$$f = 2\Omega \sin(\phi)$$

Di mana:
- Kecepatan sudut rotasi bumi: $\Omega = 7.292115 \times 10^{-5}\text{ rad/s}$.
- Lintang rata-rata perairan pantai Sub-AOI Prigi: $\phi = -8.50^\circ\text{ S} = -0.148353\text{ rad}$.

### Evaluasi Numerik:
$$\sin(-8.50^\circ) = -0.147809$$
$$f = 2 \times (7.292115 \times 10^{-5}) \times (-0.147809) = \mathbf{-2.1557 \times 10^{-5}\text{ s}^{-1}}$$

### Catatan Kritis:
- Parameter $f$ bernilai **NEGATIF** karena perairan berada di selatan khatulistiwa ($\phi < 0$).
- Pada lintang selatan, gaya Coriolis membelokkan massa air ke arah **KIRI** dari arah datangnya angin (kebalikan dari Belahan Bumi Utara yang membelok ke kanan).

---

## 3. VEKTOR TEGANGAN ANGIN PERMUKAAN (*WIND STRESS* $\boldsymbol{\tau}$)

Medan angin permukaan diekstrak dari reanalisis ECMWF ERA5 pada ketinggian 10 meter:
$$\mathbf{U}_{10} = (u_{10}, v_{10})$$
Kecepatan angin total:
$$|\mathbf{U}_{10}| = \sqrt{u_{10}^2 + v_{10}^2}$$

Tegangan angin permukaan ($\boldsymbol{\tau}$, $\text{N/m}^2$) dihitung menggunakan formulasi aerodinamika:
$$\boldsymbol{\tau} = \rho_{\text{air}} \, C_d \, |\mathbf{U}_{10}| \, \mathbf{U}_{10}$$

Di mana:
- Kerapatan udara: $\rho_{\text{air}} = 1.225\text{ kg/m}^3$.
- Koefisien seret (*Drag Coefficient* $C_d$) mengikuti formulasi empiris Wu (1982) / Large & Pond (1981):
  $$C_d = (0.80 + 0.065 \, |\mathbf{U}_{10}|) \times 10^{-3} \quad (\text{untuk } |\mathbf{U}_{10}| \in [5, 12]\text{ m/s}, \, C_d \approx 1.20\text{–}1.45 \times 10^{-3})$$

Komponen tegangan angin:
- Komponen zonal (Timur-Barat): $\tau_x = \rho_{\text{air}} C_d |\mathbf{U}_{10}| u_{10}$
- Komponen meridional (Utara-Selatan): $\tau_y = \rho_{\text{air}} C_d |\mathbf{U}_{10}| v_{10}$

---

## 4. VERIFIKASI ARAH TRANSPOR MASSA EKMAN

### 4.1 Prinsip Penentuan Arah: Perpaduan Angin dan Lintang
> **ATURAN UTAMA AUDIT:** Arah transpor massa Ekman TIDAK BOLEH disimpulkan hanya dari tanda parameter Coriolis ($f < 0$). Arah transpor ditentukan oleh perkalian silang antara vektor tegangan angin permukaan ($\boldsymbol{\tau}$) dan vektor normal lokal dengan mempertimbangkan tanda $f$.

Persamaan integrasi kedalaman transpor massa Ekman ($\mathbf{M}_E$, satuan $\text{kg}/(\text{m}\cdot\text{s})$ atau volume transpor per meter garis pantai $\text{m}^2/\text{s}$ saat dibagi $\rho_w$):
$$\mathbf{M}_E = \frac{\boldsymbol{\tau} \times \hat{\mathbf{k}}}{\rho_w \, f}$$

Dalam komponen skalar Kartesius ($+x$ ke Timur, $+y$ ke Utara):
$$M_{ex} = \frac{\tau_y}{\rho_w \, f}, \quad M_{ey} = -\frac{\tau_x}{\rho_w \, f}$$
Dengan kerapatan air laut: $\rho_w = 1025\text{ kg/m}^3$.

### 4.2 Analisis Dinamika Selama Monsun Timur (Southeast Monsoon / JJA)
1. **Arah Angin:** Angin Monsun Tenggara bertiup dari arah Tenggara menuju Barat Laut. 
   - Komponen zonal bertiup ke arah barat: $u_{10} < 0 \implies \tau_x < 0$.
   - Komponen meridional bertiup ke arah utara: $v_{10} > 0 \implies \tau_y > 0$.
2. **Evaluasi Komponen Meridional ($M_{ey}$):**
   $$M_{ey} = -\frac{\tau_x}{\rho_w \, f} = -\frac{(-)}{\rho_w \, (-)} = -\frac{(+)}{(-)} \times (-1) = \text{NEGATIF } (<0)$$
   - Karena sumbu $+y$ mengarah ke Utara (ke daratan pulau Jawa), maka nilai $M_{ey} < 0$ menunjukkan transpor massa mengarah ke **SELATAN (menjauhi pantai / offshore)**.
3. **Konsekuensi Kontinuitas Massa di Pantai:**
   Garis pantai Jawa Timur berorientasi zonal Timur-Barat. Transpor massa air permukaan yang bergerak menjauhi pantai menimbulkan kekosongan massa fluida di mintakat pesisir (*coastal divergence* $\nabla \cdot \mathbf{M}_E > 0$). Secara konservasi massa, air yang hilang wajib digantikan oleh naiknya massa air sub-termoklin yang dingin, asin, dan kaya nutrien dari kedalaman $100\text{–}250\text{ meter}$ (*classical wind-driven coastal upwelling*).

---

## 5. PEMISAHAN KONSEPTUAL: TRANSPOR EKMAN PANTAI VS EKMAN PUMPING

Audit menemukan perlunya pemisahan yang tegas antara dua proses vertikal yang sering dikelirukan:

```
+-----------------------------------------------------------------------------------------+
|                  PERBEDAAN TRANSPOR EKMAN PANTAI VS PEMOMPAAN EKMAN                     |
+------------------------------+----------------------------------------------------------+
| Parameter Pembeda            | 1. Transpor Ekman Pantai     | 2. Pemompaan Ekman        |
|                              |    (Coastal Ekman Divergence)|    (Open-Ocean Pumping)  |
+------------------------------+------------------------------+---------------------------+
| Lokasi Terjadinya            | Mintakat Pesisir (0 - 30 NM) | Samudra Terbuka (>30 NM)  |
| Penggerak Utama              | Tegangan angin sejajar pantai| Rotasi/curl tegangan angin|
|                              | (Alongshore Wind Stress tx)  | (Wind Stress Curl rot(t)) |
| Rumus Kecepatan Vertikal (w) | w ~ M_ey / L_def             | w_E = curl(t) / (rho_w*f) |
| Efek Batas Daratan           | Mutlak membutuhkan pantai   | Tidak memerlukan daratan  |
| Peran di WPPNRI 573          | Upwelling pesisir Jawa Timur | Pengangkatan termoklin    |
|                              | saat Monsun Tenggara (JJA)   | kubah oseanik lepas pantai|
+------------------------------+------------------------------+---------------------------+
```

Kecepatan pemompaan Ekman lepas pantai dihitung melalui curl tegangan angin:
$$w_E = \frac{1}{\rho_w} \left( \frac{\partial}{\partial x}\left(\frac{\tau_y}{f}\right) - \frac{\partial}{\partial y}\left(\frac{\tau_x}{f}\right) \right) \approx \frac{1}{\rho_w f} \left( \frac{\partial \tau_y}{\partial x} - \frac{\partial \tau_x}{\partial y} \right) - \frac{\beta \tau_x}{\rho_w f^2}$$

Di Belahan Bumi Selatan ($f < 0$), pengangkatan air ke atas (*Ekman suction / upwelling*, $w_E > 0$) terjadi apabila nilai *wind stress curl* bernilai **negatif** ($\nabla \times \boldsymbol{\tau} < 0$).

---

## 6. PEMBAKUAN ISTILAH: COASTAL-OFFSHORE SST CONTRAST INDEX

### 6.1 Koreksi Terminologi
- Formula perbedaan suhu:
  $$\Delta T = \overline{\text{SST}}_{\text{offshore } (>60\text{ NM})} - \overline{\text{SST}}_{\text{coastal } (<12\text{ NM})}$$
- **Koreksi Ilmiah:** Istilah *Coastal Upwelling Index (CUI)* atau *Bakun Index* dicabut dan **DILARANG** digunakan untuk formula ini. Nama resmi yang wajib dipakai di seluruh sistem adalah:

$$\mathbf{Coastal\text{-}Offshore\text{ }SST\text{ }Contrast\text{ }Index\text{ }}(\Delta T_{c\text{-}o})$$

### 6.2 Batasan Ilmiah: Mengapa Kontras Suhu Bukan Bukti Tunggal Upwelling?
Auditor menegaskan bahwa penurunan suhu di dekat pantai ($\Delta T_{c\text{-}o} > 0$) **TIDAK DAPAT DIKLAIM SECARA TUNGGAL SEBAGAI BUKTI PASTI UPWELLING**, karena:
1. **Limpasan Air Sungai / Presipitasi Dingin:** Selama musim hujan lebat, aliran sungai dapat mendinginkan lapisan permukaan air teluk dangkal tanpa adanya proses penaikan massa air dalam.
2. **Pencampuran Pasang Surut (*Tidal Mixing*):** Di selat-selat sempit atau perairan dangkal dekat karang, turbulensi pasut dapat memecah stratifikasi suhu secara lokal.
3. **Tutupan Awan Pesisir:** Awan orografis di sepanjang pegunungan pantai selatan Jawa dapat membatasi radiasi matahari di pesisir dibandingkan di laut lepas yang cerah, menciptakan gradien suhu semu.

### Syarat Pembuktian Fenomena Upwelling yang Sah:
Fenomena *upwelling* di selatan Jawa baru terbukti secara ilmiah apabila terjadi **ko-eksistensi simultan** antara:
1. Nilai $\Delta T_{c\text{-}o}$ positif tinggi ($>1.5^\circ\text{C}$).
2. Transpor Ekman lepas pantai yang kuat ($M_{ey} < -3.0\text{ m}^2/\text{s}$).
3. Peningkatan biomassa klorofil-a ($>0.45\text{ mg/m}^3$) akibat injeksi nitrat/fosfat.
4. Penurunan anomali tinggi muka laut (*negative sea surface height anomaly / SSHA*) dari altimetri satelit yang mengindikasikan pendangkalan lapisan termoklin.

---

## 7. KESIMPULAN AUDIT TASK 3

1. Formulasi Coriolis $f = -2.1557 \times 10^{-5}\text{ s}^{-1}$ (negatif di Belahan Bumi Selatan) telah diverifikasi secara matematis.
2. Transpor massa Ekman terbukti bergerak ke selatan (lepas pantai) selama Monsun Timur sebagai hasil perkalian tegangan angin zonal barat ($\tau_x < 0$) dengan nilai $f < 0$.
3. Transpor Ekman pantai telah dipisahkan secara konseptual dan matematis dari pemompaan Ekman lepas pantai.
4. Nomenklatur perbedaan suhu telah dibakukan menjadi `Coastal-Offshore SST Contrast Index`, dengan penegasan batasan bahwa kontras suhu semata tidak boleh diklaim sebagai bukti tunggal upwelling tanpa dukungan variabel pendukung lainnya.
