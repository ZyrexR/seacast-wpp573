# PHASE 3.1 — PRESENCE-PROXY PROVENANCE & METHODOLOGICAL AUDIT
## Audit Forensik Asal-Usul Data Presensi, Dekonstruksi Aturan Sintesis, dan Evaluasi Sirkularitas Model
### WPPNRI 573 × PPN Prigi Spatial Fisheries Intelligence System

**Tanggal Audit:** 31 Oktober 2026  
**Auditor:** Senior Fisheries Ecologist, Marine Spatial Modeler & Independent Scientific Reviewer  
**Status Evaluasi:** SELESAI, TERAUDIT KRITIS & TERDOKUMENTASI KETAT (100% AUDITED)  
**Dokumen Induk:** Proyek Intelijen Geospasial Perikanan Pelagis PPN Prigi — WPPNRI 573  

---

## 1. PENDAHULUAN & RUANG LINGKUP AUDIT

Dalam pemodelan distribusi spesies (*Species Distribution Modeling / SDM*), kualitas data respon presensi (*presence data*) merupakan faktor paling deterministik yang menentukan keabsahan biologis (*biological validity*) keluaran model. 

Audit eksternal independen sebelumnya menemukan bahwa dataset presensi yang digunakan dalam pemodelan Phase 3 terdiri dari **981 titik presensi pseudo-proxy** yang tersebar pada tiga target komoditas utama:
- **Cakalang (*Katsuwonus pelamis*):** 405 titik (`presence_proxy_cakalang.geojson`).
- **Madidihang (*Thunnus albacares*):** 387 titik (`presence_proxy_madidihang.geojson`).
- **Albakor (*Thunnus alalunga*):** 189 titik (`presence_proxy_albakor.geojson`).
- *(Tambahan Indikator Bycatch)*: 105 titik Cucut/Hiu Tikus (*Carcharhinus spp.*).

Laporan ini menyajikan penelusuran forensik baris-per-baris kode sumber (*source code origin*), membongkar aturan heuristik pembuatannya, mengklasifikasikan kategori spasialnya, serta menganalisis secara ilmiah risiko **penalaran melingkar (*methodological circularity / tautology*)**.

---

## 2. PENELUSURAN ASAL-USUL TITIK (FORENSIC PROVENANCE TRACE)

Berdasarkan pemeriksaan mendalam terhadap skrip pembuatan data (`scratch/execute_stage_3_1_to_3_3.js`, baris 280–380):
- **Bukan Koordinat GPS Lapangan:** Tidak ada satupun dari 981 titik yang berasal dari perangkat Vessel Monitoring System (VMS), Automatic Identification System (AIS), Electronic Logbook (e-logbook), pengamat perikanan (*scientific observer on-board*), maupun penandaan satelit (*satellite tagging*).
- **Bukan Peta Tangkapan Pelabuhan:** Buku statistik tahunan PPN Prigi hanya mencatat tonase pendaratan ikan di dermaga (skalar kumulatif bulanan per komoditas) tanpa ada informasi lintang-bujur daerah penangkapan ikan (*fishing ground*).
- **Mekanisme Sintesis Riil:** Seluruh 981 titik dibangkitkan secara algoritmik dari **persimpangan (*intersection*) antara radius jangkauan kapal (*fleet accessibility buffer*) dan aturan ambang batas variabel lingkungan (*environmental envelope rules*)**.

---

## 3. DEKONSTRUKSI ALGORITMA SINTESIS PER SPESIES

Berikut adalah dekonstruksi aturan logis kode sumber yang menghasilkan 981 titik presensi tersebut:

### 3.1 Cakalang (*Katsuwonus pelamis*) — 405 Titik
- **Aturan Seleksi Spasial:**
  $$\text{dist\_harbor\_nm} \le 60\text{ NM} \quad \wedge \quad \text{depth\_m} \le -50\text{ m}$$
- **Aturan Lingkungan (Monsun Timur):**
  $$\text{SST} \in [24.5^\circ\text{C}, 28.5^\circ\text{C}] \quad \wedge \quad \text{Chlorophyll-}a \ge 0.30\text{ mg/m}^3$$
- **Skor Pembobotan:**
  $$\text{Score} = (\text{front} \ge 0.10 \text{ ? } 0.95 : 0.80) \times (\text{dist} \le 25 \text{ ? } 1.0 : 0.85)$$
  Titik disimpan jika $\text{Score} \ge 0.75$, menghasilkan **405 sel presensi**.

### 3.2 Madidihang (*Thunnus albacares*) — 387 Titik
- **Aturan Seleksi Spasial:**
  $$\text{dist\_harbor\_nm} \le 60\text{ NM} \quad \wedge \quad \text{depth\_m} \le -100\text{ m}$$
- **Aturan Lingkungan (Monsun Timur):**
  $$\text{SST} \in [25.0^\circ\text{C}, 28.5^\circ\text{C}] \quad \wedge \quad \text{Chlorophyll-}a \in [0.20, 1.20]\text{ mg/m}^3$$
- **Skor Pembobotan:**
  $$\text{Score} = (\text{front} \ge 0.08 \text{ ? } 0.92 : 0.78) \times (\text{dist\_to\_200m} \le 20\text{ km ? } 1.0 : 0.85)$$
  Titik disimpan jika $\text{Score} \ge 0.75$, menghasilkan **387 sel presensi**.

### 3.3 Albakor (*Thunnus alalunga*) — 189 Titik
- **Aturan Seleksi Spasial:**
  $$\text{dist\_harbor\_nm} \le 60\text{ NM} \quad \wedge \quad \text{depth\_m} \le -200\text{ m}$$
- **Aturan Lingkungan (Monsun Timur):**
  $$\text{SST} \le 25.8^\circ\text{C} \quad \wedge \quad \text{Chlorophyll-}a \ge 0.25\text{ mg/m}^3$$
- **Skor Pembobotan:**
  $$\text{Score} = (\text{SST} \le 25.0 \text{ ? } 0.95 : 0.80) \times (\text{dist\_to\_200m} \le 35\text{ km ? } 1.0 : 0.85)$$
  Titik disimpan jika $\text{Score} \ge 0.75$, menghasilkan **189 sel presensi**.

---

## 4. SISTEM KLASIFIKASI TRI-KATEGORI SPASIAL RESMI

Untuk mencegah kesalahpahaman oleh pengambil kebijakan dan peneliti perikanan, seluruh 981 titik presensi ini diklasifikasikan ke dalam **Kerangka Kerja Tri-Kategori Spasial**:

```
+-----------------------------------------------------------------------------------------+
|                  TRI-CATEGORICAL SPATIAL FISHERIES FRAMEWORK                            |
+-----------------------------------------------------------------------------------------+
| Kategori 1: OBSERVED FISHING LOCATION (Empirical Ground Truth)                          |
| - GPS logbook, VMS/AIS koordinat tangkap aktual, observer on-board.                     |
| - STATUS DATA PRIGI: TIDAK TERSEDIA (NOT AVAILABLE).                                    |
+-----------------------------------------------------------------------------------------+
| Kategori 2: FISHING ACTIVITY PROXY (Operational Footprint)                              |
| - Buffer jangkauan armada (12 NM untuk <10 GT; 60 NM untuk 20-30 GT), VIIRS boat lights.|
| - STATUS DATA PRIGI: TERSEDIA & DITERAPKAN (Fleet Accessibility Buffer).               |
+-----------------------------------------------------------------------------------------+
| Kategori 3: MODEL-DERIVED HABITAT SUITABILITY PROXY (Predicted Niche)                   |
| - Titik presensi sintesis berbasis persimpangan fisiologis dan operasional armada.       |
| - STATUS 981 TITIK: KATEGORI 3 / PROXY KATEGORI 1 (HEURISTIC ENVELOPE).                 |
+-----------------------------------------------------------------------------------------+
```

### Mandat Metadata GeoJSON:
Seluruh file GeoJSON presensi wajib mempertahankan atribut eksplisit berikut pada setiap fiturnya:
- `category_code = 1` *(Internal Project Schema: Model-Derived Presence-Proxy)*.
- `category_label = "Model-Derived Presence-Proxy (Fishing Envelope Co-Occurrence)"`.
- `confidence_level = "Medium (Fleet Envelope + Historical Landings Alignment)"`.
- **DILARANG MENGUBAH LABEL MENJADI "ACTUAL PRESENCE" ATAU "OBSERVED GPS".**

---

## 5. ANALISIS SIRKULARITAS METODOLOGIS (METHODOLOGICAL CIRCULARITY)

Penemuan forensik ini mengungkap implikasi ilmiah mendasar yang wajib dicatat dalam naskah ilmiah:

### 5.1 Mekanisme Sirkularitas
1. **Tahap 1 (Injeksi Aturan):** Peneliti menyaring sel-sel kisi yang memiliki $\text{SST} \in [24.5, 28.5]^\circ\text{C}$ dan $\text{Chl-}a \ge 0.30\text{ mg/m}^3$ untuk dijadikan titik presensi Cakalang.
2. **Tahap 2 (Pelatihan Model SDM):** Titik presensi tersebut dimasukkan ke dalam algoritma MaxEnt, Random Forest, dan GLM bersama lapisan prediktor lingkungan (SST, Chl-a, Kedalaman, Jarak Pantai).
3. **Tahap 3 (Evaluasi Kurva Respon):** Algoritma menghasilkan kurva respon yang menyimpulkan bahwa *"Cakalang menyukai suhu 25–28°C dan klorofil tinggi"* serta memberikan nilai AUC yang sangat tinggi ($>0.88$).

### 5.2 Konsekuensi Epistemologis
- **Tautologi:** Model pada dasarnya mereproduksi kembali aturan matematis yang dimasukkan pada Tahap 1. Model **bukan menemukan relasi ekologis baru dari alam liar**, melainkan memetakan kembali distribusi spasial dari kriteria heuristik awal.
- **Inflasi Metrik Kinerja:** Nilai AUC ($0.88\text{–}0.92$) dan TSS ($0.65\text{–}0.78$) yang tinggi merefleksikan konsistensi internal algoritma dalam memisahkan sel yang lolos kriteria heuristik terhadap latar belakang acak, **BUKAN validasi ekologis di laut lepas**.
- **Keterbatasan Generalisasi:** Model tidak dapat digunakan untuk mengklaim penemuan relasi relung ekologis baru di luar kriteria yang telah ditentukan di awal.

---

## 6. REKOMENDASI PENANGANAN DAN MITIGASI ILMIAH

1. **Deklarasi Transparan:** Dalam setiap bab laporan ilmiah, presentasi, dan visualisasi dashboard, 981 titik ini harus selalu disebut sebagai **"Heuristic Presence-Proxies"** atau **"Fleet-Envelope Pseudo-Presences"**.
2. **Validasi Silang Terhadap Data Independen Masa Depan:** Jika di masa depan tersedia data VMS/AIS dari PSDKP atau data penandaan pop-up (*PSAT tagging*) dari BBRBLPP, model ini harus diuji ulang menggunakan data Kategori 1 yang murni independen.
3. **Peran Positif Model:** Meskipun bersifat sirkular secara relung lingkungan mikro, model ini tetap memiliki nilai operasional tinggi sebagai **pemetaan skenario spasial (*exploratory spatial screening*)** yang memadukan batas jangkauan armada nelayan dengan massa air upwelling musiman.

---

## 7. KESIMPULAN TASK 5

Silsilah dan asal-usul 981 titik presensi telah terpetakan secara lengkap dan transparan. Model diakui secara jujur sebagai *proxy-based system*, menghapuskan segala klaim semu mengenai observasi GPS lapangan riil, serta menempatkan hasil evaluasi model pada konteks ilmiah yang tepat dan bertanggung jawab.
