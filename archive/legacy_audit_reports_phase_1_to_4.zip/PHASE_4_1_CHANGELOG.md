# PHASE 4.1 — TECHNICAL CHANGELOG
## Sistem Intelijen Geospasial Perikanan Pelagis PPN Prigi — WPPNRI 573

- **Release Version:** `4.1.0-BASELINE-REMEDIATED`
- **Date:** 2026-11-01
- **Pre-Remediation Snapshot:** `backups/phase_4_1_pre_remediation/` (`backup_manifest.json`)

---

## 1. New Files Created in Phase 4.1

| File Path | Purpose | SHA-256 Hash |
| :--- | :--- | :--- |
| `data/master.csv` | Canonical 132-month master dataset for Streamlit app (`18,405,261 kg`, `dummy=False`) | `09fdea081a29f2b1...` |
| `data/species_traits.csv` | Canonical species biological/conservation table for Streamlit Page 5 | `8abbba8f80f48479...` |
| `data/prigi_elasmobranch_bycatch_records.csv` | Canonical 132-month Cucut (`Carcharhinus spp.`) landing records (`127,452 kg`) with 8 CITES fields | `a7d07c49b8e7ede5...` |
| `outputs/sdm/hsi/rhsi_sensitivity_analysis.json` | Full sensitivity analysis across lambda, weight schemes, and thresholds | `f7c5a382d457fdd6...` |
| `scratch/validate_polygon_geometries.py` | Automated topological & equal-area validator for all 5 SDM GeoJSON zone layers | `432185865b9572f1...` |
| `scratch/test_phase_4_1_integrity.py` | Automated Phase 4.1 verification suite (`T-01`..`T-07`) and readiness gate builder | `d493793c7e0556bf...` |
| `PHASE_4_1_BASELINE_AUDIT.md` | Stage 0 read-only baseline audit & remediation plan | `b097cc85c40489ab...` |
| `PHASE_4_1_READINESS_GATE.json` | Reconstructed Phase 4.1 readiness gate (`PG-01`..`PG-14`) from actual test execution | `9afbfb1d78950bfa...` |

---

## 2. Remediated Baseline Files (Before vs After SHA-256 Hashes)

| File Path | Pre-Remediation SHA-256 (Prefix) | Post-Remediation SHA-256 (Prefix) | Modified |
| :--- | :--- | :--- | :---: |
| `data/master_prigi_all_inclusive.csv` | `004d07982f1bf86e...` | `2e09566a77985c43...` | **YES** |
| `data/oceanographic/statistics/monthly/monthly_stats_prigi.csv` | `3ac4b82fb8a0f605...` | `d3b207f5112c1431...` | **YES** |
| `data/oceanographic/statistics/monthly/monthly_stats_wpp573.csv` | `984a95c4fd6a67c4...` | `984a95c4fd6a67c4...` | **NO (Read-Only Reference)** |
| `data/oceanographic/statistics/monthly/ocean_fisheries_master_132m.json` | `2a2bea39938b1264...` | `6a8864d2f1b6a088...` | **YES** |
| `PHASE_3_1_OCEANOGRAPHIC_QC.csv` | `97a411b318881759...` | `89e4b68a12830ff4...` | **YES** |
| `FINAL_OCEANOGRAPHIC_MONTHLY_QC.csv` | `5b690f6fc8b405e7...` | `99dbb7cef68171fd...` | **YES** |
| `data/spatial_config_aoi.json` | `e21f8c5865f1f7c5...` | `ef3fdaee68240a57...` | **YES** |
| `data/spatial_readiness_report.json` | `b7ee5bd904f1e0cc...` | `3da4936fa22545e5...` | **YES** |
| `data/manifests/processing_manifest.json` | `291f19df6e2a480c...` | `99bae960e3146275...` | **YES** |
| `data/oceanographic/metadata/data_sources.json` | `c5d3c8a46f0d6857...` | `9fe8428c70b24720...` | **YES** |
| `data/oceanographic/metadata/quality_control_report.json` | `2f17a2c4a48944ed...` | `2ae69181e2912f96...` | **YES** |
| `data/oceanographic/metadata/pilot_verification_report.json` | `38349e80eb124810...` | `24f684635795f8f3...` | **YES** |
| `data/oceanographic/metadata/variable_dictionary.json` | `2b398935b743c3ac...` | `e62730917768362f...` | **YES** |
| `data/oceanographic/processed/monthly/pilot_ocean_2024_01.json` | `c1db1d8afa3542fb...` | `e4cff4cda598c3af...` | **YES** |
| `data/oceanographic/processed/monthly/pilot_ocean_2024_07.json` | `414fe6694e318540...` | `df180195b5e4e358...` | **YES** |
| `data/oceanographic/processed/seasonal/grid_musim_timur_climatology.json` | `a31442db5435fddf...` | `864eb9f5ba800856...` | **YES** |
| `data/oceanographic/processed/seasonal/grid_musim_barat_climatology.json` | `3989da119a74aa33...` | `19af7ceabec0859a...` | **YES** |
| `data/oceanographic/processed/seasonal/grid_extreme_2019_super_iod.json` | `1527a5a79a4bdd01...` | `f3895d885ee5bbf3...` | **YES** |
| `data/oceanographic/processed/seasonal/grid_extreme_2016_negative_iod.json` | `4ec53b0c07086bd5...` | `abff3f92031280b7...` | **YES** |
| `data/oceanographic/derived/bathymetry_features/prigi_shelf_break_200m.geojson` | `ce1a79c9747356ce...` | `8cb16198196e23fc...` | **YES** |
| `data/oceanographic/derived/upwelling/ocean_fisheries_correlation.json` | `e5fac753a61ba5e3...` | `852543712e1c0274...` | **YES** |
| `data/sdm/background/target_group_background.geojson` | `2a7199516f4fdd3c...` | `544f80998553ace7...` | **YES** |
| `data/sdm/predictors/predictor_stack_metadata.json` | `648e16f71d9d7a21...` | `55d0174b5b820413...` | **YES** |
| `data/sdm/predictors/predictor_stack_multi_scenario.json` | `11b7ca54b1f8f3c1...` | `86a30b13321a7e46...` | **YES** |
| `PHASE_3_MODEL_METADATA.json` | `8456a4bcdbeeb9ac...` | `1e0984d2f547a3b9...` | **YES** |
| `models/sdm/ensemble/model_evaluations_summary.json` | `433c1943e12fa3f3...` | `c8015a2f443a380d...` | **YES** |
| `outputs/sdm/hsi/hsi_all_scenarios_projections.json` | `b81340d30380a967...` | `71c7a92614fad0d9...` | **YES** |
| `outputs/sdm/zones/dynamic_bycatch_mitigation_zones.geojson` | `fd45bf0d334789fe...` | `3af485926b3392da...` | **YES** |
| `outputs/sdm/zones/functional_ecological_zones.geojson` | `c094876373c60645...` | `b5f38678f698191e...` | **YES** |
| `outputs/sdm/zones/functional_zones_cakalang.geojson` | `13ac24e918ed6982...` | `4b09ba71383fccb5...` | **YES** |
| `outputs/sdm/zones/functional_zones_madidihang.geojson` | `b84700bfd9a443d6...` | `ed88f19f6e4eb49d...` | **YES** |
| `outputs/sdm/zones/functional_zones_albakor.geojson` | `1d7af819138f3e56...` | `c1eb98046b47ca33...` | **YES** |
| `html/index.html` | `750eded735df1379...` | `c9676f5a06b431bf...` | **YES** |
| `html/oceanographic_data.js` | `b6cabc969db160ae...` | `3f8842223082bf22...` | **YES** |
| `html/sdm_data.js` | `722fca24dfd8fba1...` | `fe9d7a148935123c...` | **YES** |
| `app.py` | `48a50c28bf837c13...` | `48a50c28bf837c13...` | **NO (Read-Only Reference)** |
| `utils.py` | `e118c5cd92516b15...` | `3c7b7bc96c99286b...` | **YES** |
| `pages/2_Iklim_dan_Laut.py` | `29643694b78f69d8...` | `30cb070f727e34d5...` | **YES** |
| `pages/5_Spesies_dan_Pengelolaan.py` | `98e0cf65417aec7f...` | `09bf993ec14c686e...` | **YES** |
| `pages/6_Data_dan_Keterbatasan.py` | `b6d3426fa81c2357...` | `b6d3426fa81c2357...` | **NO (Read-Only Reference)** |
| `scratch/execute_stage_3_1_to_3_3.js` | `172add79780afd6b...` | `9bdc541c55915938...` | **YES** |
| `scratch/execute_stage_3_4_to_3_7.js` | `d39b9db96a905b7b...` | `cfc79875e99eb5b3...` | **YES** |
| `scratch/optimize_sdm_web_bundle.js` | `6fc497687721a5a2...` | `94af24c0e66d156b...` | **YES** |
| `scratch/validate_polygon_geometries.py` | `c73f002cc19ecd6c...` | `432185865b9572f1...` | **YES** |
