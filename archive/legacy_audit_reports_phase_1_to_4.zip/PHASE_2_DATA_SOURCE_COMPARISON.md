# PHASE 2 DATA SOURCE COMPARISON & SCIENTIFIC SELECTION MATRIX
## Oceanographic Data Candidates for WPPNRI 573 × PPN Prigi (2015–2025)
### Analisis Komparatif, Resolusi, Validitas Metodologis, dan Justifikasi Pemilihan Produk

---

### 1. PENDAHULUAN & KRITERIA EVALUASI

Pemilihan sumber data oseanografi untuk kurun waktu 11 tahun (Januari 2015 s.d. Desember 2025) di perairan **WPPNRI 573 (Samudra Hindia selatan Jawa hingga Laut Timor)** didasarkan pada 7 kriteria ilmiah yang ketat:
1. **Validitas Ilmiah & Pengakuan Global:** Produk resmi lembaga rujukan oseanografi (NASA, NOAA, ECMWF, Copernicus Marine, GEBCO).
2. **Kelengkapan Temporal Tanpa Celah:** Tersedia konsisten dari 1 Januari 2015 hingga 31 Desember 2025 (132 bulan penuh).
3. **Resolusi Spasial yang Relevan:** Mampu menangkap dinamika mesoscale (upwelling, front termal, dan sirkulasi arus di perairan selatan Jawa).
4. **Resiliensi terhadap Gangguan Awan:** Mengingat tingginya tutupan awan saat Monsun Barat, produk harus memiliki metode komposit atau asimilasi reanalisis yang andal.
5. **Aksesibilitas & Reproduksibilitas:** Dapat diakses via API terbuka / Google Earth Engine (GEE) / OPeNDAP tanpa biaya komersial.
6. **Konsistensi Format & Georeferensi:** Standar NetCDF4 / GeoTIFF pada datum WGS 84.
7. **Kesesuaian Skala:** Optimal untuk luasan regional WPPNRI 573 dan Sub-AOI Prigi.

---

### 2. MATRIKS PERBANDINGAN SUMBER DATA (MANDATORY COMPARISON MATRIX)

| Variable | Product Name | Provider | Dataset ID / Identifier | Source URL | Temp. Res. | Spatial Res. | Temporal Coverage | Native Unit | CRS | Format | Access Method | Limitations | Selected? | Scientific Justification |
| :--- | :--- | :--- | :--- | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :--- | :--- | :---: | :--- |
| **SST (Kandidat 1)** | MODIS-Aqua L3 SMI SST | NASA OceanColor | `MODIS-Aqua/L3SMI/SST` | `https://oceancolor.gsfc.nasa.gov` | Bulanan | 4.63 km (~0.041°) | 2002–Sekarang | °C | WGS 84 | NetCDF / GEE Asset | GEE API / NASA Direct | Sel kosong di area awan tebal musiman | **YA (Primer Spasial)** | Standar emas oseanografi perikanan tropis; tersedia di GEE; resolusi 4 km sangat pas untuk deteksi thermal front di selatan Jawa. |
| **SST (Kandidat 2)** | NOAA Daily Optimum Interpolation SST (OISST) v2.1 | NOAA NCEI | `NOAA/CDR/OISST/V2_1` | `https://www.ncei.noaa.gov/products/optimum-interpolation-sst` | Harian / Bulanan | 0.25° (~27 km) | 1981–Sekarang | °C | WGS 84 | NetCDF4 / GEE | GEE / NOAA THREDDS | Resolusi spasial relatif kasar untuk teluk pesisir | **YA (Validasi & Anomali)** | Bebas sel kosong karena metode interpolasi optimum (asimilasi in-situ + satelit); sangat kokoh untuk baseline anomali iklim 11 tahun. |
| **SST (Kandidat 3)** | GHRSST Level 4 MUR SST | NASA JPL / PO.DAAC | `JPL-L4_GHRSST-SSTfnd-MUR-GLOB` | `https://podaac.jpl.nasa.gov` | Harian | 0.01° (~1 km) | 2002–Sekarang | Kelvin / °C | WGS 84 | NetCDF4 | AWS S3 / Earthdata | Volume file sangat masif (>1 TB untuk 11 tahun), komputasi berat | **TIDAK (Terlalu Berat)** | Tidak efisien untuk komputasi regional WPPNRI 573 seluas 61.500 km²; rentan memory bottleneck. |
| **SST (Kandidat 4)** | Global Ocean OSTIA SST L4 | Copernicus Marine | `SST_GLO_SST_L4_REP_OBSERVATIONS_010_011` | `https://marine.copernicus.eu` | Harian | 0.05° (~5.5 km) | 1981–Sekarang | Kelvin / °C | WGS 84 | NetCDF4 | Copernicus Marine Toolbox API | Butuh token akun Copernicus | **CADANGAN (Alternatif)** | Sangat baik, namun MODIS Aqua via GEE lebih cepat diakses tanpa hambatan kuota unduh server. |
| **Chlorophyll-a (Kandidat 1)** | MODIS-Aqua L3 SMI Chlor_a | NASA OceanColor | `MODIS-Aqua/L3SMI/chlor_a` | `https://oceancolor.gsfc.nasa.gov` | Bulanan | 4.63 km (~0.041°) | 2002–Sekarang | mg/m³ | WGS 84 | NetCDF / GEE Asset | GEE API / NASA Direct | Kualitas optik terdegradasi di perairan sangat keruh pesisir (Case 2 water) | **YA (Primer Spasial)** | Berpasangan langsung dengan MODIS SST pada sensor dan platform yang sama; kalibrasi biologi laut terstandar internasional. |
| **Chlorophyll-a (Kandidat 2)** | Global Ocean Colour Multi-Sensor | Copernicus Marine | `OCEANCOLOUR_GLO_BGC_L4_MY_009_104` | `https://marine.copernicus.eu` | Bulanan | 4 km | 1997–Sekarang | mg/m³ | WGS 84 | NetCDF4 | Copernicus API | Data reprocessing reanalisis memiliki latency rilis | **CADANGAN** | Penggabungan sensor Sentinel-3 OLCI + MODIS + VIIRS sangat minim data hilang, cocok untuk cross-check. |
| **Batimetri (Kandidat 1)** | GEBCO 2023 Grid | GEBCO / BODC | `GEBCO_2023_Grid` | `https://www.gebco.net` | Statis | 15 arc-second (~450 m) | Versi 2023 | Meter (kedalaman negatif) | WGS 84 | GeoTIFF / NetCDF | GEBCO Portal / WMS | File grid global cukup besar (~8 GB) jika tidak di-crop | **YA (Primer Batimetri)** | Resolusi 450 m sangat presisi memetakan kontur tubir benua (*shelf-break* 200–1.000 m) di selatan Prigi. |
| **Batimetri (Kandidat 2)** | NOAA ETOPO 2022 / ETOPO1 | NOAA NCEI | `NOAA/NGDC/ETOPO1` | `https://www.ncei.noaa.gov/products/etopo-global-relief-model` | Statis | 1 arc-minute (~1.8 km) / 15 arc-sec | Versi 2022 | Meter | WGS 84 | GeoTIFF / GEE Asset | GEE API / NOAA Direct | Resolusi ETOPO1 1.8 km sedikit lebih kasar dari GEBCO | **YA (Integrasi GEE)** | Tersedia *native* di Google Earth Engine untuk komputasi *cloud-based* instan dan penurunan kemiringan lereng (*slope*). |
| **Arus Laut (Kandidat 1)** | Global Ocean Physics Reanalysis (GLORYS12V1 & Analysis) | Copernicus Marine | `GLOBAL_MULTIYEAR_PHY_001_030` & `GLOBAL_ANALYSISFORECAST_PHY_001_024` | `https://marine.copernicus.eu` | Bulanan / Harian | 1/12° (~8.3 km) | 1993–Sekarang | m/s | WGS 84 | NetCDF4 | Copernicus Marine Toolbox API | 1993–2020 reanalisis, 2021–2025 operasional analisis (perlu harmonisasi) | **YA (Primer Arus)** | Menyediakan komponen u dan v hingga 50 lapisan kedalaman; standar fisika laut terdepan dunia. |
| **Arus Laut (Kandidat 2)** | Ocean Surface Current Analysis Real-time (OSCAR) | NOAA / PO.DAAC | `OSCAR_L4_OC_third-deg` | `https://podaac.jpl.nasa.gov` | 5-harian / Bulanan | 0.33° (~36 km) | 1992–Sekarang | m/s | WGS 84 | NetCDF4 | PO.DAAC / GEE | Hanya permukaan (top 30m), resolusi kasar 36 km | **TIDAK** | Resolusi 36 km terlalu kasar untuk mendeteksi arus susur pantai dan eddy mesoscale di Teluk Prigi. |
| **Angin 10m (Kandidat 1)** | ECMWF ERA5 Monthly Averaged Reanalysis | ECMWF / Copernicus CDS | `ECMWF/ERA5/MONTHLY` | `https://cds.climate.copernicus.eu` | Bulanan | 0.25° (~27 km) | 1940–Sekarang | m/s | WGS 84 | NetCDF / GEE Asset | GEE API / CDS API | Resolusi 27 km tidak menangkap angin orografis pantai sempit | **YA (Primer Angin)** | Rekor terpercaya dunia untuk dinamika monsun, perhitungan *wind stress*, dan indeks transpor Ekman upwelling. |
| **Angin 10m (Kandidat 2)** | CCMP v3.0 Cross-Calibrated Wind | Remote Sensing Systems | `RSS-CCMP-V3.0` | `http://www.remss.com` | 6-jam / Harian | 0.25° | 1987–Sekarang | m/s | WGS 84 | NetCDF4 | RSS Direct | Akses server sering terkendala | **TIDAK** | ERA5 jauh lebih stabil dan sudah tersedia di GEE. |
| **Gelombang (Kandidat 1)** | ERA5 Reanalysis Marine Wave | ECMWF / Copernicus CDS | `reanalysis-era5-single-levels-monthly-means` | `https://cds.climate.copernicus.eu` | Bulanan | 0.5° (~50 km) | 1940–Sekarang | Meter (Hs), Derajat (Dir) | WGS 84 | NetCDF / GEE | GEE API / CDS API | Resolusi gelombang laut 50 km | **YA (Primer Gelombang)** | Sangat konsisten dengan data angin ERA5; menyediakan variabel Tinggi Gelombang Signifikan ($H_s$) dan periode gelombang. |
| **Gelombang (Kandidat 2)** | Global Ocean Wave Reanalysis | Copernicus Marine | `GLOBAL_MULTIYEAR_WAV_001_032` | `https://marine.copernicus.eu` | Bulanan / 3-jam | 0.2° (~22 km) | 1993–Sekarang | Meter | WGS 84 | NetCDF4 | Copernicus API | Memerlukan kuota unduh terpisah | **CADANGAN** | Alternatif resolusi lebih tinggi jika simulasi kapal kecil membutuhkan presisi gelombang pesisir. |

---

### 3. DETAIL FORMULASI INDIKATOR UPWELLING & THERMAL FRONT

Salah satu poin penting instruksi adalah: **Jangan mengunduh satu layer bernama "upwelling" tanpa mengetahui definisinya secara matematis dan fisik.**

Untuk perairan WPPNRI 573 (Selatan Jawa), Phase 2 akan menerapkan **Dua Pendekatan Upwelling yang Berbeda & Terpisah**:

#### A. Coastal Thermal Contrast Upwelling Index ($CUI_{thermal}$)
Mengukur perbedaan suhu antara perairan pesisir (neritik Prigi) dan perairan lepas pantai Samudra Hindia:
$$CUI_{thermal}(m, y) = SST_{offshore}(m, y) - SST_{coastal}(m, y)$$
* **Logika Fisik:** Saat terjadi upwelling Monsun Timur, massa air dingin terangkat di dekat pantai selatan Jawa, sehingga $SST_{coastal}$ anjlok tajam (mencapai 25,5°C) sementara $SST_{offshore}$ masih berada pada kisaran 27,5°C–28,0°C.
* **Interpretasi Nilai:**
  * $CUI_{thermal} > +1,0^\circ\text{C}$ : Upwelling kuat aktif.
  * $0,0^\circ\text{C} \le CUI_{thermal} \le +1,0^\circ\text{C}$ : Upwelling moderat / peralihan.
  * $CUI_{thermal} < 0,0^\circ\text{C}$ : Kondisi non-upwelling (Musim Barat).

#### B. Wind-Driven Cross-Shore Ekman Mass Transport ($M_{Ekman}$)
Upwelling di selatan Jawa dipicu oleh angin Monsun Tenggara yang bertiup sejajar pantai dari timur ke barat. Menurut teori Ekman:
$$\tau_x = \rho_{air} \cdot C_D \cdot U_{10} \cdot \sqrt{U_{10}^2 + V_{10}^2}$$
$$M_{Ekman} = -\frac{\tau_x}{\rho_{water} \cdot f} \quad (\text{satuan: } \text{kg}\cdot\text{m}^{-1}\cdot\text{s}^{-1} \text{ atau } \text{m}^2/\text{s})$$
* **Parameter Fisik:**
  * $\rho_{air} = 1,225\text{ kg/m}^3$ (densitas udara).
  * $C_D \approx 1,3 \times 10^{-3}$ (koefisien hambatan permukaan laut).
  * $\rho_{water} \approx 1.025\text{ kg/m}^3$ (densitas air laut).
  * $f = 2\Omega \sin(\phi)$ (parameter Coriolis, bernilai negatif di Belahan Bumi Selatan sekitar $-8,5^\circ\text{ S}$, $f \approx -2,15 \times 10^{-5}\text{ s}^{-1}$).
* **Arah Transpor:** Nilai $\tau_x$ negatif (angin dari timur) dibagi $f$ negatif menghasilkan transpor massa air laut ke arah lepas pantai (ke selatan), yang memicu penarikan air dasar laut ke permukaan (*upwelling*).

#### C. Deteksi Thermal Front Berbasis Gradien Spasial
Thermal front dihitung menggunakan turunan parsial spasial pada grid SST dengan kernel Sobel:
$$G_x = \frac{\partial SST}{\partial x}, \quad G_y = \frac{\partial SST}{\partial y}$$
$$\|\nabla SST\| = \sqrt{G_x^2 + G_y^2} \quad (\text{satuan terstandarisasi: } ^\circ\text{C} / \text{km})$$
* **Ambang Batas Deteksi:** $\|\nabla SST\| \ge 0,08^\circ\text{C}/\text{km}$ (ekuivalen dengan perubahan suhu $\ge 0,35^\circ\text{C}$ melintasi sel pixel 4,63 km) ditetapkan sebagai batas zona *thermal front* aktif.

---

### 4. KESIMPULAN PRODUK TERPILIH (FINAL SELECTION)

Berdasarkan pertimbangan ilmiah, cakupan 11 tahun (2015–2025), dan stabilitas akses:
1. **SST:** NASA MODIS-Aqua L3 SMI (Primer 4 km) + NOAA OISST v2.1 (Validasi Anomali).
2. **Klorofil-a:** NASA MODIS-Aqua L3 SMI (Primer 4 km).
3. **Batimetri & Slope:** GEBCO 2023 Grid (450 m) + NOAA ETOPO1 (GEE Native).
4. **Angin 10m:** ECMWF ERA5 Monthly Reanalysis (0.25°).
5. **Gelombang Signifikan ($H_s$):** ECMWF ERA5 Marine Wave (0.5°).
6. **Arus Permukaan:** Copernicus Marine GLORYS12V1 / GLOBAL_PHY (1/12° ~ 8 km).
