# PHASE 4.1 — DATA INTEGRITY REPORT
## Sistem Intelijen Geospasial Perikanan Pelagis PPN Prigi — WPPNRI 573

- **Audit Date:** 2026-11-01 (Reconciled in Phase 4.1.1)
- **Canonical Source Dataset:** `data/master_prigi_all_inclusive.csv` (reconciled against `Laporan Statistik Perikanan PPN Prigi 2025.xlsx` Sheet 2 & Sheet 5, `Audit_Sheet5_CellByCell.csv`, and `FINAL_FISHERIES_MONTHLY_AUDIT.csv`)
- **Temporal Coverage:** January 2015 – December 2025 (`132` continuous calendar months)
- **Verification Status:** `PASS` (`0` cross-file numerical discrepancies)

---

## 1. Canonical Production & Effort Reconciliation (2015–2025)

| Metric | Pre-Remediation Conflicting Values | Canonical Verified Value | Synchronized Files |
| :--- | :--- | :--- | :--- |
| **April 2022 Total Catch** | `198,446 kg` vs `198,246 kg` | **`198,246 kg`** (`Cakalang = 122,265 kg`) | `master_prigi_all_inclusive.csv`, `master.csv`, `monthly_stats_prigi.csv`, `ocean_fisheries_master_132m.json`, `html/oceanographic_data.js`, `html/index.html` |
| **2022 Annual Catch** | `1,992,632 kg` vs `1,992,432 kg` | **`1,992,432 kg`** | `annual_climatology.json`, `html/oceanographic_data.js` |
| **Peralihan 1 (MAM) Catch** | `4,027,222 kg` (`mean 122,037 kg`) | **`4,027,022 kg`** (`mean 122,031 kg`) | `seasonal_climatology.json`, `html/oceanographic_data.js` |
| **132-Month Cumulative Catch (2015–2025)** | `18,827,401 kg` / `18,405,461 kg` / `18,405,261 kg` | **`18,405,261 kg`** (`total_selected_taxa_catch_kg`, 12 Sheet 5 categories; `pelagic_catch_kg = 18,070,653 kg` [98.18%]) | All CSV, JSON, JS, HTML, and Streamlit files |
| **Fishing Trips (2015–2025, 132 Months)** | `189,334` vs `249,257` vs `166,731` | **`189,334 trips`** (5 primary pelagic gears, 2015–2025) | `master_prigi_all_inclusive.csv`, `master.csv`, `monthly_stats_prigi.csv`, `html/index.html` |
| **All-Inclusive Historical Trips (2012–2025)** | Conflated with 11-year study period | **`249,257 trips`** (14-year historical archive) | Explicitly labeled in `html/index.html` and `PHASE_4_1_READINESS_GATE.json` |
| **Active Fishing Fleet (2025)** | `794` (2016 peak; `688` in 2021) vs `443` (2025 active) | **`443 units`** (`296` `<10 GT`, `53` `10–20 GT`, `91` `20–30 GT`, `3` `>30 GT`) | `html/index.html`, `PHASE_3_MODEL_METADATA.json`, `effort_bias_surface.json`, `prigi_fleet_by_gt_2015_2025.csv` |

---

## 2. Canonical 12-Taxon Cumulative Production Breakdown (132 Months)

| ID | Local Name | Scientific Name | Role / Classification | Verified 11-Year Catch (kg) | Share (%) | IUCN / CITES Status |
| :--- | :--- | :--- | :--- | ---: | ---: | :--- |
| 1 | Cakalang (Blereng) | *Katsuwonus pelamis* | Target Pelagic (SDM Modeled) | `8,294,092` | `45.06%` | Least Concern (IUCN 2021) |
| 2 | Tongkol Krai | *Auxis thazard* | Neritic-Oceanic Pelagic | `3,094,621` | `16.81%` | Least Concern (IUCN 2021) |
| 3 | Madidihang (YFT) | *Thunnus albacares* | Target Pelagic (SDM Modeled) | `2,933,924` | `15.94%` | Least Concern (IUCN 2021) |
| 4 | Tongkol Como | *Euthynnus affinis* | Neritic Pelagic | `2,412,039` | `13.11%` | Least Concern (IUCN 2021) |
| 5 | Tongkol Kenyar | *Sarda orientalis* | Neritic Pelagic | `520,888` | `2.83%` | Least Concern (IUCN 2021) |
| 6 | Albakor | *Thunnus alalunga* | Target Pelagic (SDM Modeled) | `316,632` | `1.72%` | Least Concern (IUCN 2021) |
| 7 | Setuhuk Hitam / Marlin | *Istiompax indica* | Apex Billfish Indicator | `315,281` | `1.71%` | Data Deficient / Vulnerable |
| 8 | Gulamah / Awon | *Johnius / Nibea spp.* | Demersal Port-Record Exception | `207,156` | `1.13%` | Data Deficient (Demersal Exception) |
| 9 | Hiu Cucut (Bycatch) | *Carcharhinus spp.* | Elasmobranch Bycatch Screening | `127,452` | `0.69%` | `NEEDS_VERIFICATION` (CITES App. II / App. I Check `2026-03-05`) |
| 10 | Julung-julung | *Hemiramphus spp.* | Surface Small Pelagic Exception | `68,906` | `0.37%` | Genus Complex (LC / NE) |
| 11 | Tuna Mata Besar (BET) | *Thunnus obesus* | Deep Pelagic Target | `63,135` | `0.34%` | Vulnerable (IUCN 2021) |
| 12 | Tenggiri | *Scomberomorus commerson* | Neritic Pelagic | `51,135` | `0.28%` | Near Threatened (IUCN 2023) |
| **Total (12 Taxa)** | **`total_selected_taxa_catch_kg`** | **PPN Prigi Sheet 5 Audited** | **132 Months (2015–2025)** | **`18,405,261`** | **`100.00%`** | **Legacy Alias: `total_pelagis_kg`** |
| **Pelagic Subset (10 Taxa)** | **`pelagic_catch_kg`** | **True Teleost Pelagic Landings** | **9 Large (`18,001,747`) + 1 Small (`68,906`)** | **`18,070,653`** | **`98.18%`** | **Excludes Gulamah & Cucut** |
| **Demersal Exception** | **`demersal_exception_kg`** | ***Johnius / Nibea spp.* (Gulamah)** | **Sheet 5 Col I Exception** | **`207,156`** | **`1.13%`** | **Excluded from `pelagic_catch_kg`** |
| **Elasmobranch Bycatch** | **`elasmobranch_bycatch_kg`** | ***Carcharhinus spp.* (Cucut)** | **Sheet 5 Col K Bycatch** | **`127,452`** | **`0.69%`** | **Excluded from `pelagic_catch_kg`** |

---

## 3. Oceanographic Time-Series Synchronization (`CONF-08` & `CONF-09`)

1. **Sub-AOI Prigi vs WPPNRI 573 Series:** `sst_mean`, `chl_mean`, and `hs_mean` in `data/master_prigi_all_inclusive.csv`, `data/master.csv`, and `html/index.html` (`masterData`) are now 100% synchronized with `prigi_sst_mean`, `prigi_chl_mean`, and `hs_wave_m` in `data/oceanographic/statistics/monthly/ocean_fisheries_master_132m.json` (`0` differences across all 132 months). Broad regional series are explicitly preserved as `wpp573_sst_mean` and `wpp573_chl_mean` in `PHASE_3_1_OCEANOGRAPHIC_QC.csv` and `FINAL_OCEANOGRAPHIC_MONTHLY_QC.csv`.
2. **Verified Lag-0 Statistical Associations (Non-Causal, Evaluated on Both 12-Taxon Total & 10-Taxon True Pelagic Subset):**
   - `Total Selected Taxa (12)` vs `Thermal Front Sobel`: `r = +0.3954` (`pelagic_catch_kg (10)`: `r = +0.3880`)
   - `Total Selected Taxa (12)` vs `Significant Wave Height (Hs)`: `r = +0.4100` (`pelagic_catch_kg (10)`: `r = +0.4044`)
   - `Total Selected Taxa (12)` vs `SST Contrast (ΔT coast-offshore)`: `r = +0.3718` (`pelagic_catch_kg (10)`: `r = +0.3635`)
   - `Total Selected Taxa (12)` vs `Chlorophyll-a`: `r = +0.3652` (`pelagic_catch_kg (10)`: `r = +0.3602`)
   - `Total Selected Taxa (12)` vs `Coastal SST`: `r = -0.3707` (`pelagic_catch_kg (10)`: `r = -0.3597`)
   - `Total Selected Taxa (12)` vs `Meridional Ekman Transport (Mey)`: `r = -0.4580` (`pelagic_catch_kg (10)`: `r = -0.4498`)
