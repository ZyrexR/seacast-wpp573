# PHASE 4 PRECONDITIONS & OPERATIONAL CONSTRAINTS (FINAL REVISED VERSION)
## Ketentuan Wajib, Prasyarat Ilmiah, Landasan Regulasi, dan Batasan Operasional Sebelum Memulai Phase 4 (DOM-DSS)
### Sistem Intelijen Geospasial Perikanan Pelagis PPN Prigi — WPPNRI 573

---

| Parameter Dokumen | Spesifikasi Formal |
| :--- | :--- |
| **Identitas Proyek** | Sistem Intelijen Geospasial Perikanan Pelagis PPN Prigi — WPPNRI 573 |
| **Institusi Pelaksana** | Tim Mahasiswa Sistem Informasi Kelautan (SIK 2024), Universitas Pendidikan Indonesia |
| **Agenda Akademis** | Ujian Akhir Semester (UAS) Terintegrasi Analisis Sistem Informasi Kelautan (ASIK) VI 2026 |
| **Dokumen Konfigurasi Rujukan** | `PHASE_4_READINESS_GATE.json` (Versi 2.0.0) |
| **Tanggal Pemutakhiran Dokumen** | 1 November 2026 |
| **Status Otorisasi** | **BINDING / MENGIKAT PENUH** untuk seluruh perancangan algoritma, antarmuka, dan arsitektur Phase 4 |
| **Keputusan Gerbang Kesiapan** | **GO — PROTOTYPE DEVELOPMENT** / **NO-GO — OPERATIONAL DEPLOYMENT** |

---

## 1. PENDAHULUAN DAN RUANG LINGKUP PROYEK

Laporan audit saintifik independen dan remediasi teknis menyeluruh (Phase 3.1 dan Gerbang Validasi Final) telah membuktikan bahwa basis data perikanan dan oseanografi historis PPN Prigi telah terekonsiliasi secara penuh. Rekonsiliasi mencakup pembetulan galat pencatatan tipografi 200 kg pada April 2022 (menetapkan total produksi pelagis besar 11 tahun 2015–2025 pada angka definitif **18.405.261 kg**), isolasi trip masa studi (menetapkan **189.334 trip** untuk 2015–2025 dari total historis 249.257 trip), kontinuitas 132 bulan data oseanografi tanpa kekosongan kalender, serta eliminasi klaim tak berdasar pada antarmuka dasbor.

Meskipun demikian, audit juga menetapkan bahwa sistem intelijen geospasial ini memiliki **empat keterbatasan empiris mendasar (*fundamental empirical constraints*)** yang timbul dari sifat inheren data sekunder pelabuhan dan keterbatasan observasi lapangan langsung. Oleh karena itu, sebelum memasuki tahapan perancangan sistem pendukung keputusan dinamis (**Phase 4: Dynamic Ocean Management & Decision Support System / DOM-DSS**), dokumen ini menetapkan kerangka kerja, prasyarat ilmiah, batasan operasional, dan lima protokol wajib yang mengikat secara akademis dan teknis.

Sistem yang dikembangkan pada Phase 4 berkedudukan hukum murni sebagai **Sistem Pendukung Keputusan Akademis (*Academic Decision-Support System*)**. Sistem ini bertujuan mengintegrasikan data lingkungan laut multitemporal dan pemodelan spasial habitat pelagis untuk kepentingan riset, eksplorasi keilmuan, dan bahan pertimbangan navigasi perikanan, serta **sama sekali tidak memiliki kewenangan regulasi, lisensi, penutupan kawasan, atau pengganti instruksi keselamatan maritim resmi**.

---

## 2. EMPAT KETERBATASAN EMPIRIS MENDASAR (*BLOCKING CONSTRAINTS*)

Empat keterbatasan empiris berikut merupakan realitas data yang tidak dapat dihilangkan secara komputasional atau statistik. Setiap modul algoritma, tampilan visual, dan representasi luaran pada Phase 4 wajib menyesuaikan diri dengan batasan ini tanpa kompromi:

```
+=================================================================================================================+
|                     EMPAT KETERBATASAN EMPIRIS UTAMA (UNRESOLVED BLOCKING CONSTRAINTS)                          |
+---+--------------------+----------------------------+-----------------------------------------------------------+
|No | Isu Pembatas       | Status Ketersediaan Data   | Mitigasi Wajib dalam Sistem Phase 4                       |
+---+--------------------+----------------------------+-----------------------------------------------------------+
| 1 | Ketiadaan Data GPS | UNRESOLVED                 | Seluruh luaran PFG harus berformat "Advisory Screening",  |
|   | Tangkap Empiris    | (Tidak ada VMS/e-Logbook)  | bukan kepastian koordinat titik jatuh jaring nelayan.     |
+---+--------------------+----------------------------+-----------------------------------------------------------+
| 2 | Sirkularitas Relung| UNRESOLVED                 | Nilai model wajib disajikan sebagai Relative HSI (RHSI),  |
|   | Ekologis SDM       | (Presensi dari heuristik)  | dilarang diklaim sebagai probabilitas absolut menangkap.  |
+---+--------------------+----------------------------+-----------------------------------------------------------+
| 3 | Batasan Spasial    | UNRESOLVED                 | Seluruh rekomendasi DSS dibatasi pada Sub-AOI Prigi       |
|   | Sub-AOI Prigi      | (Hanya 4.16% WPPNRI 573)   | (111-113° E, -8 s/d -10.45° S); dilarang diekstrapolasi. |
+---+--------------------+----------------------------+-----------------------------------------------------------+
| 4 | Ketiadaan Survei   | UNRESOLVED                 | 123 poligon berstatus kandidat penapisan batimetri,       |
|   | Lapangan Bycatch   | (Hanya pendaratan TPI)     | bukan larangan penangkapan ikan tertutup (no-take zone).  |
+---+--------------------+----------------------------+-----------------------------------------------------------+
```

### 2.1 Keterbatasan 1: Ketiadaan Data GPS Titik Tangkap Aktual
- **Deskripsi:** Catatan pendaratan ikan di PPN Prigi hanya mencatat volume produksi (kg), nilai produksi (Rp), jumlah trip, dan jenis alat tangkap saat kapal membongkar muatan di dermaga/TPI. Data ini tidak disertai koordinat lintang-bujur posisi alat tangkap diturunkan, lintasan kapal dari Vessel Monitoring System (VMS) atau Automatic Identification System (AIS), maupun e-logbook penangkapan ikan.
- **Konsekuensi Sistem:** Sistem Phase 4 tidak memiliki data empiris posisi spasial penangkapan ikan di laut. Seluruh luaran daerah penangkapan ikan potensial (*Potential Fishing Ground / PFG*) harus disajikan dan dipahami sebagai **Penapisan Saran Spasial (*Advisory Screening*)**, bukan koordinat titik tangkap aktual (*actual catch coordinates*). Pengembang dilarang membuat titik-titik koordinat acak atau sintetis untuk memvisualisasikan "lokasi tangkapan nelayan".

### 2.2 Keterbatasan 2: Sirkularitas Heuristik Relung Ekologis SDM
- **Deskripsi:** Model distribusi spesies (SDM) yang dibangun pada Phase 3 dilatih menggunakan 981 titik *pseudo-presence* yang diekstraksi dari aturan heuristik oseanografi perikanan (suhu permukaan laut, klorofil-a, dan batimetri lereng). Akibatnya, hubungan relung ekologis yang dipelajari algoritma *machine learning* (Random Forest, MaxEnt, GLM, GAM) mencerminkan asumsi input pembentuk titik tersebut (*heuristic circularity*).
- **Konsekuensi Sistem:** Skor kesesuaian habitat luaran ensemble tidak boleh ditafsirkan sebagai probabilitas murni keberadaan biologis ikan ($P(Y=1)$) atau probabilitas keberhasilan penangkapan komersial. Indeks tersebut wajib dinamai dan diinterpretasikan sebagai **Relative Habitat Suitability Index (RHSI)** dengan skala $0,00\text{–}1,00$.

### 2.3 Keterbatasan 3: Batasan Spasial Domain Sub-AOI Prigi
- **Deskripsi:** Domain operasional model dibatasi secara ketat pada Sub-AOI Prigi dengan batas koordinat $111^\circ 00'\text{ E}\text{ s/d }113^\circ 00'\text{ E}$ dan $-8^\circ 00'\text{ S}\text{ s/d }-10^\circ 27'\text{ S}$ ($-8.00^\circ\text{ s/d }-10.45^\circ\text{ S}$). Luas domain ini adalah $59.206\text{ km}^2$, yang hanya mencakup sekitar **4,16% dari total luas WPPNRI 573** ($1.423.238\text{ km}^2$).
- **Konsekuensi Sistem:** Dinamika oseanografi dan estimasi habitat yang dihitung dalam model ini adalah fenomena meso-skala lokal di selatan Jawa Timur. Seluruh modul DSS, rekomendasi navigasi, dan visualisasi spasial Phase 4 **dilarang keras diekstrapolasi** ke seluruh Samudra Hindia selatan Jawa, Bali, atau Nusa Tenggara.

### 2.4 Keterbatasan 4: Ketiadaan Data Survei Lapangan Bycatch Hiu
- **Deskripsi:** PPN Prigi mencatat pendaratan cucut/hiu (*Carcharhinus spp.*) dari hasil tangkapan sampingan nelayan pancing ulur, rawai, atau pukat cincin. Namun, tidak ada program *scientific observer* di atas kapal, tidak ada logbook bycatch berkoordinat, dan tidak ada verifikasi morfometrik detail di dermaga.
- **Konsekuensi Sistem:** Lapisan 123 poligon lereng batimetri yang dibentuk pada Phase 3 bukan merupakan peta sebaran hiu aktual, bukan *hotspot* bycatch terverifikasi, bukan habitat kritis yang divalidasi secara biologis, dan **bukan kawasan konservasi laut atau zona larangan tangkap (*no-take marine reserve*)**. Lapisan ini berstatus murni sebagai instrumen penapisan batimetri sukarela (*candidate bathymetric screening polygons for voluntary shark bycatch review*).

---

## 3. LIMA PROTOKOL OPERASIONAL WAJIB PADA SISTEM PHASE 4 (MANDATORY DSS PROTOCOLS)

Seluruh komponen perangkat lunak, modul analitik, basis data, dan antarmuka pengguna pada Phase 4 wajib tunduk pada kelima protokol berikut:

---

### 3.1 PROTOKOL 1: Relative Habitat Suitability and Uncertainty-Penalized Advisory Scoring

Protokol ini mengatur standarisasi perhitungan, nomenklatur, penyajian, dan penanganan ketidakpastian luaran model habitat pelagis:

#### 3.1.1 Definisi dan Pelabelan Baku
1. Seluruh indeks kesesuaian habitat hasil pemodelan ensemble wajib diberi label resmi **Relative Habitat Suitability Index (RHSI)** dengan skala numerik terikat pada rentang $[0,00, 1,00]$.
2. Nilai RHSI didefinisikan secara tegas sebagai **indeks kesesuaian habitat spasial relatif**, dan **BUKAN**:
   - Probabilitas absolut keberadaan spesies ($P(Y=1|\mathbf{x})$);
   - Probabilitas keberhasilan operasi penangkapan ikan (*catch probability*);
   - Indikator kepastian hasil tangkapan (*catch per unit effort / CPUE*).
3. Luaran modul rekomendasi daerah penangkapan ikan berstatus **`Advisory Screening`** (penapisan saran spasial) untuk membantu eksplorasi daerah tangkapan potensial, bukan koordinat pasti titik penurunan alat tangkap.

#### 3.1.2 Penyajian Terpisah pada Antarmuka (Decoupled Visual Presentation)
Sistem wajib menampilkan nilai rata-rata RHSI dan ukuran ketidakpastian/ketidaksepakatan model secara terpisah pada antarmuka pengguna:
- Peta/lapisan utama menampilkan gradien RHSI ensemble ($\overline{RHSI}_w$);
- Peta/lapisan terpisah (atau panel inspeksi sel) menampilkan nilai ketidaksepakatan ensemble ($\sigma_w$);
- Pengguna diberikan kendali interaktif untuk mengamati tingkat ketidaksepakatan antar-algoritma pada setiap sel kisi.

#### 3.1.3 Formulasi Matematis Normalisasi Bobot dan Ketidakpastian Ensemble
Dalam arsitektur ensemble yang menggabungkan $M$ model dasar (misal: Random Forest, MaxEnt, GLM, GAM), pembobotan model individual didasarkan pada skor evaluasi performa model (seperti TSS atau AUC pada data uji independen):

1. **Normalisasi Bobot Model:**
   Bobot model $w_i$ untuk model ke-$i$ ($i \in \{1, 2, \dots, M\}$) wajib dinormalisasi secara ketat sehingga non-negatif dan berjumlah tepat satu:
   $$w_i \ge 0, \quad \sum_{i=1}^M w_i = 1$$

2. **Rata-Rata RHSI Berbobot Ensemble ($\overline{RHSI}_w$):**
   $$\overline{RHSI}_w = \sum_{i=1}^M w_i \, RHSI_i$$
   di mana $RHSI_i$ adalah nilai estimasi kesesuaian relatif dari model ke-$i$ pada sel kisi tertentu.

3. **Ketidaksepakatan Antar-Model Berbobot ($\sigma_w$):**
   Ukuran penyebaran atau ketidaksepakatan antar-model dihitung sebagai deviasi standar berbobot (*weighted ensemble disagreement*):
   $$\sigma_w = \sqrt{\sum_{i=1}^M w_i \left(RHSI_i - \overline{RHSI}_w\right)^2}$$

#### 3.1.4 Formulasi Skor Advisory Gabungan (Uncertainty-Penalized Advisory Score)
Jika sistem menyediakan instrumen penskoran gabungan untuk memeringkat sel daerah potensial penangkapan ikan (*Potential Fishing Ground / PFG*), sistem wajib menerapkan formulasi eksploratif berbasis penalti ketidakpastian:

$$\mathbf{PFG_{\text{advisory}} = \overline{RHSI}_w - \lambda \sigma_w}$$

dengan ketentuan parameter:
- $\overline{RHSI}_w$: Rata-rata indeks kesesuaian habitat relatif berbobot ($[0,00, 1,00]$);
- $\sigma_w$: Ukuran ketidaksepakatan antar-model berbobot (*weighted ensemble disagreement*);
- $\lambda$: Koefisien penalti ketidakpastian (*uncertainty penalty coefficient*), dengan rentang operasional $\lambda \in [0,00, 1,00]$ dan nilai acuan dasar (*baseline*) $\lambda_{\text{baseline}} = 0,50$.

#### 3.1.5 Analisis Sensitivitas Wajib dan Pengujian Ambang Klasifikasi
1. **Analisis Sensitivitas Parameter $\lambda$:**
   Sistem wajib mendokumentasikan dan menyediakan pengujian sensitivitas skor $PFG_{\text{advisory}}$ terhadap lima skenario nilai penalti:
   $$\lambda \in \{0,00, \, 0,25, \, 0,50, \, 0,75, \, 1,00\}$$
   di mana $\lambda = 0,00$ mencerminkan kondisi tanpa penalti (netral risiko), $\lambda = 0,50$ mencerminkan kondisi standar kehati-hatian (*precautionary baseline*), dan $\lambda = 1,00$ mencerminkan penalti ketidakpastian penuh (*conservative screening*).
2. **Evaluasi Ambang Batas Klasifikasi:**
   Ambang batas klasifikasi (seperti $PFG_{\text{threshold}} = 0,60$) **bukan merupakan standar universal** yang berlaku secara mutlak di seluruh laut tropis. Ambang batas ini harus diuji sensitivitasnya terhadap proporsi luasan area tangkap yang terpilih (*area fraction*) dan stabilitas spasial temporal antarmusim. Setiap perubahan ambang batas harus dicatat dalam metadata sistem.

#### 3.1.6 Nomenklatur dan Batasan Interpretasi Statistik
- Nilai $\sigma_w$ secara formal didefinisikan sebagai **`weighted ensemble disagreement`** (ukuran ketidaksepakatan antar-model) dan **DILARANG KERAS** ditafsirkan sebagai:
  - Keseluruhan ketidakpastian biologis ekosistem laut;
  - Interval kepercayaan statistik formal (*statistical confidence interval*, misal $95\%\text{ CI}$);
  - Standar deviasi kesalahan observasi fisik.
- Skor $PFG_{\text{advisory}}$ resmi disebut sebagai **`Uncertainty-Penalized Advisory Score`**, dan **DILARANG KERAS** disebut sebagai *confidence interval* atau *probabilitas keberhasilan penangkapan*.

#### 3.1.7 Penyimpanan Data Ganda (Dual-Score Storage Architecture)
Dalam basis data dan struktur luaran GeoJSON/JSON, sistem wajib menyimpan dua representasi nilai skor:
1. `raw_advisory_score`: Nilai murni hasil perhitungan $\overline{RHSI}_w - \lambda\sigma_w$ sebelum pemotongan (*unclipped*). Nilai ini dapat bertanda negatif (jika $\overline{RHSI}_w < \lambda\sigma_w$) dan diperlukan untuk verifikasi matematis integritas algoritma.
2. `visualization_score`: Nilai skor setelah dikenakan fungsi pemotongan rentang (*clipping*) ke interval $[0,00, 1,00]$:
   $$\text{visualization\_score} = \max\left(0,00, \, \min\left(1,00, \, PFG_{\text{advisory}}\right)\right)$$
   Nilai ini digunakan untuk keperluan visualisasi peta dan pewarnaan tematik.

---

### 3.2 PROTOKOL 2: Tiered Maritime Risk Screening

Protokol ini menetapkan arsitektur instrumen penapisan keselamatan maritim bertingkat yang mengintegrasikan dinamika cuaca laut dan karakteristik armada perikanan:

#### 3.2.1 Status Hukum dan Kedudukan Klasifikasi Internal
1. Klasifikasi risiko maritim yang dibangun pada Phase 4 merupakan **instrumen penapisan risiko eksploratif internal (*internal exploratory risk screening instrument*)**.
2. Klasifikasi ini **BUKAN** klasifikasi resmi BMKG, **BUKAN** warta navigasi maritim resmi (*Notice to Mariners*), dan **TIDAK MENGGANTIKAN** peringatan dini resmi dari stasiun meteorologi maritim BMKG maupun instruksi syahbandar pelabuhan.

#### 3.2.2 Kepatuhan terhadap Legenda dan Produk Resmi BMKG
1. Kategori tinggi gelombang laut wajib mengacu pada terminologi dan ambang batas resmi Badan Meteorologi, Klimatologi, dan Geofisika (BMKG) yang berlaku pada produk maritim yang diintegrasikan:
   - Kategori Tenang (*Calm*): $0,10\text{–}0,50\text{ m}$
   - Kategori Rendah (*Low*): $0,50\text{–}1,25\text{ m}$
   - Kategori Sedang (*Moderate*): $1,25\text{–}2,50\text{ m}$
   - Kategori Tinggi (*Rough*): $2,50\text{–}4,00\text{ m}$
   - Kategori Sangat Tinggi (*Very Rough*): $4,00\text{–}6,00\text{ m}$
   - Kategori Ekstrem (*Phenomenal*): $> 6,00\text{ m}$
2. Sistem wajib mendokumentasikan dan menyimpan nomor identitas produk (*Product ID*) dan versi legenda BMKG yang digunakan dalam basis data sistem.

#### 3.2.3 Pemisahan Parameter Oseanografi-Meteorologi dan Armada
Sistem wajib memantau dan menyimpan parameter berikut sebagai variabel terpisah, tanpa mencampuradukkan satuan atau sifat fisiknya:
1. **Dinamika Gelombang:**
   - Tinggi gelombang signifikan ($H_s$ dalam meter);
   - Arah rambat gelombang dominan (*wave direction* dalam derajat kompas);
   - Periode puncak gelombang ($T_p$ dalam detik) untuk mengidentifikasi potensi gelombang alun (*swell*) yang berbahaya bagi stabilitas kapal kecil.
2. **Dinamika Angin:**
   - Kecepatan angin rata-rata berkelanjutan (*sustained wind speed* dalam knot);
   - Kecepatan hembusan angin sesaat (*wind gust* dalam knot);
   - Arah datang angin (*wind direction* dalam derajat kompas).
   *Catatan Ketat:* Rata-rata angin dan hembusan angin (*wind gust*) **wajib disimpan dan ditampilkan sebagai dua parameter berbeda secara eksplisit**. Hembusan angin sesaat sering kali memicu kecelakaan pembalikan kapal (*capsizing*) meskipun kecepatan angin rata-rata berada pada tingkat moderat.
3. **Karakteristik Kapal dan Navigasi:**
   - Jenis konstruksi lambung kapal (*hull type*: sekoci kayu berlaminasi fiberglass, kapal kayu tradisional, kapal baja);
   - Lambung timbul (*freeboard* dalam meter) dan sarat kapal (*draft* dalam meter) — *lihat klausul distingsi 3.2.4*;
   - Kondisi muatan kapal (*vessel loading condition*): kondisi berangkat tanpa muatan (*empty holds with ballast/ice*) versus kondisi pulang bermuatan penuh tangkapan (*fully laden*), yang sangat memengaruhi tinggi metasentrik dan cadangan daya apung (*reserve buoyancy*);
   - Kondisi stabilitas dinamis kapal (*stability condition*);
   - Profil perjalanan kapal (*trip profile*): perjalanan harian pesisir (*one-day coastal trip* $< 12\text{ NM}$) versus perjalanan lepas pantai multi-hari (*multi-day offshore trip* hingga lereng tubir benua $> 60\text{ NM}$);
   - Tonase kotor kapal (*gross tonnage / GT*).

#### 3.2.4 Distingsi Ketat Terminologi Perkapalan: Freeboard vs Draft
Terdapat kerancuan teknis pada beberapa laporan pendahuluan yang menggabungkan istilah *freeboard* dan *draft*. Sistem Phase 4 mewajibkan pemisahan definisi naval secara mutlak:
- **Freeboard (Lambung Timbul):** Jarak vertikal yang diukur dari garis air muat (*waterline*) ke geladak utama teratas yang kedap air (*main watertight deck*). Freeboard mencerminkan cadangan daya apung kapal; freeboard yang terlalu rendah meningkatkan risiko masuknya air laut ke geladak (*deck wetness / swamping*).
- **Draft (Sarat Kapal):** Jarak vertikal yang diukur dari garis air muat (*waterline*) ke bagian terbawah dari lunas kapal (*keel*). Draft mencerminkan kedalaman lambung kapal yang terbenam di bawah permukaan air; draft menentukan hambatan gerak, kemampuan mempertahankan haluan, dan risiko kandas di perairan dangkal muara Teluk Prigi.
- **Larangan:** Istilah `freeboard draft` **DILARANG DIGUNAKAN**. Keduanya harus dicatat sebagai dua variabel numerik terpisah: `freeboard_m` dan `draft_m`.

#### 3.2.5 Penilaian Multivariat dan Larangan Penggunaan GT sebagai Penentu Tunggal
- Ukuran kapal dalam Tonase Kotor (*Gross Tonnage / GT*) **TIDAK BOLEH** digunakan sebagai satu-satunya parameter penentu keselamatan pelayaran. Kapal dengan GT sama (misal 15 GT) dapat memiliki ketahanan cuaca yang sangat berbeda tergantung pada bentuk lambung (monohull vs kapal katamaran), rasio panjang-lebar (*L/B*), tinggi freeboard efektif, distribusi beban palkah es, dan keberadaan peralatan penutup palka kedap air.
- Evaluasi risiko harus dihasilkan dari algoritma matriks multivariat yang menggabungkan interaksi antara kondisi laut ($H_s, T_p$, angin, hembusan) dan status spesifik kapal (tipe alat tangkap, muatan, profil trip).

#### 3.2.6 Prinsip Indikator Risiko Tertinggi (Worst-Case Precautionary Trigger)
1. Dalam mengevaluasi tingkat risiko maritim, sistem wajib menerapkan prinsip kehati-hatian (*precautionary principle*): **jika salah satu parameter maritim atau kapal mencapai tingkat risiko yang lebih tinggi, sistem wajib menetapkan status penapisan berdasarkan indikator risiko tertinggi yang aktif (*worst-case trigger*)**.
2. Faktor pemicu (*trigger variable*) wajib ditampilkan secara eksplisit kepada pengguna (misal: "Tingkat Risiko Tinggi dipicu oleh hembusan angin sesaat (*wind gust*) mencapai 32 knot meskipun $H_s = 1,4\text{ m}$").
3. Penggabungan indikator dilarang merata-ratakan variabel yang berbeda satuan fisik (misal: meter tinggi gelombang tidak boleh dirata-ratakan secara numerik dengan knot kecepatan angin).

#### 3.2.7 Larangan Mutlak Label Jaminan Keselamatan "Aman"
1. Sistem **DILARANG KERAS MENGGUNAKAN LABEL "AMAN" ATAU "SAFE"** dalam bentuk apa pun sebagai jaminan keselamatan pelayaran nelayan. Keselamatan di laut dipengaruhi oleh faktor kelalaian manusia (*human error*), kegagalan mekanikal mesin, kebocoran lambung, dan fenomena gelombang tak terduga (*freak waves*) yang berada di luar jangkauan sensor sistem.
2. Sistem wajib menggunakan terminologi bergradasi empat tingkat:
   - **Tingkat 1 (Hijau): Risiko Rendah / Kondisi Relatif Kondusif (*Low Risk / Relatively Conducive Conditions*)**  
     *Deskripsi:* Parameter oseanografi-meteorologi berada dalam batas toleransi operasional umum sebagian besar armada, namun kewaspadaan standar navigasi tetap wajib dipelihara oleh nakhoda.
   - **Tingkat 2 (Kuning): Risiko Sedang / Waspada Operasional (*Moderate Risk / Operational Caution*)**  
     *Deskripsi:* Terjadi peningkatan tinggi gelombang, periode alun, atau kecepatan angin yang menuntut peningkatan kehati-hatian, penataan beban palka, dan kesiapan peralatan keselamatan kapal.
   - **Tingkat 3 (Oranye): Risiko Tinggi / Peringatan Cuaca Buruk (*High Risk / Rough Weather Warning*)**  
     *Deskripsi:* Kondisi laut dan hembusan angin melampaui batas aman untuk perahu kecil dan mengancam stabilitas operasional kapal pukat cincin mini atau pancing ulur; risiko tinggi gelombang pecah di atas geladak.
   - **Tingkat 4 (Merah): Bahaya Ekstrem / Kondisi Sangat Tidak Kondusif (*Extreme Hazard / Highly Unfavorable Conditions*)**  
     *Deskripsi:* Gelombang tinggi ekstrem, angin badai, atau hembusan sangat berbahaya; kondisi sangat tidak kondusif untuk seluruh aktivitas operasi penangkapan ikan di laut.

#### 3.2.8 Larangan Penerbitan Larangan Melaut Otomatis
Sistem **DILARANG MENERBITKAN LARANGAN MELAUT OTOMATIS (*AUTOMATED SEA BANS*)** dalam bentuk pop-up pemblokiran sistem atau instruksi sepihak yang melarang kapal keluar pelabuhan. Keputusan menerbitkan Surat Persetujuan Berlayar (SPB) atau menunda keberangkatan kapal sepenuhnya merupakan wewenang hukum Syahbandar di Pelabuhan Perikanan, dan keputusan navigasi di laut berada di tangan nakhoda (*master of the vessel*).

#### 3.2.9 Protokol Penanganan Data Cuaca Kedaluwarsa (*Stale/Disconnect Protocol*)
1. Apabila koneksi feed BMKG terputus, API gagal merespons, data citra satelit/model maritim tidak diperbarui, atau data yang tersedia telah melampaui batas masa berlaku operasional (*operational validity window*, misal $> 6\text{ jam}$ untuk prakiraan cuaca atau $> 24\text{ jam}$ untuk data analisis gelombang), sistem **WAJIB MENAMPILKAN STATUS**:
   - **`DATA KEDALUWARSA`** (*STALE DATA*);
   - **`FEED TERPUTUS`** (*DISCONNECTED FEED*); atau
   - **`TIDAK TERSEDIA`** (*DATA UNAVAILABLE*).
2. Sistem **DILARANG KERAS MEMPERTAHANKAN STATUS KESELAMATAN SEBELUMNYA SEOLAH-OLAH MASIH BERLAKU AKTUAL**. Mempertahankan label risiko rendah ketika data tidak diperbarui dapat menimbulkan persepsi keselamatan palsu (*false sense of security*) yang membahayakan nyawa nelayan.

---

### 3.3 PROTOKOL 3: Voluntary Shark Bycatch Mitigation Screening

Protokol ini mengatur representasi spasial, dasar oseanografi-batimetri, batasan hukum konservasi, rekomendasi teknis alat tangkap, dan taksonomi CITES terkait isu tangkapan sampingan hiu:

#### 3.3.1 Nomenklatur Resmi Lapisan Spasial
Lapisan 123 poligon spasial wajib ditampilkan pada seluruh antarmuka dasbor, metadata GeoJSON, dan dokumentasi teknis dengan nama resmi:

$$\mathbf{Candidate\text{ }Bathymetric\text{ }Screening\text{ }Polygons\text{ }for\text{ }Voluntary\text{ }Shark\text{ }Bycatch\text{ }Review}$$

#### 3.3.2 Definisi dan Nomenklatur Batimetri GEBCO 2023
1. **Nomenklatur Zona Kedalaman:**
   Rentang kedalaman lereng benua yang digunakan untuk menyaring poligon wajib dinamai secara baku:
   $$\mathbf{Exploratory\text{ }Bathymetric\text{ }Screening\text{ }Band\text{ }(150\text{–}1.200\text{ m})}$$
2. **Koreksi Asumsi Datum Vertikal GEBCO 2023:**
   - Dokumen teknis dan sistem **DILARANG MENGKLAIM BAHWA SELURUH SEL GEBCO 2023 MEMILIKI DATUM VERTIKAL MEAN SEA LEVEL (MSL) YANG SERAGAM TANPA VERIFIKASI SUMBER**.
   - Kisi batimetri global GEBCO 2023 (resolusi 15 detik busur) dibentuk dari penggabungan data multi-sumber: pengukuran *multibeam/singlebeam echosounder* kapal, estimasi batimetri berbasis gravitasi altimetri satelit, dan model interpolasi kedalaman pesisir regional. Setiap sumber survei asli memiliki datum vertikal referensi yang bervariasi (misal: Lowest Astronomical Tide / LAT, Mean Lower Low Water / MLLW, atau geoid regional EGM2008), yang kemudian diselaraskan secara aproksimatif ke permukaan laut rata-rata (*approximated Mean Sea Level*) pada skala global.
   - Sistem wajib mencantumkan catatan metodologis ini dalam metadata batimetri sistem.

#### 3.3.3 Pemisahan Konseptual Parameter Batimetri, Termoklin, dan Upwelling
Laporan terdahulu kerap mencampuradukkan konsep lapisan termoklin dengan fenomena upwelling pesisir. Sistem Phase 4 mewajibkan pemisahan definisi fisik dan operasional parameter berikut:
1. **Kedalaman Lapisan Termoklin:**
   - Didefinisikan melalui isoterma 20°C ($Z_{20}$ dalam meter) atau lapisan dengan gradien suhu vertikal maksimum ($\partial T / \partial z$ dalam °C/m) berdasarkan data profil vertikal reanalisis oseanografi (seperti GLORYS12V1).
   - Termoklin mencerminkan kedalaman pemisah antara lapisan campuran hangat (*warm surface mixed layer*) dan massa air dingin di bawahnya (*cold sub-surface water*).
2. **Indikator Fenomena Upwelling Permukaan:**
   - Didefinisikan melalui Kontras Suhu Permukaan Laut Pesisir-Lepas Pantai ($\Delta T_{c-o} = SST_{\text{offshore}} - SST_{\text{coastal}}$ dalam °C) dan Transpor Ekman Lintas-Pantai ($M_{ey}$ dalam $\text{kg}\cdot\text{m}^{-1}\cdot\text{s}^{-1}$ atau $\text{m}^2\cdot\text{s}^{-1}$ dengan tanda Coriolis negatif di BBS: $f = -2,155 \times 10^{-5}\text{ s}^{-1}$).
   - Upwelling mencerminkan proses pengangkatan massa air dingin kaya nutrien dari kedalaman ke lapisan fotik permukaan akibat divergensi transpor massa air oleh angin monsun timur (Juni–Agustus).
3. **Aturan Inferensi Metodologis:**
   - $Z_{20}$, gradien suhu vertikal, atau kontras $\Delta T_{c-o}$ **TIDAK BOLEH DIJADIKAN BUKTI TUNGGAL TERJADINYA UPWELLING LENGKAP**. Upwelling penuh memerlukan konfirmasi adveksi massa air dingin dan divergensi angin permukaan secara simultan.
   - Konsentrasi klorofil-a satelit ($Chl\text{-}a$) mencerminkan biomassa fitoplankton autotrof dan **TIDAK BOLEH DIASUMSIKAN SECARA LANGSUNG SEBAGAI BUKTI KELIMPAHAN MANGSA IKAN PELAGIS BESAR ATAU HIU** tanpa memperhitungkan jeda waktu trofik (*trophic time-lag* transfer energi dari fitoplankton ke zooplankton dan ikan mangsa kecil).
   - Pembentukan geometri 123 poligon harus dinyatakan secara faktual: poligon tersebut dihasilkan dari perpotongan kontur kedalaman 150–1.200 m (GEBCO 2023) dengan zona dinamika gradien suhu permukaan, dan bukan dibentuk oleh pengamatan langsung biota laut.

#### 3.3.4 Status Non-Regulasi: Bukan Hotspot, Bukan Habitat Kritis, Bukan Kawasan Konservasi
1. Lapisan 123 poligon batimetri berstatus murni sebagai **alat bantu penapisan spasial eksploratif (*exploratory spatial screening instrument*)**.
2. Poligon-poligon tersebut **DILARANG KERAS DIKLAIM, DISEBUT, ATAU DITAFSIRKAN SEBAGAI**:
   - Peta sebaran spasial hiu terverifikasi;
   - *Hotspot* tangkapan sampingan (*bycatch hotspots*) empiris;
   - Habitat kritis hiu (*critical nursery / feeding habitats*) yang divalidasi secara biologis;
   - Kawasan Konservasi Perairan Daerah/Nasional (KKP/KKN);
   - Zona larangan penangkapan ikan (*no-take marine reserves / seasonal closures*).
3. PPN Prigi, Dinas Kelautan dan Perikanan, serta Kementerian Kelautan dan Perikanan tidak menetapkan zona tertutup pada koordinat poligon tersebut.

#### 3.3.5 Rekomendasi Teknis Alat Tangkap yang Spesifik dan Proporsional
1. **Spesifisitas Mata Kail Melingkar (*Circle Hooks*):**
   - Rekomendasi penggunaan *circle hooks* (ukuran 16/0 atau 18/0 *non-offset*) dan penggantian tali kawat baja (*wire leader*) dengan tali pancing monofilamen berdiameter tebal **HANYA BERLAKU UNTUK ARMADA RAWAI HANYUT (*DRIFTING LONGLINE*) DAN PANCING ULUR (*HANDLINE*)**.
   - Efektivitas *circle hooks* didasarkan pada literatur ilmiah perikanan tangkap yang membuktikan bahwa bentuk kait melingkar cenderung tersangkut di sudut bibir (*jaw hinge*) hiu atau ikan pelagis besar, sehingga mengurangi tingkat luka dalam (*gut hooking*) dan memudahkan pelepasan hiu hidup-hidup (*post-release survival*).
2. **Larangan Klaim Efektivitas Universal:**
   - Sistem **DILARANG MENGKLAIM BAHWA CIRCLE HOOKS SECARA OTOMATIS MENGURANGI SELURUH JENIS BYCATCH HIU**. Efektivitasnya sangat bervariasi bergantung pada spesies target sasaran, ukuran hiu yang tertangkap, jenis umpan, dan teknik penarikan pancing.
3. **Materi Edukasi Mitigasi Sukarela untuk Armada Pukat Cincin Mini (*Mini Purse Seine*):**
   - Armada pukat cincin mini di PPN Prigi menargetkan ikan pelagis kecil (layang, kembung, tongkol krai) yang berkumpul di sekitar rumpon.
   - Untuk armada pukat cincin mini, rekomendasi mitigasi bycatch disajikan murni sebagai **materi edukasi sukarela (*voluntary educational guidance*)**, meliputi:
     * Penggunaan rumpon ramah lingkungan tanpa jaring bergantung (*Non-Entangling Fish Aggregating Devices / NEFADs*) untuk mencegah hiu atau penyu tersangkut di bawah rakit rumpon;
     * Prosedur pelepasan hiu yang terlingkup di dalam kantong jaring (*safe release from purse seine net*) dengan cara memotong seutas tali jaring atau menggunakan serok jaring kanvas besar (*canvas dip-net*) sebelum jaring dinaikkan ke geladak;
     * Penegasan mutlak bahwa **keselamatan awak kapal (*crew safety*) harus selalu diprioritaskan di atas upaya penyelamatan biota bycatch**. Hiu besar yang meronta di geladak kapal kecil merupakan ancaman fatal bagi keselamatan fisik nelayan.

#### 3.3.6 Kepatuhan Taksonomi dan Status Perlindungan CITES
1. **Dasar Hukum Rujukan Appendices CITES:**
   - Penentuan status perlindungan internasional wajib menggunakan **Appendices CITES yang berlaku secara sah pada tanggal pemrosesan data (efektif sejak 5 Maret 2026)** berdasarkan ketetapan Sidang Konferensi Para Pihak (CoP CITES).
2. **Distingsi Tingkat Famili Carcharhinidae vs Spesies Appendix I:**
   - Famili Carcharhinidae (*requiem sharks*) terdaftar dalam **CITES Appendix II** pada pencatatan tingkat famili (*Family listing: Carcharhinidae spp.*), dengan **pengecualian spesies yang secara spesifik telah dimasukkan ke dalam Appendix I**.
   - Contoh kasus distingsi taksonomi: ***Carcharhinus longimanus* (Oceanic whitetip shark / Cucut koboi) telah dimasukkan ke dalam CITES Appendix I (berlaku sejak 5 Maret 2026)**, yang melarang seluruh perdagangan internasional spesimen hasil tangkapan di laut bebas. Sementara itu, sebagian besar spesies *Carcharhinus* lainnya berada di bawah rezim pencatatan Appendix II (*Carcharhinidae spp.*).
3. **Larangan Klasifikasi Spesies Otomatis dari Data Pendaratan Pelabuhan:**
   - Catatan pendaratan ikan di PPN Prigi hanya mencatat kelompok hiu di bawah nama lokal "Cucut" atau kategori ilmiah umum ***Carcharhinus spp.*** tanpa rincian spesies.
   - **DATA PENDARATAN YANG HANYA TERCATAT SEBAGAI *Carcharhinus spp.* DILARANG KERAS DIKLASIFIKASIKAN SECARA OTOMATIS SEBAGAI SPESIES APPENDIX I (*C. longimanus*) MAUPUN SPESIES APPENDIX II TERTENTU TANPA ADANYA BUKTI IDENTIFIKASI TAKSONOMI MORFOMETRIK ATAU UJI GENETIK (DNA BARCODING)**.
   - Sistem wajib menandai status verifikasi data pendaratan tersebut sebagai `NEEDS_VERIFICATION`.

#### 3.3.7 Delapan Atribut Taksonomi Terstruktur Wajib
Setiap entitas data tangkapan sampingan hiu dalam basis data sistem dan GeoJSON wajib menyimpan delapan atribut taksonomi terstruktur berikut:
1. `identified_taxon_name`: Nama takson hasil identifikasi asli dalam dokumen sumber (misal: *Carcharhinus spp.* / Cucut).
2. `taxonomic_resolution_level`: Tingkat resolusi taksonomi pencatatan asli (misal: `Genus`, `Family`, atau `Species`).
3. `taxonomic_uncertainty_notes`: Catatan ketidakpastian taksonomi (misal: "Identifikasi terbatas pada tingkat genus; tidak ada pencatatan morfometrik bentuk gigi, cuping moncong, atau analisis DNA").
4. `identification_verification_status`: Status validasi spesimen (diberi nilai `NEEDS_VERIFICATION` untuk seluruh data historis pendaratan pelabuhan Prigi yang belum diaudit oleh taksonom ahli).
5. `cites_appendix`: Tingkat lampiran CITES yang relevan (misal: `Appendix II (Family listing)` atau `Undetermined at Species Level`).
6. `cites_taxonomic_scope`: Cakupan taksonomi pencantuman CITES (misal: `Family Carcharhinidae spp. with exception of Appendix I species`).
7. `cites_reference_date`: Tanggal efektif Appendices CITES yang dirujuk (`2026-03-05`).
8. `cites_verification_source`: Rujukan resmi basis data verifikasi CITES (misal: `CITES Appendices in effect from 5 March 2026 / UNEP-WCMC Species+ Database`).

#### 3.3.8 Persyaratan Peningkatan Status Poligon di Masa Depan
Seluruh 123 poligon **tetap berstatus kandidat penapisan batimetri sukarela (*candidate bathymetric screening polygons*)** sampai tersedianya program riset empiris pemantauan tangkapan sampingan yang memenuhi kriteria ilmiah:
- Terdapat petugas pemantau ilmiah (*scientific observers*) di atas kapal penangkap ikan;
- Terdapat pencatatan koordinat GPS riil titik interaksi alat tangkap dengan hiu;
- Terdapat identifikasi taksonomi tingkat spesies yang terverifikasi melalui foto morfologi atau sampel DNA;
- Terdapat data upaya penangkapan riil (*fishing effort*) dan laju mortalitas saat pelepasan (*at-vessel / post-release mortality rate*).

---

### 3.4 PROTOKOL 4: Supremasi Regulasi dan Otoritas Resmi

Protokol ini menegaskan kedudukan hukum sistem dalam tata kelola perikanan dan pelayaran nasional Republik Indonesia:

#### 3.4.1 Kedudukan Hukum Sistem Pendukung Keputusan
1. Seluruh keluaran modul analitik, visualisasi spasial, estimasi indeks kesesuaian habitat, penapisan risiko cuaca, dan penilaian mitigasi konservasi pada Phase 4 berstatus mutlak sebagai **Informasi Pendukung Keputusan Akademis (*Academic Decision-Support Information*)**.
2. Sistem ini **SAMA SEKALI TIDAK MEMILIKI KEKUATAN HUKUM (*NO STATUTORY LEGAL AUTHORITY*)** untuk:
   - Menerbitkan izin berlayar, izin penangkapan ikan, atau alokasi kuota penangkapan;
   - Menetapkan larangan melaut atau penutupan operasi pelabuhan perikanan;
   - Menetapkan zona larangan tangkap (*no-take marine reserves*) atau kawasan konservasi;
   - Menghukum, menuntut, atau mengenakan denda atas pelanggaran wilayah tangkap nelayan.

#### 3.4.2 Rujukan Peraturan Perundang-undangan Terbaru Republik Indonesia
Arsitektur hukum dan tata kelola sistem perikanan dan pelayaran wajib diselaraskan dengan peraturan perundang-undangan terbaru yang berlaku sah di wilayah Republik Indonesia:
1. **Peraturan Menteri Kelautan dan Perikanan Republik Indonesia Nomor 7 Tahun 2026 tentang Kesyahbandaran di Pelabuhan Perikanan**.  
   *Konteks Pengawasan:* Mengatur tata cara penerbitan Surat Persetujuan Berlayar (SPB), pemeriksaan kelaiklautan dan kelaikoperasian kapal penangkap ikan, pengawasan alat penangkapan ikan, serta pelaksanaan fungsi pengawasan maritim perikanan di pelabuhan pangkalan.
2. **Undang-Undang Nomor 31 Tahun 2004 tentang Perikanan** sebagaimana telah diubah dengan **Undang-Undang Nomor 45 Tahun 2009** dan disesuaikan terakhir melalui **Undang-Undang Nomor 6 Tahun 2023** (Penetapan Peraturan Pemerintah Pengganti Undang-Undang Nomor 2 Tahun 2022 tentang Cipta Kerja menjadi Undang-Undang).  
   *Konteks Tata Kelola:* Mengatur asas pengelolaan perikanan berkelanjutan di Wilayah Pengelolaan Perikanan Negara Republik Indonesia (WPPNRI 573), kepatuhan izin berusaha, pemanfaatan sumber daya ikan secara bertanggung jawab, dan perlindungan plasma nutfah laut.
3. **Undang-Undang Nomor 17 Tahun 2008 tentang Pelayaran** sebagaimana telah disempurnakan terakhir dengan **Undang-Undang Nomor 66 Tahun 2024** (Perubahan Ketiga atas Undang-Undang Nomor 17 Tahun 2008 tentang Pelayaran).  
   *Konteks Keselamatan Maritim:* Mengatur standar keselamatan dan keamanan pelayaran, kelaiklautan kapal, navigasi laut, tanggung jawab nakhoda, serta peran stasiun radio pantai dan otoritas pelabuhan.
4. **Peraturan Kepala Badan Meteorologi, Klimatologi, dan Geofisika Nomor Kep. 009 Tahun 2010 tentang Prosedur Standar Operasional Pelayanan Informasi Meteorologi Maritim** (beserta regulasi pemutakhiran layanan informasi cuaca maritim BMKG yang berlaku).

#### 3.4.3 Nomenklatur dan Kewenangan Mutlak Syahbandar
1. **Nomenklatur Wajib Otoritas Pelabuhan Perikanan:**
   Dalam seluruh antarmuka sistem, dokumen manual, dan teks penjelas, pejabat berwenang wajib disebut secara lengkap dan tepat dengan nomenklatur:
   $$\mathbf{Syahbandar\text{ }di\text{ }Pelabuhan\text{ }Perikanan\text{ }yang\text{ }berwenang\text{ }sesuai\text{ }peraturan\text{ }perundang-undangan}$$
2. **Kewenangan Eksklusif Syahbandar:**
   Kewenangan menerbitkan, menunda, atau menolak pemberian **Surat Persetujuan Berlayar (SPB)**, memeriksa surat-surat kapal, menginspeksi kelaiklautan fisik dan peralatan keselamatan pelayaran kapal penangkap ikan, serta mengumumkan maklumat pelayaran cuaca ekstrem berada sepenuhnya di bawah yurisdiksi Syahbandar di Pelabuhan Perikanan. Sistem Phase 4 dilarang menampilkan teks yang mengindikasikan bahwa sistem dapat mengambil alih peran Syahbandar.

#### 3.4.4 Otoritas Meteorologi dan Peringatan Dini Cuaca
Rujukan utama penyediaan data meteorologi kelautan, pemodelan gelombang laut, dan penerbitan peringatan dini maritim (*marine weather early warnings*) secara sah dan mengikat di perairan Indonesia adalah **Badan Meteorologi, Klimatologi, dan Geofisika (BMKG)** melalui Stasiun Meteorologi Maritim terkait (Stasiun Meteorologi Maritim Tanjung Perak Surabaya / Stasiun Meteorologi Kelas III Trunojoyo Jawa Timur). Sistem Phase 4 wajib menampilkan atribusi resmi BMKG pada setiap visualisasi cuaca laut.

---

### 3.5 PROTOKOL 5: Data Provenance, Freshness, and Validity Transparency

Protokol ini menetapkan integritas jejak data (*audit trail*), transparansi metode, pembatasan data reanalisis, dan penanganan data kedaluwarsa pada setiap komponen sistem Phase 4:

#### 3.5.1 Enam Belas (16) Atribut Metadata Provenance Wajib
Setiap lapisan spasial (*spatial layer*), dataset numerik, dan modul analitik dalam arsitektur sistem Phase 4 wajib menyimpan dan menampilkan secara transparan 16 parameter metadata berikut:
1. `data_source`: Nama jaringan instrumen, satelit, atau model sumber (misal: MODIS-Aqua, NOAA OISST v2.1, ERA5 Marine, GLORYS12V1, GEBCO 2023).
2. `source_institution`: Nama lembaga penyedia data asli (misal: NASA Ocean Biology DAAC, NOAA NCEI, ECMWF, Copernicus Marine Service / Mercator Ocean International, GEBCO Compilation Group).
3. `product_id`: Nomor identitas produk atau kode dataset unik pada portal penyedia (misal: `GLOBAL_MULTIYEAR_PHY_001_030`, `MODIS_AQUA_L3m_CHL_8D_4km`).
4. `product_version`: Nomor versi rilis dataset resmi dari penyedia data (misal: `v2.1`, `Release 2023`, `v1.2`).
5. `observation_timestamp`: Waktu dan tanggal perekaman fisik atau pengukuran sensor asli (*UTC ISO-8601*).
6. `publication_timestamp`: Tanggal rilis resmi data oleh lembaga penyedia sumber (*UTC ISO-8601*).
7. `processing_timestamp`: Waktu dan tanggal data diproses, difilter, atau dianalisis oleh pipeline sistem Phase 4 (*UTC ISO-8601*).
8. `spatial_resolution`: Resolusi spasial kisi data asli dan hasil harmonisasi (misal: $0,083^\circ \approx 9,25\text{ km}$, 15 busur detik $\approx 450\text{ m}$).
9. `temporal_resolution`: Resolusi interval waktu data asli (misal: harian, 8-harian, bulanan).
10. `data_type`: Tipe klasifikasi data operasional — *wajib menggunakan salah satu dari empat nilai baku*:
    - `HISTORICAL` (data observasi arsip masa lampau);
    - `REANALYSIS` (data sintesis asimilasi model fisika masa lampau);
    - `OBSERVATION` (data pengukuran in-situ atau sensor satelit langsung);
    - `FORECAST` (data luaran model prakiraan dinamis masa depan).
11. `freshness_latency_status`: Status jeda waktu keterkinian data terhadap waktu operasi saat ini:
    - `CURRENT` (data segar dalam rentang validitas operasional);
    - `STALE` (data melewati batas validitas namun feed masih tersambung);
    - `FEED_DISCONNECTED` (koneksi feed data terputus);
    - `NOT_AVAILABLE` (data tidak tersedia di repositori).
12. `interpolation_flag`: Penandaan eksplisit metode pengisian kekosongan data:
    - `DIRECT_OBSERVATION` (data murni tanpa interpolasi spasial);
    - `INTERPOLATED` (data hasil interpolasi temporal/spasial akibat tutupan awan atau jeda orbit);
    - `GAP_FILLED` (data sintesis berbasis regresi spasial atau klimatologi).
13. `model_version`: Nomor versi algoritma SDM atau mesin pendukung keputusan yang mengeksekusi data (misal: `SDM_Ensemble_v3.1`, `DSS_Engine_v4.0.0`).
14. `processing_method`: Deskripsi metode komputasi yang diterapkan pada data (misal: bilinear interpolation, z-score de-trending, weighted ensemble averaging).
15. `validity_boundaries`: Batasan domain koordinat geografis di mana data dinyatakan valid secara ilmiah (dibatasi pada Sub-AOI Prigi: Bujur $111,0^\circ\text{–}113,0^\circ\text{ E}$, Lintang $-8,00^\circ\text{–}-10,45^\circ\text{ S}$).
16. `quality_control_status`: Status pengujian kontrol kualitas data:
    - `RAW` (data mentah belum melalui saringan);
    - `QC_PASSED` (data lolos uji kontinuitas fisik, rentang ekstrem, dan konsistensi dimensi);
    - `QC_FLAGGED` (data mengandung anomali atau estimasi dengan ketidakpastian tinggi).

#### 3.5.2 Pemanfaatan Terkendali Data Historis dan Reanalisis
Data deret waktu 11 tahun (2015–2025) yang mencakup reanalisis atmosfer ERA5, reanalisis oseanografi fisik GLORYS12V1, OISST v2.1, dan MODIS-Aqua memiliki nilai saintifik yang sangat tinggi bagi pemahaman oseanografi perikanan Prigi:
1. **Ruang Lingkup Pemanfaatan yang Diizinkan:**
   Sistem Phase 4 **DIPERBOLEHKAN DAN DIDORONG MENGGUNAKAN** data historis dan reanalisis untuk tujuan-tujuan ilmiah berikut:
   - Analisis retrospektif dinamika laut dan respons perikanan 11 tahun;
   - Pembentukan siklus klimatologis dasar (*baseline monthly climatology*);
   - Analisis deviasi anomali iklim laut (misal: respons terhadap fenomena IOD Positif dan El Niño);
   - Evaluasi variabilitas musiman (Monsun Timur vs Monsun Barat) dan variabilitas antar-tahun (*interannual*);
   - Pelatihan (*model training*) dan validasi independen (*hindcast testing*) model habitat pelagis;
   - Analisis relasi historis antara parameter lingkungan laut dengan fluktuasi produksi pendaratan ikan di PPN Prigi.
2. **Pembatasan Ketat Pemanfaatan Data Reanalisis:**
   - **DILARANG KERAS MENYAJIKAN DATA REANALISIS HISTORIS (SEPERTI ERA5 ATAU GLORYS) SEOLAH-OLAH MERUPAKAN PRAKIRAAN CUACA OPERASIONAL HARI INI ATAU MASA DEPAN (*OPERATIONAL FUTURE FORECASTS*)**.
   - Setiap visualisasi data historis harus secara eksplisit dilabeli sebagai `HISTORICAL` atau `REANALYSIS` dan menyertakan tanggal observasi aslinya pada antarmuka.

#### 3.5.3 Prosedur Penandaan Visual Data Kedaluwarsa (*Stale Data Flagging*)
1. Sistem wajib menyediakan modul pemantau jeda waktu (*latency monitor*) yang memeriksa stempel waktu data lingkungan secara otomatis.
2. Apabila data operasional telah melewati batas validitas (misal: data satelit SST $> 48\text{ jam}$ tanpa komposit baru, atau prakiraan BMKG $> 12\text{ jam}$ tanpa pembaruan), sistem wajib memicu penanda visual berupa spanduk (*banner*) peringatan berwarna kuning/oranye di bagian atas antarmuka peta dengan teks peringatan tegas:
   > **PERINGATAN: DATA LINGKUNGAN KEDALUWARSA (STALE DATA)**  
   > Data oseanografi/meteorologi yang ditampilkan berasal dari pembaruan terakhir [Timestamp]. Rekomendasi spasial berstatus historis dan tidak boleh dijadikan rujukan navigasi waktu-nyata saat ini.

---

## 4. LARANGAN MUTLAK PENGEMBANGAN PHASE 4 (*PROHIBITED OPERATIONAL ACTIONS*)

Dalam perancangan modul, arsitektur kode program, basis data, dan antarmuka Phase 4, pengembang dilarang keras melakukan tindakan-tindakan berikut:

```
+=================================================================================================================+
|                            TINDAKAN YANG DILARANG KERAS DALAM PENGEMBANGAN PHASE 4                             |
+----+---------------------------------------------------+--------------------------------------------------------+
| No | Tindakan Terlarang                                | Alasan Pelarangan Ilmiah / Hukum                       |
+----+---------------------------------------------------+--------------------------------------------------------+
| 1  | Membuat titik GPS penangkapan ikan sintetis       | Pelanggaran integritas data empiris perikanan          |
| 2  | Mengklaim validasi ekologis penuh dari heuristik  | Hubungan sirkular; overconfidence model                |
| 3  | Menerbitkan larangan melaut otomatis              | Pelanggaran kewenangan hukum Syahbandar Pelabuhan      |
| 4  | Menggunakan label "AMAN" sebagai jaminan          | Menimbulkan persepsi keselamatan palsu nelayan         |
| 5  | Menetapkan 123 poligon sebagai No-Take Zone       | Ketiadaan dasar hukum regulasi dan survei empiris      |
| 6  | Mengekstrapolasi model ke luar Sub-AOI Prigi      | Pelanggaran validitas domain lingkungan meso-skala     |
| 7  | Menampilkan data reanalisis sebagai prakiraan     | Menyesatkan pengguna navigasi operasional              |
| 8  | Memberi status CITES spesies otomatis pada cucut  | Data pelabuhan hanya tingkat genus Carcharhinus spp.   |
| 9  | Merata-ratakan variabel beda satuan pada risiko   | Kerancuan dimensi fisik (meter vs knot vs GT)          |
| 10 | Menghapus arsip skrip atau hasil pemrosesan lama  | Pelanggaran prinsip reprodusibilitas dan provenance    |
+----+---------------------------------------------------+--------------------------------------------------------+
```

1. **Dilarang Menghasilkan Koordinat GPS Posisi Tangkap Tiruan:**  
   Dilarang keras menggunakan algoritma pengacakan spasial untuk membuat koordinat lintang-bujur fiktif kapal nelayan atau lokasi tebar jaring.
2. **Dilarang Mengklaim Model Tervalidasi Secara Ekologis Lapangan:**  
   Dilarang menyatakan bahwa model SDM ensemble telah divalidasi secara biologis di laut bebas. Validasi yang dicapai adalah validasi statistik diskriminasi spasial proksi (*pseudo-presence discrimination*).
3. **Dilarang Menerbitkan Larangan Melaut Otomatis:**  
   Sistem dilarang memblokir layar atau menerbitkan surat larangan berlayar; fungsi penentuan kelaikan kapal melaut merupakan kewenangan hukum Syahbandar di Pelabuhan Perikanan.
4. **Dilarang Menjamin Keselamatan Berlayar dengan Kata "Aman":**  
   Dilarang menggunakan kata "Aman" (*Safe*) pada modul penapisan cuaca laut; wajib menggunakan frasa "Risiko Rendah / Kondisi Relatif Kondusif".
5. **Dilarang Menetapkan Zona Larangan Tangkap Konservasi Mandiri:**  
   Dilarang menyebut 123 poligon batimetri sebagai zona terlarang (*marine protected area / no-take zone*). Seluruh rekomendasi bersifat sukarela (*voluntary mitigation review*).
6. **Dilarang Mengekstrapolasi Model ke Seluruh WPPNRI 573:**  
   Dilarang menerapkan model di luar batas bujur $111,0^\circ\text{–}113,0^\circ\text{ E}$ dan lintang $-8,00^\circ\text{–}-10,45^\circ\text{ S}$.
7. **Dilarang Menyamarkan Data Reanalisis sebagai Prakiraan Real-Time:**  
   Dilarang menampilkan data ERA5 atau GLORYS seolah-olah merupakan cuaca hari ini atau prakiraan esok hari.
8. **Dilarang Mengaitkan Data Cucut ke Spesies Tertentu Tanpa Verifikasi:**  
   Dilarang menetapkan status CITES Appendix I (*C. longimanus*) atau Appendix II pada data pendaratan PPN Prigi tanpa verifikasi morfometrik atau DNA.
9. **Dilarang Menggabungkan Variabel Beda Satuan Secara Sembarangan:**  
   Dilarang merata-ratakan nilai tinggi gelombang (meter) dan kecepatan angin (knot) dalam satu indeks agregat tanpa model normalisasi multivariat yang valid.
10. **Dilarang Merusak atau Menimpa Data dan Skrip Historis:**  
    Dilarang menimpa atau menghapus file CSV mentah, skrip Phase 1–3, dan laporan audit sebelumnya. Seluruh berkas baru harus disimpan dengan versi dan dokumentasi yang jelas.

---

## 5. ATURAN KEPUTUSAN KESIAPAN (*READINESS DECISION RULES*)

Berdasarkan hasil audit komprehensif terhadap dokumen, basis data, dan skrip proyek hingga tanggal 1 November 2026, status kesiapan pengembangan Phase 4 secara resmi diklasifikasikan ke dalam dua tingkatan keputusan berikut:

### 5.1 KEPUTUSAN 1: GO — PROTOTYPE DEVELOPMENT (DISETUJUI DENGAN PRASYARAT)
Sistem **DIBERIKAN OTORISASI PENUH** untuk melanjutkan ke tahap **Perancangan dan Pengembangan Prototipe Phase 4 (DOM-DSS)**, terbatas pada lingkup aktivitas berikut:
1. **Perancangan Arsitektur Sistem:** Membangun antarmuka interaktif DSS mandiri (*zero-CORS standalone HTML5/JS*);
2. **Visualisasi RHSI Multimodel:** Menampilkan distribusi spasial indeks kesesuaian habitat relatif ($\overline{RHSI}_w$) dan lapisan ketidaksepakatan model ($\sigma_w$) secara terpisah;
3. **Eksplorasi Skor Advisory Gabungan:** Mengimplementasikan formula $PFG_{\text{advisory}} = \overline{RHSI}_w - \lambda\sigma_w$ dengan pengujian sensitivitas parameter $\lambda \in \{0,00, 0,25, 0,50, 0,75, 1,00\}$ dan arsitektur penyimpanan ganda (*raw score* & *visualization score*);
4. **Penapisan Risiko Maritim Bertingkat:** Mengembangkan modul penapisan cuaca bertingkat (Tingkat 1–4) berbasis interaksi gelombang ($H_s, T_p$), angin, hembusan (*gust*), dan profil kapal dengan prinsip *worst-case trigger*;
5. **Edukasi Mitigasi Konservasi Sukarela:** Menampilkan 123 poligon penapisan batimetri sukarela lereng 150–1.200 m, penyajian informasi taksonomi CITES terstruktur, dan diseminasi materi edukasi mata kail melingkar (*circle hooks*) serta rumpon ramah lingkungan (*NEFADs*);
6. **Transparansi Metadata Data Provenance:** Menyediakan inspektur metadata 16 atribut dan penanda visual data kedaluwarsa (*stale data tagging*).

### 5.2 KEPUTUSAN 2: NO-GO — OPERATIONAL DEPLOYMENT (DILARANG KERAS)
Sistem **DILARANG KERAS DAN TIDAK MEMPEROLEH OTORISASI** untuk diterapkan sebagai sistem operasional lapangan langsung (*operational commercial deployment*) yang mengikat nelayan, otoritas pelabuhan, atau regulator, dengan rincian larangan:
1. **Dilarang Menyebarkan Titik Koordinat Penangkapan Ikan Definitif:** Tidak boleh digunakan sebagai panduan penentuan koordinat pasti penurunan jaring di laut;
2. **Dilarang Menetapkan Zona Larangan Tangkap Tertutup:** Tidak boleh digunakan sebagai dasar penegakan hukum pelarangan penangkapan ikan di 123 poligon lereng batimetri;
3. **Dilarang Menerbitkan Larangan Berlayar Otomatis:** Tidak boleh digunakan untuk menghentikan operasional pelabuhan tanpa putusan resmi Syahbandar di Pelabuhan Perikanan;
4. **Dilarang Digunakan di Luar Sub-AOI Prigi:** Tidak boleh dipasang atau digunakan oleh armada perikanan di luar wilayah perairan selatan Trenggalek-Tulungagung-Blitar ($111^\circ\text{–}113^\circ\text{ E}$, $-8,0^\circ\text{–}-10,45^\circ\text{ S}$).

---

## 6. KESIMPULAN DAN PERNYATAAN KEPATUHAN

Dokumen prasyarat ini menetapkan standar integritas ilmiah, kehati-hatian teknis, dan kepatuhan hukum yang tertinggi bagi seluruh kelanjutan sistem perikanan PPN Prigi. Seluruh analis sistem, perekayasa perangkat lunak, dan peneliti yang terlibat dalam implementasi Phase 4 diwajibkan membaca, memahami, dan mematuhi setiap klausul yang tercantum dalam dokumen ini.

Dokumen ini menjadi rujukan utama bagi dokumen konfigurasi mesin gerbang kesiapan:
`PHASE_4_READINESS_GATE.json`

Setiap penyimpangan atau ketidaksesuaian implementasi terhadap dokumen ini akan menggugurkan validitas prototipe Phase 4 dan mewajibkan remediasi ulang.

---
*Ditetapkan di Surabaya / Trenggalek pada tanggal 1 November 2026 oleh Tim Penilai Ilmiah dan Auditor Sistem Geospasial Perikanan ASIK VI 2026.*
