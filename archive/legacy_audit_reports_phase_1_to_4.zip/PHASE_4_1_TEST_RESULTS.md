# PHASE 4.1 — AUTOMATED TEST RESULTS REPORT
## Sistem Intelijen Geospasial Perikanan Pelagis PPN Prigi — WPPNRI 573

- **Test Runner Script:** `scratch/test_phase_4_1_integrity.py` & `scratch/validate_polygon_geometries.py`
- **Execution Timestamp:** 2026-11-01T12:49:02+07:00
- **Environment:** Windows PowerShell | Python 3.14.7 | Node.js v24.19.0
- **Overall Test Suite Result:** `7 / 7 PASS` (`0 FAIL`)
- **Readiness Gate Summary (`PG-01`..`PG-14`):** `11 PASS`, `2 PARTIAL`, `1 NEEDS_VERIFICATION`, `0 FAIL`

---

## 1. Automated Test Suite Summary (`T-01` .. `T-07`)

| Test ID | Category | Test Name | Status | Command |
| :--- | :--- | :--- | :--- | :--- |
| `T-01` | Data Integrity | Canonical 132-Month Catch & April 2022 Reconciliation | **PASS** | `python scratch/test_phase_4_1_integrity.py` |
| `T-02` | Data Integrity | Trips (189,334 vs 249,257), Fleet (443 units), and 12-Taxon Dictionary | **PASS** | `python scratch/test_phase_4_1_integrity.py` |
| `T-03` | Spatial Integrity | Canonical Sub-AOI Prigi Bounds, Grid Count (2,050), and Equal-Area (59,550.43 km2) | **PASS** | `python scratch/test_phase_4_1_integrity.py` |
| `T-04` | Spatial Integrity | Zero Out-of-Bounds Vertices Across All Clipped GeoJSON Layers | **PASS** | `python scratch/validate_polygon_geometries.py` |
| `T-05` | Scientific Model Integrity | Weighted RHSI, Weighted Disagreement (sigma_w), Dual Advisory Scores & Sensitivity Suite | **PASS** | `python scratch/test_phase_4_1_integrity.py` |
| `T-06` | Geospatial Bycatch Integrity | 123 Clipped Polygons, L.polygon Rendering, and 8 CITES Fields Synchronized | **PASS** | `python scratch/test_phase_4_1_integrity.py` |
| `T-07` | Application Integrity | WebGIS JS Bundles, switchView('view-sdm') Fix, and Streamlit Canonical Data Loader | **PASS** | `python scratch/test_phase_4_1_integrity.py` |

---

## 2. Detailed Test Evidence & Actual Values

### T-01 — Canonical 132-Month Catch & April 2022 Reconciliation
- **Category:** Data Integrity
- **Status:** `PASS` (`passed_assertion = True`)
- **Method:** Cross-file summation and row-level equality assertion for 2022-04 and 2015-2025 grand total.
- **Command:** `python scratch/test_phase_4_1_integrity.py`
- **Target Files:** `data/master_prigi_all_inclusive.csv`, `data/master.csv`, `data/oceanographic/statistics/monthly/monthly_stats_prigi.csv`, `data/oceanographic/statistics/monthly/ocean_fisheries_master_132m.json`, `data/oceanographic/statistics/annual/annual_climatology.json`, `data/oceanographic/statistics/seasonal/seasonal_climatology.json`, `html/oceanographic_data.js`, `html/index.html`
- **Actual Value:**
```json
{
  "months_count": 132,
  "april_2022_kg": {
    "canonical_csv": 198246,
    "master_csv": 198246,
    "monthly_stats_csv": 198246,
    "ocean_132m_json": 198246,
    "index_html": 198246
  },
  "grand_total_kg": {
    "canonical_csv": 18405261,
    "master_csv": 18405261,
    "monthly_stats_csv": 18405261,
    "ocean_132m_json": 18405261,
    "annual_climatology": 18405261,
    "seasonal_climatology": 18405261,
    "index_html": 18405261
  }
}
```

### T-02 — Trips (189,334 vs 249,257), Fleet (443 units), and 12-Taxon Dictionary
- **Category:** Data Integrity
- **Status:** `PASS` (`passed_assertion = True`)
- **Method:** Numerical sum check on trip & bycatch columns and string assertion on UI metadata labels.
- **Command:** `python scratch/test_phase_4_1_integrity.py`
- **Target Files:** `data/master_prigi_all_inclusive.csv`, `data/prigi_elasmobranch_bycatch_records.csv`, `data/spatial_species_dictionary.json`, `html/index.html`
- **Actual Value:**
```json
{
  "trips_2015_2025_132m": 189334,
  "cucut_bycatch_132m_kg": 127452,
  "species_dictionary_count": 12,
  "html_explicit_disambiguation_present": true
}
```

### T-03 — Canonical Sub-AOI Prigi Bounds, Grid Count (2,050), and Equal-Area (59,550.43 km2)
- **Category:** Spatial Integrity
- **Status:** `PASS` (`passed_assertion = True`)
- **Method:** JSON schema and grid array dimension verification across all spatial manifests and grids.
- **Command:** `python scratch/test_phase_4_1_integrity.py`
- **Target Files:** `data/spatial_config_aoi.json`, `data/spatial_readiness_report.json`, `data/manifests/processing_manifest.json`, `data/oceanographic/metadata/quality_control_report.json`, `data/oceanographic/processed/seasonal/grid_*.json`
- **Actual Value:**
```json
{
  "bbox": [
    111.0,
    -10.45,
    113.0,
    -8.0
  ],
  "grid_centers_count": 2050,
  "equal_area_km2": 59550.43,
  "manifest_grid_cells": [
    2050,
    2050,
    2050,
    2050
  ],
  "seasonal_grids": {
    "grid_musim_timur_climatology.json": {
      "cells_len": 2050,
      "cells_count_meta": 2050,
      "bounds": {
        "west": 111.0,
        "east": 113.0,
        "south": -10.45,
        "north": -8.0
      }
    },
    "grid_musim_barat_climatology.json": {
      "cells_len": 2050,
      "cells_count_meta": 2050,
      "bounds": {
        "west": 111.0,
        "east": 113.0,
        "south": -10.45,
        "north": -8.0
      }
    },
    "grid_extreme_2019_super_iod.json": {
      "cells_len": 2050,
      "cells_count_meta": 2050,
      "bounds": {
        "west": 111.0,
        "east": 113.0,
        "south": -10.45,
        "north": -8.0
      }
    },
    "grid_extreme_2016_negative_iod.json": {
      "cells_len": 2050,
      "cells_count_meta": 2050,
      "bounds": {
        "west": 111.0,
        "east": 113.0,
        "south": -10.45,
        "north": -8.0
      }
    }
  }
}
```

### T-04 — Zero Out-of-Bounds Vertices Across All Clipped GeoJSON Layers
- **Category:** Spatial Integrity
- **Status:** `PASS` (`passed_assertion = True`)
- **Method:** Exhaustive vertex coordinate boundary test against [111.00, 113.00] E x [-10.45, -8.00] S.
- **Command:** `python scratch/validate_polygon_geometries.py`
- **Target Files:** `data/oceanographic/derived/bathymetry_features/prigi_shelf_break_200m.geojson`, `data/sdm/background/target_group_background.geojson`, `outputs/sdm/zones/*.geojson`
- **Actual Value:**
```json
{
  "shelf_break_200m_oob_vertices": 0,
  "target_group_background_oob_points": 0,
  "sdm_zone_layers": {
    "functional_ecological_zones.geojson": {
      "features": 1923,
      "oob_vertices": 0,
      "total_area_km2": 56365.86
    },
    "functional_zones_cakalang.geojson": {
      "features": 1923,
      "oob_vertices": 0,
      "total_area_km2": 56365.86
    },
    "functional_zones_madidihang.geojson": {
      "features": 1858,
      "oob_vertices": 0,
      "total_area_km2": 54431.4
    },
    "functional_zones_albakor.geojson": {
      "features": 513,
      "oob_vertices": 0,
      "total_area_km2": 15190.88
    },
    "dynamic_bycatch_mitigation_zones.geojson": {
      "features": 123,
      "oob_vertices": 0,
      "total_area_km2": 3653.23
    }
  }
}
```

### T-05 — Weighted RHSI, Weighted Disagreement (sigma_w), Dual Advisory Scores & Sensitivity Suite
- **Category:** Scientific Model Integrity
- **Status:** `PASS` (`passed_assertion = True`)
- **Method:** Exhaustive mathematical verification across 36,900 cell projections and metadata boolean audit.
- **Command:** `python scratch/test_phase_4_1_integrity.py`
- **Target Files:** `models/sdm/ensemble/model_evaluations_summary.json`, `outputs/sdm/hsi/hsi_all_scenarios_projections.json`, `outputs/sdm/hsi/rhsi_sensitivity_analysis.json`, `PHASE_3_MODEL_METADATA.json`, `FINAL_SDM_VALIDATION_MATRIX.csv`
- **Actual Value:**
```json
{
  "weights_normalized_sum_1": true,
  "cells_verified": 36900,
  "formula_mismatch_count": 0,
  "albakor_zero_weight_maxent_excluded_from_sigma_w": true,
  "ml_training_executed_in_code": false,
  "spatial_cv_executed_in_code": false,
  "lambda_scenarios_count": 5,
  "weight_schemes_count": 4
}
```

### T-06 — 123 Clipped Polygons, L.polygon Rendering, and 8 CITES Fields Synchronized
- **Category:** Geospatial Bycatch Integrity
- **Status:** `PASS` (`passed_assertion = True`)
- **Method:** GeoJSON feature inspection, CITES 8-field schema check, and Leaflet L.polygon call verification.
- **Command:** `python scratch/test_phase_4_1_integrity.py`
- **Target Files:** `outputs/sdm/zones/dynamic_bycatch_mitigation_zones.geojson`, `data/spatial_species_dictionary.json`, `data/prigi_elasmobranch_bycatch_records.csv`, `html/sdm_data.js`, `html/index.html`
- **Actual Value:**
```json
{
  "polygon_count": 123,
  "total_clipped_area_km2": 3653.23,
  "boundary_clipped_cells": 6,
  "layer_official_name": "Candidate Bathymetric Screening Polygons for Voluntary Shark Bycatch Review",
  "all_123_polygons_have_8_cites_fields": true,
  "species_dict_id9_has_8_cites_fields": true,
  "bycatch_csv_has_8_cites_fields": true,
  "html_renders_true_L_polygon": true
}
```

### T-07 — WebGIS JS Bundles, switchView('view-sdm') Fix, and Streamlit Canonical Data Loader
- **Category:** Application Integrity
- **Status:** `PASS` (`passed_assertion = True`)
- **Method:** Node.js Function() compilation + bundle execution and Python import verification of utils.get_master().
- **Command:** `python scratch/test_phase_4_1_integrity.py`
- **Target Files:** `html/index.html`, `html/oceanographic_data.js`, `html/sdm_data.js`, `utils.py`, `data/master.csv`, `data/species_traits.csv`
- **Actual Value:**
```json
{
  "node_js_validation": {
    "inline_scripts": 3,
    "master_vs_ocean_diffs": 0,
    "sdm_bycatch_features": 123,
    "sdm_has_ring": true,
    "sdm_cell_tuple_len": 9
  },
  "switch_view_sdm_fixed": true,
  "streamlit_get_master_dummy": false,
  "streamlit_get_master_rows": 132,
  "streamlit_get_master_total_kg": 18405261,
  "streamlit_species_traits_rows": 6
}
```

---

## 3. Readiness Gate Verification Table (`PG-01` .. `PG-14`)

| Gate ID | Gate Name | Status | Target Files | Notes |
| :--- | :--- | :--- | :--- | :--- |
| `PG-01` | No synthetic fishing GPS & strict AOI clamping of background proxy points | **PASS** | `data/sdm/background/target_group_background.geojson`, `data/sdm/presence_proxy/presence_proxy_all_species.geojson`, `scratch/execute_stage_3_1_to_3_3.js` | 93 jittered background points previously outside [-10.45, -8.00] S were clamped strictly inside [111.0000, 113.0000] x [-10.4500, -8.0000]. |
| `PG-02` | RHSI relative interpretation & honest heuristic algorithmic provenance | **PASS** | `models/sdm/ensemble/model_evaluations_summary.json`, `PHASE_3_MODEL_METADATA.json`, `FINAL_SDM_VALIDATION_MATRIX.csv` ... | Explicitly documents analytical Gaussian/step/logit heuristic curves and proxy-discrimination evaluation metrics. |
| `PG-03` | Ensemble weight normalization | **PASS** | `models/sdm/ensemble/model_evaluations_summary.json` | Weights sum to 1.000 for Cakalang (0.320+0.355+0.325), Madidihang (0.325+0.350+0.325), and Albakor (0.000+0.550+0.450). |
| `PG-04` | Weighted ensemble disagreement (sigma_w) & dual-score advisory storage | **PASS** | `outputs/sdm/hsi/hsi_all_scenarios_projections.json`, `html/sdm_data.js`, `html/index.html` | Remediated CONF-10: Albakor zero-weight component (hsi_maxent, w=0) no longer inflates sigma_w, and dual advisory scores are stored in every cell. |
| `PG-05` | Lambda penalty, weight scheme, and threshold sensitivity analysis | **PASS** | `outputs/sdm/hsi/rhsi_sensitivity_analysis.json` | Full computational sensitivity matrix generated and persisted in outputs/sdm/hsi/rhsi_sensitivity_analysis.json. |
| `PG-06` | Internal maritime risk classification & safety label compliance | **PARTIAL** | `html/index.html`, `PHASE_4_PRECONDITIONS_FINAL.md` | Status PARTIAL reflects that baseline UI complies with PROHIB-03 and PROHIB-04 (zero 'AMAN' guarantees or automated bans), while the interactive multivariate risk screening module is scoped for Phase 4.4. |
| `PG-07` | BMKG feed freshness & stale data handling | **PARTIAL** | `data/oceanographic/metadata/data_sources.json`, `html/oceanographic_data.js` | Status PARTIAL is honest because Phase 4.1 is strictly baseline remediation; live feed polling and stale-data banners belong to Phase 4.2–4.4. |
| `PG-08` | 123 bycatch candidate polygon geometry validation & exact AOI clipping | **PASS** | `outputs/sdm/zones/dynamic_bycatch_mitigation_zones.geojson`, `html/sdm_data.js`, `html/index.html` | Remediated CONF-13 & CONF-14: polygons clipped to [111.00, 113.00] E (3,653.23 km2 equal-area) and rendered as true polygons instead of circleMarker. |
| `PG-09` | CITES taxonomy verification & 8 mandatory taxonomic fields | **NEEDS_VERIFICATION** | `data/spatial_species_dictionary.json`, `data/prigi_elasmobranch_bycatch_records.csv`, `outputs/sdm/zones/dynamic_bycatch_mitigation_zones.geojson` ... | Software schema is 100% compliant (all 8 fields synchronized); biological status remains NEEDS_VERIFICATION because historical port landings lack specimen-level DNA/morphometric identification. |
| `PG-10` | Current legal references & Syahbandar statutory authority | **PASS** | `html/index.html`, `PHASE_4_PRECONDITIONS_FINAL.md` | Complies fully with PROT-04. |
| `PG-11` | Historical/reanalysis separation & non-causal statistical framing | **PASS** | `data/oceanographic/derived/upwelling/ocean_fisheries_correlation.json`, `data/oceanographic/metadata/variable_dictionary.json`, `html/oceanographic_data.js` ... | Remediated CONF-08, CONF-09, and hardcoded correlation matrix in html/index.html. |
| `PG-12` | Geographic and environmental validity (Canonical Sub-AOI Prigi) | **PASS** | `data/spatial_config_aoi.json`, `data/spatial_readiness_report.json`, `data/manifests/processing_manifest.json` ... | Remediated CONF-05, CONF-06, CONF-07, CONF-16, and CONF-18. |
| `PG-13` | Canonical fisheries & macroeconomic data reconciliation (2015–2025) | **PASS** | `data/master_prigi_all_inclusive.csv`, `data/master.csv`, `data/oceanographic/statistics/monthly/monthly_stats_prigi.csv` ... | Remediated CONF-01, CONF-02, CONF-03, CONF-04, and CONF-17. |
| `PG-14` | Application & WebGIS runtime integrity (View 7 SDM map & Streamlit loader) | **PASS** | `html/index.html`, `html/oceanographic_data.js`, `html/sdm_data.js` ... | Remediated CONF-15 and BUG-01..BUG-04. |
