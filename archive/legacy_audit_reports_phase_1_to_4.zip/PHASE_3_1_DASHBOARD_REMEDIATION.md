# PHASE 3.1 — DASHBOARD LABEL & METADATA REMEDIATION REPORT
## Laporan Remediasi Antarmuka Pengguna, Penyelarasan Nomenklatur Ilmiah, dan Eliminasi Label Menyesatkan
### WPPNRI 573 × PPN Prigi Spatial Fisheries Intelligence System

**Tanggal Audit:** 31 Oktober 2026  
**Auditor:** Senior Geospatial Frontend Architect, UI/UX Marine Specialist & Scientific Reviewer  
**File Terdampak:** `html/index.html`, `html/sdm_data.js`, `models/sdm/ensemble/model_evaluations_summary.json`  
**Status Evaluasi:** SELESAI, TEREVISI PENUH & TERVALIDASI (100% REMEDIATED)  
**Dokumen Induk:** Proyek Intelijen Geospasial Perikanan Pelagis PPN Prigi — WPPNRI 573  

---

## 1. PENDAHULUAN & RUANG LINGKUP REMEDIASI UI

Antarmuka dasbor interaktif merupakan garda terdepan dalam diseminasi hasil analisis sistem intelijen geospasial perikanan pelagis PPN Prigi. Ketidakakuratan dalam penamaan label (*mislabeling*) pada antarmuka dapat berakibat fatal: pengambil kebijakan (*stakeholders*) atau pelaku usaha perikanan dapat salah mengartikan indeks probabilitas relatif atau zona proksi heuristik sebagai lokasi koordinat ikan yang pasti di laut lepas.

Task 9 ini bertujuan melakukan audit menyeluruh terhadap antarmuka dasbor interaktif, menghapus terminologi absolut yang tidak berdasar, menyelaraskan label dengan prinsip metodologi ilmiah, dan mendokumentasikan setiap perubahan teks tanpa mengubah desain visual maupun arsitektur dasbor.

---

## 2. INVENTARIS KATA DAN TERMINOLOGI YANG DILARANG

Sesuai arahan audit ilmiah, istilah-istilah absolut berikut telah disaring dan **dihapus total** dari antarmuka:

| Terminologi Lama (Dilarang) | Terminologi Baru (Resmi) | Alasan Epistemologis & Regulasi |
| :--- | :--- | :--- |
| **Actual Presence** | **Heuristic Presence-Proxy Point** | Titik bukan koordinat GPS riil, melainkan sintesis relung heuristik & jangkauan armada. |
| **Verified Fishing Ground** | **Potential Fishing Ground Advisory** | Tidak ada data VMS/e-logbook kapal aktif di laut untuk memverifikasi lokasi tangkap. |
| **Verified Nursery Ground** | **Potential Nursery Habitat Proxy** | Hanya didasarkan pada proksi batimetri teluk terlindung (<50m), bukan survei larva. |
| **Verified Bycatch Hotspot** | **Bycatch Screening Advisory Overlay** | Merupakan lapisan penapisan risiko kedalaman tubir, bukan lokasi kematian hiu terverifikasi. |
| **Predictive Probability (HSI)**| **Relative Habitat Suitability Index (RHSI)**| Indeks berskala [0, 1] tidak terkalibrasi dengan prevalensi absolut populasi di alam. |
| **Peta Prediksi Regional WPPNRI 573**| **Peta Advisory RHSI // Sub-AOI Prigi** | Domain spasial hanya mencakup 2.050 sel (2° × 2.45° di Jatim), bukan 24° bujur WPP 573. |

---

## 3. RINCIAN PERUBAHAN PADA ELEMEN ANTARMUKA (`html/index.html`)

Audit kode antarmuka berhasil mengidentifikasi dan memodifikasi komponen visual berikut:

### 3.1 Pilihan Mode Layer SDM (`#selSdmLayerMode`)
- **Sebelum:**
  - `<option value="hsi_ens">Ensemble HSI (Kesesuaian Habitat 0.00 - 1.00)</option>`
  - `<option value="hsi_maxent">MaxEnt Model HSI</option>`
  - `<option value="functional_zones">Zonasi Fungsional Ekologis (5 Kategori)</option>`
- **Sesudah (Remediasi):**
  - `<option value="hsi_ens">Ensemble Relative HSI (RHSI 0.00 - 1.00)</option>`
  - `<option value="hsi_maxent">MaxEnt Model RHSI</option>`
  - `<option value="functional_zones">Zonasi Fungsional Ekologis (5 Kategori Screening)</option>`

### 3.2 Label Kartu Indikator Kinerja Utama (KPI Cards)
- **Sebelum:**
  - `<div class="kpi-lbl">Rata-rata HSI Regional</div>`
  - `<div class="kpi-lbl">Cakupan Area HSI Tinggi (≥0.65)</div>`
- **Sesudah (Remediasi):**
  - `<div class="kpi-lbl">Rata-rata RHSI Sub-AOI Prigi</div>`
  - `<div class="kpi-lbl">Cakupan Area RHSI Tinggi (≥0.65)</div>`

### 3.3 Judul Panel Peta & Legenda Spasial
- **Sebelum:**
  - `Peta Prediksi Habitat Suitability Index (HSI) & Zonasi Dinamis // WPPNRI 573 × PPN Prigi`
  - `Sangat Sesuai (≥0.65)`
- **Sesudah (Remediasi):**
  - `Peta Advisory Relative Habitat Suitability Index (RHSI) & Zonasi Dinamis // Sub-AOI Prigi`
  - `Kesesuaian Relatif Tinggi (RHSI ≥0.65)`

### 3.4 Label Interaktif Checkbox Overlay & Pop-up Tooltip
- **Sebelum:**
  - Checkbox: `Zona Mitigasi Bycatch`
  - Pop-up Grid: `Ensemble HSI: 0.812 (MaxEnt: 0.790)`
  - Pop-up Bycatch: `Zona Mitigasi Bycatch Dinamis`
  - Pop-up Presensi: `Presence-Proxy Point | Kesesuaian Relung: 0.807`
- **Sesudah (Remediasi):**
  - Checkbox: `Zona Penapisan Mitigasi Bycatch (Advisory)`
  - Pop-up Grid: `Ensemble RHSI: 0.812 (MaxEnt RHSI: 0.790)`
  - Pop-up Bycatch: `Zona Penapisan Mitigasi Bycatch (Advisory)` dengan target eksplisit `Hiu Cucut Tikus (Carcharhinus spp.)`
  - Pop-up Presensi: `Heuristic Presence-Proxy Point | Kesesuaian Relung Heuristik: 0.807`

---

## 4. REMEDIASI STATUS EVALUASI MODEL (`model_evaluations_summary.json` & `sdm_data.js`)

Dalam berkas evaluasi model awal, terdapat inkonsistensi teks evaluasi pada Cakalang dan Madidihang:
- **Temuan:** Nilai AUC $0.795$ (Cakalang) dan $0.784$ (Madidihang) dilabeli `"status": "HIGHLY_ACCURATE (AUC > 0.85)"`.
- **Koreksi Ilmiah:** Status telah diubah secara terprogram menjadi:
  - Cakalang Ensemble: `"status": "MODERATELY_ACCURATE (0.70 <= AUC < 0.80)"`
  - Madidihang Ensemble: `"status": "MODERATELY_ACCURATE (0.70 <= AUC < 0.80)"`
  - Albakor Ensemble (AUC 0.860): `"status": "HIGHLY_ACCURATE (AUC >= 0.85)"`
- Skrip optimasi web bundle (`scratch/optimize_sdm_web_bundle.js`) telah dijalankan ulang dan menghasilkan file bundle mandiri terkompresi `html/sdm_data.js` (1.962 KB) yang bebas CORS dan konsisten secara internal.

---

## 5. KESIMPULAN TASK 9

Seluruh elemen teks, atribut tooltip, judul panel, legenda, dan metadata status model pada antarmuka web dasbor telah diselaraskan 100% dengan kaidah saintifik. Pengguna dasbor kini disajikan informasi yang transparan dan dapat dipertanggungjawabkan, membedakan secara tegas antara statistik pendaratan observasi pelabuhan, skenario aksesibilitas armada, proksi keberadaan, dan indeks kesesuaian habitat relatif (RHSI).
