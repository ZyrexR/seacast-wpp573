# FINAL SCIENTIFIC AUDIT: ECOLOGICAL ZONATION & BYCATCH MITIGATION
## Audit Ambang Batas Zonasi Fungsional, Dekonstruksi 123 Poligon Penapisan Bycatch, dan Batasan Ilmiah Mitigasi Alat Tangkap
### Pre-Phase 4 Scientific Validation Gate | Task 7 Deliverable

**Auditor:** Senior Marine Conservation Scientist, Fisheries Policy Auditor & Protected Species Specialist  
**Tanggal Audit:** 31 Oktober 2026  
**Status Evaluasi:** SELESAI, TERAUDIT KRITIS & SESUAI REGULASI PERIKANAN (100% AUDITED)  

---

## 1. PENDAHULUAN & RUANG LINGKUP AUDIT ZONASI EKOLOGIS

Zonasi fungsional ekologis dan mitigasi tangkapan sampingan (*bycatch*) merupakan komponen penting dalam perencanaan tata ruang laut dinamis (*Dynamic Ocean Management / DOM*). Namun, penetapan zona spasial tanpa dasar regulasi yang sah atau pemetaan spesies terancam tanpa koordinat empiris dapat menimbulkan disinformasi ilmiah dan konflik hukum dengan komunitas nelayan tradisional.

Tugas 7 ini melakukan audit menyeluruh terhadap:
1. Sumber dan rasionalitas ilmiah ambang batas (*thresholds*) seluruh kelas zonasi.
2. Asal-usul 123 poligon mitigasi tangkapan sampingan.
3. Pembakuan terminologi menjadi lapisan penapisan risiko (*screening layer*).
4. Pemisahan data pendaratan dermaga *Carcharhinus spp.* dari koordinat laut lepas.
5. Batasan ilmiah penerapan mata pancing melingkar (*circle hooks*).
6. Penegasan status hukum agar tidak menciptakan larangan sepihak tanpa dasar Keputusan Menteri KP.

---

## 2. AUDIT RASIONALITAS DAN SUMBER AMBANG BATAS ZONASI FUNGSIONAL

Tabel berikut mendokumentasikan asal-usul ilmiah dan dasar regulasi dari seluruh ambang batas zonasi spasial dalam sistem:

```
+-----------------------------------------------------------------------------------------------------------------+
|                       AUDIT AMBANG BATAS KELAS ZONASI FUNGSIONAL SPASIAL                                        |
+---+----------------------------+--------------------------------+-----------------------------------------------+
|No | Kelas Zonasi Fungsional    | Ambang Batas Algoritma         | Dasar Ilmiah & Regulasi Rujukan               |
+---+----------------------------+--------------------------------+-----------------------------------------------+
| 1 | Potential Fishing Ground   | dist_harbor <= 12 NM           | UU No. 23/2014 (Kewenangan Laut Daerah 0-12NM)|
|   | (<10 GT Inshore)           | RHSI >= 0.65, depth <= -30m    | Kapasitas jelajah kapal motor tempel Prigi.   |
+---+----------------------------+--------------------------------+-----------------------------------------------+
| 2 | Potential Fishing Ground   | dist_harbor <= 60 NM           | Profil operasi armada pukat cincin mini       |
|   | (20-30 GT Offshore)        | RHSI >= 0.65, depth <= -100m   | (one-day fishing trip kapasitas BBM 60 NM).   |
+---+----------------------------+--------------------------------+-----------------------------------------------+
| 3 | Potential Feeding Ground   | Front Sobel >= 0.08 °C/km      | Cayula & Cornillon (1992); Zainuddin et al.   |
|   | Proxy                      | Klorofil-a >= 0.40 mg/m³       | Zona konvergensi nutrisi & retensi plankton.  |
+---+----------------------------+--------------------------------+-----------------------------------------------+
| 4 | Potential Nursery Ground   | Kedalaman < 50m, Jarak < 12 NM | Proksi hidrodinamika perairan teluk terlindung|
|   | Proxy                      | (Teluk Prigi & Teluk Damas)    | (Bukan hasil survei iktioplankton larva).     |
+---+----------------------------+--------------------------------+-----------------------------------------------+
| 5 | Potential Spawning Ground  | SST 26.0 - 28.0 °C             | Toleransi termal pemijahan tuna tropis;       |
|   | Proxy                      | Jarak lepas pantai > 25 NM     | Masa tenang peralihan monsun (MAM/SON).       |
+---+----------------------------+--------------------------------+-----------------------------------------------+
```

---

## 3. DEKONSTRUKSI 123 POLIGON PENAPISAN BYCATCH

Berkas `outputs/sdm/zones/dynamic_bycatch_mitigation_zones.geojson` memuat 123 fitur poligon spasial. Audit menelusuri bagaimana 123 fitur ini diciptakan:

### 3.1 Asal-Usul Algoritmik dalam Kode Sumber
Pemeriksaan pada `execute_stage_3_1_to_3_3.js` menunjukkan bahwa 123 poligon dibentuk melalui perpotongan tiga kriteria biofisik pada Skenario Monsun Timur:
1. **Kedalaman Lereng Benua (*Continental Slope*):** Sel dengan kedalaman batimetri antara **$-150\text{ meter}$ hingga $-1.200\text{ meter}$**.
2. **Suhu Lapisan Atas Termoklin:** Sel dengan $\text{SST} \in [24.5^\circ\text{C}, 26.0^\circ\text{C}]$ yang bertepatan dengan lidah air dingin upwelling.
3. **Tumpang Tindih Habitat Target:** Sel yang secara bersamaan memiliki nilai kesesuaian tuna tinggi ($\text{RHSI} \ge 0.85$).

### 3.2 Pembakuan Terminologi: Lapisan Penapisan (Screening Layer)
> **PUTUSAN AUDIT:** Karena 123 poligon ini dihasilkan dari persimpangan kedalaman dan suhu teoritis (tanpa didukung oleh satu pun koordinat GPS interaksi penangkapan hiu riil), poligon-poligon ini **DILARANG DISEBUT SEBAGAI "VERIFIED BYCATCH HOTSPOTS"**.

Terminologi resmi yang sah adalah:

$$\mathbf{Dynamic\text{ }Bycatch\text{ }Screening\text{ }Advisory\text{ }Layer}$$
*(Lapisan Penapisan Risiko Tangkapan Sampingan Dinamis)*

---

## 4. PEMISAHAN DATA PENDARATAN *Carcharhinus spp.* DARI TITIK TANGKAP

- **Data Buku Statistik Pelabuhan:** Sheet 5 mencatat pendaratan kumulatif cucut sebesar $127.452\text{ kg}$ selama 2015–2025.
- **Koreksi Ilmiah:** Pendaratan cucut di dermaga PPN Prigi adalah hasil tangkapan sampingan yang dibawa pulang oleh kapal nelayan pancing ulur dan jaring insang dari berbagai lokasi di Samudra Hindia.
- **Larangan Proyeksi Deterministik:** Dilarang memetakan tonase pendaratan dermaga Prigi ke 123 poligon laut lepas. Menghubungkan pendaratan pelabuhan langsung ke poligon laut lepas tanpa data logbook GPS adalah kesalahan metode spasial (*ecological fallacy*).

---

## 5. BATASAN ILMIAH DAN DISIPLIN ALAT TANGKAP UNTUK CIRCLE HOOKS

Dalam laporan draf sebelumnya, direkomendasikan penggunaan *Circle Hooks* untuk menekan bycatch hiu tanpa membedakan armada penangkapan. Audit menetapkan koreksi teknis perikanan berikut:

```
+-----------------------------------------------------------------------------------------------------------------+
|                       EVALUASI KELAYAKAN TEKNIS PENERAPAN CIRCLE HOOKS                                          |
+---+-----------------------+-----------------------------+--------------------+----------------------------------+
|No | Jenis Alat Tangkap    | Kelayakan Circle Hooks      | Tingkat Relevansi  | Penjelasan Mekanisme Teknis      |
+---+-----------------------+-----------------------------+--------------------+----------------------------------+
| 1 | Pancing Rawai Tuna    | SANGAT DIREKOMENDASIKAN     | 100% RELEVAN       | Mata kail melingkar (16/0-18/0)  |
|   | (Tuna Longline)       | (Bukti Ilmiah Kuat)         |                    | mengait rahang bibir (jaw hook), |
|   |                       |                             |                    | memudahkan pelepasan hidup.      |
+---+-----------------------+-----------------------------+--------------------+----------------------------------+
| 2 | Pancing Ulur Kedalaman| DIREKOMENDASIKAN            | 100% RELEVAN       | Mengurangi risiko kail tertelan  |
|   | (Deep Handline)       | (Bukti Ilmiah Kuat)         |                    | ke dalam esofagus/organ vital.   |
+---+-----------------------+-----------------------------+--------------------+----------------------------------+
| 3 | Pukat Cincin Mini     | TIDAK RELEVAN / SALAH ALAT  | 0% (BUKAN PANCING) | Pukat cincin adalah jaring lingka|
|   | (Purse Seine)         | (Tidak menggunakan kail)    |                    | tanpa mata pancing sama sekali!  |
+---+-----------------------+-----------------------------+--------------------+----------------------------------+
| 4 | Jaring Insang Hanyut  | TIDAK RELEVAN / SALAH ALAT  | 0% (BUKAN PANCING) | Jaring dinding vertikal nilon;   |
|   | (Drift Gillnet)       | (Tidak menggunakan kail)    |                    | mitigasi memerlukan pinger suara.|
+---+-----------------------+-----------------------------+--------------------+----------------------------------+
```

### Mitigasi yang Tepat untuk Pukat Cincin dan Jaring Insang:
- **Armada Pukat Cincin (Purse Seine):** Penggunaan Rumpon Ramah Lingkungan tanpa jaring bergantung (*Non-Entangling FADs* dengan tali lilitan daun kelapa), pemantauan visual sebelum jaring ditarik ke geladak (*brailing*), dan pelepasan segera menggunakan kanvas tandu (*shark scooper*).
- **Armada Jaring Insang (Gillnet):** Penurunan tali ris atas (*headline*) minimal 2–3 meter di bawah permukaan laut untuk meloloskan mamalia dan penyu permukaan.

---

## 6. ASPEK REGULASI DAN KEPATUHAN HUKUM PERIKANAN NASIONAL

Audit menegaskan kepatuhan terhadap hierarki hukum pengelolaan perikanan Republik Indonesia:
1. **Ketiadaan Wewenang Regulasi Mandiri:** Sistem perangkat lunak atau peneliti akademik **TIDAK MEMILIKI WEWENANG HUKUM** untuk menetapkan larangan melaut, larangan kedalaman penangkapan, atau zona tertutup (*no-take marine reserves*).
2. **Dasar Hukum Resmi:** Penetapan kawasan larangan penangkapan ikan secara sah hanya dapat dilakukan oleh Menteri Kelautan dan Perikanan RI melalui Keputusan Menteri (Kepmen-KP) berdasarkan mandat UU No. 31/2004 jo UU No. 45/2009 tentang Perikanan dan Permen-KP No. 31/2020 tentang Pengelolaan Kawasan Konservasi.
3. **Status 123 Poligon Bycatch:** Ditetapkan sebagai **ZONA PENAPISAN SUKARELA (*VOLUNTARY CONSERVATION SCREENING ADVISORY*)**, yang memberikan edukasi kehati-hatian bagi armada pancing rawai untuk meminimalkan kematian hiu langka yang dilindungi CITES Appendix II.

---

## 7. KESIMPULAN AUDIT TASK 7

1. Ambang batas zonasi spasial telah diselaraskan dengan batas yuridis laut daerah (12 NM) dan profil jangkauan armada Prigi (60 NM).
2. Sebanyak 123 poligon diakui secara transparan sebagai lapisan penapisan risiko kedalaman tubir (*Dynamic Bycatch Screening Advisory Layer*), bukan hotspot tangkapan sampingan terkonfirmasi.
3. Rekomendasi penggunaan *Circle Hooks* dibatasi secara ilmiah hanya untuk alat tangkap pancing rawai dan pancing ulur, dengan panduan alternatif mitigasi yang sesuai bagi armada pukat cincin dan jaring insang.
4. Seluruh zona diposisikan secara hukum sebagai panduan advisori sukarela, tanpa memuat larangan operasional sepihak.
