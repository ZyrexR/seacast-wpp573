# PHASE 3.1 — OCEANOGRAPHIC METHODOLOGY & ALGORITHMIC REVIEW
## Tinjauan Kritis dan Remediasi Metodologi Oseanografi Fisika
### WPPNRI 573 × PPN Prigi Spatial Fisheries Intelligence System

**Tanggal Audit:** 31 Oktober 2026  
**Auditor:** Senior Physical Oceanographer, Marine Geospatial Analyst & Independent Reviewer  
**Status Evaluasi:** TERVERIFIKASI & TEREVISI SECARA FISIKA (100% REMEDIATED)  
**Dokumen Induk:** Proyek Intelijen Geospasial Perikanan Pelagis PPN Prigi — WPPNRI 573  

---

## 1. PENDAHULUAN

Tinjauan metodologis ini disusun untuk menindaklanjuti temuan audit eksternal independen terkait tiga formula utama oseanografi yang diterapkan pada Phase 2:
1. Penggunaan nama "Coastal Upwelling Index (CUI)" untuk selisih suhu lepas pantai dan pantai.
2. Formulasi transpor massa Ekman, konvensi tanda, parameter Coriolis di Belahan Bumi Selatan, dan efek lintang.
3. Algoritma deteksi *thermal front*, konversi jarak metrik berbasis lintang, masking batas darat-laut, serta ambang batas (*threshold*).

---

## 2. REMEDIASI NOMENKLATUR: COASTAL-OFFSHORE SST CONTRAST INDEX

### 2.1 Identifikasi Masalah
Dalam dokumentasi Phase 2 sebelumnya, selisih suhu permukaan laut:
$$\Delta T = \text{SST}_{\text{offshore}} - \text{SST}_{\text{coastal}}$$
disebut sebagai *Coastal Upwelling Index (CUI)* atau *Bakun Upwelling Index*.

**Audit Ilmiah:** Penamaan tersebut secara fisik **tidak tepat (*scientifically inaccurate*)**.
- Indeks Bakun yang sesungguhnya (*Bakun Upwelling Index / BUI*, Bakun 1973) didefinisikan sebagai volume transpor air tegak lurus pantai per 100 meter garis pantai ($\text{m}^3/\text{s}/100\text{ m}$) yang dihitung dari tegangan angin permukaan, bukan selisih suhu skalar.
- Penurunan suhu di dekat pantai ($\text{SST}_{\text{coastal}} < \text{SST}_{\text{offshore}}$) memang merupakan indikator terjadinya *upwelling*, tetapi besaran suhu juga dipengaruhi oleh bahang radiasi matahari, awan lokal, pencampuran vertikal pasut, limpasan air sungai, dan evaporasi permukaan.

### 2.2 Penetapan Nomenklatur Baru yang Wajib Digunakan
Nomenklatur resmi untuk formula ini dibakukan menjadi:

$$\mathbf{Coastal\text{-}Offshore\text{ }SST\text{ }Contrast\text{ }Index\text{ }}(\Delta T_{c\text{-}o})$$

- **Definisi Operasional:**
  $$\Delta T_{c\text{-}o} = \overline{\text{SST}}_{\text{offshore } (>60\text{ NM})} - \overline{\text{SST}}_{\text{coastal } (<12\text{ NM})}$$
- **Satuan:** Derajat Celsius ($^\circ\text{C}$).
- **Interpretasi Ilmiah:** Nilai $\Delta T_{c\text{-}o} > 0$ mengindikasikan adanya massa air yang lebih dingin di pesisir dibandingkan di perairan lepas pantai, yang menjadi *proxy thermal* pendukung indikasi fenomena upwelling, tetapi bukan pengukuran kecepatan vertikal air ($w$) secara langsung.

---

## 3. AUDIT RIGOROUS: PERHITUNGAN TRANSPOR MASSA EKMAN

Transpor Ekman dihitung untuk membuktikan secara dinamika fluida apakah angin Monsun Tenggara menghasilkan transpor massa air permukaan menjauhi garis pantai selatan Jawa (*offshore divergence*).

```
                      Garis Pantai Jawa Timur (Lat ~ -8.3° S)
======================================================================== (Daratan)
      ^
      |  Upwelling Vertikal (W_up > 0)
      |  (Massa air dingin sub-permukaan naik)
      |
  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
      |
      V  Transpor Ekman Permukaan (M_ey < 0, Menuju ke SELATAN / LEPAS PANTAI)
         Angin Monsun Tenggara: tau_x < 0 (Ke arah Barat)
         Coriolis Parameter di Belahan Bumi Selatan: f < 0
```

### 3.1 Parameter Fisika dan Persamaan Dinamika

1. **Tegangan Angin Permukaan (*Wind Stress* $\boldsymbol{\tau}$):**
   $$\boldsymbol{\tau} = \rho_{\text{air}} \, C_d \, |\mathbf{U}_{10}| \, \mathbf{U}_{10}$$
   - Kerapatan udara ($\rho_{\text{air}}$): $1.225\text{ kg/m}^3$.
   - Koefisien seret (*Drag Coefficient* $C_d$): Mengikuti formulasi Wu (1982) / Large & Pond (1981):
     $$C_d = (0.80 + 0.065 \, |\mathbf{U}_{10}|) \times 10^{-3} \quad (\text{atau } \approx 1.30 \times 10^{-3} \text{ untuk angin rata-rata } 5\text{–}8\text{ m/s})$$
   - Komponen tegangan zonal ($\tau_x$): $\rho_{\text{air}} C_d \sqrt{u_{10}^2 + v_{10}^2} \cdot u_{10}$ ($\text{N/m}^2$).

2. **Parameter Coriolis ($f$) di Belahan Bumi Selatan:**
   $$f = 2\Omega \sin(\phi)$$
   - Kecepatan sudut rotasi bumi: $\Omega = 7.2921 \times 10^{-5}\text{ rad/s}$.
   - Lintang rata-rata Sub-AOI Prigi: $\phi = -8.5^\circ\text{ S} = -0.14835\text{ rad}$.
   - **Evaluasi Parameter $f$:**
     $$f = 2 \times (7.2921 \times 10^{-5}) \times \sin(-8.5^\circ) = -2.155 \times 10^{-5}\text{ s}^{-1}$$
   - **PENTING:** Nilai $f$ bertanda **NEGATIF** karena berada di Belahan Bumi Selatan (*Southern Hemisphere*).

3. **Kerapatan Air Laut ($\rho_w$):**
   - Nilai baku air permukaan Samudra Hindia tropis: $\rho_w = 1025\text{ kg/m}^3$.

4. **Komponen Transpor Massa Ekman ($M_{ey}$):**
   $$M_{ey} = -\frac{\tau_x}{\rho_w \, f}$$
   - **Analisis Tanda Geografis:**
     * Selama Monsun Timur (Juni–Oktober), angin bertiup kencang dari Tenggara ke Barat Laut, sehingga komponen zonal angin bertiup ke arah barat: $u_{10} < 0 \implies \tau_x < 0$.
     * Karena $f < 0$, maka:
       $$M_{ey} = -\frac{(-)}{1025 \times (-)} = -\frac{(+)}{(-)} \times (-1) = \text{Negatif } (<0)$$
     * Dalam sistem koordinat Kartesius samudra ($+y$ ke Utara, $-y$ ke Selatan), nilai $M_{ey} < 0$ menunjukkan transpor massa mengarah ke **SELATAN** (menjauhi pantai Jawa menuju samudra terbuka).
     * Transpor lepas pantai (*offshore transport*) ini secara konservasi massa memicu divergensi pesisir dan *coastal upwelling*.
   - **Satuan Resmi:** Meter kuadrat per detik ($\text{m}^2/\text{s}$), yang setara dengan meter kubik per detik per meter garis pantai ($\text{m}^3/\text{s}/\text{m}$).

### 3.2 Keterbatasan Ilmiah Indikator Upwelling Ekman
Auditor mendokumentasikan batasan inheren dari kalkulasi ini:
1. **Asumsi Laut Tak Terbatas & Homogen:** Teori klasik Ekman mengasumsikan kedalaman fluida tak berhingga dan stratifikasi seragam. Di dekat pantai (zona neritik dangkal $<50\text{ m}$), lapisan batas dasar laut (*bottom boundary layer*) tumpang tindih dengan lapisan batas permukaan.
2. **Ketiadaan Forcing Jarak Jauh (*Remote Forcing*):** Dinamika *upwelling* di selatan Jawa dipengaruhi kuat oleh gelombang Kelvin ekuatorial Samudra Hindia yang merambat ke timur sepanjang khatulistiwa, membelok ke selatan di barat Sumatra, dan menjalar ke timur di selatan Jawa. Transpor Ekman lokal tidak merefleksikan penjalaran gelombang Kelvin ini maupun dinamika Indian Ocean Dipole (IOD) skala basin.
3. **Penyederhanaan Topografi Garis Pantai:** Garis pantai Jawa Timur berliku dengan teluk-teluk dalam (termasuk Teluk Prigi), tanjung, dan pulau-pulau kecil yang mendistorsi medan angin lokal menjadi *wind shadow* atau *funneling effect*.

---

## 4. AUDIT TEKNIS: DETEKSI THERMAL FRONT

### 4.1 Koreksi Jarak Metrik Berbasis Lintang (Metric Distance Scaling)
Operator gradien spasial Sobel yang diterapkan pada kisi geografis beraturan ($0.05^\circ \times 0.05^\circ$) wajib mengonversi selisih koordinat derajat menjadi jarak metrik riil (kilometer).

Pada elipsoid WGS-84, panjang 1 derajat bervariasi terhadap lintang $\phi$:
- **Jarak Meridional (Utara-Selatan, $\Delta y$):**
  $$\Delta y = \left( 111.13209 - 0.55982 \cos(2\phi) + 0.00117 \cos(4\phi) \right) \Delta \phi \approx 110.574 \times \Delta \phi\text{ km}$$
- **Jarak Zonal (Timur-Barat, $\Delta x$):**
  $$\Delta x = \left( 111.41288 \cos(\phi) - 0.09350 \cos(3\phi) \right) \Delta \lambda \approx 111.320 \cos(\phi) \times \Delta \lambda\text{ km}$$

Pada lintang sentral Sub-AOI Prigi ($\phi = -8.5^\circ\text{ S}$):
$$\cos(-8.5^\circ) = 0.989015$$
Untuk ukuran sel $\Delta \lambda = \Delta \phi = 0.05^\circ$:
$$\Delta x = 0.05 \times 111.320 \times 0.989015 \approx \mathbf{5.505\text{ km}}$$
$$\Delta y = 0.05 \times 110.574 \approx \mathbf{5.529\text{ km}}$$

### 4.2 Formulasi Gradien Sobel Termal
Gradien spasial dihitung menggunakan kernel Sobel 2D termodifikasi dengan bobot jarak:
$$G_x = \frac{1}{8 \Delta x} \begin{bmatrix} -1 & 0 & +1 \\ -2 & 0 & +2 \\ -1 & 0 & +1 \end{bmatrix} * T, \quad G_y = \frac{1}{8 \Delta y} \begin{bmatrix} +1 & +2 & +1 \\ 0 & 0 & 0 \\ -1 & -2 & -1 \end{bmatrix} * T$$

Besar gradien suhu mutlak (*Thermal Gradient Magnitude*):
$$|\nabla T| = \sqrt{G_x^2 + G_y^2} \quad (\text{Satuan Baku: } \mathbf{^\circ\text{C/km}})$$

### 4.3 Land Masking & Penolakan Artefak Pesisir
- **Masalah Artefak:** Sel-sel laut yang berbatasan langsung dengan daratan pulau Jawa memiliki tetangga berupa daratan. Jika daratan diisi nilai sembarang atau NaN tanpa masking yang benar, konvolusi Sobel akan menghasilkan lonjakan gradien palsu (*spurious coastal front*) hingga $>0.50^\circ\text{C/km}$.
- **Remediasi Masking:**
  1. Seluruh sel daratan di-mask menggunakan batas poligon daratan BIG.
  2. Sel pada jarak $<5.5\text{ km}$ dari garis pantai dihitung menggunakan operator beda hingga satu arah (*one-sided difference*) khusus sel basah, atau di-mask dari klasifikasi front oseanik untuk menghindari kesalahan interpretasi habitat pelagis.

### 4.4 Ambang Batas Klasifikasi Front Oseanografi (*Front Thresholds*)
Berdasarkan literatur oseanografi perikanan tropis (Cayula & Cornillon, 1992; Zainuddin et al., 2017), ambang batas gradien suhu ditetapkan sebagai berikut:

| Kategori Front | Rentang Gradien ($|\nabla T|$) | Signifikansi Ekologis bagi Pelagis Besar |
| :--- | :---: | :--- |
| **Latar Belakang / Non-Front** | $< 0.030 ^\circ\text{C/km}$ | Massa air homogen, retensi mangsa rendah |
| **Front Lemah (*Weak Front*)** | $0.030 - 0.050 ^\circ\text{C/km}$ | Batas percampuran awal massa air |
| **Front Moderat (*Moderate Front*)** | $0.050 - 0.080 ^\circ\text{C/km}$ | Zona akumulasi plankton dan mikronekton |
| **Front Kuat (*Strong Front*)** | $> 0.080 ^\circ\text{C/km}$ | Zona konvergensi termal tinggi, batas foraging optimal madidihang dan cakalang |

---

## 5. KESIMPULAN TASK 4

1. Seluruh penggunaan istilah "Coastal Upwelling Index" telah diganti secara sah menjadi **`Coastal-Offshore SST Contrast Index`**.
2. Dinamika transpor Ekman telah diverifikasi dengan parameter $f = -2.155 \times 10^{-5}\text{ s}^{-1}$ bertanda negatif di Belahan Bumi Selatan, membuktikan transpor massa mengarah ke selatan (lepas pantai) selama Monsun Timur.
3. Gradien thermal front Sobel telah terbukti menggunakan jarak metrik riil (km) yang dikoreksi kosinus lintang ($\approx 5.505\text{ km}$ per sel), dengan satuan baku $^\circ\text{C/km}$ dan proteksi masking daratan.
