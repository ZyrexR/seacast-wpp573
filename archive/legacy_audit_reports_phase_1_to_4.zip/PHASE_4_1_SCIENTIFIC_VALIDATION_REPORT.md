# PHASE 4.1 — SCIENTIFIC VALIDATION & SENSITIVITY REPORT
## Sistem Intelijen Geospasial Perikanan Pelagis PPN Prigi — WPPNRI 573

- **Validation Date:** 2026-11-01
- **Model Paradigm:** Heuristic Multi-Criteria Habitat Suitability Screening (`RHSI`)
- **ML Training Executed in Code:** `False` (`ml_training_executed_in_code = false`)
- **Spatial Block CV Executed in Code:** `False` (`spatial_cv_executed_in_code = false`)
- **Cells Verified:** `6` scenarios × `3` species × `2,050` cells = **`36,900` cell projections** (`0` formula errors)

---

## 1. Algorithmic Provenance & Honest Heuristic Framing

Code inspection of `scratch/execute_stage_3_1_to_3_3.js` and `scratch/execute_stage_3_4_to_3_7.js` confirmed that the three component suitability scores are analytical heuristic response functions evaluated against deterministic presence-proxy points:
1. **Component 1 (`hsi_maxent` / `rhsi_niche_gauss`):** Gaussian-Sigmoid thermal, trophic, and frontal niche envelope.
2. **Component 2 (`hsi_rf` / `rhsi_rule_step`):** Multi-threshold environmental rule-step function.
3. **Component 3 (`hsi_glm` / `rhsi_poly_logit`):** Polynomial logistic environmental response curve.

All false claims of trained statistical machine learning models or 5-fold spatial cross-validation have been removed from `models/sdm/ensemble/model_evaluations_summary.json`, `PHASE_3_MODEL_METADATA.json`, `FINAL_SDM_VALIDATION_MATRIX.csv`, and `html/index.html`. AUC/TSS metrics are explicitly labeled as **Exploratory Proxy-Discrimination Metrics (Non-CV)**.

---

## 2. Mathematical Formulation & Albakor Zero-Weight Disagreement Fix (`CONF-10`)

For each cell and species with normalized component weights $w_i \ge 0, \sum_{i=1}^3 w_i = 1.000$:

$$\overline{RHSI}_w = \sum_{i=1}^{3} w_i \cdot RHSI_i$$

$$\sigma_w = \sqrt{\sum_{i=1}^{3} w_i \cdot \left(RHSI_i - \overline{RHSI}_w\right)^2}$$

$$PFG_{\text{raw}}(\lambda) = \overline{RHSI}_w - \lambda \cdot \sigma_w, \quad PFG_{\text{vis}}(\lambda) = \min\left(1, \max\left(0, PFG_{\text{raw}}(\lambda)\right)\right)$$

### Impact of Correcting Unweighted SD to Weighted $\sigma_w$ for Albakor (`w_maxent = 0.000, w_rf = 0.517, w_glm = 0.483`)
- **Old Unweighted Mean Disagreement (including zero-weight MaxEnt component):** `0.2691` (Max: `0.5757`)
- **Remediated Weighted Mean Disagreement ($\sigma_w$, where $w=0$ contributes $0$):** **`0.1993`** (Max: `0.4960`)
- **Artificial Disagreement Inflation Removed:** `0.0698`

---

## 3. Sensitivity Analysis Across Penalty $\lambda \in \{0.00, 0.25, 0.50, 0.75, 1.00\}$ and Threshold $\tau \in \{0.50, 0.55, 0.60, 0.65, 0.70\}$

Reference Scenario: **Musim Timur (JJA Climatology — Peak Upwelling)** (`2,050` cells = `59,550.43 km²`).

| Species | $\lambda$ | Mean Raw Advisory | Min / Max Advisory | % AOI $\ge 0.50$ | % AOI $\ge 0.55$ | % AOI $\ge 0.60$ | % AOI $\ge 0.65$ | % AOI $\ge 0.70$ |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **Cakalang** | `0.00` | `0.624` | `0.416 / 0.939` | `52.0%` | `45.2%` | `40.7%` | `38.0%` | `37.4%` |
| **Cakalang** | `0.25` | `0.584` | `0.339 / 0.917` | `48.0%` | `41.5%` | `37.6%` | `37.6%` | `34.4%` |
| **Cakalang** | `0.50` | `0.544` | `0.262 / 0.895` | `43.7%` | `37.6%` | `37.6%` | `36.6%` | `31.8%` |
| **Cakalang** | `0.75` | `0.504` | `0.184 / 0.874` | `37.6%` | `37.6%` | `37.6%` | `32.4%` | `29.3%` |
| **Cakalang** | `1.00` | `0.464` | `0.107 / 0.852` | `37.6%` | `37.6%` | `32.4%` | `32.4%` | `22.7%` |
| **Madidihang** | `0.00` | `0.681` | `0.459 / 0.933` | `92.9%` | `92.9%` | `90.0%` | `48.5%` | `23.8%` |
| **Madidihang** | `0.25` | `0.631` | `0.366 / 0.910` | `92.9%` | `92.8%` | `42.0%` | `23.8%` | `23.8%` |
| **Madidihang** | `0.50` | `0.582` | `0.271 / 0.888` | `89.9%` | `41.7%` | `23.8%` | `23.8%` | `23.8%` |
| **Madidihang** | `0.75` | `0.533` | `0.175 / 0.865` | `44.3%` | `23.8%` | `23.8%` | `23.8%` | `18.7%` |
| **Madidihang** | `1.00` | `0.483` | `0.080 / 0.842` | `23.8%` | `23.8%` | `23.8%` | `22.0%` | `14.0%` |
| **Albakor** | `0.00` | `0.212` | `0.001 / 0.523` | `13.5%` | `0.0%` | `0.0%` | `0.0%` | `0.0%` |
| **Albakor** | `0.25` | `0.163` | `0.001 / 0.400` | `0.0%` | `0.0%` | `0.0%` | `0.0%` | `0.0%` |
| **Albakor** | `0.50` | `0.113` | `0.001 / 0.277` | `0.0%` | `0.0%` | `0.0%` | `0.0%` | `0.0%` |
| **Albakor** | `0.75` | `0.063` | `0.000 / 0.153` | `0.0%` | `0.0%` | `0.0%` | `0.0%` | `0.0%` |
| **Albakor** | `1.00` | `0.013` | `-0.000 / 0.030` | `0.0%` | `0.0%` | `0.0%` | `0.0%` | `0.0%` |

---

## 4. Sensitivity to Ensemble Weighting Schemes (`lambda = 0.50`, `tau = 0.65` / `0.50`)

| Species | Weighting Scheme | Weights (`maxent`, `rf`, `glm`) | Mean $\overline{RHSI}_w$ | Mean $\sigma_w$ | Mean Advisory (`λ=0.5`) | PFG Cells $\le 60$ NM (`Area km²`) |
| :--- | :--- | :--- | :---: | :---: | :---: | :---: |
| **Cakalang** | `baseline_auc_weights` | `(0.320, 0.355, 0.325)` | `0.624` | `0.160` | `0.544` | `598 (17940.77 km²)` |
| **Cakalang** | `equal_active_weights` | `(0.333, 0.334, 0.333)` | `0.626` | `0.161` | `0.545` | `607 (18215.0 km²)` |
| **Cakalang** | `equal_all_three_weights` | `(0.333, 0.334, 0.333)` | `0.626` | `0.161` | `0.545` | `607 (18215.0 km²)` |
| **Cakalang** | `niche_dominant_weights` | `(0.500, 0.250, 0.250)` | `0.622` | `0.156` | `0.544` | `615 (18458.76 km²)` |
| **Madidihang** | `baseline_auc_weights` | `(0.295, 0.365, 0.340)` | `0.681` | `0.197` | `0.582` | `389 (11652.89 km²)` |
| **Madidihang** | `equal_active_weights` | `(0.333, 0.334, 0.333)` | `0.695` | `0.198` | `0.597` | `389 (11652.89 km²)` |
| **Madidihang** | `equal_all_three_weights` | `(0.333, 0.334, 0.333)` | `0.695` | `0.198` | `0.597` | `389 (11652.89 km²)` |
| **Madidihang** | `niche_dominant_weights` | `(0.500, 0.250, 0.250)` | `0.748` | `0.195` | `0.651` | `389 (11652.89 km²)` |
| **Albakor** | `baseline_auc_weights` | `(0.000, 0.517, 0.483)` | `0.212` | `0.199` | `0.113` | `0 (0 km²)` |
| **Albakor** | `equal_active_weights` | `(0.000, 0.500, 0.500)` | `0.205` | `0.199` | `0.106` | `0 (0 km²)` |
| **Albakor** | `equal_all_three_weights` | `(0.333, 0.334, 0.333)` | `0.292` | `0.243` | `0.170` | `0 (0 km²)` |
| **Albakor** | `niche_dominant_weights` | `(0.200, 0.400, 0.400)` | `0.257` | `0.238` | `0.138` | `0 (0 km²)` |
