# FINAL SCIENTIFIC AUDIT: FISHING FLEET SAFETY ADVISORY
## Audit Ambang Batas Keselamatan Pelayaran, Karakterisasi Gelombang Signifikan, Skenario Jangkauan Armada, dan Matriks Penapisan Risiko
### Pre-Phase 4 Scientific Validation Gate | Task 8 Deliverable

**Auditor:** Senior Marine Safety Officer, Maritime Navigation Specialist & Fisheries GIS Analyst  
**Tanggal Audit:** 31 Oktober 2026  
**Status Evaluasi:** SELESAI, TERAUDIT KRITIS & SESUAI STANDAR MARITIM BMKG/IMO (100% AUDITED)  

---

## 1. PENDAHULUAN & RUANG LINGKUP AUDIT KESELAMATAN

Dalam pengembangan sistem pendukung keputusan penangkapan ikan (*Decision Support System / DSS*) pada Phase 4 mendatang, integrasi antara zona potensi ikan (PFG) dan keselamatan pelayaran (*maritime safety*) merupakan syarat mutlak. Memandu nelayan menuju perairan dengan kelimpahan ikan tinggi tanpa memperhitungkan status laut (*sea state*) dapat mengancam keselamatan jiwa di laut (*Safety of Life at Sea / SOLAS*).

Namun, penetapan ambang batas keselamatan yang kaku atau otomatis melarang kapal melaut secara sepihak di dalam sistem informasi adalah kesalahan fatal konseptual. Tugas 8 ini melakukan audit terhadap:
1. Ambang batas tinggi gelombang signifikan ($H_s > 2.0\text{ meter}$).
2. Skenario buffer jangkauan operasional 12 NM dan 60 NM.
3. Kapasitas teknis kapal penangkap ikan berdasarkan kelas Gross Tonnage (GT).
4. Pemisahan antara skenario analisis dan batasan operasional riil di lapangan.
5. Pembangunan matriks penapisan risiko bertingkat (*Tiered Risk-Screening Matrix*) yang selaras dengan standar BMKG.

---

## 2. AUDIT AMBANG BATAS GELOMBANG SIGNIFIKAN ($H_s > 2.0\text{ METER}$)

### 2.1 Analisis Fisika Gelombang Laut di Selatan Jawa
Tinggi gelombang signifikan ($H_s$) yang diekstrak dari model gelombang ECMWF ERA5 WAM merepresentasikan tinggi rata-rata dari sepertiga gelombang tertinggi dalam suatu spektrum gelombang acak.
- Di perairan Samudra Hindia selatan Jawa, medan gelombang didominasi oleh perpaduan antara **gelombang angin lokal (*wind sea*)** dan **gelombang alun jarak jauh (*ocean swell*)** yang dibangkitkan dari badai lintang tinggi Samudra Hindia selatan (lintang $40^\circ\text{–}50^\circ\text{ S}$).

### 2.2 Dekonstruksi Klaim: Larangan Melaut Otomatis $H_s > 2\text{ m}$
> **PUTUSAN AUDIT:** Pernyataan bahwa "Tinggi gelombang $H_s > 2.0\text{ meter}$ secara otomatis melarang kapal melaut" adalah **TIDAK TEPAT DAN DILARANG DIGUNAKAN SEBAGAI KLAIM ABSOLUT**.

Alasan Teknis & Maritim:
1. **Faktor Periode Gelombang ($T_p$):** Gelombang alun dengan $H_s = 2.0\text{ m}$ dan periode panjang ($T_p = 14\text{–}16\text{ detik}$) memiliki kecuraman rendah (*low wave steepness*), sehingga relatif aman dilewati kapal motor jika dibandingkan dengan gelombang curam berperiode pendek ($H_s = 1.8\text{ m}$, $T_p = 5\text{–}6\text{ detik}$) yang mudah membalikkan perahu motor tempel.
2. **Kondisi Geomorfologi Teluk Prigi:** Teluk Prigi merupakan teluk alami yang sangat terlindung (*semi-enclosed bay*) dengan bukaan sempit ke arah selatan. Pada saat laut lepas Samudra Hindia bergelombang $2.2\text{ meter}$, perairan di dalam teluk sering kali tetap tenang ($H_s < 0.8\text{ meter}$).
3. **Kewenangan Hukum:** Penerbitan Surat Persetujuan Berlayar (SPB) dan Maklumat Keselamatan Pelayaran merupakan **kewenangan mutlak Syahbandar Pelabuhan Perikanan**, bukan sistem perangkat lunak DSS.

---

## 3. AUDIT SKENARIO BUFFER JANGKAUAN FLEET ACCESSIBILITY (12 NM & 60 NM)

Audit mengklarifikasi perbedaan antara batasan skenario model spasial dan batasan operasional riil armada:

```
+-----------------------------------------------------------------------------------------------------------------+
|                       PERBANDINGAN SKENARIO MODEL VS OPERASI AKTUAL ARMADA                                      |
+---+-------------------+-------------------+--------------------+------------------------------------------------+
|No | Parameter Buffer  | Skenario Model    | Operasi Aktual     | Rujukan Teknis & Batasan Lapangan              |
+---+-------------------+-------------------+--------------------+------------------------------------------------+
| 1 | Buffer 12 NM      | Batas Armada      | Jangkauan Fleksibel| Berdasarkan UU 23/2014 (Laut Provinsi) dan     |
|   | (< 10 GT)         | Pesisir Dangkal   | 5 - 18 NM          | kapasitas tangki BBM motor tempel (20-40 L).   |
|   |                   |                   |                    | Saat laut tenang, nelayan sering ke 15 NM.     |
+---+-------------------+-------------------+--------------------+------------------------------------------------+
| 2 | Buffer 60 NM      | Batas Armada      | Jangkauan Trip     | Berdasarkan kapasitas solar kapal pukat cincin |
|   | (20 - 30 GT)      | Oseanotropis      | 20 - 75 NM         | mini (20-30 GT) untuk operasi one-day trip.    |
|   |                   |                   |                    | Saat mengejar ruaya, armada dapat ke 70 NM.    |
+---+-------------------+-------------------+--------------------+------------------------------------------------+
| 3 | Batas Kedalaman   | Zona Tubir        | Tidak Ada Larangan | Delineasi oseanografi neritik (<200m) vs       |
|   | 200 Meter         | Batimetri Benua   | Yuridis Kedalaman  | oseanik (>200m); bukan larangan penangkapan.   |
+---+-------------------+-------------------+--------------------+------------------------------------------------+
```

### Kesimpulan:
Buffer 12 NM dan 60 NM pada sistem diakui sebagai **Skenario Aksesibilitas Armada Rujukan (*Fleet Accessibility Scenarios*)**, bukan batas fisik atau garis larangan hukum yang membatasi pergerakan nelayan.

---

## 4. PENDEKATAN MATRIKS PENAPISAN RISIKO KESELAMATAN BERTINGKAT (*TIERED RISK-SCREENING MATRIX*)

Sebagai pengganti larangan otomatis, sistem Phase 4 diwajibkan menggunakan **Matriks Penapisan Risiko Bertingkat** yang diselaraskan dengan Peraturan BMKG No. Kep. 009/2010 tentang Peringatan Dini Cuaca Maritim:

```
+-----------------------------------------------------------------------------------------------------------------+
|                       MATRIKS PENAPISAN RISIKO KESELAMATAN PELAYARAN PRIGI                                      |
+-----------+--------------------+-------------------+-------------------------+----------------------------------+
| Tingkat   | Kriteria Oseanografi| Kategori Status   | Rekomendasi Armada <10GT| Rekomendasi Armada 20-30 GT      |
+-----------+--------------------+-------------------+-------------------------+----------------------------------+
| Level 1   | Hs <= 1.25 meter   | AMAN              | Operasi penangkapan     | Operasi penangkapan penuh di     |
| (Hijau)   | Angin < 10 knot    | (Low Risk)        | normal di seluruh zona  | seluruh zona jangkauan (60 NM).  |
|           | Arus < 0.25 m/s    |                   | 0 - 12 NM.              |                                  |
+-----------+--------------------+-------------------+-------------------------+----------------------------------+
| Level 2   | 1.25 < Hs <= 2.0 m | WASPADA SEDANG    | Disarankan beroperasi di| Operasi normal; perhatikan update|
| (Kuning)  | Angin 10 - 15 knot | (Moderate Risk)   | dekat perairan teluk    | cuaca BMKG berkala; waspadai     |
|           | Arus 0.25-0.45 m/s |                   | (< 5 NM dari pantai).   | alun di perairan tubir benua.    |
+-----------+--------------------+-------------------+-------------------------+----------------------------------+
| Level 3   | 2.0 < Hs <= 2.5 m  | WASPADA TINGGI    | SANGAT BERISIKO TINGGI; | Diimbau beroperasi hati-hati;    |
| (Oranye)  | Angin 15 - 20 knot | (High Advisory)   | Diimbau tidak melaut di | kurangi kecepatan di laut lepas; |
|           | Arus 0.45-0.65 m/s |                   | luar mulut Teluk Prigi. | pastikan radio komunikasi aktif. |
+-----------+--------------------+-------------------+-------------------------+----------------------------------+
| Level 4   | Hs > 2.50 meter    | BAHAYA EKSTREM    | BAHAYA MAKSIMUM;        | BAHAYA TINGGI;                   |
| (Merah)   | Angin > 20 knot    | (Severe Hazard)   | Seluruh armada motor    | Patuhi maklumat Syahbandar;      |
|           | Arus > 0.65 m/s    |                   | tempel dilarang melaut. | tunda operasi di Samudra Hindia. |
+-----------+--------------------+-------------------+-------------------------+----------------------------------+
```

---

## 5. PANDUAN IMPLEMENTASI SISTEM PENDUKUNG KEPUTUSAN PHASE 4

Dalam membangun modul Decision Support System (DSS) pada Phase 4:
1. **Format Informasi:** Tampilan keselamatan harus disajikan dalam bentuk **Tingkat Risiko Spasial (*Spatial Risk Level*)** berupa kode warna (Hijau, Kuning, Oranye, Merah) pada peta interaktif.
2. **Peringatan Batasan Sistem (*Disclaimer*):** Sistem wajib menyertakan klausul pelepasan tanggung jawab hukum (*disclaimer*):
   > *"Sistem ini berfungsi sebagai alat penapis risiko dan bantuan navigasi ilmiah. Keputusan melaut, izin berlayar, dan keselamatan kapal sepenuhnya berada di bawah diskresi nakhoda dan kepatuhan terhadap maklumat resmi Syahbandar Perikanan serta BMKG Maritim."*
3. **Pemisahan Lapisan DSS:** Peta Kesesuaian Ikan (RHSI) dan Peta Risiko Gelombang (Hs) harus dapat ditumpangsusunkan (*overlaid*) secara independen agar nelayan dapat melihat zona di mana ikan melimpah namun kondisi gelombang berbahaya.

---

## 6. KESIMPULAN AUDIT TASK 8

1. Larangan melaut otomatis berbasis kaku $H_s > 2.0\text{ m}$ telah digantikan dengan pendekatan saintifik **Matriks Penapisan Risiko Bertingkat (Level 1 s/d Level 4)**.
2. Buffer 12 NM dan 60 NM dikonfirmasi sebagai skenario jangkauan kapasitas armada, bukan batasan hukum sepihak.
3. Kepatuhan terhadap otoritas Syahbandar Perikanan dan BMKG Maritim telah ditegaskan sebagai pilar navigasi dalam perancangan Phase 4.
