# PHASE 4.1 — SPATIAL VALIDATION REPORT
## Sistem Intelijen Geospasial Perikanan Pelagis PPN Prigi — WPPNRI 573

- **Validation Date:** 2026-11-01
- **Validator Scripts:** `scratch/validate_polygon_geometries.py` & `scratch/test_phase_4_1_integrity.py`
- **Verification Status:** `PASS` (`0` out-of-bounds vertices, `0` self-intersections, `0` interior polygon overlaps)

---

## 1. Canonical Sub-AOI Prigi Configuration

| Parameter | Canonical Value | Notes |
| :--- | :--- | :--- |
| **Geographic Bounding Box** | `111.00° BT – 113.00° BT`, `-10.45° LS – -8.00° LS` | Clipped operational analysis window south of East Java |
| **Grid Resolution** | `0.05° × 0.05°` (`~5.55 km`) | Uniform geographic grid spacing |
| **Grid Center Dimensions** | `50` meridional rows (`-8.00°` to `-10.45°` S) × `41` zonal columns (`111.00°` to `113.00°` E) = **`2,050` grid centers** | `49 × 40 = 1,960` inter-center intervals |
| **Exact Equal-Area (WGS84 / EPSG:6933)** | **`59,550.43 km²`** (`4.18%` of WPPNRI 573 `1,423,238 km²`) | Computed via exact WGS84 authalic/ellipsoidal surface integral; legacy spherical approximation (`59,206 km²`) noted for provenance |
| **CRS Architecture** | Display: `EPSG:4326` | Local metric distance: `EPSG:32749` (UTM 49S) | Equal-area: `EPSG:6933` |
| **Bathymetry Provenance** | `GEBCO 2023 Grid & NOAA ETOPO1 Bedrock (multi-source composite without single uniform vertical datum)` | Synchronized across all metadata, GeoJSONs, and UI popups |

---

## 2. Exact Geometric Clipping Validation Across Vector & Grid Layers

Every polygon, polyline, and point layer bounded by Sub-AOI Prigi was tested against `[111.0000, 113.0000]° BT × [-10.4500, -8.0000]° LS`:

| Layer / File | Geometry Type | Features Count | Boundary-Clipped Features | Equal-Area (`km²`) | Out-of-Bounds Vertices | Self-Intersections | Interior Overlaps | Status |
| :--- | :--- | ---: | ---: | ---: | ---: | ---: | ---: | :--- |
| `data/oceanographic/derived/bathymetry_features/prigi_shelf_break_200m.geojson` | `LineString` | `1` (`41` vertices) | `2` endpoints interpolated at `111.00°` & `113.00°` | N/A (Line) | **`0`** | `0` | N/A | **PASS** |
| `data/sdm/background/target_group_background.geojson` | `Point` | `2,000` | `93` jittered points clamped to AOI | N/A (Points) | **`0`** | N/A | N/A | **PASS** |
| `outputs/sdm/zones/dynamic_bycatch_mitigation_zones.geojson` | `Polygon` | `123` | `6` western-edge cells (`15.22 km²` each) | **`3,653.23 km²`** | **`0`** | **`0`** | **`0`** | **PASS** |
| `outputs/sdm/zones/functional_ecological_zones.geojson` | `Polygon` | `1,923` | `134` edge cells | **`56,365.86 km²`** | **`0`** | **`0`** | **`0`** | **PASS** |
| `outputs/sdm/zones/functional_zones_cakalang.geojson` | `Polygon` | `1,923` | `134` edge cells | **`56,365.86 km²`** | **`0`** | **`0`** | **`0`** | **PASS** |
| `outputs/sdm/zones/functional_zones_madidihang.geojson` | `Polygon` | `1,858` | `131` edge cells | **`54,431.40 km²`** | **`0`** | **`0`** | **`0`** | **PASS** |
| `outputs/sdm/zones/functional_zones_albakor.geojson` | `Polygon` | `513` | `28` edge cells | **`15,190.88 km²`** | **`0`** | **`0`** | **`0`** | **PASS** |
| `data/oceanographic/processed/seasonal/grid_*.json` (4 files) | Grid Centers | `2,050` per file | Exact `[111.00, 113.00] × [-10.45, -8.00]` | **`59,550.43 km²`** | **`0`** | N/A | N/A | **PASS** |
