# -*- coding: utf-8 -*-
"""
Export AOI_WPP573_MASTER to ESRI Shapefile format using pyshp.
"""
import json
import os
import shapefile

WORKSPACE = r"C:\Users\ThinkPad\.gemini\antigravity\scratch\prigi-pelagis"
MASTER_GEOJSON = os.path.join(WORKSPACE, "data", "aoi", "processed", "AOI_WPP573_MASTER.geojson")
SHP_BASE = os.path.join(WORKSPACE, "data", "aoi", "processed", "AOI_WPP573_MASTER")

def export_shp():
    with open(MASTER_GEOJSON, "r", encoding="utf-8") as f:
        data = json.load(f)
    
    feat = data["features"][0]
    geom = feat["geometry"]
    props = feat["properties"]
    
    w = shapefile.Writer(SHP_BASE, shapeType=shapefile.POLYGON)
    w.field("namobj", "C", size=50)
    w.field("kodwpp", "C", size=10)
    w.field("area_km2", "F", size=15, decimal=2)
    w.field("source", "C", size=50)
    
    # Coordinates in MultiPolygon: list of polygons, each polygon is list of rings
    coords = geom["coordinates"]
    all_rings = []
    for poly in coords:
        for ring in poly:
            all_rings.append(ring)
            
    w.poly(all_rings)
    w.record(
        props.get("namobj", "WPP-RI 573"),
        props.get("kodwpp", "573"),
        props.get("equal_area_epsg6933_km2", 933749.49),
        "BIG"
    )
    w.close()
    
    # Write WGS 84 .prj
    wgs84_wkt = 'GEOGCS["GCS_WGS_1984",DATUM["D_WGS_1984",SPHEROID["WGS_1984",6378137.0,298.257223563]],PRIMEM["Greenwich",0.0],UNIT["Degree",0.0174532925199433]]'
    with open(SHP_BASE + ".prj", "w", encoding="utf-8") as f:
        f.write(wgs84_wkt)
        
    print(f"Shapefile written successfully to {SHP_BASE}.shp")

if __name__ == "__main__":
    export_shp()

