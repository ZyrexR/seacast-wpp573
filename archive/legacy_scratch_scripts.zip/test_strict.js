var fs = require('fs');
var code = fs.readFileSync('gee/SEACAST_PRIGI_GEE_PRODUCTION_2015_2025_v2_3_2.js', 'utf8');

var globalMock = {
  ee: {
    Projection: function() { return { scale: function() { return 1; } }; },
    Image: {
      constant: function() { return { updateMask: function() { return { rename: function() { return { toFloat: function() {} } } } } } },
      pixelLonLat: function() { return { select: function() { return { reproject: function() { return { multiply: function() { return { cos: function() {} } } } } } } } }
    },
    Number: function() { return 0; },
    Algorithms: { If: function() {}, IsEqual: function() {} },
    FeatureCollection: function() {
      return {
        size: function() { return { getInfo: function() { return 1; } }; },
        geometry: function() { return { area: function() { return { divide: function() { return { getInfo: function() { return 933749.49; } }; } }; }, type: function() { return { equals: function() { return true; } }; }, isUnbounded: function() { return false; }, coordinates: function() { return { size: function() { return { subtract: function() { return 1400; } }; } }; } }; },
        map: function() { return { aggregate_sum: function() { return { getInfo: function() { return 933749.49; } }; }, sort: function() { return { limit: function() { return { map: function() { return { aggregate_max: function() { return { getInfo: function() { return 0.001; } }; } }; } }; } }; } }; },
        aggregate_array: function() { return { size: function() { return 8129; }, distinct: function() { return { size: function() { return 8129; } }; } }; },
        aggregate_histogram: function() { return { PURE_OCEAN: 7166, COASTAL_BOUNDARY: 501, OUTER_AOI_BOUNDARY: 462 }; },
        first: function() { return { geometry: function() { return globalMock.ee.FeatureCollection().geometry(); } }; }
      };
    },
    ImageCollection: function() { return { filterDate: function() { return { first: function() { return { getInfo: function() { return { properties: { CHLA_AVE_SLOPE: '0.0016' } }; } }; } }; } }; },
    Feature: function() { return { geometry: function() { return globalMock.ee.FeatureCollection().geometry(); } }; },
    Reducer: { sum: function() {} },
    Dictionary: function() { return { getInfo: function() { return { n_ids: 8129, n_unique: 8129, classes: { PURE_OCEAN: 7166, COASTAL_BOUNDARY: 501, OUTER_AOI_BOUNDARY: 462 } }; } }; }
  },
  print: function() { console.log.apply(console, arguments); },
  Map: { centerObject: function() {}, addLayer: function() {}, add: function() {}, setOptions: function() {} },
  ui: { Label: function() {} }
};

var strictCode = '"use strict";\n' + code;
try {
  var vm = require('vm');
  var ctx = Object.assign({}, globalMock);
  ctx.global = ctx;
  ctx.window = ctx;
  vm.createContext(ctx);
  vm.runInContext(strictCode, ctx);
  console.log('STRICT MODE PASSED: Script ran through successfully!');
} catch (e) {
  console.error('STRICT MODE ERROR:', e);
}

