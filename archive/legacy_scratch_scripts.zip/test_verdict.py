import ee

ee.Initialize(project="seca-513505")

l = ee.List(["VALID", "VALID", "PASS_HIGH_QUALITY"])


def has(s):
  return l.contains(s)


hasNoValid = l.contains("NO_VALID_DATA")
hasUnresolved = l.contains("BLOCKED_UNRESOLVED_QC")
hasUnverified = l.contains("BLOCKED_UNVERIFIED_SCALE")
blockedInvalid = ee.Algorithms.If(
    hasNoValid, True, ee.Algorithms.If(hasUnresolved, True, hasUnverified)
)

framesStatus = ee.String("FULL")
hasPartial = l.contains("PARTIAL_COVERAGE")
hasMissingOpt = l.contains("MISSING_OPTIONAL")
framesPartial = framesStatus.equals("PARTIAL_FRAMES")
qualified = ee.Algorithms.If(
    hasPartial, True, ee.Algorithms.If(hasMissingOpt, True, framesPartial)
)

verdict = ee.Algorithms.If(
    has("NO_DATA"),
    "BLOCKED_MISSING_SOURCE",
    ee.Algorithms.If(
        blockedInvalid,
        "BLOCKED_INVALID_DATA",
        ee.Algorithms.If(
            has("LOW_COVERAGE"),
            "BLOCKED_SPATIAL_COVERAGE",
            ee.Algorithms.If(qualified, "PASS_QUALIFIED_DATA", "PASS_HIGH_QUALITY"),
        ),
    ),
)

print("verdict:", verdict.getInfo())

