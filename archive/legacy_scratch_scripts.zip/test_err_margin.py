import ee
import time

ee.Initialize(project="seca-513505")

aoiFC = ee.FeatureCollection("projects/seca-513505/assets/AOI_WPP573_MASTER")
rawGeom = aoiFC.first().geometry()
polys = rawGeom.geometries().map(
    lambda g: ee.Algorithms.If(
        ee.Geometry(g).type().equals("Polygon"), g, None
    )
).removeAll([None])
polyCoords = polys.map(lambda p: ee.Geometry(p).coordinates())
geom = ee.Geometry(ee.Geometry.MultiPolygon(polyCoords))

gridFC = ee.FeatureCollection("projects/seca-513505/assets/GRID_010_REGIONAL_8129")
first_cell = gridFC.sort("cell_id").first()

for err in [10, 100, 500, 1000]:
  t0 = time.time()
  inter = first_cell.geometry().intersection(geom, err).area(err).divide(1e6)
  ar = ee.Number(first_cell.get("cell_km2"))
  frac = inter.divide(ar).getInfo()
  print(f"err={err}: frac={frac} took {time.time()-t0:.2f}s", flush=True)

