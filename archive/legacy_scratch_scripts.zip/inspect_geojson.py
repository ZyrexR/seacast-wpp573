import json
import math
from pathlib import Path

geojson_path = Path(r"C:\Users\ThinkPad\.gemini\antigravity\scratch\prigi-pelagis\outputs\sdm\zones\dynamic_bycatch_mitigation_zones.geojson")

with open(geojson_path, "r", encoding="utf-8") as f:
    data = json.load(f)

features = data.get("features", [])
print(f"Total features count: {len(features)}")
print(f"GeoJSON Type: {data.get('type')}")
print(f"CRS metadata: {data.get('crs')}")

geom_types = set()
empty_count = 0
coords_list = []
props_list = []

# Sub-AOI bounds
MIN_LON, MAX_LON = 111.0, 113.0
MIN_LAT, MAX_LAT = -10.45, -8.00

outside_sub_aoi_features = []
depth_values = []
min_lons, max_lons = [], []
min_lats, max_lats = [], []

for idx, feat in enumerate(features):
    geom = feat.get("geometry", {})
    props = feat.get("properties", {})
    props_list.append(props)
    
    g_type = geom.get("type")
    geom_types.add(g_type)
    coords = geom.get("coordinates", [])
    
    if not coords or len(coords) == 0:
        empty_count += 1
        continue
    
    # Check bounds
    # For Polygon: coords is list of rings, coords[0] is outer ring
    # For MultiPolygon: list of polygons
    all_pts = []
    if g_type == "Polygon":
        for ring in coords:
            all_pts.extend(ring)
    elif g_type == "MultiPolygon":
        for poly in coords:
            for ring in poly:
                all_pts.extend(ring)
    
    lons = [p[0] for p in all_pts]
    lats = [p[1] for p in all_pts]
    
    feat_min_lon, feat_max_lon = min(lons), max(lons)
    feat_min_lat, feat_max_lat = min(lats), max(lats)
    min_lons.append(feat_min_lon)
    max_lons.append(feat_max_lon)
    min_lats.append(feat_min_lat)
    max_lats.append(feat_max_lat)
    
    # Check if completely inside Sub-AOI
    if feat_min_lon < MIN_LON or feat_max_lon > MAX_LON or feat_min_lat < MIN_LAT or feat_max_lat > MAX_LAT:
        outside_sub_aoi_features.append({
            "index": idx,
            "id": props.get("zone_id", idx),
            "bounds": [feat_min_lon, feat_min_lat, feat_max_lon, feat_max_lat]
        })
    
    # Check properties
    depth_values.append({
        "zone_id": props.get("zone_id"),
        "depth_min": props.get("depth_min_m"),
        "depth_max": props.get("depth_max_m"),
        "depth_mean": props.get("depth_mean_m"),
        "area_km2": props.get("area_km2")
    })

print(f"Geometry Types found: {geom_types}")
print(f"Empty geometries: {empty_count}")
print(f"Overall bounding box of 123 polygons:")
print(f"  Longitude: [{min(min_lons):.4f}, {max(max_lons):.4f}]")
print(f"  Latitude:  [{min(min_lats):.4f}, {max(max_lats):.4f}]")
print(f"Features exceeding Sub-AOI bounds (111-113, -10.45 to -8.0): {len(outside_sub_aoi_features)}")

# Check properties attributes
first_props = features[0].get("properties", {})
print("\nFirst feature properties keys:")
for k, v in first_props.items():
    print(f"  {k}: {v}")

# Check duplicate geometries
coord_hashes = {}
duplicate_geoms = []
for idx, feat in enumerate(features):
    geom_str = json.dumps(feat.get("geometry", {}).get("coordinates", []))
    if geom_str in coord_hashes:
        duplicate_geoms.append((coord_hashes[geom_str], idx))
    else:
        coord_hashes[geom_str] = idx

print(f"\nDuplicate geometries count: {len(duplicate_geoms)}")

# Check depth range consistency
inconsistent_depth = []
for d in depth_values:
    dmin = d.get("depth_min")
    dmax = d.get("depth_max")
    # Expected band 150 - 1200m
    if dmin is not None and dmax is not None:
        if dmin < 100 or dmax > 1500:  # check if outside reasonable slope band
            inconsistent_depth.append(d)

print(f"Depth inconsistency count: {len(inconsistent_depth)}")
if inconsistent_depth:
    print(f"Sample inconsistent: {inconsistent_depth[:3]}")

# Area stats from properties
areas = [p.get("area_km2") for p in depth_values if p.get("area_km2") is not None]
if areas:
    print(f"\nArea stats (from properties km2):")
    print(f"  Total area: {sum(areas):.2f} km2")
    print(f"  Min area: {min(areas):.2f} km2")
    print(f"  Max area: {max(areas):.2f} km2")
    print(f"  Mean area: {sum(areas)/len(areas):.2f} km2")
