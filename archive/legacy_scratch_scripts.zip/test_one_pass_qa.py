import ee
import time

ee.Initialize(project='seca-513505')

aoiFC = ee.FeatureCollection("projects/seca-513505/assets/AOI_WPP573_MASTER")
bbox = ee.Geometry.Rectangle([102.50, -14.00, 126.50, -6.80])
inAoi = ee.Image.constant(1).clip(aoiFC).rename('domain')

start, end = '2024-04-01', '2024-05-01'

# 1. SST
sst_raw = ee.ImageCollection('NOAA/CDR/OISST/V2_1').filterDate(start, end).filterBounds(bbox).select('sst')
sst_img = sst_raw.mean().multiply(0.01).rename('sst_mean_c')

# 2. CHLA
modisRaw = ee.ImageCollection('NASA/OCEANDATA/MODIS-Aqua/L3SMI').filterDate(start, end).filterBounds(bbox).select('chlor_a')
chla_img = modisRaw.mean().rename('chla_mg_m3')

# 3. CFSV2
cfs_raw = ee.ImageCollection('NOAA/CFSV2/FOR6H_HARMONIZED').filterDate(start, end).filterBounds(bbox)
u = cfs_raw.select('u-component_of_wind_height_above_ground').mean()
v = cfs_raw.select('v-component_of_wind_height_above_ground').mean()
wind = u.hypot(v).rename('wind_speed_mean_m_s')
stress = wind.multiply(0.001).rename('wind_stress_tau_mag')
ekman = wind.multiply(0.0001).rename('ekman_w_e_m_s')

# 4. HYCOM
hycom_raw = ee.ImageCollection('HYCOM/sea_water_velocity').filterDate(start, end).filterBounds(bbox)
curr = hycom_raw.select('velocity_u_0').mean().multiply(0.001).rename('current_speed_m_s')

# 5. ETOPO1
etopo = ee.Image('NOAA/NGDC/ETOPO1').select('bedrock')
depth = etopo.multiply(-1.0).updateMask(etopo.lt(0)).rename('depth_m')

# 6. Front
KX = ee.Kernel.fixed(3, 3, [[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]])
KY = ee.Kernel.fixed(3, 3, [[-1, -2, -1], [0, 0, 0], [1, 2, 1]])
front_dx = sst_img.convolve(KX)
front_dy = sst_img.convolve(KY)
front = front_dx.hypot(front_dy).rename('sst_gradient_deg_km')

bands_to_test = ['sst_mean_c', 'chla_mg_m3', 'wind_speed_mean_m_s', 'wind_stress_tau_mag', 'current_speed_m_s', 'sst_gradient_deg_km', 'ekman_w_e_m_s', 'depth_m']
composite = sst_img.addBands([chla_img, wind, stress, ekman, curr, depth, front]).updateMask(inAoi)

valid_masks = composite.select(bands_to_test).mask()
stack = inAoi.addBands(valid_masks)

t0 = time.time()
print("Executing ONE single reduceRegion pass for ALL 8 variables...")
sums = stack.reduceRegion(
    reducer=ee.Reducer.sum(),
    geometry=bbox,
    scale=20000,
    maxPixels=1e10,
    tileScale=8
).getInfo()
print(f"ONE-PASS REDUCTION SUCCEEDED in {time.time()-t0:.2f}s!")
print(sums)

