# -*- coding: utf-8 -*-
"""
Acquisition script for Official WPPNRI 573 Boundary from BIG MapServer Layer 21.
"""
import urllib.request
import urllib.parse
import json
import ssl
import sys
import os

WORKSPACE = r"C:\Users\ThinkPad\.gemini\antigravity\scratch\prigi-pelagis"
BASE_URL = "https://kspservices.big.go.id/satupeta/rest/services/PUBLIK/SUMBER_DAYA_ALAM_DAN_LINGKUNGAN/MapServer/21"

ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

def query_attribute_list():
    params = {
        "where": "namobj LIKE '%573%' OR kodwpp LIKE '%573%'",
        "outFields": "objectid,namobj,perairan,ruleid_ksp,fcode,metadata,kodwpp,remark,srs_id",
        "returnGeometry": "false",
        "f": "json"
    }
    url = f"{BASE_URL}/query?{urllib.parse.urlencode(params)}"
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, context=ctx, timeout=30) as resp:
        return json.loads(resp.read().decode("utf-8"))

if __name__ == "__main__":
    res = query_attribute_list()
    print("Query result:")
    print(json.dumps(res, indent=2))

