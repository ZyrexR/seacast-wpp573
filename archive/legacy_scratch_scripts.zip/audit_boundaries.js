const fs = require('fs');
const prigiDir = 'C:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis';

const bigGeoPath = prigiDir + '/data/boundaries/wppnri_573_big.geojson';
const webGeoPath = prigiDir + '/data/boundaries/wppnri_573_web.geojson';

const statBig = fs.statSync(bigGeoPath);
const statWeb = fs.statSync(webGeoPath);

console.log(`BIG GeoJSON size: ${(statBig.size / (1024*1024)).toFixed(2)} MB`);
console.log(`Web GeoJSON size: ${(statWeb.size / 1024).toFixed(2)} KB`);

// Read web GeoJSON
const webGeo = JSON.parse(fs.readFileSync(webGeoPath, 'utf8'));
console.log('Web GeoJSON type:', webGeo.type);
console.log('Features count:', webGeo.features ? webGeo.features.length : 0);
if (webGeo.features && webGeo.features[0]) {
  console.log('Properties:', webGeo.features[0].properties);
  console.log('Geometry type:', webGeo.features[0].geometry.type);
  const coords = webGeo.features[0].geometry.coordinates;
  console.log('Polygon rings / parts:', coords.length);
}

// Read head of big GeoJSON
const bigStream = fs.createReadStream(bigGeoPath, { start: 0, end: 1000 });
bigStream.on('data', chunk => {
  console.log('\n--- BIG GEOJSON HEAD ---');
  console.log(chunk.toString('utf8'));
});
