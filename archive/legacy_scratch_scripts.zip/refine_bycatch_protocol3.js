// Refine dynamic_bycatch_mitigation_zones.geojson to embed Protocol 3 clauses
const fs = require('fs');
const path = require('path');

const prigiDir = 'C:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis';
const bcPath = path.join(prigiDir, 'outputs/sdm/zones/dynamic_bycatch_mitigation_zones.geojson');
const bcData = JSON.parse(fs.readFileSync(bcPath, 'utf8'));

bcData.metadata = {
  layer_official_name: 'Candidate Bathymetric Screening Polygons for Voluntary Shark Bycatch Review',
  total_polygons: 123,
  status: 'Candidate Bathymetric Screening Instrument (Exploratory / Non-Regulated / Non-Hotspot)',
  depth_range_criteria: '150 - 1200 m (Continental Slope Bathymetric Screening)',
  thermocline_definition: 'Vertical thermal gradient / subsurface thermocline interaction (separated from surface upwelling indicators)',
  upwelling_indicator: 'Coastal-Offshore SST Contrast Index (Delta T_c-o) and Ekman cross-shore divergence',
  cites_compliance_scope: 'Strictly applied to species listed in CITES Appendix II (e.g. Carcharhinus falciformis, C. longimanus); not generalized to all shark taxa',
  scientific_caveat: 'Polygons are NOT shark distribution maps, NOT verified bycatch hotspots, NOT validated critical habitats, and NOT no-take zones. Until empirical bycatch data with species, time, location, gear, and fishing effort is available, all 123 polygons maintain status as candidate bathymetric screening polygons.'
};

bcData.features.forEach(f => {
  f.properties.zone_name = 'Candidate Bathymetric Screening Polygons for Voluntary Shark Bycatch Review';
  f.properties.layer_type = 'Candidate Bathymetric Screening Instrument';
  f.properties.target_species = 'Hiu Cucut (Carcharhinus spp. - CITES App II reference)';
  f.properties.mitigation_guidance = 'Pancing Rawai/Ulur: edukasi sukarela circle hooks (16/0-18/0); Pukat Cincin: edukasi non-entangling FADs & safe release berpedoman keselamatan awak. Bukan larangan operasional.';
});

fs.writeFileSync(bcPath, JSON.stringify(bcData, null, 2), 'utf8');
console.log('Successfully updated dynamic_bycatch_mitigation_zones.geojson with complete Protocol 3 metadata.');

// Re-run optimize_sdm_web_bundle.js
require('./optimize_sdm_web_bundle.js');
console.log('Successfully regenerated html/sdm_data.js');
