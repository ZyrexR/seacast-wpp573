import ee

ee.Initialize(project="seca-513505")

aoi_fc = ee.FeatureCollection("projects/seca-513505/assets/AOI_WPP573_MASTER")
raw_geom = aoi_fc.first().geometry()
geoms = raw_geom.geometries()
polys = geoms.map(lambda g: ee.Algorithms.If(ee.Geometry(g).type().equals("Polygon"), g, None)).removeAll([None])
poly_coords = polys.map(lambda p: ee.Geometry(p).coordinates())
clean_multipoly = ee.Geometry.MultiPolygon(poly_coords)

grid_fc = ee.FeatureCollection("projects/seca-513505/assets/GRID_010_REGIONAL_8129")
sample_cells = grid_fc.sort("cell_id").limit(10)

def check_sample(f):
    inter_area = f.geometry().intersection(clean_multipoly, 10).area(10).divide(1e6)
    cell_area = f.geometry().area(10).divide(1e6)
    frac = inter_area.divide(cell_area)
    prop_val = ee.Number(ee.Algorithms.If(f.get("aoi_fract"), f.get("aoi_fract"), 0))
    return f.set("_diff", frac.subtract(prop_val).abs())

max_diff = sample_cells.map(check_sample).aggregate_max("_diff").getInfo()
print("Max diff on 10 sample cells using geodesic area:", max_diff)

