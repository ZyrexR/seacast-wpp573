const fs = require('fs');
const path = require('path');

const prigiDir = 'C:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis';

function walk(dir) {
  let results = [];
  const list = fs.readdirSync(dir);
  list.forEach(file => {
    const fullPath = path.join(dir, file);
    const stat = fs.statSync(fullPath);
    if (stat && stat.isDirectory()) {
      results = results.concat(walk(fullPath));
    } else {
      results.push({
        fullPath,
        relPath: path.relative(prigiDir, fullPath).replace(/\\/g, '/'),
        size: stat.size,
        mtime: stat.mtime.toISOString()
      });
    }
  });
  return results;
}

const allFiles = walk(prigiDir);
console.log('Total files found in workspace:', allFiles.length);

const byExt = {};
allFiles.forEach(f => {
  const ext = path.extname(f.relPath).toLowerCase() || '(no-ext)';
  byExt[ext] = (byExt[ext] || 0) + 1;
});
console.log('Extensions:', byExt);

const byTopDir = {};
allFiles.forEach(f => {
  const top = f.relPath.split('/')[0];
  byTopDir[top] = (byTopDir[top] || 0) + 1;
});
console.log('Top level folders:', byTopDir);

// Check root files
const rootFiles = allFiles.filter(f => !f.relPath.includes('/'));
console.log('\nRoot files:');
rootFiles.forEach(f => console.log(` - ${f.relPath} (${f.size} bytes)`));
