import json
import math
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(r"c:\Users\ThinkPad\.gemini\antigravity\scratch\prigi-pelagis")
ZONES_DIR = ROOT / "outputs" / "sdm" / "zones"

AOI_WEST = 111.00
AOI_EAST = 113.00
AOI_SOUTH = -10.45
AOI_NORTH = -8.00
EPS = 1e-9

# WGS84 ellipsoid constants for EPSG:6933 equal-area calculation
a_wgs = 6378137.0
f_wgs = 1.0 / 298.257223563
b_wgs = a_wgs * (1.0 - f_wgs)
e2_wgs = 2.0 * f_wgs - f_wgs * f_wgs
e_wgs = math.sqrt(e2_wgs)

def authalic_box_area_km2(lon1, lon2, lat1, lat2):
    if lon2 <= lon1 or lat2 <= lat1:
        return 0.0
    def S(phi):
        s = math.sin(phi)
        t1 = s / (2.0 * (1.0 - e2_wgs * s * s))
        t2 = (1.0 / (4.0 * e_wgs)) * math.log((1.0 + e_wgs * s) / (1.0 - e_wgs * s))
        return 2.0 * math.pi * (b_wgs ** 2) * (t1 + t2)
    d_lam = abs(math.radians(lon2) - math.radians(lon1))
    return (d_lam / (2.0 * math.pi)) * abs(S(math.radians(lat2)) - S(math.radians(lat1))) / 1e6

def segments_properly_intersect(p1, p2, p3, p4):
    def ccw(A, B, C):
        return (C[1] - A[1]) * (B[0] - A[0]) - (B[1] - A[1]) * (C[0] - A[0])
    d1 = ccw(p3, p4, p1)
    d2 = ccw(p3, p4, p2)
    d3 = ccw(p1, p2, p3)
    d4 = ccw(p1, p2, p4)
    if ((d1 > EPS and d2 < -EPS) or (d1 < -EPS and d2 > EPS)) and ((d3 > EPS and d4 < -EPS) or (d3 < -EPS and d4 > EPS)):
        return True
    return False

def validate_polygon_ring(ring):
    if len(ring) < 4:
        return False, "fewer_than_4_vertices", None
    if ring[0] != ring[-1]:
        return False, "ring_not_closed", None
    # Signed planar area
    n = len(ring) - 1
    signed_area = 0.0
    for i in range(n):
        x1, y1 = ring[i]
        x2, y2 = ring[i + 1]
        signed_area += (x1 * y2 - x2 * y1)
    signed_area *= 0.5
    if abs(signed_area) <= 1e-12:
        return False, "zero_or_degenerate_area", None
    # Non-adjacent segment self-intersection check
    segs = [(ring[i], ring[i + 1]) for i in range(n)]
    for i in range(n):
        for j in range(i + 2, n):
            if i == 0 and j == n - 1:
                continue
            if segments_properly_intersect(segs[i][0], segs[i][1], segs[j][0], segs[j][1]):
                return False, "self_intersection", None
    lons = [p[0] for p in ring[:-1]]
    lats = [p[1] for p in ring[:-1]]
    bbox = (min(lons), max(lons), min(lats), max(lats))
    return True, "valid", bbox

def bbox_overlap_area_km2(b1, b2):
    w = max(b1[0], b2[0])
    e = min(b1[1], b2[1])
    s = max(b1[2], b2[2])
    n = min(b1[3], b2[3])
    if e - w <= EPS or n - s <= EPS:
        return 0.0
    return authalic_box_area_km2(w, e, s, n)

def bbox_difference_outside_aoi_km2(b):
    total_a = authalic_box_area_km2(b[0], b[1], b[2], b[3])
    inside_a = bbox_overlap_area_km2(b, (AOI_WEST, AOI_EAST, AOI_SOUTH, AOI_NORTH))
    return max(0.0, round(total_a - inside_a, 8))

GEOJSON_FILES = [
    "functional_ecological_zones.geojson",
    "functional_zones_cakalang.geojson",
    "functional_zones_madidihang.geojson",
    "functional_zones_albakor.geojson",
    "dynamic_bycatch_mitigation_zones.geojson",
]

layer_cells = {}
results = {
    "validation_timestamp": datetime.now(timezone.utc).isoformat(),
    "canonical_aoi_bounds": {
        "west": AOI_WEST,
        "east": AOI_EAST,
        "south": AOI_SOUTH,
        "north": AOI_NORTH,
        "sub_aoi_exact_epsg6933_area_km2": round(authalic_box_area_km2(AOI_WEST, AOI_EAST, AOI_SOUTH, AOI_NORTH), 2),
        "wppnri_573_nominal_reference_area_km2": 1423238.0,
        "sub_aoi_pct_of_nominal_wpp573": 4.1842,
        "wppnri_573_big_polygon_epsg6933_area_km2": 933749.49,
        "sub_aoi_pct_of_big_polygon_wpp573": 6.3776
    },
    "layers": {},
    "cross_layer_overlap_matrix": {},
    "background_points_validation": {},
    "overall_status": "PASS"
}

for fname in GEOJSON_FILES:
    fpath = ZONES_DIR / fname
    data = json.loads(fpath.read_text(encoding="utf-8"))
    features = data.get("features", [])

    invalid_geoms = 0
    self_intersections = 0
    unclosed_rings = 0
    outside_aoi_polygons = 0
    total_area_outside_aoi_km2 = 0.0
    duplicate_geometries = 0
    within_layer_interior_overlaps = 0
    boundary_clipped_count = 0
    total_area_km2 = 0.0

    seen_bboxes = {}
    bboxes_list = []
    cell_bbox_map = {}

    for idx, feat in enumerate(features):
        geom = feat.get("geometry", {})
        if geom.get("type") != "Polygon":
            invalid_geoms += 1
            continue
        coords = geom.get("coordinates", [])
        if not coords:
            invalid_geoms += 1
            continue
        ring = coords[0]
        ok, reason, bbox = validate_polygon_ring(ring)
        if not ok:
            invalid_geoms += 1
            if reason == "self_intersection":
                self_intersections += 1
            elif reason == "ring_not_closed":
                unclosed_rings += 1
            continue

        # Check within(AOI) and difference(AOI)
        diff_km2 = bbox_difference_outside_aoi_km2(bbox)
        if (
            bbox[0] < AOI_WEST - EPS
            or bbox[1] > AOI_EAST + EPS
            or bbox[2] < AOI_SOUTH - EPS
            or bbox[3] > AOI_NORTH + EPS
            or diff_km2 > 1e-6
        ):
            outside_aoi_polygons += 1
            total_area_outside_aoi_km2 += diff_km2

        bbox_key = tuple(round(v, 6) for v in bbox)
        if bbox_key in seen_bboxes:
            duplicate_geometries += 1
        else:
            seen_bboxes[bbox_key] = feat["properties"].get("cell_id", idx)

        poly_area = authalic_box_area_km2(*bbox)
        total_area_km2 += poly_area
        if feat.get("properties", {}).get("clipped_to_aoi_boundary", False):
            boundary_clipped_count += 1

        bboxes_list.append(bbox)
        cid = feat.get("properties", {}).get("cell_id", idx)
        cell_bbox_map[cid] = bbox

    # Check within-layer interior overlaps (O(N^2) over rectangular clipped cells)
    n_b = len(bboxes_list)
    for i in range(n_b):
        b1 = bboxes_list[i]
        for j in range(i + 1, n_b):
            b2 = bboxes_list[j]
            if b1[1] <= b2[0] + EPS or b2[1] <= b1[0] + EPS or b1[3] <= b2[2] + EPS or b2[3] <= b1[2] + EPS:
                continue
            ov = bbox_overlap_area_km2(b1, b2)
            if ov > 1e-6:
                within_layer_interior_overlaps += 1

    layer_cells[fname] = cell_bbox_map

    layer_pass = (
        invalid_geoms == 0
        and self_intersections == 0
        and unclosed_rings == 0
        and outside_aoi_polygons == 0
        and total_area_outside_aoi_km2 == 0.0
        and duplicate_geometries == 0
        and within_layer_interior_overlaps == 0
    )
    if not layer_pass:
        results["overall_status"] = "FAIL"

    results["layers"][fname] = {
        "feature_count": len(features),
        "valid_polygons": len(features) - invalid_geoms,
        "invalid_geometries": invalid_geoms,
        "self_intersections": self_intersections,
        "unclosed_rings": unclosed_rings,
        "duplicate_geometries": duplicate_geometries,
        "within_layer_interior_overlaps": within_layer_interior_overlaps,
        "polygons_outside_aoi": outside_aoi_polygons,
        "difference_area_outside_aoi_km2": round(total_area_outside_aoi_km2, 6),
        "within_aoi_verified": outside_aoi_polygons == 0 and total_area_outside_aoi_km2 == 0.0,
        "boundary_clipped_polygons": boundary_clipped_count,
        "total_area_epsg6933_km2": round(total_area_km2, 2),
        "status": "PASS" if layer_pass else "FAIL"
    }

# Compute cross-layer overlap matrix (distinct from within-layer topology)
for i, f1 in enumerate(GEOJSON_FILES):
    results["cross_layer_overlap_matrix"][f1] = {}
    map1 = layer_cells[f1]
    for j, f2 in enumerate(GEOJSON_FILES):
        if i == j:
            continue
        map2 = layer_cells[f2]
        shared_cids = set(map1.keys()).intersection(set(map2.keys()))
        shared_area = sum(authalic_box_area_km2(*map1[cid]) for cid in shared_cids)
        results["cross_layer_overlap_matrix"][f1][f2] = {
            "shared_cells_count": len(shared_cids),
            "shared_area_epsg6933_km2": round(shared_area, 2),
            "overlap_type": (
                "Identical alias layer (functional_ecological_zones == Cakalang primary layer)"
                if {f1, f2} == {"functional_ecological_zones.geojson", "functional_zones_cakalang.geojson"}
                else "Multi-layer ecological/bathymetric co-occurrence (Valid Cross-Layer Overlay)"
            )
        }

# Validate background points
bg_path = ROOT / "data" / "sdm" / "background" / "target_group_background.geojson"
bg_data = json.loads(bg_path.read_text(encoding="utf-8"))
bg_feats = bg_data["features"]
bg_out = 0
bg_bound = 0
for f in bg_feats:
    lon, lat = f["geometry"]["coordinates"]
    if not (AOI_WEST <= lon <= AOI_EAST and AOI_SOUTH <= lat <= AOI_NORTH):
        bg_out += 1
    if abs(lon - AOI_WEST) < EPS or abs(lon - AOI_EAST) < EPS or abs(lat - AOI_SOUTH) < EPS or abs(lat - AOI_NORTH) < EPS:
        bg_bound += 1

results["background_points_validation"] = {
    "file": "data/sdm/background/target_group_background.geojson",
    "total_points": len(bg_feats),
    "points_outside_aoi": bg_out,
    "points_on_aoi_boundary_pre_patch": 93,
    "points_on_aoi_boundary_post_patch": bg_bound,
    "status": "PASS" if (len(bg_feats) == 5000 and bg_out == 0 and bg_bound == 0) else "FAIL"
}
if results["background_points_validation"]["status"] != "PASS":
    results["overall_status"] = "FAIL"

out_json = ROOT / "scratch" / "polygon_geometry_validation_results.json"
out_json.write_text(json.dumps(results, indent=2), encoding="utf-8")
print(json.dumps(results, indent=2))
