const fs = require('fs');
const prigiDir = 'C:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis';
const utils = fs.readFileSync(prigiDir + '/utils.py', 'utf8');
const gmIdx = utils.indexOf('def get_master');
console.log(utils.substring(gmIdx, gmIdx + 800));
