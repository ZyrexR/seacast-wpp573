const fs = require('fs');
const prigiDir = 'C:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis';
const ocean132 = JSON.parse(fs.readFileSync(prigiDir + '/data/oceanographic/statistics/monthly/ocean_fisheries_master_132m.json', 'utf8'));
const sumJson = ocean132.reduce((acc, r) => acc + r.total_pelagis_kg, 0);
console.log('JSON sum total_pelagis_kg:', sumJson);

const csv = fs.readFileSync(prigiDir + '/data/master_prigi_all_inclusive.csv', 'utf8').trim().split('\n');
const header = csv[0].split(',');
const idx = header.indexOf('total_pelagis_kg');
let sumCsv = 0;
for (let i = 1; i < csv.length; i++) {
  sumCsv += parseFloat(csv[i].split(',')[idx]) || 0;
}
console.log('CSV sum total_pelagis_kg:', sumCsv);
console.log('Difference:', sumCsv - sumJson);
