var fs = require('fs');
var code = fs.readFileSync('gee/SEACAST_PRIGI_GEE_PRODUCTION_2015_2025_v2_3_2.js', 'utf8');
var lines = code.split('\n');
var es6 = [/\bconst\b/, /\blet\b/, /=>/, /`/, /\bMath\.sign\b/];
var hits = [];
lines.forEach(function(l, i) {
  var t = l.trim();
  if (t.indexOf('//') === 0 || t.indexOf('*') === 0) return;
  es6.forEach(function(p) {
    if (p.test(l)) hits.push((i + 1) + ': ' + l);
  });
});
console.log('Hits: ' + hits.length);
hits.forEach(function(h) { console.log(h); });

