const fs = require('fs');
const prigiDir = 'C:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis';

console.log('--- data_sources.json ---');
console.log(fs.readFileSync(prigiDir + '/data/oceanographic/metadata/data_sources.json', 'utf8'));

console.log('--- processing_manifest.json ---');
console.log(fs.readFileSync(prigiDir + '/data/manifests/processing_manifest.json', 'utf8'));
