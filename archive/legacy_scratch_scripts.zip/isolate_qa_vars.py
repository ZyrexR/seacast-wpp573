import ee
import time

ee.Initialize(project='seca-513505')

MASTER_AOI = "projects/seca-513505/assets/AOI_WPP573_MASTER"
aoiFC = ee.FeatureCollection(MASTER_AOI)
bbox = ee.Geometry.Rectangle([102.50, -14.00, 126.50, -6.80])
inAoi = ee.Image.constant(1).clip(aoiFC).rename('aoi')

start, end = '2024-04-01', '2024-05-01'

# 1. SST
sst_raw = ee.ImageCollection('NOAA/CDR/OISST/V2_1').filterDate(start, end).filterBounds(bbox).select('sst')
proj_sst = sst_raw.first().projection()
sst_coll = sst_raw.map(lambda img: img.multiply(0.01).updateMask(img.multiply(0.01).gte(-3.0).And(img.multiply(0.01).lte(45.0))))
sst_img = sst_coll.mean().rename('sst_mean_c').setDefaultProjection(proj_sst)

# 2. CHLA
modisRaw = ee.ImageCollection('NASA/OCEANDATA/MODIS-Aqua/L3SMI').filterDate(start, end).filterBounds(bbox).select('chlor_a')
gcomRaw = ee.ImageCollection('JAXA/GCOM-C/L3/OCEAN/CHLA/V3').filterDate(start, end).filterBounds(bbox).select('CHLA_AVE')
target = modisRaw.first().projection()
modis = modisRaw.map(lambda img: img.updateMask(img.gte(0.01).And(img.lte(100.0))))
modisCount = modis.count().rename('modis_valid_count').setDefaultProjection(target)
modisMean = modis.mean().rename('modis_mean').setDefaultProjection(target)
modisValid = modisCount.gt(0).And(modisMean.mask()).rename('modis_valid')

gProj = gcomRaw.first().projection()
gcom = gcomRaw.map(lambda img: img.multiply(0.0016).updateMask(img.multiply(0.0016).gte(0.01).And(img.multiply(0.0016).lte(100.0))))
gcomCount = gcom.count().rename('gcom_valid_count').setDefaultProjection(gProj).reproject(target)
gcomMean = gcom.mean().rename('gcom_mean').setDefaultProjection(gProj).reproject(target)
gcomValid = gcomCount.gt(0).And(gcomMean.mask()).rename('gcom_valid')
fallback = gcomValid.And(modisValid.Not())

value = ee.ImageCollection([
    gcomMean.rename('chla_mg_m3').toFloat().updateMask(gcomValid),
    modisMean.rename('chla_mg_m3').toFloat().updateMask(modisValid)
]).mosaic().rename('chla_mg_m3').reproject(target)

modisFlag = modisValid.rename('chla_modis_flag').reproject(target)
gcomFlag = fallback.rename('chla_gcom_fallback_flag').reproject(target)
validAny = modisValid.Or(gcomValid).rename('chla_valid_flag').reproject(target)
logv = value.updateMask(value.gt(0)).log10().rename('chla_log10')
chla_img = value.addBands([modisCount, gcomCount.reproject(target), modisFlag, gcomFlag, validAny, logv])

# 3. CFSV2
cfs_raw = ee.ImageCollection('NOAA/CFSV2/FOR6H_HARMONIZED').filterDate(start, end).filterBounds(bbox)
cfs_proj = cfs_raw.first().projection()
u = cfs_raw.select('u-component_of_wind_height_above_ground').mean().rename('wind_u_m_s')
v = cfs_raw.select('v-component_of_wind_height_above_ground').mean().rename('wind_v_m_s')
wind = u.hypot(v).rename('wind_speed_mean_m_s').setDefaultProjection(cfs_proj)
stress = wind.multiply(0.001).rename('wind_stress_tau_mag').setDefaultProjection(cfs_proj)
ekman = wind.multiply(0.0001).rename('ekman_w_e_m_s').setDefaultProjection(cfs_proj)

# 4. HYCOM
hycom_raw = ee.ImageCollection('HYCOM/sea_water_velocity').filterDate(start, end).filterBounds(bbox)
hycom_proj = hycom_raw.first().projection()
curr_u = hycom_raw.select('velocity_u_0').mean().multiply(0.001)
curr_v = hycom_raw.select('velocity_v_0').mean().multiply(0.001)
current_img = curr_u.hypot(curr_v).rename('current_speed_m_s').setDefaultProjection(hycom_proj)

# 5. ETOPO1
etopo = ee.Image('NOAA/NGDC/ETOPO1').select('bedrock')
bathy_proj = etopo.projection()
depth = etopo.multiply(-1.0).updateMask(etopo.lt(0)).rename('depth_m')

# 6. Front
KX = ee.Kernel.fixed(3, 3, [[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]])
KY = ee.Kernel.fixed(3, 3, [[-1, -2, -1], [0, 0, 0], [1, 2, 1]])
front_dx = sst_img.select('sst_mean_c').convolve(KX).rename('sst_dTdx_c_km')
front_dy = sst_img.select('sst_mean_c').convolve(KY).rename('sst_dTdy_c_km')
front = front_dx.hypot(front_dy).rename('sst_gradient_deg_km')

specs = [
    ('sst', sst_img, 'sst_mean_c', proj_sst, 25000),
    ('chla', chla_img, 'chla_mg_m3', target, 4638),
    ('wind', wind, 'wind_speed_mean_m_s', cfs_proj, 23191),
    ('stress', stress, 'wind_stress_tau_mag', cfs_proj, 23191),
    ('current', current_img, 'current_speed_m_s', hycom_proj, 9276),
    ('front', front, 'sst_gradient_deg_km', proj_sst, 25000),
    ('ekman', ekman, 'ekman_w_e_m_s', cfs_proj, 23191),
    ('bathy', depth, 'depth_m', bathy_proj, 10000)
]

for name, img, band, proj, scale in specs:
    t0 = time.time()
    try:
        stack = inAoi.rename('domain').addBands(img.select(band).mask().rename('valid'))
        sums = stack.reduceRegion(
            reducer=ee.Reducer.sum(),
            geometry=bbox,
            crs=proj,
            scale=scale,
            maxPixels=1e10,
            tileScale=8
        ).getInfo()
        print(f"Var {name} SUCCEEDED in {time.time()-t0:.2f}s: {sums}")
    except Exception as e:
        print(f"Var {name} FAILED in {time.time()-t0:.2f}s: {e}")

