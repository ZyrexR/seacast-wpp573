import ee

ee.Initialize(project="seca-513505")
gridFC = ee.FeatureCollection("projects/seca-513505/assets/GRID_010_REGIONAL_8129")
sample = gridFC.limit(10)


def check_cell_area(f):
  geom_area = f.geometry().area(1).divide(1e6)
  prop_area = ee.Number(f.get("cell_km2"))
  diff = geom_area.subtract(prop_area).abs()
  return f.set("_area_diff", diff)


max_diff = sample.map(check_cell_area).aggregate_max("_area_diff").getInfo()
print("Max area diff on sample cells:", max_diff)

