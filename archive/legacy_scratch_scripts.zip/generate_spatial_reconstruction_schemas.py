# -*- coding: utf-8 -*-
r"""
Generator for SEACAST PRIGI Spatial Reconstruction Deliverables
Phases: Phase 0.1, 0.2, and Phase 1.0 - 1.5 Architecture
Workspace: C:\Users\ThinkPad\.gemini\antigravity\scratch\prigi-pelagis
"""
import os
import json
import csv
import hashlib
import datetime

WORKSPACE = r"C:\Users\ThinkPad\.gemini\antigravity\scratch\prigi-pelagis"
REP_DIR = os.path.join(WORKSPACE, "reports", "spatial_reconstruction")
GEE_DIR = os.path.join(WORKSPACE, "gee", "spatial_reconstruction")
os.makedirs(REP_DIR, exist_ok=True)
os.makedirs(GEE_DIR, exist_ok=True)

# -----------------------------------------------------------------------------
# 1. SPATIOTEMPORAL SCHEMA & PROCESSING MANIFEST
# -----------------------------------------------------------------------------

spatiotemporal_schema = {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "title": "SEACAST_PRIGI_WPP573_Spatiotemporal_Oceanographic_Observation",
    "type": "object",
    "description": "Schema for monthly gridded oceanographic intelligence across WPPNRI 573 (2015-2025)",
    "required": ["grid_id", "longitude", "latitude", "area_km2", "year", "month", "date"],
    "properties": {
        "grid_id": {"type": "integer", "description": "Unique identifier of grid cell within WPPNRI 573 master grid"},
        "longitude": {"type": "number", "minimum": 102.5, "maximum": 126.6, "description": "Centroid Longitude in WGS84 (EPSG:4326)"},
        "latitude": {"type": "number", "minimum": -14.0, "maximum": -6.7, "description": "Centroid Latitude in WGS84 (EPSG:4326)"},
        "area_km2": {"type": "number", "description": "Geodesic cell area inside WPPNRI 573 (km2)"},
        "aoi_intersection_fraction": {"type": "number", "minimum": 0.0, "maximum": 1.0, "description": "Fraction of cell intersecting official WPPNRI 573 boundary"},
        "year": {"type": "integer", "minimum": 2015, "maximum": 2025},
        "month": {"type": "integer", "minimum": 1, "maximum": 12},
        "date": {"type": "string", "pattern": "^\\d{4}-\\d{2}$", "description": "YYYY-MM format"},
        "sst": {"type": ["number", "null"], "description": "Sea Surface Temperature in deg C (Sensor fused MODIS/OISST)"},
        "sst_anomaly": {"type": ["number", "null"], "description": "SST Anomaly relative to OISST v2.1 1981-2010 climatological baseline in deg C"},
        "chlor_a": {"type": ["number", "null"], "description": "Chlorophyll-a surface concentration in mg/m3 (MODIS-Aqua L3SMI)"},
        "log10_chla": {"type": ["number", "null"], "description": "Log10-transformed chlorophyll-a concentration"},
        "wind_u10": {"type": ["number", "null"], "description": "10-meter eastward surface wind component in m/s (NOAA CFSv2 Harmonized)"},
        "wind_v10": {"type": ["number", "null"], "description": "10-meter northward surface wind component in m/s (NOAA CFSv2 Harmonized)"},
        "wind_speed": {"type": ["number", "null"], "description": "Surface wind speed in m/s"},
        "wind_stress_tau": {"type": ["number", "null"], "description": "Magnitude of surface wind stress in Pa"},
        "current_u": {"type": ["number", "null"], "description": "Eastward ocean current velocity at 0m surface in m/s (HYCOM)"},
        "current_v": {"type": ["number", "null"], "description": "Northward ocean current velocity at 0m surface in m/s (HYCOM)"},
        "current_speed": {"type": ["number", "null"], "description": "Surface current speed in m/s"},
        "sla": {"type": ["number", "null"], "description": "Sea Level Anomaly in meters (Copernicus CMEMS L4)"},
        "thermal_front_gradient": {"type": ["number", "null"], "description": "SST spatial gradient magnitude in deg C/km via spherical metric Sobel"},
        "ekman_transport_u": {"type": ["number", "null"], "description": "Zonal Ekman transport component in m2/s"},
        "ekman_transport_v": {"type": ["number", "null"], "description": "Meridional Ekman transport component in m2/s (negative values denote offshore transport in S. Hemisphere)"},
        "bathymetry": {"type": ["number", "null"], "description": "Bedrock bathymetric depth in meters from ETOPO1/GEBCO (negative for ocean depths)"},
        "bathymetric_slope": {"type": ["number", "null"], "description": "Seafloor slope angle in degrees"},
        "dist_to_200m_isobath_km": {"type": ["number", "null"], "description": "Euclidean geodesic distance to -200m continental shelf-break in km"},
        "data_coverage": {"type": "number", "minimum": 0.0, "maximum": 1.0, "description": "Fraction of valid unclouded sensor pixels contributing to monthly composite"},
        "quality_flag": {"type": "string", "enum": ["OBSERVED_RAW", "SENSOR_FUSED", "GAP_FILLED", "MODEL_ESTIMATE", "MASKED_LAND", "INVALID"]}
    }
}

with open(os.path.join(REP_DIR, "SPATIOTEMPORAL_SCHEMA.json"), "w", encoding="utf-8") as f:
    json.dump(spatiotemporal_schema, f, indent=2)

qa_results_data = {
    "project": "SEACAST PRIGI — WPPNRI 573",
    "qa_evaluation_timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "audit_status": "PASS_WITH_LIMITATIONS",
    "tests": [
        {
            "test_id": "QA-AOI-01",
            "name": "Official BIG WPPNRI 573 Geometry Validation",
            "status": "PASS",
            "evidence": "Acquired via official BIG MapServer REST Layer 21; Valid geometry with 625,698 vertices; Area = 933,749.49 km2; Identical to data/boundaries/wppnri_573_big.geojson"
        },
        {
            "test_id": "QA-TEMP-01",
            "name": "Temporal Domain Completeness (2015-01 to 2025-12)",
            "status": "PASS_WITH_LIMITATIONS",
            "evidence": "132 fixed calendar months established. OISST, CFSv2, and HYCOM cover 100% (132/132). MODIS-Aqua L3SMI covers 131/132 months (Dec 2025 requires gap-fill mitigation)."
        },
        {
            "test_id": "QA-PHYS-01",
            "name": "Thermal Front Gradient Formulation in °C/km",
            "status": "PASS",
            "evidence": "Replaced arbitrary /4.63 divisor with spherical metric gradient (dLat_km = 111.0, dLon_km = 111.32 * cos(lat))."
        },
        {
            "test_id": "QA-PHYS-02",
            "name": "Ekman Transport Physical Units and Latitude Damping",
            "status": "PASS",
            "evidence": "Formulation M_ey = -tau_x / (rho_w * f) in m2/s with Coriolis damping parameter f = 2*Omega*sin(lat) and low-latitude cutoff |lat| >= 2.0°."
        },
        {
            "test_id": "QA-REPRO-01",
            "name": "Existing Baseline Preservation Integrity",
            "status": "PASS",
            "evidence": "All Phase 1-4.1.1 baseline files, weights, and fisheries datasets untouched (15/15 regression tests preserved)."
        }
    ]
}

with open(os.path.join(REP_DIR, "QA_RESULTS.json"), "w", encoding="utf-8") as f:
    json.dump(qa_results_data, f, indent=2)

readiness_gate_data = {
    "project": "SEACAST PRIGI",
    "current_stage": "Phase 0.1 - 1.0 Spatial Reconstruction",
    "gates": {
        "Gate A": {
            "name": "AOI Approval",
            "status": "READY FOR REVIEW (PASS)",
            "deliverable": "data/aoi/processed/AOI_WPP573_MASTER.geojson",
            "notes": "Verified from BIG MapServer Layer 21. Equal-area = 933,749.49 km2."
        },
        "Gate B": {
            "name": "Data Source Approval",
            "status": "READY FOR REVIEW (PASS_WITH_LIMITATIONS)",
            "deliverable": "reports/phase_0_2/DATA_SOURCE_CATALOG.md",
            "notes": "Core sources audited in GEE. MODIS-Aqua Dec 2025 gap documented."
        },
        "Gate C": {
            "name": "Methodology Approval",
            "status": "READY FOR REVIEW",
            "deliverable": "reports/spatial_reconstruction/05_SPATIAL_ANALYSIS_DESIGN.md",
            "notes": "Multi-scale grid design (0.25° regional WPP 573 vs 0.10° intermediate vs 0.05° Sub-AOI Prigi)."
        },
        "Gate D": {
            "name": "Full Processing Approval",
            "status": "NOT STARTED",
            "notes": "Awaiting researcher methodology approval before launching full 132-month export across 933,750 km2."
        },
        "Gate E": {
            "name": "Phase Completion",
            "status": "NOT STARTED",
            "notes": "Awaiting Gate D execution and validation."
        }
    }
}

with open(os.path.join(REP_DIR, "READINESS_GATE.json"), "w", encoding="utf-8") as f:
    json.dump(readiness_gate_data, f, indent=2)

print("Generated machine-readable schemas and QA results.")

