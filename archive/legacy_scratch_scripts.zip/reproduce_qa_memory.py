import ee
import time

ee.Initialize(project='seca-513505')

print("Diagnosing exact QA_MODULE.evaluate...")

MASTER_AOI = "projects/seca-513505/assets/AOI_WPP573_MASTER"
CANONICAL_GRID = "projects/seca-513505/assets/GRID_010_REGIONAL_8129"
aoiFC = ee.FeatureCollection(MASTER_AOI)
gridFC = ee.FeatureCollection(CANONICAL_GRID)

rawGeom = aoiFC.first().geometry()
polys = rawGeom.geometries().map(lambda g: ee.Algorithms.If(ee.Geometry(g).type().equals('Polygon'), g, None)).removeAll([None])
polyCoords = polys.map(lambda p: ee.Geometry(p).coordinates())
geom = ee.Geometry(ee.Geometry.MultiPolygon(polyCoords))

bbox = ee.Geometry.Rectangle([102.50, -14.00, 126.50, -6.80])
inAoi = ee.Image.constant(1).clip(aoiFC).rename('aoi')

start, end = '2024-04-01', '2024-05-01'

# 1. SST
sst_raw = ee.ImageCollection('NOAA/CDR/OISST/V2_1').filterDate(start, end).filterBounds(geom).select('sst')
b_sst = sst_raw
proj_sst = sst_raw.first().projection()
sst_coll = sst_raw.map(lambda img: img.multiply(0.01).updateMask(img.multiply(0.01).gte(-3.0).And(img.multiply(0.01).lte(45.0))))
sst_img = sst_coll.mean().rename('sst_mean_c').addBands([
    sst_coll.min().rename('sst_min_c'),
    sst_coll.max().rename('sst_max_c'),
    sst_coll.reduce(ee.Reducer.stdDev()).rename('sst_stddev_c'),
    sst_coll.count().rename('sst_obs_count')
]).setDefaultProjection(proj_sst)

# 2. CHLA
modisRaw = ee.ImageCollection('NASA/OCEANDATA/MODIS-Aqua/L3SMI').filterDate(start, end).filterBounds(geom).select('chlor_a')
gcomRaw = ee.ImageCollection('JAXA/GCOM-C/L3/OCEAN/CHLA/V3').filterDate(start, end).filterBounds(geom).select('CHLA_AVE')
target = modisRaw.first().projection()
modis = modisRaw.map(lambda img: img.updateMask(img.gte(0.01).And(img.lte(100.0))))
modisCount = modis.count().rename('modis_valid_count').setDefaultProjection(target)
modisMean = modis.mean().rename('modis_mean').setDefaultProjection(target)
modisValid = modisCount.gt(0).And(modisMean.mask()).rename('modis_valid')

gProj = gcomRaw.first().projection()
gcom = gcomRaw.map(lambda img: img.multiply(0.0016).updateMask(img.multiply(0.0016).gte(0.01).And(img.multiply(0.0016).lte(100.0))))
gcomCount = gcom.count().rename('gcom_valid_count').setDefaultProjection(gProj).reproject(target)
gcomMean = gcom.mean().rename('gcom_mean').setDefaultProjection(gProj).reproject(target)
gcomValid = gcomCount.gt(0).And(gcomMean.mask()).rename('gcom_valid')
fallback = gcomValid.And(modisValid.Not())

value = ee.ImageCollection([
    gcomMean.rename('chla_mg_m3').toFloat().updateMask(gcomValid),
    modisMean.rename('chla_mg_m3').toFloat().updateMask(modisValid)
]).mosaic().rename('chla_mg_m3').reproject(target)

source = ee.ImageCollection([
    ee.Image.constant(2).toByte().updateMask(fallback),
    ee.Image.constant(1).toByte().updateMask(modisValid)
]).mosaic().unmask(0).rename('chla_source_code').reproject(target)

validAny = modisValid.Or(gcomValid).rename('chla_valid_flag').reproject(target)
modisFlag = modisValid.rename('chla_modis_flag').reproject(target)
gcomFlag = fallback.rename('chla_gcom_fallback_flag').reproject(target)
logv = value.updateMask(value.gt(0)).log10().rename('chla_log10')
chla_img = value.addBands([source, modisCount, gcomCount.reproject(target), modisFlag, gcomFlag, validAny, logv])

# NOTE: CHLOROPHYLL_MODULE summary:
# If summary uses inAoi + bbox:
t0 = time.time()
stk_chla = inAoi.rename('domain').addBands([modisFlag, gcomFlag, validAny])
sums_chla = stk_chla.reduceRegion(reducer=ee.Reducer.sum(), geometry=bbox, crs=target, scale=target.nominalScale(), maxPixels=1e10, tileScale=8)
dom_c = ee.Number(sums_chla.get('domain'))
mp_c = ee.Number(sums_chla.get('chla_modis_flag'))
gp_c = ee.Number(sums_chla.get('chla_gcom_fallback_flag'))
vp_c = ee.Number(sums_chla.get('chla_valid_flag'))
chla_summary = ee.Dictionary({
    'domain_px': dom_c, 'modis_px': mp_c, 'gcom_fallback_px': gp_c, 'valid_px': vp_c,
    'nodata_px': dom_c.subtract(vp_c), 'modis_raw_count': modisRaw.size(), 'gcom_raw_count': gcomRaw.size()
})
print("CHLA summary computed in", time.time() - t0, "s")

# 3. CFSV2
cfs_raw = ee.ImageCollection('NOAA/CFSV2/FOR6H_HARMONIZED').filterDate(start, end).filterBounds(geom)
cfs_proj = cfs_raw.first().projection()
u = cfs_raw.select('u-component_of_wind_height_above_ground').mean().rename('wind_u_m_s')
v = cfs_raw.select('v-component_of_wind_height_above_ground').mean().rename('wind_v_m_s')
wind = u.hypot(v).rename('wind_speed_mean_m_s').setDefaultProjection(cfs_proj)
stress = wind.multiply(0.001).rename('wind_stress_tau_mag').setDefaultProjection(cfs_proj)
ekman = wind.multiply(0.0001).rename('ekman_w_e_m_s').setDefaultProjection(cfs_proj)

# 4. HYCOM
hycom_raw = ee.ImageCollection('HYCOM/sea_water_velocity').filterDate(start, end).filterBounds(geom)
hycom_proj = hycom_raw.first().projection()
curr_u = hycom_raw.select('velocity_u_0').mean().multiply(0.001)
curr_v = hycom_raw.select('velocity_v_0').mean().multiply(0.001)
current_img = curr_u.hypot(curr_v).rename('current_speed_m_s').setDefaultProjection(hycom_proj)

# 5. ETOPO1
etopo = ee.Image('NOAA/NGDC/ETOPO1').select('bedrock')
bathy_proj = etopo.projection()
depth = etopo.multiply(-1.0).updateMask(etopo.lt(0)).rename('depth_m')

# 6. Front
KX = ee.Kernel.fixed(3, 3, [[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]])
KY = ee.Kernel.fixed(3, 3, [[-1, -2, -1], [0, 0, 0], [1, 2, 1]])
front_dx = sst_img.select('sst_mean_c').convolve(KX).rename('sst_dTdx_c_km')
front_dy = sst_img.select('sst_mean_c').convolve(KY).rename('sst_dTdy_c_km')
front = front_dx.hypot(front_dy).rename('sst_gradient_deg_km')

# Test QA variables:
print("Evaluating all QA variables...")
specs = [
    {'key': 'sst', 'img': sst_img, 'band': 'sst_mean_c', 'proj': proj_sst, 'raw': sst_raw.size()},
    {'key': 'chla', 'img': chla_img, 'band': 'chla_mg_m3', 'proj': target, 'raw': modisRaw.size()},
    {'key': 'wind', 'img': wind, 'band': 'wind_speed_mean_m_s', 'proj': cfs_proj, 'raw': cfs_raw.size()},
    {'key': 'stress', 'img': stress, 'band': 'wind_stress_tau_mag', 'proj': cfs_proj, 'raw': cfs_raw.size()},
    {'key': 'current', 'img': current_img, 'band': 'current_speed_m_s', 'proj': hycom_proj, 'raw': hycom_raw.size()},
    {'key': 'front', 'img': front, 'band': 'sst_gradient_deg_km', 'proj': proj_sst, 'raw': sst_raw.size()},
    {'key': 'ekman', 'img': ekman, 'band': 'ekman_w_e_m_s', 'proj': cfs_proj, 'raw': cfs_raw.size()},
    {'key': 'bathy', 'img': depth, 'band': 'depth_m', 'proj': bathy_proj, 'scale': 10000, 'raw': ee.Number(1)}
]

out = {}
statuses = {}
for s in specs:
    t1 = time.time()
    # Mask of the band inside AOI
    # NOTE: In JS, variable passed: domainMask, evalBBox
    stack = inAoi.rename('domain').addBands(s['img'].select(s['band']).mask().rename('valid'))
    sums = stack.reduceRegion(
        reducer=ee.Reducer.sum(),
        geometry=bbox,
        crs=s['proj'],
        scale=s.get('scale', s['proj'].nominalScale()),
        maxPixels=1e10,
        tileScale=8
    )
    dom = ee.Number(sums.get('domain'))
    val = ee.Number(sums.get('valid'))
    cov = ee.Number(ee.Algorithms.If(dom.gt(0), val.divide(dom).min(1.0), 0))
    raw = ee.Number(s['raw'])
    st = ee.String(ee.Algorithms.If(raw.eq(0), 'NO_DATA',
        ee.Algorithms.If(val.eq(0), 'NO_VALID_DATA',
        ee.Algorithms.If(cov.lt(0.3), 'LOW_COVERAGE',
        ee.Algorithms.If(cov.lt(0.7), 'PARTIAL_COVERAGE', 'VALID')))))
    statuses[s['key']] = st
    out[s['key'] + '_coverage'] = cov
    out[s['key'] + '_status'] = st

status_list = ee.List([statuses[k] for k in statuses])
blockedInvalid = ee.Algorithms.If(status_list.contains('NO_VALID_DATA'), True, False)
qualified = ee.Algorithms.If(status_list.contains('PARTIAL_COVERAGE'), True, status_list.contains('MISSING_OPTIONAL'))
verdict = ee.Algorithms.If(status_list.contains('NO_DATA'), 'BLOCKED_MISSING_SOURCE',
    ee.Algorithms.If(blockedInvalid, 'BLOCKED_INVALID_DATA',
    ee.Algorithms.If(status_list.contains('LOW_COVERAGE'), 'BLOCKED_SPATIAL_COVERAGE',
    ee.Algorithms.If(qualified, 'PASS_QUALIFIED_DATA', 'PASS_HIGH_QUALITY'))))

out['scientific_qa_verdict'] = verdict
out['chla_summary'] = chla_summary

t_eval = time.time()
res_qa = ee.Dictionary(out).getInfo()
print(f"COMPLETE QA evaluated in {time.time()-t_eval:.2f}s! Verdict: {res_qa['scientific_qa_verdict']}")

