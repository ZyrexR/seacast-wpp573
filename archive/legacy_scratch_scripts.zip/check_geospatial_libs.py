# -*- coding: utf-8 -*-
for mod in ['shapely', 'geopandas', 'pyproj', 'fiona', 'osgeo']:
    try:
        m = __import__(mod)
        v = getattr(m, '__version__', 'available')
        print(f"{mod}: available ({v})")
    except ImportError:
        print(f"{mod}: NOT available")

