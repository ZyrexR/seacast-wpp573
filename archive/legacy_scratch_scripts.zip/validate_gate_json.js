const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, '..', 'PHASE_4_READINESS_GATE.json');
try {
  const content = fs.readFileSync(filePath, 'utf8');
  const data = JSON.parse(content);
  console.log("JSON parsed successfully!");
  console.log("Document Version:", data.document_version);
  console.log("Readiness Status:", data.readiness_status);
  console.log("Overall Score:", data.overall_score_weighted);
  console.log("Blocking Constraints Count:", data.blocking_constraints.length);
  console.log("Mandatory Protocols:", Object.keys(data.mandatory_protocols));
  console.log("Prohibited Actions Count:", data.prohibited_actions.length);
  console.log("Validation Checks Count:", data.validation_checks.length);
  
  const checkIds = data.validation_checks.map(c => c.id);
  console.log("Check IDs:", checkIds.join(', '));
  
  const validIds = ['PG-01','PG-02','PG-03','PG-04','PG-05','PG-06','PG-07','PG-08','PG-09','PG-10','PG-11','PG-12'];
  const allPresent = validIds.every(id => checkIds.includes(id));
  console.log("All 12 PG checks present:", allPresent);

  const statuses = data.validation_checks.map(c => `${c.id}: ${c.status}`);
  console.log("Statuses:\n", statuses.join('\n'));
} catch (err) {
  console.error("JSON Error:", err);
  process.exit(1);
}
