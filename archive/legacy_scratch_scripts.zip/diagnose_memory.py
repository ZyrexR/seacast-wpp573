import ee
import time

ee.Initialize(project='seca-513505')

aoiFC = ee.FeatureCollection("projects/seca-513505/assets/AOI_WPP573_MASTER")
bbox = ee.Geometry.Rectangle([102.50, -14.00, 126.50, -6.80])
inAoi = ee.Image.constant(1).clip(aoiFC)

start, end = '2024-04-01', '2024-05-01'

modisRaw = ee.ImageCollection('NASA/OCEANDATA/MODIS-Aqua/L3SMI').filterDate(start, end).filterBounds(bbox).select('chlor_a')
gcomRaw = ee.ImageCollection('JAXA/GCOM-C/L3/OCEAN/CHLA/V3').filterDate(start, end).filterBounds(bbox).select('CHLA_AVE')
target = modisRaw.first().projection()

modis = modisRaw.map(lambda img: img.updateMask(img.gte(0.01).And(img.lte(100.0))))
modisCount = modis.count().rename('modis_valid_count').setDefaultProjection(target)
modisMean = modis.mean().rename('modis_mean').setDefaultProjection(target)
modisValid = modisCount.gt(0).And(modisMean.mask()).rename('modis_valid')

gProj = gcomRaw.first().projection()
gcom = gcomRaw.map(lambda img: img.multiply(0.0016).updateMask(img.multiply(0.0016).gte(0.01).And(img.multiply(0.0016).lte(100.0))))
gcomCount = gcom.count().rename('gcom_valid_count').setDefaultProjection(gProj)
gcomMean = gcom.mean().rename('gcom_mean').setDefaultProjection(gProj)
gcomValid = gcomCount.gt(0).And(gcomMean.mask()).rename('gcom_valid')
fallback = gcomValid.And(modisValid.Not())

# Without redundant reprojects on individual flags
modisFlag = modisValid.rename('chla_modis_flag')
gcomFlag = fallback.rename('chla_gcom_fallback_flag')
validAny = modisValid.Or(gcomValid).rename('chla_valid_flag')

# Reduction with inAoi domain mask over bbox (NO 1398-hole polygon!)
t0 = time.time()
stack = inAoi.rename('domain').addBands([modisFlag, gcomFlag, validAny])
sums = stack.reduceRegion(
    reducer=ee.Reducer.sum(),
    geometry=bbox,
    crs=target,
    scale=target.nominalScale(),
    maxPixels=1e10,
    tileScale=8
).getInfo()
print("CHLA summary with inAoi + bbox took", time.time() - t0, "s:", sums)

