const fs = require('fs');
const transcriptPath = 'C:/Users/ThinkPad/.gemini/antigravity/brain/cc088fc0-e16d-416d-8247-15acc089a9e9/.system_generated/logs/transcript.jsonl';

const stream = fs.createReadStream(transcriptPath, { encoding: 'utf8' });
let remaining = '';

stream.on('data', chunk => {
  const lines = (remaining + chunk).split('\n');
  remaining = lines.pop();
  lines.forEach(line => {
    if (line.includes('2378077') || line.includes('2.378.077') || line.includes('1503220')) {
      const obj = JSON.parse(line);
      console.log(`Step ${obj.step_index} (${obj.type}): snippet:`, obj.content ? obj.content.substring(0, 300) : 'no content');
    }
  });
});
stream.on('end', () => console.log('Done searching transcript.'));
