import ee
import time

ee.Initialize(project='seca-513505')

aoiFC = ee.FeatureCollection('projects/seca-513505/assets/AOI_WPP573_MASTER')
gridFC = ee.FeatureCollection('projects/seca-513505/assets/GRID_010_REGIONAL_8129')
bbox = ee.Geometry.Rectangle([105.0, -14.0, 119.0, -7.5])
inAoi = ee.Image.constant(1).clip(aoiFC).rename('aoi')

start, end = '2024-04-01', '2024-05-01'

sst_raw = ee.ImageCollection('NOAA/CDR/OISST/V2_1').filterDate(start, end).filterBounds(bbox).select('sst')
sst_img = sst_raw.mean().multiply(0.01).rename('sst_mean_c').addBands(ee.Image.constant(0.05).rename('sst_gradient_deg_km')).addBands(ee.Image.constant(1).rename('thermal_front_flag'))

modis = ee.ImageCollection('NASA/OCEANDATA/MODIS-Aqua/L3SMI').filterDate(start, end).filterBounds(bbox).select('chlor_a')
chla_img = modis.mean().rename('chla_mg_m3').addBands(ee.Image.constant(1).rename('chla_modis_flag')).addBands(ee.Image.constant(0).rename('chla_gcom_fallback_flag'))

cfs = ee.ImageCollection('NOAA/CFSV2/FOR6H_HARMONIZED').filterDate(start, end).filterBounds(bbox)
u = cfs.select('u-component_of_wind_height_above_ground').mean()
v = cfs.select('v-component_of_wind_height_above_ground').mean()
wind_speed = u.hypot(v).rename('wind_speed_mean_m_s')
tau = wind_speed.multiply(0.001).rename('wind_stress_tau_mag')
ekman = wind_speed.multiply(0.0001).rename('ekman_w_e_m_s')
precip = wind_speed.multiply(0).rename('precip_mm_day')
cfs_img = wind_speed.addBands([tau, ekman, precip])

hycom = ee.ImageCollection('HYCOM/sea_water_velocity').filterDate(start, end).filterBounds(bbox)
hycom_u = hycom.select('velocity_u_0').mean().multiply(0.001)
hycom_v = hycom.select('velocity_v_0').mean().multiply(0.001)
current_img = hycom_u.hypot(hycom_v).rename('current_speed_m_s')

etopo = ee.Image('NOAA/NGDC/ETOPO1').select('bedrock')
bathy_img = etopo.multiply(-1.0).updateMask(etopo.lt(0)).rename('depth_m')

groups = [
    {'name': 'chla', 'img': chla_img, 'bands': ['chla_mg_m3', 'chla_modis_flag', 'chla_gcom_fallback_flag'], 'proj': modis.first().projection(), 'deg': 0.0416},
    {'name': 'current', 'img': current_img, 'bands': ['current_speed_m_s'], 'proj': hycom.first().projection(), 'deg': 0.0833},
    {'name': 'bathy', 'img': bathy_img, 'bands': ['depth_m'], 'proj': etopo.projection(), 'deg': 0.0166},
    {'name': 'sst', 'img': sst_img, 'bands': ['sst_mean_c', 'sst_gradient_deg_km', 'thermal_front_flag'], 'proj': sst_raw.first().projection(), 'deg': 0.25},
    {'name': 'cfsv2', 'img': cfs_img, 'bands': ['wind_speed_mean_m_s', 'wind_stress_tau_mag', 'ekman_w_e_m_s', 'precip_mm_day'], 'proj': cfs.first().projection(), 'deg': 0.208}
]

def stackFor(g):
    sel = g['img'].select(g['bands'])
    vals = sel.updateMask(inAoi)
    valids = sel.mask().updateMask(inAoi).rename(['v_' + b for b in g['bands']])
    return vals.addBands(valids)

def reduceArea(fc, g):
    red = ee.Reducer.mean().combine(reducer2=ee.Reducer.count(), sharedInputs=True)
    r = stackFor(g).reduceRegions(collection=fc, reducer=red, crs=g['proj'], scale=g['proj'].nominalScale(), tileScale=4)
    def setProps(f):
        d = {}
        for b in g['bands']:
            valid = ee.Number(ee.Algorithms.If(f.get(b + '_count'), f.get(b + '_count'), 0))
            dom = ee.Number(ee.Algorithms.If(f.get('v_' + b + '_count'), f.get('v_' + b + '_count'), 0))
            cov = ee.Number(ee.Algorithms.If(dom.gt(0), valid.divide(dom), 0))
            d[b + '_mean'] = f.get(b + '_mean')
            d[b + '_valid_px'] = valid
            d[b + '_domain_px'] = dom
            d[b + '_cov'] = cov
        d['agg_method_' + g['name']] = 'AREA_MEAN_NATIVE_PIXELS'
        return f.set(d)
    return r.map(setProps)

def reduceCentroid(fc, g):
    r = stackFor(g).reduceRegions(collection=fc, reducer=ee.Reducer.first(), crs=g['proj'], scale=g['proj'].nominalScale(), tileScale=4)
    def setProps(f):
        d = {}
        for b in g['bands']:
            v = f.get('v_' + b)
            dom = ee.Number(ee.Algorithms.If(ee.Algorithms.IsEqual(v, None), 0, 1))
            valid = ee.Number(ee.Algorithms.If(v, v, 0))
            d[b + '_mean'] = f.get(b)
            d[b + '_valid_px'] = valid
            d[b + '_domain_px'] = dom
            d[b + '_cov'] = valid
        d['agg_method_' + g['name']] = 'NATIVE_PIXEL_AT_CELL_CENTROID'
        return f.set(d)
    return r.map(setProps)

CELL = 0.1
# Test on gridFC
t0 = time.time()
print("Starting aggregation on gridFC...")
fc = gridFC
for g in groups:
    if g['deg'] < CELL:
        fc = reduceArea(fc, g)

cen = fc.map(lambda f: ee.Feature(f.geometry().centroid(1), f.toDictionary()))
for g in groups:
    if g['deg'] >= CELL:
        cen = reduceCentroid(cen, g)

# Attach table
prov_dict = {'processing_version': 'SEACAST_PRIGI_v2.3.2', 'year_month': '2024-04', 'sst_source_id': 'NOAA/CDR/OISST/V2_1', 'cfsv2_qc_exclusions': 'test'}
slim = {'processing_version': 'SEACAST_PRIGI_v2.3.2', 'year_month': '2024-04'}
table = cen.map(lambda f: f.set(slim)).set(prov_dict)

# Now test T15: limit(20)
t1 = time.time()
lim20 = table.limit(20).getInfo()
print(f"limit(20) returned {len(lim20['features'])} rows in {time.time()-t1:.2f}s!")
f0 = lim20['features'][0]['properties']
print("Row 0 properties:")
for k in ['cell_id', 'sst_mean_c_mean', 'sst_mean_c_cov', 'chla_mg_m3_mean', 'chla_mg_m3_cov', 'agg_method_cfsv2', 'agg_method_chla']:
    print(f"  {k}: {f0.get(k)}")

# Test T16: propertyNames
props = table.propertyNames().getInfo()
print("Table propertyNames:", props)

