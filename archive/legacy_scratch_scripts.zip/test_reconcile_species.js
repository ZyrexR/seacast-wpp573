// Task 1 Final Reconciliation Script
const fs = require('fs');
const path = require('path');

const prigiDir = 'C:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis';
const master132 = JSON.parse(fs.readFileSync(path.join(prigiDir, 'data/oceanographic/statistics/monthly/ocean_fisheries_master_132m.json'), 'utf8'));

// 1. Calculate sums of each species across 132 months
const speciesKeys = [
  'cakalang_kg',
  'madidihang_kg',
  'tongkol_krai_kg',
  'tongkol_kenyar_kg',
  'tongkol_como_kg',
  'albakor_kg',
  'tuna_mata_besar_kg',
  'marlin_kg',
  'tenggiri_kg',
  'gulamah_kg',
  'julung_kg',
  'cucut_kg'
];

const speciesNames = {
  cakalang_kg: 'Cakalang (Katsuwonus pelamis)',
  madidihang_kg: 'Madidihang (Thunnus albacares)',
  tongkol_krai_kg: 'Tongkol Krai (Auxis thazard)',
  tongkol_kenyar_kg: 'Tongkol Kenyar (Auxis rochei)',
  tongkol_como_kg: 'Tongkol Como (Euthynnus affinis)',
  albakor_kg: 'Albakor (Thunnus alalunga)',
  tuna_mata_besar_kg: 'Tuna Mata Besar (Thunnus obesus)',
  marlin_kg: 'Marlin (Istiophoridae)',
  tenggiri_kg: 'Tenggiri (Scomberomorus commerson)',
  gulamah_kg: 'Gulamah (Sciaenidae)',
  julung_kg: 'Julung-julung (Hemiramphidae)',
  cucut_kg: 'Cucut / Hiu Cucut (Carcharhinus spp.)'
};

const speciesSums = {};
speciesKeys.forEach(k => speciesSums[k] = 0);
let sumOfSpeciesSums = 0;
let reportedColumnTotalSum = 0;

master132.forEach(m => {
  let rowSpeciesSum = 0;
  speciesKeys.forEach(k => {
    const val = m[k] || 0;
    speciesSums[k] += val;
    rowSpeciesSum += val;
  });
  sumOfSpeciesSums += rowSpeciesSum;
  reportedColumnTotalSum += m.total_pelagis_kg;
});

console.log('--- SPECIES SUMS (132 MONTHS: 2015-2025) ---');
speciesKeys.forEach(k => {
  console.log(`${speciesNames[k]}: ${speciesSums[k].toLocaleString()} kg`);
});
console.log('----------------------------------------------------');
console.log('Mathematical sum of species columns:', sumOfSpeciesSums.toLocaleString(), 'kg');
console.log('Reported total column in master CSV:', reportedColumnTotalSum.toLocaleString(), 'kg');
console.log('Discrepancy (Reported - Sum of Species):', (reportedColumnTotalSum - sumOfSpeciesSums), 'kg');

// 2. Identify the exact discrepancy in April 2022
const apr2022 = master132.find(m => m.year_month === '2022-04');
let apr2022SpeciesSum = 0;
speciesKeys.forEach(k => { apr2022SpeciesSum += apr2022[k] || 0; });
console.log('\n--- APRIL 2022 ROW AUDIT ---');
console.log('April 2022 sum of 12 species:', apr2022SpeciesSum.toLocaleString(), 'kg');
console.log('April 2022 reported total:', apr2022.total_pelagis_kg.toLocaleString(), 'kg');
console.log('April 2022 difference:', (apr2022.total_pelagis_kg - apr2022SpeciesSum), 'kg');
