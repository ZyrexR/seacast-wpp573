// Script to build a lean, lightning-fast html/sdm_data.js (Phase 4.1 Remediated)
const fs = require('fs');
const path = require('path');

const prigiDir = 'C:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis';

const evaluations = JSON.parse(fs.readFileSync(path.join(prigiDir, 'models/sdm/ensemble/model_evaluations_summary.json'), 'utf8'));
const projections = JSON.parse(fs.readFileSync(path.join(prigiDir, 'outputs/sdm/hsi/hsi_all_scenarios_projections.json'), 'utf8'));
const sensitivity = JSON.parse(fs.readFileSync(path.join(prigiDir, 'outputs/sdm/hsi/rhsi_sensitivity_analysis.json'), 'utf8'));
const presCakalang = JSON.parse(fs.readFileSync(path.join(prigiDir, 'data/sdm/presence/presence_proxy_cakalang.geojson'), 'utf8')).features;
const presMadidihang = JSON.parse(fs.readFileSync(path.join(prigiDir, 'data/sdm/presence/presence_proxy_madidihang.geojson'), 'utf8')).features;
const presAlbakor = JSON.parse(fs.readFileSync(path.join(prigiDir, 'data/sdm/presence/presence_proxy_albakor.geojson'), 'utf8')).features;
const bycatchGeoJSON = JSON.parse(fs.readFileSync(path.join(prigiDir, 'outputs/sdm/zones/dynamic_bycatch_mitigation_zones.geojson'), 'utf8'));

// Generate Heuristic Response Curves
const responseCurves = {
  sst: { x: [], cakalang: [], madidihang: [], albakor: [] },
  chla: { x: [], cakalang: [], madidihang: [], albakor: [] },
  front: { x: [], cakalang: [], madidihang: [], albakor: [] }
};

for (let s = 18; s <= 32; s += 0.5) {
  responseCurves.sst.x.push(parseFloat(s.toFixed(1)));
  responseCurves.sst.cakalang.push(parseFloat(Math.exp(-0.5 * Math.pow((s - 26.8) / 1.8, 2)).toFixed(3)));
  responseCurves.sst.madidihang.push(parseFloat(Math.exp(-0.5 * Math.pow((s - 27.2) / 1.6, 2)).toFixed(3)));
  responseCurves.sst.albakor.push(parseFloat(Math.exp(-0.5 * Math.pow((s - 23.8) / 2.2, 2)).toFixed(3)));
}

for (let c = 0.05; c <= 2.5; c += 0.1) {
  responseCurves.chla.x.push(parseFloat(c.toFixed(2)));
  responseCurves.chla.cakalang.push(parseFloat((c > 0.2 ? Math.min(1.0, (c - 0.2) / 0.5) : 0).toFixed(3)));
  responseCurves.chla.madidihang.push(parseFloat((c > 0.15 ? Math.min(1.0, (c - 0.15) / 0.35) : 0).toFixed(3)));
  responseCurves.chla.albakor.push(parseFloat((c > 0.2 ? Math.min(1.0, (c - 0.2) / 0.4) : 0).toFixed(3)));
}

for (let f = 0; f <= 0.30; f += 0.02) {
  responseCurves.front.x.push(parseFloat(f.toFixed(2)));
  responseCurves.front.cakalang.push(parseFloat(Math.min(1.0, f / 0.12).toFixed(3)));
  responseCurves.front.madidihang.push(parseFloat(Math.min(1.0, f / 0.10).toFixed(3)));
  responseCurves.front.albakor.push(parseFloat(Math.min(1.0, f / 0.08).toFixed(3)));
}

const compactPresence = {
  cakalang: presCakalang.map(p => ({ lat: p.geometry.coordinates[1], lon: p.geometry.coordinates[0], hsi: p.properties.suitability_proxy })),
  madidihang: presMadidihang.map(p => ({ lat: p.geometry.coordinates[1], lon: p.geometry.coordinates[0], hsi: p.properties.suitability_proxy })),
  albakor: presAlbakor.map(p => ({ lat: p.geometry.coordinates[1], lon: p.geometry.coordinates[0], hsi: p.properties.suitability_proxy }))
};

// Zone dictionary mapping (remediated nomenclature)
const zoneDict = [
  'General Oceanic Matrix',
  'Potential Fishing Ground (<10 GT Inshore)',
  'Potential Fishing Ground (20-30 GT Offshore)',
  'Potential Feeding Ground',
  'Potential Spawning Ground Proxy',
  'Potential Nursery Ground Proxy',
  'Candidate Bathymetric Screening Polygons for Voluntary Shark Bycatch Review'
];

function getZoneCode(name) {
  if (name === 'Dynamic Bycatch Mitigation Advisory Zone') return 6;
  const idx = zoneDict.indexOf(name);
  return idx >= 0 ? idx : 0;
}

// Compact scenarios with full RHSI, weighted disagreement, and advisory scores
const compactScenarios = {};
for (let sc in projections) {
  const scObj = projections[sc];
  const firstSpCells = scObj.species_hsi.cakalang.cells;

  // Base coordinates and environment (shared across species)
  const baseGrid = firstSpCells.map(c => ({
    id: c.cell_id,
    lat: c.lat,
    lon: c.lon,
    d: c.depth_m,
    nm: c.dist_harbor_nm,
    iso_km: c.dist_to_200m_isobath_km,
    sst: c.sst,
    chl: c.chl,
    fr: c.front
  }));

  const speciesData = {};
  for (let sp in scObj.species_hsi) {
    const spObj = scObj.species_hsi[sp];
    speciesData[sp] = {
      mean_hsi: spObj.mean_weighted_rhsi,
      mean_weighted_rhsi: spObj.mean_weighted_rhsi,
      mean_sigma_w: spObj.mean_disagreement_sigma_w,
      mean_raw_advisory: spObj.mean_raw_advisory_score,
      mean_vis_score: spObj.mean_visualization_score,
      high_suitability_percent: spObj.high_suitability_percent,
      high_suitability_cells: spObj.high_suitability_cells,
      high_advisory_percent: spObj.high_advisory_percent,
      high_advisory_cells: spObj.high_advisory_cells,
      // Per-cell arrays:
      // [0: weighted_mean_rhsi, 1: hsi_maxent, 2: weighted_ensemble_disagreement, 3: zone_code, 4: is_bycatch,
      //  5: raw_advisory_score, 6: visualization_score, 7: hsi_rf, 8: hsi_glm]
      cells: spObj.cells.map(c => [
        c.weighted_mean_rhsi,
        c.hsi_maxent,
        c.weighted_ensemble_disagreement,
        getZoneCode(c.zone_class),
        c.is_bycatch_risk ? 1 : 0,
        c.raw_advisory_score,
        c.visualization_score,
        c.hsi_rf,
        c.hsi_glm
      ])
    };
  }

  compactScenarios[sc] = {
    grid: baseGrid,
    species: speciesData
  };
}

// Preserve full clipped polygon geometry and all 8 CITES fields for all 123 bycatch screening polygons
const compactBycatch = bycatchGeoJSON.features.map(f => ({
  cell_id: f.properties.cell_id,
  lat: f.properties.lat || parseFloat(((f.geometry.coordinates[0][0][1] + f.geometry.coordinates[0][2][1]) / 2).toFixed(4)),
  lon: f.properties.lon || parseFloat(((f.geometry.coordinates[0][0][0] + f.geometry.coordinates[0][2][0]) / 2).toFixed(4)),
  ring: f.geometry.coordinates[0],
  d: f.properties.depth_m,
  sst: f.properties.sst_celsius,
  nm: f.properties.dist_harbor_nm,
  area_km2: f.properties.area_km2,
  clipped_to_aoi_boundary: f.properties.clipped_to_aoi_boundary,
  zone_name: f.properties.zone_name,
  layer_type: f.properties.layer_type,
  mitigation_guidance: f.properties.mitigation_guidance,
  identified_taxon_name: f.properties.identified_taxon_name,
  taxonomic_resolution_level: f.properties.taxonomic_resolution_level,
  taxonomic_uncertainty_notes: f.properties.taxonomic_uncertainty_notes,
  identification_verification_status: f.properties.identification_verification_status,
  cites_appendix: f.properties.cites_appendix,
  cites_taxonomic_scope: f.properties.cites_taxonomic_scope,
  cites_reference_date: f.properties.cites_reference_date,
  cites_verification_source: f.properties.cites_verification_source
}));

const bundle = `// SEACAST PRIGI // COMPACT OPTIMIZED PHASE 3 & 4.1 RHSI HEURISTIC HABITAT SCREENING BUNDLE
// Standalone zero-CORS format (Remediated Baseline Integrity)

window.SDM_DATA = {
  modelParadigm: "Heuristic Multi-Criteria Habitat Suitability Screening (RHSI)",
  bycatchLayerOfficialName: "Candidate Bathymetric Screening Polygons for Voluntary Shark Bycatch Review",
  zoneDict: ${JSON.stringify(zoneDict)},
  evaluations: ${JSON.stringify(evaluations)},
  sensitivitySummary: ${JSON.stringify({
    albakor_zero_weight_fix_impact: sensitivity.albakor_zero_weight_fix_impact,
    weight_scheme_comparison: sensitivity.weight_scheme_comparison,
    lambda_and_threshold_grid: sensitivity.lambda_and_threshold_grid
  })},
  responseCurves: ${JSON.stringify(responseCurves)},
  compactPresence: ${JSON.stringify(compactPresence)},
  bycatchMetadata: ${JSON.stringify(bycatchGeoJSON.metadata)},
  bycatchFeaturesCount: ${compactBycatch.length},
  bycatchFeatures: ${JSON.stringify(compactBycatch)},
  scenarios: ${JSON.stringify(compactScenarios)}
};

console.log("SEACAST PRIGI // Remediated RHSI bundle loaded: 6 scenarios, 3 species, 123 clipped bycatch polygons.");
`;

fs.writeFileSync(path.join(prigiDir, 'html/sdm_data.js'), bundle, 'utf8');
const sizeKb = (Buffer.byteLength(bundle, 'utf8') / 1024).toFixed(1);
console.log(`Successfully built remediated html/sdm_data.js (${sizeKb} KB).`);
