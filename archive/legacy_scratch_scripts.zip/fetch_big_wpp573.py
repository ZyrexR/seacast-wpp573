# -*- coding: utf-8 -*-
"""
Acquire full GeoJSON for WPP-RI 573 from BIG MapServer Layer 21.
"""
import urllib.request
import urllib.parse
import json
import ssl
import sys
import os
import hashlib
import datetime

WORKSPACE = r"C:\Users\ThinkPad\.gemini\antigravity\scratch\prigi-pelagis"
BASE_URL = "https://kspservices.big.go.id/satupeta/rest/services/PUBLIK/SUMBER_DAYA_ALAM_DAN_LINGKUNGAN/MapServer/21"

ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

def fetch_wpp573_geojson():
    params = {
        "where": "namobj = 'WPP-RI 573'",
        "outFields": "*",
        "returnGeometry": "true",
        "outSR": "4326",
        "f": "geojson"
    }
    url = f"{BASE_URL}/query?{urllib.parse.urlencode(params)}"
    print(f"Requesting GeoJSON from: {url}")
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, context=ctx, timeout=60) as resp:
        content = resp.read()
    
    print(f"Downloaded bytes: {len(content):,} bytes")
    # Verify valid JSON
    data = json.loads(content.decode("utf-8"))
    features = data.get("features", [])
    print(f"Features returned: {len(features)}")
    if features:
        feat = features[0]
        geom = feat.get("geometry", {})
        props = feat.get("properties", {})
        print("Properties:", props)
        print("Geometry Type:", geom.get("type"))
        coords = geom.get("coordinates", [])
        print("Outer Rings Count:", len(coords))
        n_vertices = sum(len(ring) for ring in coords) if geom.get("type") == "Polygon" else sum(sum(len(r) for r in poly) for poly in coords)
        print("Total Vertices:", n_vertices)
        
    raw_path = os.path.join(WORKSPACE, "data", "aoi", "raw", "WPP573_BIG_ORIGINAL.geojson")
    with open(raw_path, "wb") as f:
        f.write(content)
    print(f"Saved raw GeoJSON to: {raw_path}")
    return raw_path, data

if __name__ == "__main__":
    fetch_wpp573_geojson()

