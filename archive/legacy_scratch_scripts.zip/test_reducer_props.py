import ee
ee.Initialize(project='seca-513505')

# Create a small image and feature collection
img = ee.Image.constant([10, 20]).rename(['band_a', 'band_b'])
fc = ee.FeatureCollection([
    ee.Feature(ee.Geometry.Polygon([[[111, -9], [111.1, -9], [111.1, -8.9], [111, -8.9], [111, -9]]]), {'cell_id': 'test_1'})
])

red = ee.Reducer.mean().combine(reducer2=ee.Reducer.count(), sharedInputs=True)
res = img.reduceRegions(collection=fc, reducer=red, scale=1000).first().getInfo()
print("Combined Reducer Properties:", res['properties'])

