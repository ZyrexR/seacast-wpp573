import math
import sys

# Test vectors specified by user
rhsi = [0.8, 0.6, 0.4]
weights = [0.5, 0.3, 0.2]
lambda_val = 0.5

# Expected values
expected_weighted_rhsi = 0.66
expected_disagreement = 0.1562  # approx
expected_advisory_score = 0.5819 # approx

# Mathematical formulation
# 1. Weights normalization assertion
sum_w = sum(weights)
assert abs(sum_w - 1.0) < 1e-9, f"Weights must sum to 1.0, got {sum_w}"

# 2. Weighted mean RHSI
weighted_rhsi = sum(w * r for w, r in zip(weights, rhsi))

# 3. Weighted ensemble disagreement (weighted standard deviation)
var_w = sum(w * ((r - weighted_rhsi) ** 2) for w, r in zip(weights, rhsi))
disagreement = math.sqrt(var_w)

# 4. PFG advisory score
raw_advisory_score = weighted_rhsi - lambda_val * disagreement
visualization_score = max(0.0, min(1.0, raw_advisory_score))

# Numerical tolerance evaluation
tol_rhsi = 1e-6
tol_disagree = 1e-4 # due to 4-decimal rounding in prompt
tol_advisory = 1e-4

diff_rhsi = abs(weighted_rhsi - expected_weighted_rhsi)
diff_disagree = abs(disagreement - expected_disagreement)
diff_advisory = abs(raw_advisory_score - expected_advisory_score)

print("=== UNIT TEST: WEIGHTED ENSEMBLE DISAGREEMENT & ADVISORY SCORING ===")
print(f"Inputs:")
print(f"  RHSI vector:    {rhsi}")
print(f"  Weights vector: {weights} (sum = {sum_w})")
print(f"  Lambda:         {lambda_val}")
print(f"\nResults:")
print(f"  Weighted RHSI:        {weighted_rhsi:.6f} | Expected: {expected_weighted_rhsi:.4f} | Diff: {diff_rhsi:.2e} | Pass: {diff_rhsi < tol_rhsi}")
print(f"  Weighted Disagreement:{disagreement:.6f} | Expected: {expected_disagreement:.4f} | Diff: {diff_disagree:.2e} | Pass: {diff_disagree < tol_disagree}")
print(f"  Raw Advisory Score:   {raw_advisory_score:.6f} | Expected: {expected_advisory_score:.4f} | Diff: {diff_advisory:.2e} | Pass: {diff_advisory < tol_advisory}")
print(f"  Visualization Score:  {visualization_score:.6f} (clipped to [0, 1])")

# Check if application source code has an existing implementation
# As checked earlier, app.py and utils.py do not yet have this function integrated.
app_has_function = False
print(f"\nApplication Codebase Integration Status:")
print(f"  Integrated in app.py / utils.py: {app_has_function}")
print(f"  Status for PG-04: PARTIAL (Formula and unit test verified; application codebase integration pending Phase 4 prototype development)")
