import os, hashlib, csv

manifest_p = 'reports/phase_1_1_remediation/06_reproducibility/EVIDENCE_MANIFEST_SHA256.csv'

target_files = [
    'reports/phase_1_1_remediation/03_grid/GRID_CELL_AREA_QA.csv',
    'reports/phase_1_1_remediation/03_grid/GRID_REPRODUCTION_QA.csv',
    'reports/phase_1_1_remediation/03_grid/GRID_AREA_RECONCILIATION.md',
    'reports/phase_1_1_remediation/06_reproducibility/GRID_SCHEMA_VALIDATION_REPORT.md'
]

manifest_hashes = {}
with open(manifest_p, 'r', encoding='utf-8') as f:
    for row in csv.DictReader(f):
        norm_p = os.path.normpath(row['relative_path'])
        manifest_hashes[norm_p] = row['sha256']

print("=== FORENSIC SHA-256 COMPARISON AGAINST PHASE 1.1 MANIFEST ===")
for tf in target_files:
    norm_tf = os.path.normpath(tf)
    exp_hash = manifest_hashes.get(norm_tf)
    
    with open(tf, 'rb') as fp:
        actual_hash = hashlib.sha256(fp.read()).hexdigest()
    
    match = (actual_hash == exp_hash)
    status_str = "MATCH (VERIFIED INTACT)" if match else "MISMATCH (MODIFIED)"
    print(f"File: {tf}")
    print(f"  Manifest Hash: {exp_hash}")
    print(f"  Actual Disk:   {actual_hash}")
    print(f"  Match Status:  {status_str}")
    print("-" * 70)

