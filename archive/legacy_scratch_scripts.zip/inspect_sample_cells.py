import ee

ee.Initialize(project="seca-513505")
gridFC = ee.FeatureCollection("projects/seca-513505/assets/GRID_010_REGIONAL_8129")
first10 = gridFC.sort("cell_id").limit(10).getInfo()
print("First 10 cell IDs and classes:")
for f in first10["features"]:
  p = f["properties"]
  print(
      f"  {p.get('cell_id')}: class={p.get('cell_class')} aoi_fract={p.get('aoi_fract')} ocean_frac={p.get('ocean_frac')}"
  )

