const fs = require('fs');

const dir = 'C:\\Users\\ThinkPad\\.gemini\\antigravity\\brain\\cc088fc0-e16d-416d-8247-15acc089a9e9\\scratch\\unzipped_excel';
const ssXml = fs.readFileSync(dir + '\\xl\\sharedStrings.xml', 'utf8');
const siRegex = /<si>([\s\S]*?)<\/si>/g;
let match;
const sharedStrings = [];
while ((match = siRegex.exec(ssXml)) !== null) {
  const textMatches = match[1].match(/<t[^>]*>([\s\S]*?)<\/t>/g);
  sharedStrings.push(textMatches ? textMatches.map(t => t.replace(/<t[^>]*>|<\/t>/g, '')).join('') : '');
}

function parseSheetRows(filename) {
  const xml = fs.readFileSync(dir + '\\xl\\worksheets\\' + filename, 'utf8');
  const rowRegex = /<row[^>]+r="(\d+)"[^>]*>([\s\S]*?)<\/row>/g;
  let rMatch;
  const rows = [];
  while ((rMatch = rowRegex.exec(xml)) !== null) {
    const rNum = parseInt(rMatch[1]);
    const rowContent = rMatch[2];
    const cRegex = /<c[^>]+r="([A-Z]+)\d+"(?:[^>]+t="([^"]+)")?[^>]*>(?:<v>([\s\S]*?)<\/v>)?<\/c>/g;
    let cMatch;
    const rowData = {};
    while ((cMatch = cRegex.exec(rowContent)) !== null) {
      let val = cMatch[3];
      if (val !== undefined && cMatch[2] === 's') val = sharedStrings[parseInt(val)];
      rowData[cMatch[1]] = val;
    }
    rows.push({ rNum, rowData });
  }
  return rows;
}

// Sheet 3: Gear Trips
const s3Rows = parseSheetRows('sheet3.xml');
let curY3 = null;
const s3Monthly = [];
s3Rows.forEach(r => {
  if (r.rowData['B'] && !isNaN(parseFloat(r.rowData['B'])) && parseFloat(r.rowData['B']) >= 2012 && parseFloat(r.rowData['B']) <= 2025 && !r.rowData['C']) {
    curY3 = parseInt(r.rowData['B']);
  }
  if (r.rowData['C'] && r.rowData['C'] !== 'Bulan' && r.rowData['B'] && !isNaN(parseFloat(r.rowData['B']))) {
    const mNum = parseInt(r.rowData['B']);
    let sum = 0;
    ['D','E','F','G','H','I','J'].forEach(c => {
      sum += parseFloat(r.rowData[c]) || 0;
    });
    s3Monthly.push({ year: curY3, month: mNum, sum, reported: parseFloat(r.rowData['K']) || sum });
  }
});

// Sheet 4: GT Trips
const s4Rows = parseSheetRows('sheet4.xml');
let curY4 = null;
const s4Monthly = [];
s4Rows.forEach(r => {
  if (r.rowData['A'] && !isNaN(parseFloat(r.rowData['A'])) && parseFloat(r.rowData['A']) >= 2012 && parseFloat(r.rowData['A']) <= 2025) {
    curY4 = parseInt(r.rowData['A']);
  }
  if (r.rowData['C'] && r.rowData['C'] !== 'Bulan' && r.rowData['B'] && !isNaN(parseFloat(r.rowData['B']))) {
    const mNum = parseInt(r.rowData['B']);
    let sum = 0;
    ['D','E','F','G'].forEach(c => {
      sum += parseFloat(r.rowData[c]) || 0;
    });
    s4Monthly.push({ year: curY4, month: mNum, sum, reported: parseFloat(r.rowData['H']) || sum });
  }
});

console.log('Total monthly records S3:', s3Monthly.length, 'S4:', s4Monthly.length);

const yearlyS3 = {}, yearlyS4 = {};
for (let y = 2012; y <= 2025; y++) { yearlyS3[y] = 0; yearlyS4[y] = 0; }

s3Monthly.forEach(r => yearlyS3[r.year] += r.sum);
s4Monthly.forEach(r => yearlyS4[r.year] += r.sum);

console.log('YEAR | SHEET 3 (GEAR) | SHEET 4 (GT) | DIFF (S3 - S4)');
console.log('----------------------------------------------------');
let totS3 = 0, totS4 = 0;
let totS3_2015_2025 = 0, totS4_2015_2025 = 0;

for (let y = 2012; y <= 2025; y++) {
  totS3 += yearlyS3[y];
  totS4 += yearlyS4[y];
  if (y >= 2015) {
    totS3_2015_2025 += yearlyS3[y];
    totS4_2015_2025 += yearlyS4[y];
  }
  const diff = yearlyS3[y] - yearlyS4[y];
  console.log(`${y} | ${yearlyS3[y].toLocaleString().padStart(14)} | ${yearlyS4[y].toLocaleString().padStart(12)} | ${diff.toLocaleString().padStart(14)}`);
}
console.log('----------------------------------------------------');
console.log(`TOTAL 2012-2025 | ${totS3.toLocaleString().padStart(14)} | ${totS4.toLocaleString().padStart(12)} | ${(totS3 - totS4).toLocaleString().padStart(14)}`);
console.log(`TOTAL 2015-2025 | ${totS3_2015_2025.toLocaleString().padStart(14)} | ${totS4_2015_2025.toLocaleString().padStart(12)} | ${(totS3_2015_2025 - totS4_2015_2025).toLocaleString().padStart(14)}`);
