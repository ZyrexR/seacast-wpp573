import ee
import time

ee.Initialize(project='seca-513505')

aoiFC = ee.FeatureCollection("projects/seca-513505/assets/AOI_WPP573_MASTER")
inAoi = ee.Image.constant(1).clip(aoiFC).rename('aoi')

start, end = '2024-04-01', '2024-05-01'
bbox = ee.Geometry.Rectangle([102.50, -14.00, 126.50, -6.80])

# SST & Front
sst_raw = ee.ImageCollection('NOAA/CDR/OISST/V2_1').filterDate(start, end).filterBounds(bbox).select('sst')
sst_img = sst_raw.mean().multiply(0.01).rename('sst_mean_c')

# Thermal front module
# nativeGradients:
# var native = img.reproject(proj);
# var ddx = native.convolve(k.KX)...
proj_sst = sst_raw.first().projection()
KX = ee.Kernel.fixed(3, 3, [[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]])
KY = ee.Kernel.fixed(3, 3, [[-1, -2, -1], [0, 0, 0], [1, 2, 1]])
native_sst = sst_img.reproject(proj_sst)
dx = native_sst.convolve(KX).rename('sst_dTdx_c_km')
dy = native_sst.convolve(KY).rename('sst_dTdy_c_km')
front = dx.hypot(dy).rename('sst_gradient_deg_km')

# CHLA
modisRaw = ee.ImageCollection('NASA/OCEANDATA/MODIS-Aqua/L3SMI').filterDate(start, end).filterBounds(bbox).select('chlor_a')
gcomRaw = ee.ImageCollection('JAXA/GCOM-C/L3/OCEAN/CHLA/V3').filterDate(start, end).filterBounds(bbox).select('CHLA_AVE')
target = modisRaw.first().projection()
modis = modisRaw.map(lambda img: img.updateMask(img.gte(0.01).And(img.lte(100.0))))
modisCount = modis.count().rename('modis_valid_count').setDefaultProjection(target)
modisMean = modis.mean().rename('modis_mean').setDefaultProjection(target)
modisValid = modisCount.gt(0).And(modisMean.mask()).rename('modis_valid')

gProj = gcomRaw.first().projection()
gcom = gcomRaw.map(lambda img: img.multiply(0.0016).updateMask(img.multiply(0.0016).gte(0.01).And(img.multiply(0.0016).lte(100.0))))
gcomCount = gcom.count().rename('gcom_valid_count').setDefaultProjection(gProj).reproject(target)
gcomMean = gcom.mean().rename('gcom_mean').setDefaultProjection(gProj).reproject(target)
gcomValid = gcomCount.gt(0).And(gcomMean.mask()).rename('gcom_valid')
fallback = gcomValid.And(modisValid.Not())

value = ee.ImageCollection([
    gcomMean.rename('chla_mg_m3').toFloat().updateMask(gcomValid),
    modisMean.rename('chla_mg_m3').toFloat().updateMask(modisValid)
]).mosaic().rename('chla_mg_m3').reproject(target)

source = ee.ImageCollection([
    ee.Image.constant(2).toByte().updateMask(fallback),
    ee.Image.constant(1).toByte().updateMask(modisValid)
]).mosaic().unmask(0).rename('chla_source_code').reproject(target)

# ETOPO
etopo = ee.Image('NOAA/NGDC/ETOPO1').select('bedrock')
elev = etopo.rename('elevation_m')
depth = elev.multiply(-1.0).updateMask(elev.lt(0)).rename('depth_m')

# CFSV2 & Ekman
cfs = ee.ImageCollection('NOAA/CFSV2/FOR6H_HARMONIZED').filterDate(start, end).filterBounds(bbox)
u = cfs.select('u-component_of_wind_height_above_ground').mean().rename('wind_speed_mean_m_s')
stress = u.multiply(0.001).rename('wind_stress_tau_mag')
ekman = u.multiply(0.0001).rename('ekman_w_e_m_day')

# HYCOM
hycom = ee.ImageCollection('HYCOM/sea_water_velocity').filterDate(start, end).filterBounds(bbox)
curr = hycom.select('velocity_u_0').mean().multiply(0.001).rename('current_speed_m_s')

composite = sst_img.addBands([front, value, source, u, stress, ekman, curr, depth]).updateMask(inAoi)

for band in ['depth_m', 'sst_mean_c', 'sst_gradient_deg_km', 'chla_mg_m3', 'wind_speed_mean_m_s']:
    t0 = time.time()
    try:
        m = composite.select(band).getMapId()
        print(f"getMapId for {band} took {time.time()-t0:.2f}s: {m['mapid'][:20]}...")
    except Exception as e:
        print(f"getMapId for {band} FAILED in {time.time()-t0:.2f}s: {e}")

