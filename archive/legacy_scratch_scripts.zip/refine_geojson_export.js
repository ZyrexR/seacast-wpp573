const fs = require('fs');
const path = require('path');

const prigiDir = 'C:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis';
const projections = JSON.parse(fs.readFileSync(path.join(prigiDir, 'outputs/sdm/hsi/hsi_all_scenarios_projections.json'), 'utf8'));
const eastCells = projections.east_monsoon_jja.species_hsi;

const speciesList = [
  { key: 'cakalang', name: 'Cakalang (Katsuwonus pelamis)', file: 'functional_zones_cakalang.geojson' },
  { key: 'madidihang', name: 'Madidihang (Thunnus albacares)', file: 'functional_zones_madidihang.geojson' },
  { key: 'albakor', name: 'Albakor (Thunnus alalunga)', file: 'functional_zones_albakor.geojson' }
];

speciesList.forEach(sp => {
  const cells = eastCells[sp.key].cells;
  const features = [];
  cells.forEach(cell => {
    if (cell.zone_class !== 'General Oceanic Matrix') {
      features.push({
        type: 'Feature',
        geometry: {
          type: 'Polygon',
          coordinates: [[
            [parseFloat((cell.lon - 0.025).toFixed(3)), parseFloat((cell.lat - 0.025).toFixed(3))],
            [parseFloat((cell.lon + 0.025).toFixed(3)), parseFloat((cell.lat - 0.025).toFixed(3))],
            [parseFloat((cell.lon + 0.025).toFixed(3)), parseFloat((cell.lat + 0.025).toFixed(3))],
            [parseFloat((cell.lon - 0.025).toFixed(3)), parseFloat((cell.lat + 0.025).toFixed(3))],
            [parseFloat((cell.lon - 0.025).toFixed(3)), parseFloat((cell.lat - 0.025).toFixed(3))]
          ]]
        },
        properties: {
          cell_id: cell.cell_id,
          zone_class: cell.zone_class,
          zone_advisory: cell.zone_advisory,
          hsi: cell.hsi_ens,
          species: sp.name,
          scenario: 'Musim Timur (JJA)',
          sst: cell.sst,
          chl: cell.chl,
          depth_m: cell.depth_m,
          dist_harbor_nm: cell.dist_harbor_nm
        }
      });
    }
  });

  const geo = {
    type: 'FeatureCollection',
    metadata: {
      species: sp.name,
      scenario: 'Musim Timur (JJA) - Peak Fishing Season',
      total_zones: features.length,
      crs: 'EPSG:4326'
    },
    features: features
  };

  fs.writeFileSync(path.join(prigiDir, 'outputs/sdm/zones', sp.file), JSON.stringify(geo, null, 2), 'utf8');
  console.log(`Saved ${sp.file} with ${features.length} zones.`);
});

// Also create bycatch mitigation specific GeoJSON
const bycatchFeatures = [];
eastCells.cakalang.cells.forEach(cell => {
  if (cell.zone_class === 'Dynamic Bycatch Mitigation Advisory Zone') {
    bycatchFeatures.push({
      type: 'Feature',
      geometry: {
        type: 'Polygon',
        coordinates: [[
          [parseFloat((cell.lon - 0.025).toFixed(3)), parseFloat((cell.lat - 0.025).toFixed(3))],
          [parseFloat((cell.lon + 0.025).toFixed(3)), parseFloat((cell.lat - 0.025).toFixed(3))],
          [parseFloat((cell.lon + 0.025).toFixed(3)), parseFloat((cell.lat + 0.025).toFixed(3))],
          [parseFloat((cell.lon - 0.025).toFixed(3)), parseFloat((cell.lat + 0.025).toFixed(3))],
          [parseFloat((cell.lon - 0.025).toFixed(3)), parseFloat((cell.lat - 0.025).toFixed(3))]
        ]]
      },
      properties: {
        cell_id: cell.cell_id,
        zone_name: 'Dynamic Bycatch Mitigation Advisory Zone',
        target_threat: 'Hiu Cucut Tikus (Carcharhinus spp.) & Pelagic Elasmobranchs',
        vulnerability: 'CITES Appendix II / IUCN VU/CR',
        conservation_action: 'Avoid deep night sets & encourage circle hook utilization on shelf-break',
        depth_m: cell.depth_m,
        sst: cell.sst,
        dist_harbor_nm: cell.dist_harbor_nm
      }
    });
  }
});

fs.writeFileSync(path.join(prigiDir, 'outputs/sdm/zones/dynamic_bycatch_mitigation_zones.geojson'), JSON.stringify({
  type: 'FeatureCollection',
  metadata: {
    title: 'WPPNRI 573 Dynamic Bycatch Mitigation Advisory Layer',
    focal_zone: 'Shelf-break tubir benua 200 - 1000m',
    features_count: bycatchFeatures.length
  },
  features: bycatchFeatures
}, null, 2), 'utf8');
console.log(`Saved dynamic_bycatch_mitigation_zones.geojson with ${bycatchFeatures.length} zones.`);
