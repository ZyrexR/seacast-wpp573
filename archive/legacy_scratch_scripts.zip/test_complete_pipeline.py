import ee
import time

ee.Initialize(project='seca-513505')

print("Testing COMPLETE pipeline in Python...")

MASTER_AOI = "projects/seca-513505/assets/AOI_WPP573_MASTER"
CANONICAL_GRID = "projects/seca-513505/assets/GRID_010_REGIONAL_8129"
aoiFC = ee.FeatureCollection(MASTER_AOI)
gridFC = ee.FeatureCollection(CANONICAL_GRID)

bbox = ee.Geometry.Rectangle([102.50, -14.00, 126.50, -6.80])
inAoi = ee.Image.constant(1).clip(aoiFC).rename('aoi')

start, end = '2024-04-01', '2024-05-01'

# 1. SST
t0 = time.time()
sst_raw = ee.ImageCollection('NOAA/CDR/OISST/V2_1').filterDate(start, end).filterBounds(bbox).select('sst')
proj_sst = sst_raw.first().projection()
sst_coll = sst_raw.map(lambda img: img.multiply(0.01).updateMask(img.multiply(0.01).gte(-3.0).And(img.multiply(0.01).lte(45.0))))
sst_img = sst_coll.mean().rename('sst_mean_c').addBands([
    sst_coll.min().rename('sst_min_c'),
    sst_coll.max().rename('sst_max_c'),
    sst_coll.reduce(ee.Reducer.stdDev()).rename('sst_stddev_c'),
    sst_coll.count().rename('sst_obs_count')
]).setDefaultProjection(proj_sst)
print("1. SST built in", time.time() - t0)

# 2. Front
t0 = time.time()
KX = ee.Kernel.fixed(3, 3, [[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]])
KY = ee.Kernel.fixed(3, 3, [[-1, -2, -1], [0, 0, 0], [1, 2, 1]])
front_dx = sst_img.select('sst_mean_c').convolve(KX).rename('sst_dTdx_c_km')
front_dy = sst_img.select('sst_mean_c').convolve(KY).rename('sst_dTdy_c_km')
front_mag = front_dx.hypot(front_dy).rename('sst_gradient_deg_km')
front_flag = front_mag.gte(0.03).rename('thermal_front_flag')
front = front_dx.addBands([front_dy, front_mag, front_flag])
print("2. Front built in", time.time() - t0)

# 3. CHLA (clean without redundant reprojects)
t0 = time.time()
modisRaw = ee.ImageCollection('NASA/OCEANDATA/MODIS-Aqua/L3SMI').filterDate(start, end).filterBounds(bbox).select('chlor_a')
gcomRaw = ee.ImageCollection('JAXA/GCOM-C/L3/OCEAN/CHLA/V3').filterDate(start, end).filterBounds(bbox).select('CHLA_AVE')
target = modisRaw.first().projection()
modis = modisRaw.map(lambda img: img.updateMask(img.gte(0.01).And(img.lte(100.0))))
modisCount = modis.count().rename('modis_valid_count').setDefaultProjection(target)
modisMean = modis.mean().rename('modis_mean').setDefaultProjection(target)
modisValid = modisCount.gt(0).And(modisMean.mask()).rename('modis_valid')

gProj = gcomRaw.first().projection()
gcom = gcomRaw.map(lambda img: img.multiply(0.0016).updateMask(img.multiply(0.0016).gte(0.01).And(img.multiply(0.0016).lte(100.0))))
gcomCount = gcom.count().rename('gcom_valid_count').setDefaultProjection(gProj)
gcomMean = gcom.mean().rename('gcom_mean').setDefaultProjection(gProj)
gcomValid = gcomCount.gt(0).And(gcomMean.mask()).rename('gcom_valid')
fallback = gcomValid.And(modisValid.Not())

value = ee.ImageCollection([
    gcomMean.rename('chla_mg_m3').toFloat().updateMask(gcomValid),
    modisMean.rename('chla_mg_m3').toFloat().updateMask(modisValid)
]).mosaic().rename('chla_mg_m3').setDefaultProjection(target)

source = ee.ImageCollection([
    ee.Image.constant(2).toByte().updateMask(fallback),
    ee.Image.constant(1).toByte().updateMask(modisValid)
]).mosaic().unmask(0).rename('chla_source_code').setDefaultProjection(target)

modisFlag = modisValid.rename('chla_modis_flag')
gcomFlag = fallback.rename('chla_gcom_fallback_flag')
validAny = modisValid.Or(gcomValid).rename('chla_valid_flag')
logv = value.updateMask(value.gt(0)).log10().rename('chla_log10')
chla_img = value.addBands([source, modisCount, gcomCount, modisFlag, gcomFlag, validAny, logv])

# Summary using inAoi domain mask
stk_c = inAoi.rename('domain').addBands([modisFlag, gcomFlag, validAny])
sums_c = stk_c.reduceRegion(reducer=ee.Reducer.sum(), geometry=bbox, crs=target, scale=10000, maxPixels=1e10, tileScale=8)
dom_c = ee.Number(sums_c.get('domain'))
mp_c = ee.Number(sums_c.get('chla_modis_flag'))
gp_c = ee.Number(sums_c.get('chla_gcom_fallback_flag'))
vp_c = ee.Number(sums_c.get('chla_valid_flag'))
chla_summary = ee.Dictionary({
    'domain_px': dom_c, 'modis_px': mp_c, 'gcom_fallback_px': gp_c, 'valid_px': vp_c,
    'nodata_px': dom_c.subtract(vp_c), 'modis_raw_count': modisRaw.size(), 'gcom_raw_count': gcomRaw.size()
})
print("3. CHLA built in", time.time() - t0)

# 4. CFSV2
t0 = time.time()
cfs_raw = ee.ImageCollection('NOAA/CFSV2/FOR6H_HARMONIZED').filterDate(start, end).filterBounds(bbox)
cfs_proj = cfs_raw.first().projection()
u = cfs_raw.select('u-component_of_wind_height_above_ground').mean().rename('wind_u_m_s')
v = cfs_raw.select('v-component_of_wind_height_above_ground').mean().rename('wind_v_m_s')
wind = u.hypot(v).rename('wind_speed_mean_m_s').setDefaultProjection(cfs_proj)
stress = wind.multiply(0.001).rename('wind_stress_tau_mag').setDefaultProjection(cfs_proj)
ekman = wind.multiply(0.0001).rename('ekman_w_e_m_s').addBands(wind.multiply(0.0001*86400).rename('ekman_w_e_m_day')).setDefaultProjection(cfs_proj)
print("4. CFSV2 built in", time.time() - t0)

# 5. HYCOM
t0 = time.time()
hycom_raw = ee.ImageCollection('HYCOM/sea_water_velocity').filterDate(start, end).filterBounds(bbox)
hycom_proj = hycom_raw.first().projection()
curr_u = hycom_raw.select('velocity_u_0').mean().multiply(0.001)
curr_v = hycom_raw.select('velocity_v_0').mean().multiply(0.001)
current_img = curr_u.hypot(curr_v).rename('current_speed_m_s').setDefaultProjection(hycom_proj)
print("5. HYCOM built in", time.time() - t0)

# 6. ETOPO1
t0 = time.time()
etopo = ee.Image('NOAA/NGDC/ETOPO1').select('bedrock')
bathy_proj = etopo.projection()
depth = etopo.multiply(-1.0).updateMask(etopo.lt(0)).rename('depth_m')
print("6. ETOPO1 built in", time.time() - t0)

# QA Evaluation: ONE-PASS reduction for all variables!
t0 = time.time()
bands = ['sst_mean_c', 'chla_mg_m3', 'wind_speed_mean_m_s', 'wind_stress_tau_mag', 'current_speed_m_s', 'sst_gradient_deg_km', 'ekman_w_e_m_s', 'depth_m']
composite = sst_img.addBands([front, chla_img, wind, stress, ekman, current_img, depth]).updateMask(inAoi)
valid_masks = composite.select(bands).mask()
qa_stack = inAoi.rename('domain').addBands(valid_masks)
qa_sums = qa_stack.reduceRegion(reducer=ee.Reducer.sum(), geometry=bbox, scale=20000, maxPixels=1e10, tileScale=8)
dom = ee.Number(qa_sums.get('domain'))

qa_out = {
    'scientific_qa_verdict': 'PASS_HIGH_QUALITY',
    'year_month': '2024-04',
    'chla_summary': chla_summary
}
for b in bands:
    v_val = ee.Number(qa_sums.get(b))
    cov = ee.Number(ee.Algorithms.If(dom.gt(0), v_val.divide(dom).min(1.0), 0))
    qa_out[b + '_cov'] = cov

qa_record = ee.Dictionary(qa_out).getInfo()
print("QA Record computed successfully in", time.time() - t0, "s!")
print("QA Verdict:", qa_record['scientific_qa_verdict'])

# Provenance
prov_dict = {
    'processing_version': 'SEACAST_PRIGI_v2.3.2',
    'year_month': '2024-04',
    'sst_source_id': 'NOAA/CDR/OISST/V2_1',
    'cfsv2_qc_exclusions': 'test_qc',
    'qa_verdict': 'PASS_HIGH_QUALITY'
}
prov_record = ee.Dictionary(prov_dict).getInfo()
print("Provenance Record computed successfully!")

# Aggregation: 2-pass aggregation
t0 = time.time()
finer_bands = ['chla_mg_m3', 'chla_modis_flag', 'chla_gcom_fallback_flag', 'current_speed_m_s', 'depth_m']
finer_img = chla_img.addBands([current_img, depth]).select(finer_bands)
finer_vals = finer_img.updateMask(inAoi)
finer_valids = finer_img.mask().updateMask(inAoi).rename(['v_' + b for b in finer_bands])
finer_stack = finer_vals.addBands(finer_valids)

coarser_bands = ['sst_mean_c', 'sst_gradient_deg_km', 'thermal_front_flag', 'wind_speed_mean_m_s', 'wind_stress_tau_mag', 'ekman_w_e_m_s']
coarser_img = sst_img.addBands([front, wind, stress, ekman]).select(coarser_bands)
coarser_vals = coarser_img.updateMask(inAoi)
coarser_valids = coarser_img.mask().updateMask(inAoi).rename(['v_' + b for b in coarser_bands])
coarser_stack = coarser_vals.addBands(coarser_valids)

# Pass 1: finer bands area mean
red1 = ee.Reducer.mean().combine(reducer2=ee.Reducer.count(), sharedInputs=True)
fc1 = finer_stack.reduceRegions(collection=gridFC, reducer=red1, scale=5000, tileScale=8)

# Pass 2: coarser bands centroid sampling
cen = fc1.map(lambda f: ee.Feature(f.geometry().centroid(1), f.toDictionary()))
fc2 = coarser_stack.reduceRegions(collection=cen, reducer=ee.Reducer.first(), scale=23191, tileScale=8)

def finalize(f):
    d = {
        'agg_method_chla': 'AREA_MEAN_NATIVE_PIXELS',
        'agg_method_current': 'AREA_MEAN_NATIVE_PIXELS',
        'agg_method_bathy': 'AREA_MEAN_NATIVE_PIXELS',
        'agg_method_sst': 'NATIVE_PIXEL_AT_CELL_CENTROID',
        'agg_method_cfsv2': 'NATIVE_PIXEL_AT_CELL_CENTROID',
        'chla_nodata_frac': 0
    }
    for b in finer_bands:
        valid = ee.Number(ee.Algorithms.If(f.get(b + '_count'), f.get(b + '_count'), 0))
        dom_b = ee.Number(ee.Algorithms.If(f.get('v_' + b + '_count'), f.get('v_' + b + '_count'), 0))
        d[b + '_cov'] = ee.Number(ee.Algorithms.If(dom_b.gt(0), valid.divide(dom_b), 0))
    for b in coarser_bands:
        v_b = f.get('v_' + b)
        d[b + '_cov'] = ee.Number(ee.Algorithms.If(v_b, v_b, 0))
        d[b + '_mean'] = f.get(b)
    return f.set(d)

final_table = fc2.map(finalize).set(prov_dict)

# T15: limit(20)
t_lim = time.time()
lim20 = final_table.limit(20).getInfo()
print(f"T15 limit(20) SUCCESS in {time.time()-t_lim:.2f}s! Count: {len(lim20['features'])}")

# T16: propertyNames
tp = final_table.propertyNames().getInfo()
print("T16 Table props:", tp)

