const fs = require('fs');
const prigiDir = 'C:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis';

function head(file, n=5) {
  const c = fs.readFileSync(prigiDir + '/' + file, 'utf8');
  return c.split('\n').slice(0, n).join('\n');
}

console.log('--- master_prigi_all_inclusive.csv ---');
console.log(head('data/master_prigi_all_inclusive.csv', 3));

console.log('--- master_prigi_pelagis_2015_2022.csv ---');
console.log(head('data/master_prigi_pelagis_2015_2022.csv', 3));

console.log('--- prigi_fleet_trips_2012_2025.csv ---');
console.log(head('data/prigi_fleet_trips_2012_2025.csv', 3));
