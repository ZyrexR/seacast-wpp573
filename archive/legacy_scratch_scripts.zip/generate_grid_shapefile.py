import csv
import zipfile
import os
import shapefile

csv_path = 'data/qa/phase_1_1/grid/GRID_010_REGIONAL_CELLS_QA.csv'
out_dir = 'data/qa/phase_1_1/grid'
shp_base = os.path.join(out_dir, 'GRID_010_REGIONAL_8129')

# Create Shapefile writer for Polygon
w = shapefile.Writer(shp_base, shapeType=shapefile.POLYGON)
w.field('cell_id', 'C', size=24)
w.field('cell_class', 'C', size=24)
w.field('aoi_fract', 'N', decimal=4)
w.field('ocean_frac', 'N', decimal=4)
w.field('cell_km2', 'N', decimal=2)
w.field('lon_center', 'F', decimal=4)
w.field('lat_center', 'F', decimal=4)

count = 0
with open(csv_path, 'r', encoding='utf-8') as f:
    reader = csv.DictReader(f)
    for row in reader:
        lon = float(row['lon_center'])
        lat = float(row['lat_center'])
        dx = 0.05
        dy = 0.05
        poly = [[
            [round(lon - dx, 6), round(lat - dy, 6)],
            [round(lon + dx, 6), round(lat - dy, 6)],
            [round(lon + dx, 6), round(lat + dy, 6)],
            [round(lon - dx, 6), round(lat + dy, 6)],
            [round(lon - dx, 6), round(lat - dy, 6)]
        ]]
        w.poly(poly)
        w.record(
            cell_id=row['cell_id'],
            cell_class=row['cell_classification'],
            aoi_fract=float(row['aoi_intersection_fraction']),
            ocean_frac=float(row['ocean_fraction']),
            cell_km2=float(row['cell_area_km2']),
            lon_center=lon,
            lat_center=lat
        )
        count += 1

w.close()

# Write .prj (EPSG:4326)
prj_wkt = 'GEOGCS["GCS_WGS_1984",DATUM["D_WGS_1984",SPHEROID["WGS_1984",6378137.0,298.257223563]],PRIMEM["Greenwich",0.0],UNIT["Degree",0.0174532925199433]]'
with open(shp_base + '.prj', 'w', encoding='utf-8') as f:
    f.write(prj_wkt)

# Create zip
zip_path = shp_base + '.zip'
with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for ext in ['.shp', '.shx', '.dbf', '.prj']:
        fpath = shp_base + ext
        zipf.write(fpath, arcname=os.path.basename(fpath))

print(f"Successfully created Shapefile with {count} polygons. Zip size: {os.path.getsize(zip_path)} bytes")

