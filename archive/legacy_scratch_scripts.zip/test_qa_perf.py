import ee
import time

ee.Initialize(project="seca-513505")

aoiFC = ee.FeatureCollection("projects/seca-513505/assets/AOI_WPP573_MASTER")
rawGeom = aoiFC.first().geometry()
polys = rawGeom.geometries().map(
    lambda g: ee.Algorithms.If(
        ee.Geometry(g).type().equals("Polygon"), g, None
    )
).removeAll([None])
polyCoords = polys.map(lambda p: ee.Geometry(p).coordinates())
geom = ee.Geometry(ee.Geometry.MultiPolygon(polyCoords))

sst_img = (
    ee.ImageCollection("NOAA/CDR/OISST/V2_1")
    .filterDate("2024-04-01", "2024-05-01")
    .select("sst")
    .mean()
    .multiply(0.01)
)

# Test A: evaluate with geom, NO reproject, scale=25000
t0 = time.time()
sums_a = (
    sst_img.mask()
    .reduceRegion(
        reducer=ee.Reducer.sum(),
        geometry=geom,
        scale=25000,
        maxPixels=1e9,
        tileScale=4,
    )
    .getInfo()
)
print(f"Test A (scale 25km, no reproject): took {time.time()-t0:.2f}s, {sums_a}")

# Test B: evaluate with bounding box or simplified geom
bbox = ee.Geometry.Rectangle([102.5, -14.0, 126.5, -6.8])
t0 = time.time()
sums_b = (
    sst_img.mask()
    .reduceRegion(
        reducer=ee.Reducer.sum(),
        geometry=bbox,
        scale=25000,
        maxPixels=1e9,
        tileScale=4,
    )
    .getInfo()
)
print(f"Test B (bbox, scale 25km): took {time.time()-t0:.2f}s, {sums_b}")

