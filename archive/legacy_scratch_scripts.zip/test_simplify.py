import ee
import time

ee.Initialize(project="seca-513505")

aoiFC = ee.FeatureCollection("projects/seca-513505/assets/AOI_WPP573_MASTER")
rawGeom = aoiFC.first().geometry()
polys = rawGeom.geometries().map(
    lambda g: ee.Algorithms.If(
        ee.Geometry(g).type().equals("Polygon"), g, None
    )
).removeAll([None])
polyCoords = polys.map(lambda p: ee.Geometry(p).coordinates())
geom = ee.Geometry(ee.Geometry.MultiPolygon(polyCoords))

gridFC = ee.FeatureCollection("projects/seca-513505/assets/GRID_010_REGIONAL_8129")
first_cell = gridFC.first()

t0 = time.time()
simple_geom = geom.simplify(1000)
inter = first_cell.geometry().intersection(simple_geom, 1000).area(1000).divide(1e6)
frac = inter.divide(ee.Number(first_cell.get("cell_km2"))).getInfo()
print(f"simplify(1000) inter took {time.time()-t0:.2f}s, frac={frac}", flush=True)

