// Inspect presence points
const fs = require('fs');
const path = require('path');

const presenceDir = 'C:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis/data/sdm/presence';
const files = [
  'presence_proxy_cakalang.geojson',
  'presence_proxy_madidihang.geojson',
  'presence_proxy_albakor.geojson',
  'presence_proxy_bycatch_indicators.geojson'
];

files.forEach(f => {
  const filePath = path.join(presenceDir, f);
  if (fs.existsSync(filePath)) {
    const data = JSON.parse(fs.readFileSync(filePath, 'utf8'));
    console.log(`=== ${f} ===`);
    console.log('Total features:', data.features.length);
    if (data.features.length > 0) {
      console.log('Sample properties:', data.features[0].properties);
      console.log('Sample geometry:', data.features[0].geometry);
      // check unique sources/methods in properties
      const methods = new Set();
      const years = new Set();
      data.features.forEach(feat => {
        if (feat.properties) {
          if (feat.properties.method) methods.add(feat.properties.method);
          if (feat.properties.source) methods.add(feat.properties.source);
          if (feat.properties.year) years.add(feat.properties.year);
        }
      });
      console.log('Unique methods/sources:', Array.from(methods));
      console.log('Years count:', years.size);
    }
  }
});
