const fs = require('fs');
const prigiDir = 'C:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis';

console.log('--- APP.PY CONTENT ---');
console.log(fs.readFileSync(prigiDir + '/app.py', 'utf8'));

console.log('--- REQUIREMENTS.TXT ---');
console.log(fs.readFileSync(prigiDir + '/requirements.txt', 'utf8'));

console.log('--- UTILS.PY (First 40 lines) ---');
const utils = fs.readFileSync(prigiDir + '/utils.py', 'utf8');
console.log(utils.split('\n').slice(0, 40).join('\n'));
