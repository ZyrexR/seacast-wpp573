const fs = require('fs');
const path = require('path');

const prigiDir = 'C:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis';
const projections = JSON.parse(fs.readFileSync(path.join(prigiDir, 'outputs/sdm/hsi/hsi_all_scenarios_projections.json'), 'utf8'));

// Update all cells across all scenarios to include is_bycatch_risk
for (let sc in projections) {
  for (let sp in projections[sc].species_hsi) {
    const cells = projections[sc].species_hsi[sp].cells;
    cells.forEach(c => {
      c.is_bycatch_risk = (c.depth_m >= -1000 && c.depth_m <= -200 && c.sst <= 26.0);
      if (c.is_bycatch_risk && c.zone_class === 'General Oceanic Matrix') {
        c.zone_class = 'Dynamic Bycatch Mitigation Advisory Zone';
        c.zone_advisory = 'High Vulnerability Shelf-Break (Elasmobranch Shark Co-Occurrence Risk)';
      }
    });
  }
}

fs.writeFileSync(path.join(prigiDir, 'outputs/sdm/hsi/hsi_all_scenarios_projections.json'), JSON.stringify(projections, null, 2), 'utf8');

// Generate independent Bycatch Mitigation Advisory GeoJSON
const eastCells = projections.east_monsoon_jja.species_hsi.cakalang.cells;
const bycatchFeatures = [];

eastCells.forEach(cell => {
  if (cell.is_bycatch_risk) {
    bycatchFeatures.push({
      type: 'Feature',
      geometry: {
        type: 'Polygon',
        coordinates: [[
          [parseFloat((cell.lon - 0.025).toFixed(3)), parseFloat((cell.lat - 0.025).toFixed(3))],
          [parseFloat((cell.lon + 0.025).toFixed(3)), parseFloat((cell.lat - 0.025).toFixed(3))],
          [parseFloat((cell.lon + 0.025).toFixed(3)), parseFloat((cell.lat + 0.025).toFixed(3))],
          [parseFloat((cell.lon - 0.025).toFixed(3)), parseFloat((cell.lat + 0.025).toFixed(3))],
          [parseFloat((cell.lon - 0.025).toFixed(3)), parseFloat((cell.lat - 0.025).toFixed(3))]
        ]]
      },
      properties: {
        cell_id: cell.cell_id,
        zone_name: 'Dynamic Bycatch Mitigation Advisory Zone',
        target_threat: 'Hiu Cucut Tikus (Carcharhinus spp.) & Pari Pelagis',
        conservation_status: 'CITES Appendix II / IUCN Vulnerable (VU) & Endangered (EN)',
        recommended_mitigation: 'Penggunaan Circle Hooks, pembatasan tali pancing kedalaman >200m, dan pelarangan wire leader',
        depth_m: cell.depth_m,
        sst_celsius: cell.sst,
        dist_harbor_nm: cell.dist_harbor_nm,
        hsi_target_fish: cell.hsi_ens
      }
    });
  }
});

fs.writeFileSync(path.join(prigiDir, 'outputs/sdm/zones/dynamic_bycatch_mitigation_zones.geojson'), JSON.stringify({
  type: 'FeatureCollection',
  metadata: {
    title: 'WPPNRI 573 Dynamic Bycatch Mitigation Advisory Layer',
    target_taxa: 'Elasmobranch Apex Predators (Carcharhinus spp.)',
    total_features: bycatchFeatures.length,
    focal_depth_envelope: '-200 m to -1000 m (Shelf-Break / Tubir Benua)',
    thermal_condition: 'SST <= 26.0 °C (Upwelling Season)'
  },
  features: bycatchFeatures
}, null, 2), 'utf8');

console.log(`Updated projections and generated ${bycatchFeatures.length} Dynamic Bycatch Mitigation features.`);
