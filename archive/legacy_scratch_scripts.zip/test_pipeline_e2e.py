import ee
import time

ee.Initialize(project='seca-513505')

# Config
MASTER_AOI = "projects/seca-513505/assets/AOI_WPP573_MASTER"
CANONICAL_GRID = "projects/seca-513505/assets/GRID_010_REGIONAL_8129"
aoiFC = ee.FeatureCollection(MASTER_AOI)
gridFC = ee.FeatureCollection(CANONICAL_GRID)
bbox = ee.Geometry.Rectangle([102.50, -14.00, 126.50, -6.80])
aoiMask = ee.Image.constant(1).clip(aoiFC)

# Test T14 fix (Math.sign equivalent)
r_ekman_w_e_m_s = -0.000123
sg = 1
shSign = ((1 if r_ekman_w_e_m_s > 0 else (-1 if r_ekman_w_e_m_s < 0 else 0)) == -sg)
print("T14 shSign test:", shSign, "(expected True)")

# Test QA evaluate with bbox & domainMask
start, end = '2024-04-01', '2024-05-01'
sst_raw = ee.ImageCollection('NOAA/CDR/OISST/V2_1').filterDate(start, end).filterBounds(bbox).select('sst')
sst_img = sst_raw.mean().multiply(0.01).rename('sst_mean_c')

t0 = time.time()
stack = aoiMask.rename('domain').addBands(sst_img.mask().rename('valid'))
sums = stack.reduceRegion(
    reducer=ee.Reducer.sum(),
    geometry=bbox,
    scale=25000,
    maxPixels=1e10,
    tileScale=8
).getInfo()
dom = sums['domain']
val = sums['valid']
cov = val / dom if dom > 0 else 0
print(f"QA single var took {time.time()-t0:.2f}s: dom={dom:.1f}, val={val:.1f}, cov={cov:.4f}")

# Test T16 properties
prov_dict = {
    'processing_version': 'SEACAST_PRIGI_v2.3.2',
    'year_month': '2024-04',
    'sst_source_id': 'NOAA/CDR/OISST/V2_1',
    'cfsv2_qc_exclusions': 'test_qc'
}
test_img = sst_img.set(prov_dict)
test_fc = gridFC.limit(20).set(prov_dict)

ip = test_img.propertyNames().getInfo()
tp = test_fc.propertyNames().getInfo()
ok16 = ('processing_version' in ip and 'sst_source_id' in ip and 'cfsv2_qc_exclusions' in ip and 'processing_version' in tp)
print("T16 check:", ok16, "ip:", ip, "tp:", tp)

