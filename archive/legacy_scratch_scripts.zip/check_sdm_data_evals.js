const fs = require('fs');
const sdmData = fs.readFileSync('C:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis/html/sdm_data.js', 'utf8');
const evalsMatch = sdmData.match(/evaluations:\s*(\{.*?\})\s*,\s*compactPresence/);
if (evalsMatch) {
  const evals = JSON.parse(evalsMatch[1]);
  console.log('Evaluations in sdm_data.js:');
  console.log(JSON.stringify(evals, null, 2));
} else {
  console.log('Could not find evaluations section with regex.');
}
