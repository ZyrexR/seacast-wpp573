// Script to update html/index.html with Phase 3 SDM & Dynamic Habitat Suitability Dashboard
const fs = require('fs');
const path = require('path');

const indexPath = 'C:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis/html/index.html';
let html = fs.readFileSync(indexPath, 'utf8');

// 1. Add script tag in head
if (!html.includes('sdm_data.js')) {
  html = html.replace(
    '<script src="oceanographic_data.js"></script>',
    '<script src="oceanographic_data.js"></script>\n<script src="sdm_data.js"></script>'
  );
  console.log('Added sdm_data.js to <head>.');
}

// 2. Add navigation button
const sdmNavBtn = `  <button onclick="switchView('view-sdm')">
    <svg width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9"/></svg>
    Model SDM & Habitat Dinamis (Phase 3)
  </button>
</nav>`;

if (!html.includes("switchView('view-sdm')")) {
  html = html.replace('</nav>', sdmNavBtn);
  console.log('Added SDM navigation button to <nav>.');
}

// 3. Add tab-pane id="view-sdm"
const viewSdmPane = `
  <!-- VIEW 7: SPECIES DISTRIBUTION MODELING & DYNAMIC HABITAT SUITABILITY (PHASE 3) -->
  <div class="tab-pane" id="view-sdm">
    <!-- SPATIAL & SCENARIO CONTROL BAR -->
    <div class="ctl-strip" style="justify-content: space-between;">
      <div style="display:flex; align-items:center; gap:14px; flex-wrap:wrap;">
        <label>Target Spesies:
          <select id="selSdmSpecies" onchange="updateSdmSpatialLayer()">
            <option value="cakalang">1. Cakalang (Skipjack Tuna - Katsuwonus pelamis)</option>
            <option value="madidihang">2. Madidihang (Yellowfin Tuna - Thunnus albacares)</option>
            <option value="albakor">3. Albakor (Albacore - Thunnus alalunga)</option>
          </select>
        </label>

        <label>Skenario Oseanografi:
          <select id="selSdmScenario" onchange="updateSdmSpatialLayer()">
            <option value="east_monsoon_jja">Musim Timur (JJA) - Puncak Upwelling & Fishing Season</option>
            <option value="west_monsoon_djf">Musim Barat (DJF) - Non-Upwelling & Low Season</option>
            <option value="transition_1_mam">Peralihan 1 (MAM) - Inisiasi Upwelling & Laut Tenang</option>
            <option value="transition_2_son">Peralihan 2 (SON) - Pelemahan Upwelling & Ruaya</option>
            <option value="super_positive_iod_2019">Ekstrem Super Positive IOD (2019) - Upwelling Kuat</option>
            <option value="negative_iod_2016">Ekstrem Negative IOD (2016) - Fisheries Collapse</option>
          </select>
        </label>

        <label>Mode Tampilan Layer:
          <select id="selSdmLayerMode" onchange="updateSdmSpatialLayer()">
            <option value="hsi_ens">Ensemble HSI (Kesesuaian Habitat 0.00 - 1.00)</option>
            <option value="hsi_maxent">MaxEnt Model HSI</option>
            <option value="uncertainty">Peta Ketidakpastian Spasial (Uncertainty σ)</option>
            <option value="functional_zones">Zonasi Fungsional Ekologis (5 Kategori)</option>
          </select>
        </label>
      </div>

      <div style="display:flex; align-items:center; gap:16px; flex-wrap:wrap;">
        <label><input type="checkbox" id="chkSdmBuffer" checked onchange="toggleSdmOverlay('buffer')"> Jangkauan Armada (12 & 60 NM)</label>
        <label><input type="checkbox" id="chkSdmShelfBreak" checked onchange="toggleSdmOverlay('shelf')"> Tubir Benua 200m</label>
        <label><input type="checkbox" id="chkSdmPresence" onchange="toggleSdmOverlay('presence')"> Titik Presence-Proxy</label>
        <label><input type="checkbox" id="chkSdmBycatch" checked onchange="toggleSdmOverlay('bycatch')"> Zona Mitigasi Bycatch</label>
      </div>
    </div>

    <!-- KPI SUMMARY BAR -->
    <div class="kpi-row" id="sdmKpis" style="margin-bottom: 16px;">
      <div class="kpi-card">
        <div class="kpi-val" id="kpiSdmMeanHsi" style="color: #00f2fe;">0.615</div>
        <div class="kpi-lbl">Rata-rata HSI Regional</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-val" id="kpiSdmHighSuit" style="color: #10b981;">37.6%</div>
        <div class="kpi-lbl">Cakupan Area HSI Tinggi (≥0.65)</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-val" id="kpiSdmModelAuc" style="color: #fbbf24;">0.795</div>
        <div class="kpi-lbl">Ensemble AUC (5-Fold Validated)</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-val" id="kpiSdmTopVar" style="color: #f43f5e;">SST (38.5%)</div>
        <div class="kpi-lbl">Faktor Prediktor Paling Dominan</div>
      </div>
    </div>

    <!-- MAP CONTAINER -->
    <div class="panel" style="margin-bottom: 16px;">
      <div class="panel-header">
        <div class="panel-title" id="sdmMapTitle">Peta Prediksi Habitat Suitability Index (HSI) & Zonasi Dinamis // WPPNRI 573 × PPN Prigi</div>
        <div style="font-size: 11px; color: var(--text-muted);">
          <span style="display:inline-block; width:12px; height:12px; background:#10b981; border-radius:2px; vertical-align:middle; margin-right:4px;"></span>Sangat Sesuai (≥0.65)
          <span style="display:inline-block; width:12px; height:12px; background:#fbbf24; border-radius:2px; vertical-align:middle; margin-left:8px; margin-right:4px;"></span>Moderat (0.40 - 0.64)
          <span style="display:inline-block; width:12px; height:12px; background:#0284c7; border-radius:2px; vertical-align:middle; margin-left:8px; margin-right:4px;"></span>Rendah (0.15 - 0.39)
          <span style="display:inline-block; width:12px; height:12px; background:#f43f5e; border-radius:2px; vertical-align:middle; margin-left:8px; margin-right:4px;"></span>Mitigasi Bycatch Hiu
        </div>
      </div>
      <div id="sdmMap" style="height: 480px; width: 100%; border-radius: 6px; background: #070d18;"></div>
    </div>

    <!-- ANALYTICAL CHARTS GRID -->
    <div class="grid-layout">
      <div class="panel">
        <div class="panel-header">
          <div class="panel-title">Perbandingan Rata-rata HSI Antar Skenario Musiman & Ekstrem</div>
        </div>
        <div id="chartSdmSeasonalHsi" style="height: 320px;"></div>
      </div>

      <div class="panel">
        <div class="panel-header">
          <div class="panel-title">Evaluasi Metrik Model (AUC & TSS: MaxEnt vs RF vs GLM vs Ensemble)</div>
        </div>
        <div id="chartSdmModelAuc" style="height: 320px;"></div>
      </div>
    </div>

    <div class="panel" style="margin-top: 16px;">
      <div class="panel-header">
        <div class="panel-title">Kurva Respon Relung Ekologis (Thermal, Trophic & Front Gradient Niche)</div>
      </div>
      <div id="chartSdmResponseCurve" style="height: 300px;"></div>
    </div>
  </div>
`;

if (!html.includes('id="view-sdm"')) {
  html = html.replace('</main>', viewSdmPane + '\n</main>');
  console.log('Inserted view-sdm tab pane before </main>.');
}

// 4. Update switchView to initialize sdm map
if (!html.includes("if (viewId === 'view-sdm')")) {
  html = html.replace(
    "if (viewId === 'view-ocean') {",
    "if (viewId === 'view-sdm') {\n    setTimeout(function() { initSdmMap(); renderSdmCharts(); }, 150);\n  }\n  if (viewId === 'view-ocean') {"
  );
  console.log('Updated switchView to trigger initSdmMap and renderSdmCharts.');
}

// 5. Add JavaScript code for SDM Map & Charts
const sdmScript = `
// =========================================================================
// PHASE 3: SPECIES DISTRIBUTION MODELING & DYNAMIC HABITAT SCRIPT
// =========================================================================
var sdmMapInstance = null;
var sdmMapInitialized = false;
var sdmGridLayerGroup = null;
var sdmBufferLayerGroup = null;
var sdmShelfLayerGroup = null;
var sdmPresenceLayerGroup = null;
var sdmBycatchLayerGroup = null;

function initSdmMap() {
  if (sdmMapInitialized || typeof L === 'undefined') return;
  const container = document.getElementById('sdmMap');
  if (!container) return;

  sdmMapInstance = L.map('sdmMap').setView([-8.65, 111.75], 8);

  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; OpenStreetMap contributors | SEACAST PRIGI SDM Engine'
  }).addTo(sdmMapInstance);

  // Harbor Marker
  const harbor = L.marker([-8.2818, 111.7314]);
  harbor.bindPopup('<b>PPN Prigi (Basis Analisis)</b><br>Kab. Trenggalek, Jatim<br>Basis Pendaratan 12 Taksa Pelagis').addTo(sdmMapInstance);

  // Layer Groups
  sdmGridLayerGroup = L.layerGroup().addTo(sdmMapInstance);
  sdmBufferLayerGroup = L.layerGroup().addTo(sdmMapInstance);
  sdmShelfLayerGroup = L.layerGroup().addTo(sdmMapInstance);
  sdmPresenceLayerGroup = L.layerGroup().addTo(sdmMapInstance);
  sdmBycatchLayerGroup = L.layerGroup().addTo(sdmMapInstance);

  // Initialize Fleet Buffer (12 & 60 NM)
  const b12 = L.circle([-8.2818, 111.7314], {
    radius: 12 * 1852,
    color: '#fbbf24',
    weight: 1.8,
    dashArray: '4, 4',
    fillColor: '#fbbf24',
    fillOpacity: 0.04
  }).bindPopup('<b>Tertiary AOI: Buffer 12 NM</b><br>Zona Operasional Armada Kapal Motor &lt;10 GT');
  sdmBufferLayerGroup.addLayer(b12);

  const b60 = L.circle([-8.2818, 111.7314], {
    radius: 60 * 1852,
    color: '#00f2fe',
    weight: 2,
    dashArray: '6, 6',
    fillColor: '#00f2fe',
    fillOpacity: 0.02
  }).bindPopup('<b>Tertiary AOI: Buffer 60 NM</b><br>Zona Jelajah Armada Kapal Pukat Cincin 20 - 30 GT');
  sdmBufferLayerGroup.addLayer(b60);

  // Initialize Shelf-Break 200m
  if (window.prigiShelfBreak200m) {
    const shelfLayer = L.geoJSON(window.prigiShelfBreak200m, {
      style: { color: '#ec4899', weight: 2.2, opacity: 0.85, dashArray: '3, 4' },
      onEachFeature: function(f, l) {
        l.bindPopup('<b>Isobath 200 Meter (Tubir Benua / Shelf-Break)</b><br>Koridor Ruaya & Zona Pengangkatan Massa Air Upwelling');
      }
    });
    sdmShelfLayerGroup.addLayer(shelfLayer);
  }

  // Official BIG WPPNRI 573 Boundary
  if (typeof wppnri573WebData !== 'undefined') {
    L.geoJSON(wppnri573WebData, {
      style: { color: '#00f2fe', weight: 1.5, fillOpacity: 0.02 }
    }).addTo(sdmMapInstance);
  }

  sdmMapInitialized = true;
  updateSdmSpatialLayer();
}

function updateSdmSpatialLayer() {
  if (!sdmMapInstance || !window.SDM_DATA) return;
  sdmGridLayerGroup.clearLayers();
  sdmBycatchLayerGroup.clearLayers();

  const species = document.getElementById('selSdmSpecies').value;
  const scenarioKey = document.getElementById('selSdmScenario').value;
  const layerMode = document.getElementById('selSdmLayerMode').value;

  const scData = window.SDM_DATA.scenarios[scenarioKey];
  if (!scData) return;

  const grid = scData.grid;
  const spData = scData.species[species];
  if (!spData) return;

  // Update KPIs
  document.getElementById('kpiSdmMeanHsi').innerText = spData.mean_hsi.toFixed(3);
  document.getElementById('kpiSdmHighSuit').innerText = spData.high_suitability_percent + '%';
  
  const evalSummary = window.SDM_DATA.evaluations[species];
  if (evalSummary) {
    document.getElementById('kpiSdmModelAuc').innerText = evalSummary.ensemble.auc.toFixed(3);
    const topVar = Object.entries(evalSummary.variable_importance_percent).sort((a,b)=>b[1]-a[1])[0];
    document.getElementById('kpiSdmTopVar').innerText = topVar[0].replace('_celsius', '').replace('_mg_m3', '').toUpperCase() + ' (' + topVar[1] + '%)';
  }

  // Color functions
  function getHsiColor(hsi) {
    if (hsi >= 0.75) return '#10b981'; // Very High
    if (hsi >= 0.65) return '#34d399'; // High
    if (hsi >= 0.50) return '#fbbf24'; // Moderate
    if (hsi >= 0.35) return '#38bdf8'; // Low-Mod
    if (hsi >= 0.20) return '#0284c7'; // Low
    return '#070d18'; // Non-suitable
  }

  function getUncertaintyColor(u) {
    if (u >= 0.15) return '#f43f5e'; // High uncertainty
    if (u >= 0.08) return '#fbbf24'; // Moderate
    return '#10b981'; // Low uncertainty (concordant models)
  }

  function getZoneColor(code) {
    // 0: Matrix, 1: PFG Inshore, 2: PFG Offshore, 3: Feeding, 4: Spawning, 5: Nursery, 6: Bycatch
    switch(code) {
      case 1: return '#10b981'; // PFG Inshore
      case 2: return '#00f2fe'; // PFG Offshore
      case 3: return '#a855f7'; // Feeding
      case 4: return '#f59e0b'; // Spawning
      case 5: return '#ec4899'; // Nursery
      case 6: return '#f43f5e'; // Bycatch
      default: return '#1e293b';
    }
  }

  // Render Grid Cells
  grid.forEach((base, idx) => {
    const spCell = spData.cells[idx]; // [hsi_ens, hsi_maxent, uncertainty, zone_code, is_bycatch]
    const hsiEns = spCell[0];
    const hsiMaxEnt = spCell[1];
    const uncertainty = spCell[2];
    const zoneCode = spCell[3];
    const isBycatch = spCell[4];

    let fillColor = '#070d18';
    let fillOpacity = 0.55;

    if (layerMode === 'hsi_ens') {
      fillColor = getHsiColor(hsiEns);
      fillOpacity = hsiEns >= 0.2 ? 0.70 : 0.25;
    } else if (layerMode === 'hsi_maxent') {
      fillColor = getHsiColor(hsiMaxEnt);
      fillOpacity = hsiMaxEnt >= 0.2 ? 0.70 : 0.25;
    } else if (layerMode === 'uncertainty') {
      fillColor = getUncertaintyColor(uncertainty);
      fillOpacity = 0.65;
    } else if (layerMode === 'functional_zones') {
      fillColor = getZoneColor(zoneCode);
      fillOpacity = zoneCode > 0 ? 0.75 : 0.15;
    }

    const bounds = [
      [base.lat - 0.025, base.lon - 0.025],
      [base.lat + 0.025, base.lon + 0.025]
    ];

    const rect = L.rectangle(bounds, {
      color: fillColor,
      weight: 0.3,
      fillColor: fillColor,
      fillOpacity: fillOpacity
    });

    const zoneName = window.SDM_DATA.zoneDict[zoneCode] || 'General Oceanic Matrix';
    const bycatchText = isBycatch === 1 ? '<br><span style="color:#f43f5e; font-weight:bold;">⚠️ High Bycatch Risk (Elasmobranchs)</span>' : '';

    rect.bindPopup(
      '<b>Inspeksi Sel SDM // ' + species.toUpperCase() + '</b><br>' +
      'Koordinat: ' + base.lat.toFixed(2) + '° S, ' + base.lon.toFixed(2) + '° E<br>' +
      '<hr style="margin:4px 0; border:0; border-top:1px solid #334155;">' +
      '<b>Ensemble HSI: ' + hsiEns.toFixed(3) + '</b> (MaxEnt: ' + hsiMaxEnt.toFixed(3) + ')<br>' +
      'Ketidakpastian Model (σ): ±' + uncertainty.toFixed(3) + '<br>' +
      '<b>Zonasi: ' + zoneName + '</b>' + bycatchText + '<br>' +
      '<hr style="margin:4px 0; border:0; border-top:1px solid #334155;">' +
      'SST: ' + base.sst.toFixed(2) + ' °C | Chl-a: ' + base.chl.toFixed(3) + ' mg/m³<br>' +
      'Front: ' + base.fr.toFixed(3) + ' °C/km | Kedalaman: ' + base.d + ' m<br>' +
      'Jarak dari PPN Prigi: ' + base.nm.toFixed(1) + ' NM'
    );

    sdmGridLayerGroup.addLayer(rect);
  });

  // Render Bycatch overlay if checked
  if (document.getElementById('chkSdmBycatch').checked && window.SDM_DATA.bycatchFeatures) {
    window.SDM_DATA.bycatchFeatures.forEach(b => {
      const circ = L.circleMarker([b.lat, b.lon], {
        radius: 4,
        color: '#f43f5e',
        weight: 1.5,
        fillColor: '#f43f5e',
        fillOpacity: 0.8
      }).bindPopup(
        '<b>Zona Mitigasi Bycatch Dinamis</b><br>' +
        'Kedalaman: ' + b.d + ' m (Tubir Benua)<br>' +
        'SST: ' + b.sst.toFixed(2) + ' °C (Upwelling)<br>' +
        'Target Perlindungan: Hiu Cucut Tikus (Carcharhinus spp.)'
      );
      sdmBycatchLayerGroup.addLayer(circ);
    });
  }

  // Render Presence-Proxy if checked
  sdmPresenceLayerGroup.clearLayers();
  if (document.getElementById('chkSdmPresence').checked && window.SDM_DATA.compactPresence[species]) {
    window.SDM_DATA.compactPresence[species].forEach(p => {
      const pt = L.circleMarker([p.lat, p.lon], {
        radius: 3,
        color: '#ffffff',
        weight: 1,
        fillColor: '#00f2fe',
        fillOpacity: 0.9
      }).bindPopup('<b>Presence-Proxy Point</b><br>Kesesuaian Relung: ' + p.hsi);
      sdmPresenceLayerGroup.addLayer(pt);
    });
  }
}

function toggleSdmOverlay(layerName) {
  if (layerName === 'buffer') {
    if (document.getElementById('chkSdmBuffer').checked) sdmMapInstance.addLayer(sdmBufferLayerGroup);
    else sdmMapInstance.removeLayer(sdmBufferLayerGroup);
  } else if (layerName === 'shelf') {
    if (document.getElementById('chkSdmShelfBreak').checked) sdmMapInstance.addLayer(sdmShelfLayerGroup);
    else sdmMapInstance.removeLayer(sdmShelfLayerGroup);
  } else if (layerName === 'presence') {
    updateSdmSpatialLayer();
  } else if (layerName === 'bycatch') {
    updateSdmSpatialLayer();
  }
}

function renderSdmCharts() {
  if (typeof Plotly === 'undefined' || !window.SDM_DATA) return;
  const darkLayout = {
    paper_bgcolor: 'transparent',
    plot_bgcolor: 'rgba(14,23,42,0.4)',
    font: { family: 'Inter, system-ui, sans-serif', color: '#94a3b8', size: 11 },
    xaxis: { gridcolor: 'rgba(51,65,85,0.4)', zerolinecolor: 'rgba(51,65,85,0.6)' },
    yaxis: { gridcolor: 'rgba(51,65,85,0.4)', zerolinecolor: 'rgba(51,65,85,0.6)' }
  };

  const species = document.getElementById('selSdmSpecies').value;
  const scKeys = ['east_monsoon_jja', 'west_monsoon_djf', 'transition_1_mam', 'transition_2_son', 'super_positive_iod_2019', 'negative_iod_2016'];
  const scLabels = ['Musim Timur', 'Musim Barat', 'Peralihan 1', 'Peralihan 2', 'Super IOD 2019', 'Negative IOD 2016'];
  
  // 1. Seasonal HSI Comparison
  const hsiVals = scKeys.map(k => window.SDM_DATA.scenarios[k].species[species].mean_hsi);
  const suitPctVals = scKeys.map(k => window.SDM_DATA.scenarios[k].species[species].high_suitability_percent);

  Plotly.react('chartSdmSeasonalHsi', [{
    x: scLabels,
    y: hsiVals,
    name: 'Rata-rata HSI',
    type: 'bar',
    marker: { color: '#00f2fe' }
  }, {
    x: scLabels,
    y: suitPctVals,
    name: 'Area Sesuai (≥0.65) %',
    yaxis: 'y2',
    type: 'scatter',
    mode: 'lines+markers',
    line: { color: '#10b981', width: 2.5 }
  }], Object.assign({}, darkLayout, {
    yaxis: { title: 'Nilai HSI (0 - 1)', range: [0, 1] },
    yaxis2: { title: 'Cakupan Area (%)', overlaying: 'y', side: 'right', range: [0, 100] },
    legend: { orientation: 'h', y: -0.25 },
    margin: { t: 20, r: 60, l: 50, b: 40 }
  }), { responsive: true, displaylogo: false });

  // 2. Model Evaluation (AUC & TSS)
  const evalData = window.SDM_DATA.evaluations[species];
  if (evalData) {
    const models = ['MaxEnt', 'Random Forest', 'GLM', 'Ensemble'];
    const aucs = [evalData.individual_models.maxent.auc, evalData.individual_models.random_forest.auc, evalData.individual_models.glm.auc, evalData.ensemble.auc];
    const tsss = [evalData.individual_models.maxent.tss, evalData.individual_models.random_forest.tss, evalData.individual_models.glm.tss, evalData.ensemble.tss];

    Plotly.react('chartSdmModelAuc', [{
      x: models,
      y: aucs,
      name: 'AUC Score',
      type: 'bar',
      marker: { color: '#fbbf24' }
    }, {
      x: models,
      y: tsss,
      name: 'TSS Score',
      type: 'bar',
      marker: { color: '#38bdf8' }
    }], Object.assign({}, darkLayout, {
      yaxis: { title: 'Score (0 - 1)', range: [0, 1.05] },
      barmode: 'group',
      legend: { orientation: 'h', y: -0.25 },
      margin: { t: 20, r: 20, l: 50, b: 40 }
    }), { responsive: true, displaylogo: false });
  }

  // 3. Response Curves
  const rc = window.SDM_DATA.responseCurves;
  if (rc) {
    Plotly.react('chartSdmResponseCurve', [{
      x: rc.sst.x,
      y: rc.sst[species],
      name: 'Thermal Niche (SST °C)',
      type: 'scatter',
      mode: 'lines',
      line: { color: '#f43f5e', width: 2.5 }
    }, {
      x: rc.chla.x.map(v => v * 10), // scaled for display
      y: rc.chla[species],
      name: 'Trophic Niche (Chl-a x0.1 mg/m³)',
      type: 'scatter',
      mode: 'lines',
      line: { color: '#10b981', width: 2.5 }
    }, {
      x: rc.front.x.map(v => v * 100), // scaled for display
      y: rc.front[species],
      name: 'Front Gradient (Sobel x0.01 °C/km)',
      type: 'scatter',
      mode: 'lines',
      line: { color: '#a855f7', width: 2.5 }
    }], Object.assign({}, darkLayout, {
      xaxis: { title: 'Nilai Relung Lingkungan Terstandarisasi' },
      yaxis: { title: 'Kesesuaian Relung Relatif (0 - 1)', range: [0, 1.1] },
      legend: { orientation: 'h', y: -0.25 },
      margin: { t: 20, r: 20, l: 50, b: 40 }
    }), { responsive: true, displaylogo: false });
  }
}
`;

if (!html.includes('initSdmMap()')) {
  // Append sdmScript before </body>
  html = html.replace('</body>', '<script id="sdm-script">\n' + sdmScript + '\n</script>\n</body>');
  console.log('Appended sdmScript before </body>.');
}

fs.writeFileSync(indexPath, html, 'utf8');
console.log('Successfully updated html/index.html with Phase 3 SDM components.');
