import pandas as pd
import datetime

df = pd.read_csv("reports/CFSV2_TIMESTAMP_RECONCILIATION_2015_2025.csv")
missing = df[df['frame_status'] == 'MISSING_FRAME']
invalid = df[df['frame_status'] == 'PRESENT_INVALID']

print("// MISSING_FRAMES (exactly 11 frames)")
print("MISSING_FRAMES: [")
for _, r in missing.iterrows():
    dt = datetime.datetime.strptime(r['timestamp'], '%Y-%m-%d %H:%M').replace(tzinfo=datetime.timezone.utc)
    ms = int(dt.timestamp() * 1000)
    print(f'  {{t_ms: {ms}, timestamp: "{r["timestamp"]}", note: "{r["notes"]}"}},')
print("],")

print("\n// INVALID_FRAMES (exactly 21 frames)")
print("INVALID_FRAMES: [")
for _, r in invalid.iterrows():
    dt = datetime.datetime.strptime(r['timestamp'], '%Y-%m-%d %H:%M').replace(tzinfo=datetime.timezone.utc)
    ms = int(dt.timestamp() * 1000)
    print(f'  {{t_ms: {ms}, timestamp: "{r["timestamp"]}", reason: "{r["qc_flag"]}"}},')
print("],")

