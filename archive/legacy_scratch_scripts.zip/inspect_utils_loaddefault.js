const fs = require('fs');
const prigiDir = 'C:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis';
const utils = fs.readFileSync(prigiDir + '/utils.py', 'utf8');
const ldIdx = utils.indexOf('def _load_default');
console.log(utils.substring(ldIdx, ldIdx + 800));
