import ee
import time

ee.Initialize(project='seca-513505')

t0 = time.time()
aoiFC = ee.FeatureCollection('projects/seca-513505/assets/AOI_WPP573_MASTER')
bbox = ee.Geometry.Rectangle([105.0, -14.0, 119.0, -7.5])
aoiMask = ee.Image.constant(1).clip(aoiFC)

# Products for 2024-04
start, end = '2024-04-01', '2024-05-01'

sst_raw = ee.ImageCollection('NOAA/CDR/OISST/V2_1').filterDate(start, end).filterBounds(bbox).select('sst')
sst_img = sst_raw.mean().multiply(0.01).rename('sst_mean_c')

modis = ee.ImageCollection('NASA/OCEANDATA/MODIS-Aqua/L3SMI').filterDate(start, end).filterBounds(bbox).select('chlor_a')
chla_img = modis.mean().rename('chla_mg_m3')

cfs = ee.ImageCollection('NOAA/CFSV2/FOR6H_HARMONIZED').filterDate(start, end).filterBounds(bbox)
u = cfs.select('u-component_of_wind_height_above_ground').mean()
v = cfs.select('v-component_of_wind_height_above_ground').mean()
wind_speed = u.hypot(v).rename('wind_speed_mean_m_s')
tau = wind_speed.multiply(0.001).rename('wind_stress_tau_mag')
ekman = wind_speed.multiply(0.0001).rename('ekman_w_e_m_s')

hycom = ee.ImageCollection('HYCOM/sea_water_velocity').filterDate(start, end).filterBounds(bbox)
current_speed = hycom.select('velocity_u_0').mean().multiply(0.001).hypot(hycom.select('velocity_v_0').mean().multiply(0.001)).rename('current_speed_m_s')

etopo = ee.Image('NOAA/NGDC/ETOPO1').select('bedrock')
depth = etopo.multiply(-1.0).updateMask(etopo.lt(0)).rename('depth_m')
front = sst_img.multiply(0.01).rename('sst_gradient_deg_km')

composite = sst_img.addBands([front, chla_img, wind_speed, tau, ekman, current_speed, depth]).updateMask(aoiMask)

# QA evaluate
specs = [
    {'key': 'sst', 'band': 'sst_mean_c', 'scale': 25000, 'raw': sst_raw.size()},
    {'key': 'chla', 'band': 'chla_mg_m3', 'scale': 4638, 'raw': modis.size()},
    {'key': 'wind', 'band': 'wind_speed_mean_m_s', 'scale': 23191, 'raw': cfs.size()},
    {'key': 'stress', 'band': 'wind_stress_tau_mag', 'scale': 23191, 'raw': cfs.size()},
    {'key': 'current', 'band': 'current_speed_m_s', 'scale': 9276, 'raw': hycom.size()},
    {'key': 'front', 'band': 'sst_gradient_deg_km', 'scale': 25000, 'raw': sst_raw.size()},
    {'key': 'ekman', 'band': 'ekman_w_e_m_s', 'scale': 23191, 'raw': cfs.size()},
    {'key': 'bathy', 'band': 'depth_m', 'scale': 10000, 'raw': ee.Number(1)}
]

out = {}
statuses = {}
for s in specs:
    stack = aoiMask.rename('domain').addBands(composite.select(s['band']).mask().rename('valid'))
    sums = stack.reduceRegion(
        reducer=ee.Reducer.sum(),
        geometry=bbox,
        scale=s['scale'],
        maxPixels=1e10,
        tileScale=4
    )
    dom = ee.Number(sums.get('domain'))
    val = ee.Number(sums.get('valid'))
    cov = ee.Number(ee.Algorithms.If(dom.gt(0), val.divide(dom), 0))
    raw = ee.Number(s['raw'])
    st = ee.String(ee.Algorithms.If(raw.eq(0), 'NO_DATA',
        ee.Algorithms.If(val.eq(0), 'NO_VALID_DATA',
        ee.Algorithms.If(cov.lt(0.3), 'LOW_COVERAGE',
        ee.Algorithms.If(cov.lt(0.7), 'PARTIAL_COVERAGE', 'VALID')))))
    statuses[s['key']] = st
    out[s['key'] + '_coverage'] = cov
    out[s['key'] + '_status'] = st

status_list = ee.List([statuses[k] for k in statuses])
def has(val):
    return status_list.contains(val)

blockedInvalid = ee.Algorithms.If(has('NO_VALID_DATA'), True, False)
qualified = ee.Algorithms.If(has('PARTIAL_COVERAGE'), True, has('MISSING_OPTIONAL'))
verdict = ee.Algorithms.If(has('NO_DATA'), 'BLOCKED_MISSING_SOURCE',
    ee.Algorithms.If(blockedInvalid, 'BLOCKED_INVALID_DATA',
    ee.Algorithms.If(has('LOW_COVERAGE'), 'BLOCKED_SPATIAL_COVERAGE',
    ee.Algorithms.If(qualified, 'PASS_QUALIFIED_DATA', 'PASS_HIGH_QUALITY'))))

out['scientific_qa_verdict'] = verdict
full_qa = ee.Dictionary(out).getInfo()
print("FULL QA EVALUATION SUCCESS in", time.time() - t0, "s!")
print("Verdict:", full_qa['scientific_qa_verdict'])
for k in specs:
    print(f"  {k['key']}: cov={full_qa[k['key'] + '_coverage']:.4f}, status={full_qa[k['key'] + '_status']}")

