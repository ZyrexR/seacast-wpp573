import ee

ee.Initialize(project="seca-513505")

aoiFC = ee.FeatureCollection("projects/seca-513505/assets/AOI_WPP573_MASTER")
rawGeom = aoiFC.first().geometry()

polys = rawGeom.geometries().map(
    lambda g: ee.Algorithms.If(
        ee.Geometry(g).type().equals("Polygon"), g, None
    )
).removeAll([None])
polyCoords = polys.map(lambda p: ee.Geometry(p).coordinates())
cleanGeom = ee.Geometry(
    ee.Algorithms.If(
        rawGeom.type().equals("GeometryCollection"),
        ee.Algorithms.If(
            polys.size().gt(1),
            ee.Geometry.MultiPolygon(polyCoords),
            ee.Algorithms.If(polys.size().eq(1), polys.get(0), rawGeom),
        ),
        rawGeom,
    )
)
geom = cleanGeom

gridFC = ee.FeatureCollection("projects/seca-513505/assets/GRID_010_REGIONAL_8129")
firstProps = gridFC.first().propertyNames().getInfo()
print("firstProps:", firstProps, flush=True)

aoiFracProp = (
    "aoi_fract"
    if "aoi_fract" in firstProps
    else (
        "aoi_fraction"
        if "aoi_fraction" in firstProps
        else "aoi_intersection_fraction"
    )
)
print("aoiFracProp selected:", aoiFracProp, flush=True)

# Test withArea and rec
try:
  print("Testing withArea...", flush=True)

  def with_area_fn(f):
    km2 = ee.Algorithms.If(
        f.get("cell_km2"),
        f.get("cell_km2"),
        ee.Algorithms.If(
            f.get("cell_area_km2"),
            f.get("cell_area_km2"),
            f.geometry().area(1).divide(1e6),
        ),
    )
    return f.set("_cell_km2", ee.Number(km2))

  withArea = gridFC.map(with_area_fn)

  def rec_fn(f):
    frac = ee.Number(
        ee.Algorithms.If(
            f.get(aoiFracProp),
            f.get(aoiFracProp),
            ee.Algorithms.If(
                f.get("aoi_fract"),
                f.get("aoi_fract"),
                ee.Algorithms.If(f.get("aoi_fraction"), f.get("aoi_fraction"), 0),
            ),
        )
    )
    return f.set("_aoi_km2", frac.multiply(ee.Number(f.get("_cell_km2"))))

  rec_val = withArea.map(rec_fn).aggregate_sum("_aoi_km2").getInfo()
  print("rec_val success:", rec_val, flush=True)
except Exception as e:
  print("rec_val FAILED:", e, flush=True)

# Test sample
try:
  print("Testing samp...", flush=True)
  sampleLimit = 10
  sample_cells = withArea.sort("cell_id").limit(sampleLimit)

  def samp_fn(f):
    geomType = f.geometry().type()
    is_poly = ee.Algorithms.If(
        geomType.equals("Polygon"),
        1,
        ee.Algorithms.If(geomType.equals("MultiPolygon"), 1, 0),
    )
    inter = ee.Number(
        ee.Algorithms.If(
            ee.Number(is_poly).eq(1),
            f.geometry().intersection(geom, 10).area(10).divide(1e6),
            ee.Number(f.get("_cell_km2")).multiply(
                ee.Number(
                    ee.Algorithms.If(
                        f.get(aoiFracProp), f.get(aoiFracProp), 0
                    )
                )
            ),
        )
    )
    frac = inter.divide(ee.Number(f.get("_cell_km2")))
    propVal = ee.Number(
        ee.Algorithms.If(f.get(aoiFracProp), f.get(aoiFracProp), 0)
    )
    return f.set("_diff", frac.subtract(propVal).abs())

  sd_val = sample_cells.map(samp_fn).aggregate_max("_diff").getInfo()
  print("sd_val success:", sd_val, flush=True)
except Exception as e:
  print("sd_val FAILED:", e, flush=True)

