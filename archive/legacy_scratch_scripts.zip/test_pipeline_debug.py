import ee
import time

ee.Initialize(project='seca-513505')

t_start = time.time()
aoiFC = ee.FeatureCollection('projects/seca-513505/assets/AOI_WPP573_MASTER')
bbox = ee.Geometry.Rectangle([105.0, -14.0, 119.0, -7.5])

# Build minimal pipeline for 2024-04
start, end = '2024-04-01', '2024-05-01'

# 1. SST
sst_raw = ee.ImageCollection('NOAA/CDR/OISST/V2_1').filterDate(start, end).filterBounds(bbox).select('sst')
sst_img = sst_raw.mean().multiply(0.01).rename('sst_mean_c')

# 2. CHLA
modis = ee.ImageCollection('NASA/OCEANDATA/MODIS-Aqua/L3SMI').filterDate(start, end).filterBounds(bbox).select('chlor_a')
chla_img = modis.mean().rename('chla_mg_m3')

# 3. CFSV2
cfs = ee.ImageCollection('NOAA/CFSV2/FOR6H_HARMONIZED').filterDate(start, end).filterBounds(bbox)
u = cfs.select('u-component_of_wind_height_above_ground').mean()
v = cfs.select('v-component_of_wind_height_above_ground').mean()
wind_speed = u.hypot(v).rename('wind_speed_mean_m_s')
tau = wind_speed.multiply(0.001).rename('wind_stress_tau_mag')
ekman = wind_speed.multiply(0.0001).rename('ekman_w_e_m_s')

# 4. HYCOM
hycom = ee.ImageCollection('HYCOM/sea_water_velocity').filterDate(start, end).filterBounds(bbox)
hycom_u = hycom.select('velocity_u_0').mean().multiply(0.001)
hycom_v = hycom.select('velocity_v_0').mean().multiply(0.001)
current_speed = hycom_u.hypot(hycom_v).rename('current_speed_m_s')

# 5. ETOPO1
etopo = ee.Image('NOAA/NGDC/ETOPO1').select('bedrock')
depth = etopo.multiply(-1.0).updateMask(etopo.lt(0)).rename('depth_m')

# Stack
composite = sst_img.addBands([chla_img, wind_speed, tau, ekman, current_speed, depth]).clip(aoiFC)

# QA Evaluation: evaluate each band
vars_to_test = [
    ('sst', 'sst_mean_c', 25000),
    ('chla', 'chla_mg_m3', 4638),
    ('wind', 'wind_speed_mean_m_s', 23191),
    ('stress', 'wind_stress_tau_mag', 23191),
    ('current', 'current_speed_m_s', 9276),
    ('bathy', 'depth_m', 20000),
]

qa_results = {}
for name, band, scale in vars_to_test:
    t0 = time.time()
    # Mask of the band inside AOI
    b_mask = composite.select(band).mask()
    stack = ee.Image.constant(1).rename('domain').addBands(b_mask.rename('valid'))
    sums = stack.reduceRegion(
        reducer=ee.Reducer.sum(),
        geometry=bbox,
        scale=scale,
        maxPixels=1e10,
        tileScale=4
    ).getInfo()
    qa_results[name] = sums
    print(f"{name} ({scale}m):", sums, f"took {time.time()-t0:.2f}s")

print(f"Total QA time: {time.time() - t_start:.2f}s")

