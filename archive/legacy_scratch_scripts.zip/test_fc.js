var fs = require('fs');
var code = fs.readFileSync('scratch/ee_api_js.js', 'utf8');
var algos = JSON.parse(fs.readFileSync('scratch/algorithms.json', 'utf8'));

var target = 'a=new J(a);return a.handle(a.Gc().list(oj(),{prettyPrint:!1}).then(pk))';
var repl = 'if (typeof a === "function") a(global.__mock_algos); return global.__mock_algos;';
code = code.replace(target, repl);

global.__mock_algos = algos;
var vm = require('vm');
var ctx = {
  console: console,
  setTimeout: setTimeout,
  clearTimeout: clearTimeout,
  global: null,
  globalThis: null,
  window: null,
  module: { exports: {} }
};
ctx.global = ctx;
ctx.globalThis = ctx;
ctx.window = ctx;
vm.createContext(ctx);
vm.runInContext(code, ctx);

var ee = ctx.ee || ctx.window.ee;
console.log('Testing FeatureCollection with ee...');
try {
  var aoiFC = ee.FeatureCollection('projects/seca-513505/assets/AOI_WPP573_MASTER');
  console.log('SUCCESS! aoiFC:', aoiFC.name());
} catch (e) {
  console.error('CRASHED WITH:', e);
}

