import json
import glob
from pathlib import Path

zones_dir = Path(r"C:\Users\ThinkPad\.gemini\antigravity\scratch\prigi-pelagis\outputs\sdm\zones")
MIN_LON, MAX_LON = 111.0, 113.0
MIN_LAT, MAX_LAT = -10.45, -8.00

geojson_files = list(zones_dir.glob("*.geojson"))
print(f"Found {len(geojson_files)} GeoJSON layer files in outputs/sdm/zones/")

results = {}

for fpath in geojson_files:
    fname = fpath.name
    with open(fpath, "r", encoding="utf-8") as f:
        data = json.load(f)
    
    features = data.get("features", [])
    outside_features = []
    min_lons, max_lons = [], []
    min_lats, max_lats = [], []
    geom_types = set()
    
    for idx, feat in enumerate(features):
        geom = feat.get("geometry", {})
        g_type = geom.get("type")
        geom_types.add(g_type)
        coords = geom.get("coordinates", [])
        
        all_pts = []
        if g_type == "Polygon":
            for ring in coords:
                all_pts.extend(ring)
        elif g_type == "MultiPolygon":
            for poly in coords:
                for ring in poly:
                    all_pts.extend(ring)
        elif g_type == "Point":
            all_pts.append(coords)
        
        if not all_pts:
            continue
            
        f_min_lon = min(p[0] for p in all_pts)
        f_max_lon = max(p[0] for p in all_pts)
        f_min_lat = min(p[1] for p in all_pts)
        f_max_lat = max(p[1] for p in all_pts)
        
        min_lons.append(f_min_lon)
        max_lons.append(f_max_lon)
        min_lats.append(f_min_lat)
        max_lats.append(f_max_lat)
        
        # Check strict boundary violation
        if f_min_lon < MIN_LON or f_max_lon > MAX_LON or f_min_lat < MIN_LAT or f_max_lat > MAX_LAT:
            outside_features.append({
                "index": idx,
                "bbox": [f_min_lon, f_min_lat, f_max_lon, f_max_lat],
                "props": feat.get("properties", {})
            })
            
    results[fname] = {
        "feature_count": len(features),
        "geom_types": list(geom_types),
        "overall_bbox": [
            min(min_lons) if min_lons else None,
            min(min_lats) if min_lats else None,
            max(max_lons) if max_lons else None,
            max(max_lats) if max_lats else None
        ],
        "outside_count": len(outside_features),
        "sample_outside": outside_features[:3] if outside_features else []
    }

for k, v in results.items():
    print(f"\nLayer: {k}")
    print(f"  Features: {v['feature_count']}, Geometry: {v['geom_types']}")
    print(f"  Overall Bounding Box: Lon [{v['overall_bbox'][0]:.4f}, {v['overall_bbox'][2]:.4f}], Lat [{v['overall_bbox'][1]:.4f}, {v['overall_bbox'][3]:.4f}]")
    print(f"  Features outside [111.0, 113.0] x [-10.45, -8.00]: {v['outside_count']}")
    if v['sample_outside']:
        print(f"  Sample outside bbox: {v['sample_outside'][0]['bbox']}")
