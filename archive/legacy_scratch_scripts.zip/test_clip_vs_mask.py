import ee
import time

ee.Initialize(project="seca-513505")

aoiFC = ee.FeatureCollection("projects/seca-513505/assets/AOI_WPP573_MASTER")
aoiMask = ee.Image().paint(aoiFC, 1)

sst = (
    ee.ImageCollection("NOAA/CDR/OISST/V2_1")
    .filterDate("2024-04-01", "2024-05-01")
    .select("sst")
    .mean()
    .multiply(0.01)
)

t0 = time.time()
# Test 1: clip with raw geom (has 1398 holes)
rawGeom = aoiFC.first().geometry()
polys = rawGeom.geometries().map(
    lambda g: ee.Algorithms.If(
        ee.Geometry(g).type().equals("Polygon"), g, None
    )
).removeAll([None])
polyCoords = polys.map(lambda p: ee.Geometry(p).coordinates())
geom = ee.Geometry(ee.Geometry.MultiPolygon(polyCoords))

# Clip with geom
img_clip = sst.clip(geom)
try:
  v1 = (
      img_clip.reduceRegion(
          reducer=ee.Reducer.mean(),
          geometry=geom,
          scale=25000,
          maxPixels=1e9,
          tileScale=4,
      )
      .get("sst")
      .getInfo()
  )
  print(f"clip(geom) took {time.time()-t0:.2f}s, val={v1}", flush=True)
except Exception as e:
  print(f"clip(geom) failed in {time.time()-t0:.2f}s: {e}", flush=True)

# Test 2: mask with aoiMask
t0 = time.time()
img_mask = sst.updateMask(aoiMask)
try:
  v2 = (
      img_mask.reduceRegion(
          reducer=ee.Reducer.mean(),
          geometry=aoiFC.geometry(),
          scale=25000,
          maxPixels=1e9,
          tileScale=4,
      )
      .get("sst")
      .getInfo()
  )
  print(f"updateMask(aoiMask) took {time.time()-t0:.2f}s, val={v2}", flush=True)
except Exception as e:
  print(f"updateMask failed in {time.time()-t0:.2f}s: {e}", flush=True)

