// Script to remediate dashboard labels and evaluations summary
const fs = require('fs');
const path = require('path');

const prigiDir = 'C:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis';

// 1. Remediate model_evaluations_summary.json
const evalPath = path.join(prigiDir, 'models/sdm/ensemble/model_evaluations_summary.json');
const evals = JSON.parse(fs.readFileSync(evalPath, 'utf8'));

evals.cakalang.ensemble.status = 'MODERATELY_ACCURATE (0.70 <= AUC < 0.80)';
evals.madidihang.ensemble.status = 'MODERATELY_ACCURATE (0.70 <= AUC < 0.80)';
evals.albakor.ensemble.status = 'HIGHLY_ACCURATE (AUC >= 0.85)';

evals.cakalang.individual_models.maxent.note = 'Heuristic proxy validation; TSS constrained by thresholding';
evals.madidihang.individual_models.maxent.note = 'Heuristic proxy validation; TSS constrained by thresholding';
evals.albakor.individual_models.maxent.note = 'MaxEnt weight set to 0.000 due to poor performance on fragmented cold tongue';

fs.writeFileSync(evalPath, JSON.stringify(evals, null, 2), 'utf8');
console.log('Successfully updated model_evaluations_summary.json');

// 2. Re-run optimize_sdm_web_bundle.js to update html/sdm_data.js
require('./optimize_sdm_web_bundle.js');
console.log('Successfully regenerated html/sdm_data.js');

// 3. Remediate html/index.html
const indexHtmlPath = path.join(prigiDir, 'html/index.html');
let indexHtml = fs.readFileSync(indexHtmlPath, 'utf8');

// Replacement 1: Select options for SDM Layer Mode
indexHtml = indexHtml.replace(
  '<option value="hsi_ens">Ensemble HSI (Kesesuaian Habitat 0.00 - 1.00)</option>',
  '<option value="hsi_ens">Ensemble Relative HSI (RHSI 0.00 - 1.00)</option>'
);
indexHtml = indexHtml.replace(
  '<option value="hsi_maxent">MaxEnt Model HSI</option>',
  '<option value="hsi_maxent">MaxEnt Model RHSI</option>'
);
indexHtml = indexHtml.replace(
  '<option value="functional_zones">Zonasi Fungsional Ekologis (5 Kategori)</option>',
  '<option value="functional_zones">Zonasi Fungsional Ekologis (5 Kategori Screening)</option>'
);

// Replacement 2: Checkbox labels
indexHtml = indexHtml.replace(
  '<label><input type="checkbox" id="chkSdmBycatch" checked onchange="toggleSdmOverlay(\'bycatch\')"> Zona Mitigasi Bycatch</label>',
  '<label><input type="checkbox" id="chkSdmBycatch" checked onchange="toggleSdmOverlay(\'bycatch\')"> Zona Penapisan Mitigasi Bycatch (Advisory)</label>'
);

// Replacement 3: KPI Labels
indexHtml = indexHtml.replace(
  '<div class="kpi-lbl">Rata-rata HSI Regional</div>',
  '<div class="kpi-lbl">Rata-rata RHSI Sub-AOI Prigi</div>'
);
indexHtml = indexHtml.replace(
  '<div class="kpi-lbl">Cakupan Area HSI Tinggi (≥0.65)</div>',
  '<div class="kpi-lbl">Cakupan Area RHSI Tinggi (≥0.65)</div>'
);

// Replacement 4: Map Panel Title & Legend
indexHtml = indexHtml.replace(
  'Peta Prediksi Habitat Suitability Index (HSI) & Zonasi Dinamis // WPPNRI 573 × PPN Prigi',
  'Peta Advisory Relative Habitat Suitability Index (RHSI) & Zonasi Dinamis // Sub-AOI Prigi'
);
indexHtml = indexHtml.replace(
  '<span style="display:inline-block; width:12px; height:12px; background:#10b981; border-radius:2px; vertical-align:middle; margin-right:4px;"></span>Sangat Sesuai (≥0.65)',
  '<span style="display:inline-block; width:12px; height:12px; background:#10b981; border-radius:2px; vertical-align:middle; margin-right:4px;"></span>Kesesuaian Relatif Tinggi (RHSI ≥0.65)'
);

// Replacement 5: Popup strings
indexHtml = indexHtml.replace(
  '\'<br><span style="color:#f43f5e; font-weight:bold;">⚠️ High Bycatch Risk (Elasmobranchs)</span>\'',
  '\'<br><span style="color:#f43f5e; font-weight:bold;">⚠️ Potensi Penapisan Bycatch (Carcharhinus spp.)</span>\''
);
indexHtml = indexHtml.replace(
  '\'<b>Ensemble HSI: \' + hsiEns.toFixed(3) + \'</b> (MaxEnt: \' + hsiMaxEnt.toFixed(3) + \')<br>\'',
  '\'<b>Ensemble RHSI: \' + hsiEns.toFixed(3) + \'</b> (MaxEnt RHSI: \' + hsiMaxEnt.toFixed(3) + \')<br>\''
);
indexHtml = indexHtml.replace(
  '\'<b>Zona Mitigasi Bycatch Dinamis</b><br>\'',
  '\'<b>Zona Penapisan Mitigasi Bycatch (Advisory)</b><br>\''
);
indexHtml = indexHtml.replace(
  '\'<b>Presence-Proxy Point</b><br>Kesesuaian Relung: \' + p.hsi',
  '\'<b>Heuristic Presence-Proxy Point</b><br>Kesesuaian Relung Heuristik: \' + p.hsi'
);

fs.writeFileSync(indexHtmlPath, indexHtml, 'utf8');
console.log('Successfully remediated html/index.html');
