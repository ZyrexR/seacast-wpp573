import ee

ee.Initialize(project="seca-513505")

# Check AOI
aoi_fc = ee.FeatureCollection("projects/seca-513505/assets/AOI_WPP573_MASTER")
raw_geom = aoi_fc.first().geometry()
geoms = raw_geom.geometries()
polys = geoms.map(lambda g: ee.Algorithms.If(ee.Geometry(g).type().equals("Polygon"), g, None)).removeAll([None])
poly_coords = polys.map(lambda p: ee.Geometry(p).coordinates())
clean_multipoly = ee.Geometry.MultiPolygon(poly_coords)

holes = clean_multipoly.coordinates().map(lambda p: ee.List(p).size().subtract(1)).reduce(ee.Reducer.sum()).getInfo()
print("Total holes:", holes)
area_km2 = clean_multipoly.area(1).divide(1e6).getInfo()
print("Geodesic area km2:", area_km2)

# Check Grid
grid_fc = ee.FeatureCollection("projects/seca-513505/assets/GRID_010_REGIONAL_8129")
print("Grid count:", grid_fc.size().getInfo())
first_grid = grid_fc.first()
props = first_grid.propertyNames().getInfo()
print("First grid props:", props)
for p in props:
    if not p.startswith("system:"):
        print(f"  {p}: {first_grid.get(p).getInfo()}")

# Let's test the grid AOI sum
# We need to see how cell area and aoi_fraction are structured
# In grid_fc, what are the property names for cell area and aoi fraction?
# Let's test the reconciliation
def calc_aoi_sum(f):
    # check if 'aoi_fraction' or similar exists
    frac = ee.Number(ee.Algorithms.If(f.get('aoi_fraction'), f.get('aoi_fraction'), 0))
    ar = f.geometry().area(1).divide(1e6)
    return f.set('_aoi_km2', frac.multiply(ar))

grid_sum = grid_fc.map(calc_aoi_sum).aggregate_sum('_aoi_km2').getInfo()
print("Grid aggregate AOI km2 (using geodesic area):", grid_sum)

# If using cell_km2 property if present:
if 'cell_km2' in props:
    def calc_aoi_sum_prop(f):
        frac = ee.Number(ee.Algorithms.If(f.get('aoi_fraction'), f.get('aoi_fraction'), 0))
        ar = ee.Number(f.get('cell_km2'))
        return f.set('_aoi_km2', frac.multiply(ar))
    grid_sum_prop = grid_fc.map(calc_aoi_sum_prop).aggregate_sum('_aoi_km2').getInfo()
    print("Grid aggregate AOI km2 (using cell_km2 prop):", grid_sum_prop)

# Test sample intersection
sample_cells = grid_fc.sort("cell_id").limit(10)
def check_sample(f):
    inter = f.geometry().intersection(clean_multipoly, 10).area(10).divide(1e6)
    cell_ar = f.geometry().area(10).divide(1e6)
    frac = inter.divide(cell_ar)
    prop_frac = ee.Number(ee.Algorithms.If(f.get('aoi_fraction'), f.get('aoi_fraction'), 0))
    return f.set('_diff', frac.subtract(prop_frac).abs())

max_diff = sample_cells.map(check_sample).aggregate_max('_diff').getInfo()
print("Max diff on sample cells:", max_diff)

