// Script to embed the 5 mandatory CITES taxonomic fields into dynamic_bycatch_mitigation_zones.geojson
const fs = require('fs');
const path = require('path');

const prigiDir = 'C:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis';
const bcPath = path.join(prigiDir, 'outputs/sdm/zones/dynamic_bycatch_mitigation_zones.geojson');
const bcData = JSON.parse(fs.readFileSync(bcPath, 'utf8'));

bcData.metadata.cites_framework_version = 'CITES Appendices (CoP19 / Notification 2026/015 in effect 5 March 2026)';
bcData.metadata.family_carcharhinidae_listing = 'Appendix II (Family-level Carcharhinidae spp., with exception of species included in Appendix I)';
bcData.metadata.species_appendix_1_exception = 'Carcharhinus longimanus (Oceanic whitetip shark) listed on Appendix I (effective 5 March 2026)';
bcData.metadata.identification_caution = 'Landing records identified only as Carcharhinus spp. must not be automatically assigned Appendix I or Appendix II at the species level without verified diagnostic taxonomy';

bcData.features.forEach(f => {
  f.properties.identified_taxon_name = 'Carcharhinus spp. (Ikan Cucut / Hiu Tikus)';
  f.properties.taxonomic_resolution_level = 'Genus';
  f.properties.cites_status_and_appendices_date = 'CITES Appendix II (Family Carcharhinidae spp. listing; Appendices in effect 5 March 2026; App I exception check required)';
  f.properties.identification_verification_status = 'Unverified Port Landing Record (TPI Prigi - Morphological inspection not conducted)';
  f.properties.taxonomic_uncertainty_notes = 'Identified only to genus level in port statistics. Cannot be conclusively differentiated between C. falciformis (App II) or C. longimanus (App I) without dentition/fin morphology or molecular DNA barcoding.';
});

fs.writeFileSync(bcPath, JSON.stringify(bcData, null, 2), 'utf8');
console.log('Successfully updated dynamic_bycatch_mitigation_zones.geojson with 5 CITES taxonomic fields.');

// Re-generate html/sdm_data.js
require('./optimize_sdm_web_bundle.js');
console.log('Successfully regenerated html/sdm_data.js');
