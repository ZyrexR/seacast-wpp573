// Update bycatch GeoJSON and HTML to conform with Protocols 2-5
const fs = require('fs');
const path = require('path');

const prigiDir = 'C:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis';

// 1. Update dynamic_bycatch_mitigation_zones.geojson
const bcPath = path.join(prigiDir, 'outputs/sdm/zones/dynamic_bycatch_mitigation_zones.geojson');
const bcData = JSON.parse(fs.readFileSync(bcPath, 'utf8'));

bcData.features.forEach(f => {
  f.properties.zone_name = 'Candidate Bathymetric Screening Polygons for Voluntary Shark Bycatch Review';
  f.properties.layer_type = 'Voluntary Bathymetric Screening Instrument (Non-Regulated / Non-Hotspot)';
  f.properties.target_species = 'Hiu Cucut (Carcharhinus spp.)';
  f.properties.recommended_mitigation = 'Pancing Rawai/Ulur: edukasi sukarela circle hooks (16/0-18/0); Pukat Cincin: edukasi non-entangling FADs & safe shark release; Tanpa pembatasan kedalaman operasional sepihak.';
});

fs.writeFileSync(bcPath, JSON.stringify(bcData, null, 2), 'utf8');
console.log('Successfully updated dynamic_bycatch_mitigation_zones.geojson');

// 2. Update html/index.html
const indexHtmlPath = path.join(prigiDir, 'html/index.html');
let indexHtml = fs.readFileSync(indexHtmlPath, 'utf8');

// Replace checkbox label
indexHtml = indexHtml.replace(
  '<label><input type="checkbox" id="chkSdmBycatch" checked onchange="toggleSdmOverlay(\'bycatch\')"> Zona Penapisan Mitigasi Bycatch (Advisory)</label>',
  '<label><input type="checkbox" id="chkSdmBycatch" checked onchange="toggleSdmOverlay(\'bycatch\')"> Candidate Bathymetric Screening Polygons (Voluntary Shark Review)</label>'
);

// Replace popup title
indexHtml = indexHtml.replace(
  '\'<b>Zona Penapisan Mitigasi Bycatch (Advisory)</b><br>\'',
  '\'<b>Candidate Bathymetric Screening Polygon (Voluntary Shark Review)</b><br>\''
);

// Replace popup note
indexHtml = indexHtml.replace(
  '\'Target Perlindungan: Hiu Cucut Tikus (Carcharhinus spp.)\'',
  '\'Target Edukasi: Hiu Cucut (Carcharhinus spp.)<br>Status: Skrining batimetri sukarela (Bukan hotspot / larangan)\''
);

fs.writeFileSync(indexHtmlPath, indexHtml, 'utf8');
console.log('Successfully updated html/index.html');

// 3. Regenerate html/sdm_data.js
require('./optimize_sdm_web_bundle.js');
console.log('Successfully regenerated html/sdm_data.js');
