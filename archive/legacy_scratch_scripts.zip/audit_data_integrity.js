const fs = require('fs');
const prigiDir = 'C:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis';

console.log('=== VERIFYING FISHERIES LANDINGS SUMS ===');
const csv = fs.readFileSync(prigiDir + '/data/master_prigi_all_inclusive.csv', 'utf8').trim().split('\n');
const header = csv[0].split(',');
const cIdx = header.indexOf('total_pelagis_kg');
const cakalangIdx = header.indexOf('cakalang_kg');
const madidihangIdx = header.indexOf('madidihang_kg');
const albakorIdx = header.indexOf('albakor_kg');
const tripsIdx = header.indexOf('total_trip_alat');

let totalPelagis = 0, totalCakalang = 0, totalMadidihang = 0, totalAlbakor = 0, totalTrips = 0;
for (let i = 1; i < csv.length; i++) {
  const row = csv[i].split(',');
  totalPelagis += parseFloat(row[cIdx]) || 0;
  totalCakalang += parseFloat(row[cakalangIdx]) || 0;
  totalMadidihang += parseFloat(row[madidihangIdx]) || 0;
  totalAlbakor += parseFloat(row[albakorIdx]) || 0;
  totalTrips += parseFloat(row[tripsIdx]) || 0;
}
console.log(`Months count: ${csv.length - 1}`);
console.log(`Total Pelagis: ${totalPelagis.toLocaleString()} kg`);
console.log(`Total Cakalang: ${totalCakalang.toLocaleString()} kg (${(totalCakalang*100/totalPelagis).toFixed(2)}%)`);
console.log(`Total Madidihang: ${totalMadidihang.toLocaleString()} kg (${(totalMadidihang*100/totalPelagis).toFixed(2)}%)`);
console.log(`Total Albakor: ${totalAlbakor.toLocaleString()} kg (${(totalAlbakor*100/totalPelagis).toFixed(2)}%)`);
console.log(`Total Trips: ${totalTrips.toLocaleString()} trips`);

console.log('\n=== VERIFYING OCEANOGRAPHIC 132M MASTER JSON ===');
const ocean132 = JSON.parse(fs.readFileSync(prigiDir + '/data/oceanographic/statistics/monthly/ocean_fisheries_master_132m.json', 'utf8'));
console.log(`ocean_fisheries_master_132m records: ${ocean132.length}`);
let sstMin = 999, sstMax = -999, chlMin = 999, chlMax = -999, missingCount = 0;
ocean132.forEach(r => {
  if (r.sst_prigi_coastal === undefined || r.chl_prigi === undefined) missingCount++;
  if (r.sst_prigi_coastal < sstMin) sstMin = r.sst_prigi_coastal;
  if (r.sst_prigi_coastal > sstMax) sstMax = r.sst_prigi_coastal;
  if (r.chl_prigi < chlMin) chlMin = r.chl_prigi;
  if (r.chl_prigi > chlMax) chlMax = r.chl_prigi;
});
console.log(`Missing fields count: ${missingCount}`);
console.log(`SST Coastal range: ${sstMin} to ${sstMax} °C`);
console.log(`Chl-a Prigi range: ${chlMin} to ${chlMax} mg/m³`);

console.log('\n=== VERIFYING PREDICTOR STACK SCENARIOS ===');
const pStack = JSON.parse(fs.readFileSync(prigiDir + '/data/sdm/predictors/predictor_stack_multi_scenario.json', 'utf8'));
console.log('Scenarios available:', Object.keys(pStack.scenarios));
for (let sc in pStack.scenarios) {
  const cells = pStack.scenarios[sc];
  console.log(`Scenario ${sc}: ${cells.length} cells`);
}

console.log('\n=== VERIFYING PRESENCE PROXIES & BACKGROUND ===');
const presSKJ = JSON.parse(fs.readFileSync(prigiDir + '/data/sdm/presence/presence_proxy_cakalang.geojson', 'utf8')).features;
const presYFT = JSON.parse(fs.readFileSync(prigiDir + '/data/sdm/presence/presence_proxy_madidihang.geojson', 'utf8')).features;
const presALB = JSON.parse(fs.readFileSync(prigiDir + '/data/sdm/presence/presence_proxy_albakor.geojson', 'utf8')).features;
const presBYC = JSON.parse(fs.readFileSync(prigiDir + '/data/sdm/presence/presence_proxy_bycatch_indicators.geojson', 'utf8')).features;
const bg = JSON.parse(fs.readFileSync(prigiDir + '/data/sdm/background/target_group_background.geojson', 'utf8')).features;
console.log(`Presence Cakalang: ${presSKJ.length}`);
console.log(`Presence Madidihang: ${presYFT.length}`);
console.log(`Presence Albakor: ${presALB.length}`);
console.log(`Presence Bycatch: ${presBYC.length}`);
console.log(`Background points: ${bg.length}`);

console.log('\n=== VERIFYING HSI PROJECTIONS ===');
const hsiProj = JSON.parse(fs.readFileSync(prigiDir + '/outputs/sdm/hsi/hsi_all_scenarios_projections.json', 'utf8'));
for (let sc in hsiProj) {
  console.log(`Scenario: ${sc}`);
  for (let sp in hsiProj[sc].species_hsi) {
    const s = hsiProj[sc].species_hsi[sp];
    console.log(`  ${sp}: Mean HSI = ${s.mean_hsi}, High Suitability = ${s.high_suitability_percent}% (${s.high_suitability_cells} cells)`);
  }
}
