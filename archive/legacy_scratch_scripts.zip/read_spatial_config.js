const fs = require('fs');
const prigiDir = 'C:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis';
console.log(fs.readFileSync(prigiDir + '/data/spatial_config_aoi.json', 'utf8'));
