// Script to build html/sdm_data.js standalone zero-CORS bundle
const fs = require('fs');
const path = require('path');

const prigiDir = 'C:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis';

const evaluations = JSON.parse(fs.readFileSync(path.join(prigiDir, 'models/sdm/ensemble/model_evaluations_summary.json'), 'utf8'));
const projections = JSON.parse(fs.readFileSync(path.join(prigiDir, 'outputs/sdm/hsi/hsi_all_scenarios_projections.json'), 'utf8'));
const presCakalang = JSON.parse(fs.readFileSync(path.join(prigiDir, 'data/sdm/presence/presence_proxy_cakalang.geojson'), 'utf8')).features;
const presMadidihang = JSON.parse(fs.readFileSync(path.join(prigiDir, 'data/sdm/presence/presence_proxy_madidihang.geojson'), 'utf8')).features;
const presAlbakor = JSON.parse(fs.readFileSync(path.join(prigiDir, 'data/sdm/presence/presence_proxy_albakor.geojson'), 'utf8')).features;
const bycatchGeoJSON = JSON.parse(fs.readFileSync(path.join(prigiDir, 'outputs/sdm/zones/dynamic_bycatch_mitigation_zones.geojson'), 'utf8'));

// Generate Response Curves for plotting
const responseCurves = {
  sst: {
    x: [],
    cakalang: [],
    madidihang: [],
    albakor: []
  },
  chla: {
    x: [],
    cakalang: [],
    madidihang: [],
    albakor: []
  },
  front: {
    x: [],
    cakalang: [],
    madidihang: [],
    albakor: []
  }
};

// Generate points for SST curve from 18 to 32 °C
for (let s = 18; s <= 32; s += 0.5) {
  responseCurves.sst.x.push(parseFloat(s.toFixed(1)));
  // Cakalang: center 26.8, width 1.8
  const cSst = Math.exp(-0.5 * Math.pow((s - 26.8) / 1.8, 2));
  responseCurves.sst.cakalang.push(parseFloat(cSst.toFixed(3)));
  // Madidihang: center 27.2, width 1.6
  const mSst = Math.exp(-0.5 * Math.pow((s - 27.2) / 1.6, 2));
  responseCurves.sst.madidihang.push(parseFloat(mSst.toFixed(3)));
  // Albakor: center 23.8, width 2.2
  const aSst = Math.exp(-0.5 * Math.pow((s - 23.8) / 2.2, 2));
  responseCurves.sst.albakor.push(parseFloat(aSst.toFixed(3)));
}

// Generate points for Chl-a curve from 0.05 to 2.5 mg/m³
for (let c = 0.05; c <= 2.5; c += 0.1) {
  responseCurves.chla.x.push(parseFloat(c.toFixed(2)));
  // Cakalang
  const cChl = c > 0.2 ? Math.min(1.0, (c - 0.2) / 0.5) : 0;
  responseCurves.chla.cakalang.push(parseFloat(cChl.toFixed(3)));
  // Madidihang
  const mChl = c > 0.15 ? Math.min(1.0, (c - 0.15) / 0.35) : 0;
  responseCurves.chla.madidihang.push(parseFloat(mChl.toFixed(3)));
  // Albakor
  const aChl = c > 0.2 ? Math.min(1.0, (c - 0.2) / 0.4) : 0;
  responseCurves.chla.albakor.push(parseFloat(aChl.toFixed(3)));
}

// Generate points for Front curve from 0 to 0.30 °C/km
for (let f = 0; f <= 0.30; f += 0.02) {
  responseCurves.front.x.push(parseFloat(f.toFixed(2)));
  responseCurves.front.cakalang.push(parseFloat(Math.min(1.0, f / 0.12).toFixed(3)));
  responseCurves.front.madidihang.push(parseFloat(Math.min(1.0, f / 0.10).toFixed(3)));
  responseCurves.front.albakor.push(parseFloat(Math.min(1.0, f / 0.08).toFixed(3)));
}

// Compact presence points for client rendering
const compactPresence = {
  cakalang: presCakalang.map(p => ({ lat: p.geometry.coordinates[1], lon: p.geometry.coordinates[0], hsi: p.properties.suitability_proxy })),
  madidihang: presMadidihang.map(p => ({ lat: p.geometry.coordinates[1], lon: p.geometry.coordinates[0], hsi: p.properties.suitability_proxy })),
  albakor: presAlbakor.map(p => ({ lat: p.geometry.coordinates[1], lon: p.geometry.coordinates[0], hsi: p.properties.suitability_proxy }))
};

// Bundle payload
const bundle = `// SEACAST PRIGI // PHASE 3 SDM & HABITAT SUITABILITY DATA BUNDLE
// Generated for standalone Zero-CORS browser execution

window.SDM_DATA = {
  evaluations: ${JSON.stringify(evaluations)},
  responseCurves: ${JSON.stringify(responseCurves)},
  compactPresence: ${JSON.stringify(compactPresence)},
  bycatchFeaturesCount: ${bycatchGeoJSON.features.length},
  bycatchFeatures: ${JSON.stringify(bycatchGeoJSON.features)},
  scenarios: ${JSON.stringify(projections)}
};

console.log("SEACAST PRIGI // Phase 3 SDM & Dynamic Habitat Suitability Bundle Loaded (6 Scenarios, 3 Species, Functional Zones).");
`;

fs.writeFileSync(path.join(prigiDir, 'html/sdm_data.js'), bundle, 'utf8');
const sizeKb = (Buffer.byteLength(bundle, 'utf8') / 1024).toFixed(1);
console.log(`Successfully built html/sdm_data.js (${sizeKb} KB).`);
