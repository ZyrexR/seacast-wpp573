import ee

ee.Initialize(project="seca-513505")

aoiFC = ee.FeatureCollection("projects/seca-513505/assets/AOI_WPP573_MASTER")
gridFC = ee.FeatureCollection("projects/seca-513505/assets/GRID_010_REGIONAL_8129")

# 1. AOI_LOAD
n = aoiFC.size().getInfo()
print("1. AOI_LOAD: features=", n)

# 2. AOI_GEOM & HOLES
rawGeom = aoiFC.first().geometry()
polys = rawGeom.geometries().map(
    lambda g: ee.Algorithms.If(
        ee.Geometry(g).type().equals("Polygon"), g, None
    )
).removeAll([None])
polyCoords = polys.map(lambda p: ee.Geometry(p).coordinates())
geom = ee.Geometry(
    ee.Algorithms.If(
        rawGeom.type().equals("GeometryCollection"),
        ee.Algorithms.If(
            polys.size().gt(1),
            ee.Geometry.MultiPolygon(polyCoords),
            ee.Algorithms.If(polys.size().eq(1), polys.get(0), rawGeom),
        ),
        rawGeom,
    )
)
holes = (
    ee.Number(
        ee.Algorithms.If(
            geom.type().equals("Polygon"),
            ee.List(geom.coordinates()).size().subtract(1),
            ee.List(geom.coordinates())
            .map(lambda p: ee.List(p).size().subtract(1))
            .reduce(ee.Reducer.sum()),
        )
    )
    .getInfo()
)
print("2. AOI_GEOM & HOLES: type=", geom.type().getInfo(), "holes=", holes)

# 3. AOI_AREA
a = geom.area(1).divide(1e6).getInfo()
rel_a = abs(a - 933749.49) / 933749.49
print(f"3. AOI_AREA: area_km2={a:.2f} rel_diff={rel_a:.6f}")

# 4. GRID_COUNT
gn = gridFC.size().getInfo()
print("4. GRID_COUNT: count=", gn)

# 5. GRID_IDS & CLASSES
firstProps = gridFC.first().propertyNames().getInfo()
aoiFracProp = "aoi_fract" if "aoi_fract" in firstProps else "aoi_fraction"
ids = ee.Dictionary({
    "n_ids": gridFC.aggregate_array("cell_id").size(),
    "n_unique": gridFC.aggregate_array("cell_id").distinct().size(),
    "classes": gridFC.aggregate_histogram("cell_class"),
}).getInfo()
print("5. GRID_IDS: ids=", ids["n_ids"], "unique=", ids["n_unique"])
print("6. GRID_CLASSES:", ids["classes"])

# 7. GRID_AOI_SUM
withArea = gridFC.map(lambda f: f.set(
    "_cell_km2",
    ee.Number(
        ee.Algorithms.If(
            f.get("cell_km2"),
            f.get("cell_km2"),
            ee.Algorithms.If(
                f.get("cell_area_km2"),
                f.get("cell_area_km2"),
                f.geometry().area(1).divide(1e6),
            ),
        )
    ),
))


def rec_fn(f):
  frac = ee.Number(
      ee.Algorithms.If(
          f.get(aoiFracProp),
          f.get(aoiFracProp),
          ee.Algorithms.If(
              f.get("aoi_fract"),
              f.get("aoi_fract"),
              ee.Algorithms.If(f.get("aoi_fraction"), f.get("aoi_fraction"), 0),
          ),
      )
  )
  return f.set("_aoi_km2", frac.multiply(ee.Number(f.get("_cell_km2"))))


rec_val = withArea.map(rec_fn).aggregate_sum("_aoi_km2").getInfo()
rel_sum = abs(rec_val - 933749.49) / 933749.49
print(f"7. GRID_AOI_SUM: sum_km2={rec_val:.2f} rel={rel_sum:.6f}")


# 8. GRID_AOI_SAMPLE
def sample_fn(f):
  frac = ee.Number(
      ee.Algorithms.If(
          f.get(aoiFracProp),
          f.get(aoiFracProp),
          ee.Algorithms.If(
              f.get("aoi_fract"),
              f.get("aoi_fract"),
              ee.Algorithms.If(f.get("aoi_fraction"), f.get("aoi_fraction"), 0),
          ),
      )
  )
  geom_area = f.geometry().area(1).divide(1e6)
  cell_km2 = ee.Number(f.get("_cell_km2"))
  area_rel_diff = geom_area.subtract(cell_km2).abs().divide(cell_km2)
  bounds_diff = ee.Number(
      ee.Algorithms.If(
          frac.lt(0), frac.abs(), ee.Algorithms.If(frac.gt(1), frac.subtract(1), 0)
      )
  )
  return f.set("_diff", area_rel_diff.max(bounds_diff))


sd_val = (
    withArea.sort("cell_id")
    .limit(10)
    .map(sample_fn)
    .aggregate_max("_diff")
    .getInfo()
)
print(f"8. GRID_AOI_SAMPLE: max_abs_diff={sd_val:.6f}")
print("\nALL PREFLIGHT CHECKS EXECUTED SUCCESSFULLY!")

