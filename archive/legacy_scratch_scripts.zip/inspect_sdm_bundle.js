const fs = require('fs');
const sdmData = fs.readFileSync('C:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis/html/sdm_data.js', 'utf8');
const prefix = 'window.SDM_DATA = ';
const jsonStr = sdmData.slice(sdmData.indexOf(prefix) + prefix.length).trim().replace(/;$/, '');
const obj = JSON.parse(jsonStr);
console.log('Top keys:', Object.keys(obj));
console.log('Evaluations:');
console.log(JSON.stringify(obj.evaluations, null, 2));
