import ee
import math
import numpy as np

ee.Initialize(project='seca-513505')

# Replicate CONFIG_MODULE constants
P_RHO_AIR = 1.225
P_RHO_SEAWATER = 1025.0
P_OMEGA = 7.2921e-5
P_R_EARTH = 6371000.0
P_CORIOLIS_MIN_ABS = 1.0e-5
P_DEG_M_EQ = 111319.49
P_METERS_PER_DEG_LAT = 111132.95
MERIDIAN_RATIO = P_METERS_PER_DEG_LAT / P_DEG_M_EQ
P_GCOM_C_SCALE_FACTOR = 0.0016
P_FRONT_THRESHOLD_C_KM = 0.05

def geoProj(deg):
    return ee.Projection('EPSG:4326').scale(deg, deg)

KX = ee.Kernel.fixed(3, 3, [[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]], -1, -1, False)
KY = ee.Kernel.fixed(3, 3, [[1, 2, 1], [0, 0, 0], [-1, -2, -1]], -1, -1, False)

def nativeGradients(img):
    proj = img.projection()
    native = img.reproject(proj)
    scaleM = ee.Number(proj.nominalScale())
    latRad = ee.Image.pixelLonLat().select('latitude').reproject(proj).multiply(math.pi / 180.0)
    dxM = latRad.cos().multiply(scaleM)
    dyM = ee.Image.constant(scaleM.multiply(MERIDIAN_RATIO))
    return {
        'native': native,
        'latRad': latRad,
        'ddx': native.convolve(KX).divide(dxM.multiply(8.0)),
        'ddy': native.convolve(KY).divide(dyM.multiply(8.0))
    }

def computeThermalFront(sstMean):
    g = nativeGradients(sstMean.select('sst_mean_c'))
    dx = g['ddx'].multiply(1000.0).rename('sst_dTdx_c_km')
    dy = g['ddy'].multiply(1000.0).rename('sst_dTdy_c_km')
    mag = dx.pow(2).add(dy.pow(2)).sqrt().rename('sst_gradient_deg_km')
    flag = mag.gte(P_FRONT_THRESHOLD_C_KM).rename('thermal_front_flag')
    return dx.addBands([dy, mag, flag])

def fromTau(tauX, tauY):
    gx = nativeGradients(tauX)
    gy = nativeGradients(tauY)
    curl = gy['ddx'].subtract(gx['ddy']).rename('wind_stress_curl')
    latRad = gy['latRad']
    f = latRad.sin().multiply(2.0 * P_OMEGA).rename('coriolis_f')
    safeF = f.updateMask(f.abs().gte(P_CORIOLIS_MIN_ABS))
    beta = latRad.cos().multiply(2.0 * P_OMEGA / P_R_EARTH).rename('beta_param')
    tauXn = gx['native']
    termCurl = curl.divide(safeF.multiply(P_RHO_SEAWATER))
    termBeta = beta.multiply(tauXn).divide(safeF.pow(2).multiply(P_RHO_SEAWATER))
    w = termCurl.add(termBeta).rename('ekman_w_e_m_s')
    return curl.addBands([f, beta, w, w.multiply(86400.0).rename('ekman_w_e_m_day'),
                          w.gt(0).rename('upwelling_favorable_flag')])

def test_thermal():
    print("Testing thermalTests()...")
    proj = geoProj(0.25)
    ll = ee.Image.pixelLonLat().reproject(proj)
    s_lon = ll.select('longitude')
    s_lat = ll.select('latitude')
    P0 = [111.7275, -8.2833]
    
    cases = [
      {'n': 'east',  'f': s_lon.multiply(0.5),  'ax': 'x', 'sign': 1},
      {'n': 'west',  'f': s_lon.multiply(-0.5), 'ax': 'x', 'sign': -1},
      {'n': 'north', 'f': s_lat.multiply(0.5),  'ax': 'y', 'sign': 1},
      {'n': 'south', 'f': s_lat.multiply(-0.5), 'ax': 'y', 'sign': -1},
      {'n': 'zero',  'f': ee.Image.constant(28).add(s_lon.multiply(0)), 'ax': 'x', 'sign': 0}
    ]
    
    for c in cases:
        img = c['f'].rename('sst_mean_c').reproject(proj)
        g = computeThermalFront(img)
        r = g.addBands(s_lat.rename('lat_probe')).reduceRegion(
            reducer=ee.Reducer.first(),
            geometry=ee.Geometry.Point(P0),
            crs=proj,
            scale=proj.nominalScale()
        ).getInfo()
        
        cosPhi = math.cos(r['lat_probe'] * math.pi / 180)
        expX = c['sign'] * 0.5 / (P_DEG_M_EQ / 1000 * cosPhi) if c['ax'] == 'x' else 0
        expY = c['sign'] * 0.5 / (P_METERS_PER_DEG_LAT / 1000) if c['ax'] == 'y' else 0
        print(f"Case {c['n']}: got (dx={r['sst_dTdx_c_km']}, dy={r['sst_dTdy_c_km']}), exp (dx={expX}, dy={expY})")

def test_ekman():
    print("\nTesting ekmanTests()...")
    proj = geoProj(0.2)
    ll = ee.Image.pixelLonLat().reproject(proj)
    s_lon = ll.select('longitude')
    s_lat = ll.select('latitude')
    k = 0.01
    zero = s_lon.multiply(0)
    
    # constant stress -> zero curl
    tx = zero.add(0.1).rename('t').reproject(proj)
    ty = zero.add(0.05).rename('t').reproject(proj)
    ek = fromTau(tx, ty)
    rc = ek.addBands(s_lat.rename('lat_probe')).reduceRegion(
        reducer=ee.Reducer.first(), geometry=ee.Geometry.Point([111.7, -8.28]),
        crs=proj, scale=proj.nominalScale()
    ).getInfo()
    print("Constant stress curl:", rc.get('wind_stress_curl'), "w_e:", rc.get('ekman_w_e_m_s'))
    
    # positive curl: tau_y = k*lon
    tx_0 = zero.rename('t').reproject(proj)
    ty_k = s_lon.multiply(k).rename('t').reproject(proj)
    ek_pos = fromTau(tx_0, ty_k)
    r_pos = ek_pos.addBands(s_lat.rename('lat_probe')).reduceRegion(
        reducer=ee.Reducer.first(), geometry=ee.Geometry.Point([111.7, -8.28]),
        crs=proj, scale=proj.nominalScale()
    ).getInfo()
    print("Positive curl:", r_pos.get('wind_stress_curl'), "w_e:", r_pos.get('ekman_w_e_m_s'))

if __name__ == "__main__":
    test_thermal()
    test_ekman()

