import ee
import time

ee.Initialize(project='seca-513505')

MASTER_AOI = "projects/seca-513505/assets/AOI_WPP573_MASTER"
aoiFC = ee.FeatureCollection(MASTER_AOI)
bbox = ee.Geometry.Rectangle([102.50, -14.00, 126.50, -6.80])
inAoi = ee.Image.constant(1).clip(aoiFC).rename('aoi')

start, end = '2024-04-01', '2024-05-01'

sst_raw = ee.ImageCollection('NOAA/CDR/OISST/V2_1').filterDate(start, end).filterBounds(bbox).select('sst')
sst_img = sst_raw.mean().multiply(0.01).rename('sst_mean_c')

etopo = ee.Image('NOAA/NGDC/ETOPO1').select('bedrock')
depth = etopo.multiply(-1.0).updateMask(etopo.lt(0)).rename('depth_m')

cfs_raw = ee.ImageCollection('NOAA/CFSV2/FOR6H_HARMONIZED').filterDate(start, end).filterBounds(bbox)
u = cfs_raw.select('u-component_of_wind_height_above_ground').mean().rename('wind_speed_mean_m_s')

hycom_raw = ee.ImageCollection('HYCOM/sea_water_velocity').filterDate(start, end).filterBounds(bbox)
curr = hycom_raw.select('velocity_u_0').mean().multiply(0.001).rename('current_speed_m_s')

layers = [
    ('depth_m', depth.updateMask(inAoi)),
    ('sst_mean_c', sst_img.updateMask(inAoi)),
    ('wind_speed_mean_m_s', u.updateMask(inAoi)),
    ('current_speed_m_s', curr.updateMask(inAoi))
]

for name, img in layers:
    t0 = time.time()
    mid = img.getMapId()
    print(f"Layer {name} getMapId took {time.time()-t0:.2f}s")

