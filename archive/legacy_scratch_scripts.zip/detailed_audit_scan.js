const fs = require('fs');
const path = require('path');

const prigiDir = 'C:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis';

function walk(dir) {
  let results = [];
  const list = fs.readdirSync(dir);
  list.forEach(file => {
    const fullPath = path.join(dir, file);
    const stat = fs.statSync(fullPath);
    if (stat && stat.isDirectory()) {
      results = results.concat(walk(fullPath));
    } else {
      results.push({
        fullPath,
        relPath: path.relative(prigiDir, fullPath).replace(/\\/g, '/'),
        size: stat.size,
        mtime: stat.mtime.toISOString()
      });
    }
  });
  return results;
}

const files = walk(prigiDir);

console.log('--- ALL FILES IN DATA ---');
files.filter(f => f.relPath.startsWith('data/')).forEach(f => {
  console.log(`${f.relPath} | ${f.size} B | ${f.mtime}`);
});

console.log('\n--- ALL FILES IN OUTPUTS & MODELS ---');
files.filter(f => f.relPath.startsWith('outputs/') || f.relPath.startsWith('models/')).forEach(f => {
  console.log(`${f.relPath} | ${f.size} B | ${f.mtime}`);
});

console.log('\n--- ALL FILES IN HTML & PAGES ---');
files.filter(f => f.relPath.startsWith('html/') || f.relPath.startsWith('pages/')).forEach(f => {
  console.log(`${f.relPath} | ${f.size} B | ${f.mtime}`);
});
