// Script to update PHASE_4_READINESS_GATE.json with Protocols 2-5 refinements
const fs = require('fs');
const path = require('path');

const prigiDir = 'C:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis';
const gatePath = path.join(prigiDir, 'PHASE_4_READINESS_GATE.json');
const gateData = JSON.parse(fs.readFileSync(gatePath, 'utf8'));

gateData.updated_at = '2026-10-31T21:33:00Z';
gateData.regulatory_references = [
  'Peraturan Menteri Kelautan dan Perikanan Nomor 7 Tahun 2026 tentang Kesyahbandaran di Pelabuhan Perikanan',
  'Undang-Undang No. 31 Tahun 2004 jo UU No. 45 Tahun 2009 tentang Perikanan',
  'Undang-Undang No. 17 Tahun 2008 tentang Pelayaran',
  'Peraturan BMKG No. Kep. 009/2010 tentang Peringatan Dini Cuaca Maritim'
];

gateData.mandatory_protocols = {
  protocol_1: {
    code: 'PROT-01',
    title: 'Relative Habitat Suitability Index (RHSI) & Advisory Scoring',
    formula: 'PFG Advisory Score = RHSI - 0.5 * sigma',
    constraint: 'No absolute catch probability claims P(Y=1)'
  },
  protocol_2: {
    code: 'PROT-02',
    title: 'Tiered Maritime Risk Screening',
    status: 'Exploratory Risk Screening Tool (Non-Official BMKG Classification)',
    wave_reference: 'Official BMKG Wave Categories (Tenang 0-0.5m, Rendah 0.5-1.25m, Sedang 1.25-2.5m, Tinggi 2.5-4.0m, Sangat Tinggi 4-6m, Ekstrem >6m)',
    rules: [
      'Evaluate combination of wave, wind, vessel type, GT size, technical capability, load condition, and trip characteristics',
      'Worst-case indicator precedence: highest risk category applies if any indicator breaches',
      'Prohibition of label AMAN as a maritime safety guarantee (use Low Risk / Relatively Conducive)',
      'Strict prohibition of automated sea bans or overriding captain/syahbandar authority',
      'Explicit stale/disconnected status if BMKG feeds fail or expire; no simulated actual status'
    ]
  },
  protocol_3: {
    code: 'PROT-03',
    title: 'Voluntary Shark Bycatch Mitigation Screening',
    layer_official_name: 'Candidate Bathymetric Screening Polygons for Voluntary Shark Bycatch Review',
    total_polygons: 123,
    definition: 'Bathymetric spatial screening instrument, NOT shark distribution map, bycatch hotspot, or no-take zone',
    rules: [
      'Gear-specific mitigation: Circle hooks (16/0 or 18/0 non-offset) for longline and handline only',
      'No universal circle hook mandate across all gears',
      'Prohibition of 200m depth operational restriction without empirical proof and legal basis',
      'Purse seine mitigation: Educational voluntary Non-Entangling FADs and safe shark release with crew safety priority'
    ]
  },
  protocol_4: {
    code: 'PROT-04',
    title: 'Supremacy of Regulation and Official Maritime Authority',
    authority_rules: [
      'Academic decision-support information only; no licensing, navigation regulation, or MPA creation legal force',
      'Harbormaster function strictly references Permen-KP No. 7 Tahun 2026 tentang Kesyahbandaran di Pelabuhan Perikanan',
      'Meteorological and maritime weather early warning authority rests solely with BMKG'
    ]
  },
  protocol_5: {
    code: 'PROT-05',
    title: 'Data Provenance, Freshness, and Validity Transparency',
    mandatory_metadata_fields: [
      'data_source',
      'observation_timestamp',
      'processing_timestamp',
      'spatial_temporal_resolution',
      'freshness_latency_status',
      'interpolation_flag',
      'model_version',
      'validity_boundaries'
    ],
    rules: [
      'Strict separation: Historical reanalysis (ERA5/GLORYS) must not be treated as operational real-time forecast',
      'Visual stale data tagging (STALE / UNAVAILABLE) if data passes operational validity period'
    ]
  }
};

fs.writeFileSync(gatePath, JSON.stringify(gateData, null, 2), 'utf8');
console.log('Successfully updated PHASE_4_READINESS_GATE.json with all 5 protocols.');
