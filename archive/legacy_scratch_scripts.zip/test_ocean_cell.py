import ee
import time

ee.Initialize(project="seca-513505")

aoiFC = ee.FeatureCollection("projects/seca-513505/assets/AOI_WPP573_MASTER")
rawGeom = aoiFC.first().geometry()
polys = rawGeom.geometries().map(
    lambda g: ee.Algorithms.If(
        ee.Geometry(g).type().equals("Polygon"), g, None
    )
).removeAll([None])
polyCoords = polys.map(lambda p: ee.Geometry(p).coordinates())
geom = ee.Geometry(ee.Geometry.MultiPolygon(polyCoords))

gridFC = ee.FeatureCollection("projects/seca-513505/assets/GRID_010_REGIONAL_8129")

# Find a pure ocean cell at lat < -11
ocean_cell = (
    gridFC.filter(ee.Filter.lt("lat_center", -11.0))
    .filter(ee.Filter.eq("cell_class", "PURE_OCEAN"))
    .first()
)
print("Ocean cell props:", ocean_cell.toDictionary().getInfo(), flush=True)

t0 = time.time()
inter = ocean_cell.geometry().intersection(geom, 100).area(100).divide(1e6)
frac = inter.divide(ee.Number(ocean_cell.get("cell_km2"))).getInfo()
print(f"Ocean cell inter took {time.time()-t0:.2f}s, frac={frac}", flush=True)

