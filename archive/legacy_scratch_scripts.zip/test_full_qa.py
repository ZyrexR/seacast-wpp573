import ee

ee.Initialize(project="seca-513505")

# Test building QA verdict with the updated logic
statuses = {
    "sst": "VALID",
    "chla": "VALID",
    "wind": "VALID",
    "stress": "VALID",
    "current": "VALID",
    "front": "VALID",
    "ekman": "VALID",
    "bathy": "VALID",
}
list_statuses = ee.List(list(statuses.values()))


def has(s):
  return list_statuses.contains(s)


blockedInvalid = ee.Algorithms.If(
    has("NO_VALID_DATA"),
    True,
    ee.Algorithms.If(
        has("BLOCKED_UNRESOLVED_QC"), True, has("BLOCKED_UNVERIFIED_SCALE")
    ),
)
framesStatus = ee.String("FULL")
qualified = ee.Algorithms.If(
    has("PARTIAL_COVERAGE"),
    True,
    ee.Algorithms.If(
        has("MISSING_OPTIONAL"), True, framesStatus.equals("PARTIAL_FRAMES")
    ),
)
verdict = ee.Algorithms.If(
    has("NO_DATA"),
    "BLOCKED_MISSING_SOURCE",
    ee.Algorithms.If(
        blockedInvalid,
        "BLOCKED_INVALID_DATA",
        ee.Algorithms.If(
            has("LOW_COVERAGE"),
            "BLOCKED_SPATIAL_COVERAGE",
            ee.Algorithms.If(qualified, "PASS_QUALIFIED_DATA", "PASS_HIGH_QUALITY"),
        ),
    ),
)
print("Verdict:", verdict.getInfo())

