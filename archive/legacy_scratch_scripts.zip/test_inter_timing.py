import ee
import time

ee.Initialize(project="seca-513505")

aoiFC = ee.FeatureCollection("projects/seca-513505/assets/AOI_WPP573_MASTER")
rawGeom = aoiFC.first().geometry()
polys = rawGeom.geometries().map(
    lambda g: ee.Algorithms.If(
        ee.Geometry(g).type().equals("Polygon"), g, None
    )
).removeAll([None])
polyCoords = polys.map(lambda p: ee.Geometry(p).coordinates())
geom = ee.Geometry(ee.Geometry.MultiPolygon(polyCoords))

gridFC = ee.FeatureCollection("projects/seca-513505/assets/GRID_010_REGIONAL_8129")

for n_cells in [1, 2, 3, 5]:
  t0 = time.time()
  cells = gridFC.sort("cell_id").limit(n_cells)

  def test_inter(f):
    inter = f.geometry().intersection(geom, 10).area(10).divide(1e6)
    ar = ee.Number(f.get("cell_km2"))
    frac = inter.divide(ar)
    prop_val = ee.Number(f.get("aoi_fract"))
    return f.set("_diff", frac.subtract(prop_val).abs())

  max_diff = cells.map(test_inter).aggregate_max("_diff").getInfo()
  print(
      f"n_cells={n_cells}: max_diff={max_diff:.6f} took {time.time()-t0:.2f}s",
      flush=True,
  )

