import ee
import time

ee.Initialize(project='seca-513505')

aoiFC = ee.FeatureCollection('projects/seca-513505/assets/AOI_WPP573_MASTER')
gridFC = ee.FeatureCollection('projects/seca-513505/assets/GRID_010_REGIONAL_8129')
bbox = ee.Geometry.Rectangle([105.0, -14.0, 119.0, -7.5])

# Image mask from aoiFC
inAoi = ee.Image.constant(1).clip(aoiFC).rename('aoi')

# Synthetic or actual images
sst_raw = ee.ImageCollection('NOAA/CDR/OISST/V2_1').filterDate('2024-04-01', '2024-05-01').filterBounds(bbox).select('sst')
sst_img = sst_raw.mean().multiply(0.01).rename('sst_mean_c').addBands(ee.Image.constant(0.05).rename('sst_gradient_deg_km')).addBands(ee.Image.constant(1).rename('thermal_front_flag'))

modis = ee.ImageCollection('NASA/OCEANDATA/MODIS-Aqua/L3SMI').filterDate('2024-04-01', '2024-05-01').filterBounds(bbox).select('chlor_a')
chla_img = modis.mean().rename('chla_mg_m3').addBands(ee.Image.constant(1).rename('chla_modis_flag')).addBands(ee.Image.constant(0).rename('chla_gcom_fallback_flag'))

cfs = ee.ImageCollection('NOAA/CFSV2/FOR6H_HARMONIZED').filterDate('2024-04-01', '2024-05-01').filterBounds(bbox)
u = cfs.select('u-component_of_wind_height_above_ground').mean()
v = cfs.select('v-component_of_wind_height_above_ground').mean()
wind_speed = u.hypot(v).rename('wind_speed_mean_m_s')
tau = wind_speed.multiply(0.001).rename('wind_stress_tau_mag')
ekman = wind_speed.multiply(0.0001).rename('ekman_w_e_m_s')
precip = wind_speed.multiply(0).rename('precip_mm_day')
cfs_img = wind_speed.addBands([tau, ekman, precip])

hycom = ee.ImageCollection('HYCOM/sea_water_velocity').filterDate('2024-04-01', '2024-05-01').filterBounds(bbox)
hycom_u = hycom.select('velocity_u_0').mean().multiply(0.001)
hycom_v = hycom.select('velocity_v_0').mean().multiply(0.001)
current_img = hycom_u.hypot(hycom_v).rename('current_speed_m_s')

etopo = ee.Image('NOAA/NGDC/ETOPO1').select('bedrock')
bathy_img = etopo.multiply(-1.0).updateMask(etopo.lt(0)).rename('depth_m')

groups = [
    {'name': 'chla', 'img': chla_img, 'bands': ['chla_mg_m3', 'chla_modis_flag', 'chla_gcom_fallback_flag'], 'proj': modis.first().projection(), 'deg': 0.0416},
    {'name': 'current', 'img': current_img, 'bands': ['current_speed_m_s'], 'proj': hycom.first().projection(), 'deg': 0.0833},
    {'name': 'bathy', 'img': bathy_img, 'bands': ['depth_m'], 'proj': etopo.projection(), 'deg': 0.0166},
    {'name': 'sst', 'img': sst_img, 'bands': ['sst_mean_c', 'sst_gradient_deg_km', 'thermal_front_flag'], 'proj': sst_raw.first().projection(), 'deg': 0.25},
    {'name': 'cfsv2', 'img': cfs_img, 'bands': ['wind_speed_mean_m_s', 'wind_stress_tau_mag', 'ekman_w_e_m_s', 'precip_mm_day'], 'proj': cfs.first().projection(), 'deg': 0.208}
]

def stackFor(g):
    sel = g['img'].select(g['bands'])
    vals = sel.updateMask(inAoi)
    valids = sel.mask().updateMask(inAoi).rename(['v_' + b for b in g['bands']])
    return vals.addBands(valids)

def reduceArea(fc, g):
    red = ee.Reducer.mean().combine(reducer2=ee.Reducer.count(), sharedInputs=True)
    r = stackFor(g).reduceRegions(collection=fc, reducer=red, crs=g['proj'], scale=g['proj'].nominalScale(), tileScale=4)
    return r.map(lambda f: f.set({
        g['bands'][0] + '_mean': f.get(g['bands'][0] + '_mean'),
        g['bands'][0] + '_cov': ee.Number(ee.Algorithms.If(ee.Number(f.get('v_' + g['bands'][0] + '_count')).gt(0), ee.Number(f.get(g['bands'][0] + '_count')).divide(ee.Number(f.get('v_' + g['bands'][0] + '_count'))), 0)),
        'agg_method_' + g['name']: 'AREA_MEAN_NATIVE_PIXELS'
    }))

def reduceCentroid(fc, g):
    r = stackFor(g).reduceRegions(collection=fc, reducer=ee.Reducer.first(), crs=g['proj'], scale=g['proj'].nominalScale(), tileScale=4)
    return r.map(lambda f: f.set({
        g['bands'][0] + '_mean': f.get(g['bands'][0]),
        g['bands'][0] + '_cov': 1,
        'agg_method_' + g['name']: 'NATIVE_PIXEL_AT_CELL_CENTROID'
    }))

CELL = 0.1
fc = gridFC
for g in groups:
    if g['deg'] < CELL:
        fc = reduceArea(fc, g)

cen = fc.map(lambda f: ee.Feature(f.geometry().centroid(1), f.toDictionary()))
for g in groups:
    if g['deg'] >= CELL:
        cen = reduceCentroid(cen, g)

t0 = time.time()
print("Starting limit(20) on fully chained table...")
lim20 = cen.limit(20).getInfo()
print(f"limit(20) SUCCESS in {time.time()-t0:.2f}s! Rows: {len(lim20['features'])}")
print("Sample props:", lim20['features'][0]['properties'])

