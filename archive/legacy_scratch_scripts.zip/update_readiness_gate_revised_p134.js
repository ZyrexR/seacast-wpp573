// Update PHASE_4_READINESS_GATE.json with exact revised Protocols 1, 3, and 4
const fs = require('fs');
const path = require('path');

const prigiDir = 'C:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis';
const gatePath = path.join(prigiDir, 'PHASE_4_READINESS_GATE.json');
const gateData = JSON.parse(fs.readFileSync(gatePath, 'utf8'));

gateData.updated_at = '2026-11-01T00:48:00Z';

// 1. Updated Statutory References in Pillar D & Gate Root
gateData.regulatory_references = [
  'Peraturan Menteri Kelautan dan Perikanan Nomor 7 Tahun 2026 tentang Kesyahbandaran di Pelabuhan Perikanan',
  'Undang-Undang Nomor 31 Tahun 2004 tentang Perikanan sebagaimana telah diubah, termasuk melalui Undang-Undang Nomor 45 Tahun 2009 dan Undang-Undang Nomor 6 Tahun 2023',
  'Undang-Undang Nomor 17 Tahun 2008 tentang Pelayaran sebagaimana telah diubah terakhir dengan Undang-Undang Nomor 66 Tahun 2024',
  'Peraturan BMKG No. Kep. 009/2010 tentang Peringatan Dini Cuaca Maritim'
];

gateData.gate_matrix.D_operational_readiness.evidence_files = [
  'FINAL_FISHING_SAFETY_ADVISORY_AUDIT.md',
  'FINAL_DASHBOARD_SCIENTIFIC_CONSISTENCY_AUDIT.md',
  'Permen-KP No. 7 Tahun 2026 tentang Kesyahbandaran di Pelabuhan Perikanan',
  'UU No. 31/2004 jo UU No. 45/2009 jo UU No. 6/2023 tentang Perikanan',
  'UU No. 17/2008 jo UU No. 66/2024 tentang Pelayaran',
  'Peraturan BMKG No. Kep. 009/2010 tentang Peringatan Dini Cuaca Maritim'
];

// 2. Protocols 1, 3, and 4 detailed updates
gateData.mandatory_protocols.protocol_1 = {
  code: 'PROT-01',
  title: 'Relative Habitat Suitability and Uncertainty-Penalized Advisory Scoring',
  rhsi_definition: 'Scale 0.00 - 1.00 relative suitability index (NOT absolute catch probability or fishing success)',
  display_rule: 'RHSI and model uncertainty (sigma_w) must be displayed separately',
  mathematical_formulation: {
    weights_normalization: 'w_i >= 0, sum(w_i) = 1 (for i = 1 to M)',
    weighted_mean_rhsi_formula: 'RHSI_bar_w = sum(w_i * RHSI_i)',
    weighted_ensemble_disagreement_formula: 'sigma_w = sqrt(sum(w_i * (RHSI_i - RHSI_bar_w)^2))',
    pfg_advisory_score_formula: 'PFG_advisory = RHSI_bar_w - lambda * sigma_w',
    variables: {
      RHSI_bar_w: 'Weighted ensemble mean relative habitat suitability index [0.00, 1.00]',
      sigma_w: 'Weighted ensemble disagreement measure (NOT overall biological uncertainty, NOT confidence interval)',
      lambda: 'Uncertainty penalty coefficient documented and tested via sensitivity analysis (range 0.0 - 1.0, baseline 0.5)'
    }
  },
  official_naming: 'Uncertainty-Penalized Advisory Score (NOT confidence interval, NOT catch probability)',
  dual_score_storage_rule: 'System MUST store both raw score before clipping (can be negative) and visualization score after [0, 1] clipping',
  metadata_logging_requirements: [
    'normalization_method',
    'uncertainty_calculation_formula',
    'penalty_coefficient_lambda_value',
    'classification_thresholds_sensitivity_tested',
    'out_of_range_handling_clipping'
  ],
  status_label: 'Advisory Screening (NOT actual coordinates of fish presence or fishing grounds)'
};

gateData.mandatory_protocols.protocol_3 = {
  code: 'PROT-03',
  title: 'Voluntary Shark Bycatch Mitigation Screening',
  layer_official_name: 'Candidate Bathymetric Screening Polygons for Voluntary Shark Bycatch Review',
  total_polygons: 123,
  cites_compliance_framework: {
    reference_date_rule: 'Identification of CITES status MUST use CITES Appendices in effect as of the data processing date',
    family_vs_species_distinction: 'For Family Carcharhinidae, system must distinguish Family-level listing (Carcharhinidae spp.) on Appendix II from species specifically listed on Appendix I',
    specific_example: 'Carcharhinus longimanus is listed on Appendix I (effective 5 March 2026), whereas Carcharhinidae spp. is on Appendix II with exception of species included in Appendix I',
    non_automatic_species_assignment_rule: 'Landing data identified only as Carcharhinus spp. MUST NOT be automatically assigned Appendix I or Appendix II at the species level without further taxonomic verification',
    five_mandatory_taxonomic_fields: [
      'identified_taxon_name',
      'taxonomic_resolution_level',
      'cites_status_and_appendices_date',
      'identification_verification_status',
      'taxonomic_uncertainty_notes'
    ]
  },
  bathymetric_and_oceanographic_rules: [
    'Spatial screening instrument based on documented bathymetric and oceanographic parameters',
    'Depth range 150-1200m is an exploratory criterion with scientific justification and measurement definition',
    'Thermocline (Z20, vertical gradient dT/dz) and surface upwelling indicators (Delta T_c-o, Ekman Mey) must be defined separately and never interchanged without justification',
    'Polygons are NOT shark distribution maps, NOT verified bycatch hotspots, NOT validated critical habitats, and NOT no-take zones',
    'Circle hooks, line configuration, operating depth, and release procedures must be gear-specific and species-specific with literature proof',
    'Circle hooks cannot be claimed to automatically reduce all types of shark bycatch',
    'Purse seine mitigation: Voluntary educational non-entangling FADs and safe release with crew safety priority',
    'All 123 polygons maintain status as candidate bathymetric screening polygons until empirical bycatch data with species, time, location, gear, and effort is available'
  ]
};

gateData.mandatory_protocols.protocol_4 = {
  code: 'PROT-04',
  title: 'Supremacy of Regulation and Official Maritime Authority',
  legal_statutes: [
    'Peraturan Menteri Kelautan dan Perikanan Nomor 7 Tahun 2026 tentang Kesyahbandaran di Pelabuhan Perikanan',
    'Undang-Undang Nomor 31 Tahun 2004 tentang Perikanan sebagaimana telah diubah, termasuk melalui Undang-Undang Nomor 45 Tahun 2009 dan Undang-Undang Nomor 6 Tahun 2023',
    'Undang-Undang Nomor 17 Tahun 2008 tentang Pelayaran sebagaimana telah diubah terakhir dengan Undang-Undang Nomor 66 Tahun 2024'
  ],
  harbormaster_authority: 'Execution of authority for issuing Port Clearance (Surat Persetujuan Berlayar / SPB), seaworthiness inspection, and maritime safety oversight is conducted strictly by the Syahbandar at the Port of Fishery who has authority in accordance with statutory regulations',
  meteorological_authority: 'Badan Meteorologi, Klimatologi, dan Geofisika (BMKG)',
  legal_status: 'Academic decision-support information only; no licensing, navigation regulation, or conservation designation legal force'
};

fs.writeFileSync(gatePath, JSON.stringify(gateData, null, 2), 'utf8');
console.log('Successfully updated PHASE_4_READINESS_GATE.json with exact revised Protocols 1, 3, and 4.');
