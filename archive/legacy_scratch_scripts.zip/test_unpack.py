import ee

ee.Initialize(project="seca-513505")
aoiFC = ee.FeatureCollection("projects/seca-513505/assets/AOI_WPP573_MASTER")
raw_geom = aoiFC.first().geometry()

polys = raw_geom.geometries().map(
    lambda g: ee.Algorithms.If(
        ee.Geometry(g).type().equals("Polygon"), g, None
    )
).removeAll([None])
polyCoords = polys.map(lambda p: ee.Geometry(p).coordinates())
cleanGeom = ee.Geometry(
    ee.Algorithms.If(
        raw_geom.type().equals("GeometryCollection"),
        ee.Algorithms.If(
            polys.size().gt(1),
            ee.Geometry.MultiPolygon(polyCoords),
            ee.Algorithms.If(polys.size().eq(1), polys.get(0), raw_geom),
        ),
        raw_geom,
    )
)

holes = ee.Number(
    ee.Algorithms.If(
        cleanGeom.type().equals("Polygon"),
        ee.List(cleanGeom.coordinates()).size().subtract(1),
        ee.List(cleanGeom.coordinates())
        .map(lambda p: ee.List(p).size().subtract(1))
        .reduce(ee.Reducer.sum()),
    )
)

d = ee.Dictionary({
    "type": cleanGeom.type(),
    "holes": holes,
    "empty": cleanGeom.isUnbounded(),
}).getInfo()
print("Unpacked geom info:", d)

