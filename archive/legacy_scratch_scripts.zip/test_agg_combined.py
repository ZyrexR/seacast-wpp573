import ee
import time

ee.Initialize(project='seca-513505')

aoiFC = ee.FeatureCollection('projects/seca-513505/assets/AOI_WPP573_MASTER')
gridFC = ee.FeatureCollection('projects/seca-513505/assets/GRID_010_REGIONAL_8129')
bbox = ee.Geometry.Rectangle([105.0, -14.0, 119.0, -7.5])
inAoi = ee.Image.constant(1).clip(aoiFC).rename('aoi')

start, end = '2024-04-01', '2024-05-01'

# 1. SST
sst_raw = ee.ImageCollection('NOAA/CDR/OISST/V2_1').filterDate(start, end).filterBounds(bbox).select('sst')
sst_img = sst_raw.mean().multiply(0.01).rename('sst_mean_c').addBands(ee.Image.constant(0.05).rename('sst_gradient_deg_km')).addBands(ee.Image.constant(1).rename('thermal_front_flag'))

# 2. CHLA
modis = ee.ImageCollection('NASA/OCEANDATA/MODIS-Aqua/L3SMI').filterDate(start, end).filterBounds(bbox).select('chlor_a')
chla_img = modis.mean().rename('chla_mg_m3').addBands(ee.Image.constant(1).rename('chla_modis_flag')).addBands(ee.Image.constant(0).rename('chla_gcom_fallback_flag'))

# 3. CFSV2
cfs = ee.ImageCollection('NOAA/CFSV2/FOR6H_HARMONIZED').filterDate(start, end).filterBounds(bbox)
u = cfs.select('u-component_of_wind_height_above_ground').mean()
v = cfs.select('v-component_of_wind_height_above_ground').mean()
wind_speed = u.hypot(v).rename('wind_speed_mean_m_s')
tau = wind_speed.multiply(0.001).rename('wind_stress_tau_mag')
ekman = wind_speed.multiply(0.0001).rename('ekman_w_e_m_s')
precip = wind_speed.multiply(0).rename('precip_mm_day')
cfs_img = wind_speed.addBands([tau, ekman, precip])

# 4. HYCOM
hycom = ee.ImageCollection('HYCOM/sea_water_velocity').filterDate(start, end).filterBounds(bbox)
hycom_u = hycom.select('velocity_u_0').mean().multiply(0.001)
hycom_v = hycom.select('velocity_v_0').mean().multiply(0.001)
current_img = hycom_u.hypot(hycom_v).rename('current_speed_m_s')

# 5. ETOPO1
etopo = ee.Image('NOAA/NGDC/ETOPO1').select('bedrock')
bathy_img = etopo.multiply(-1.0).updateMask(etopo.lt(0)).rename('depth_m')

# Stack finer bands together (chla + current + bathy)
finer_bands = ['chla_mg_m3', 'chla_modis_flag', 'chla_gcom_fallback_flag', 'current_speed_m_s', 'depth_m']
finer_img = chla_img.addBands([current_img, bathy_img]).select(finer_bands)
finer_vals = finer_img.updateMask(inAoi)
finer_valids = finer_img.mask().updateMask(inAoi).rename(['v_' + b for b in finer_bands])
finer_stack = finer_vals.addBands(finer_valids)

# Stack coarser bands together (sst + cfsv2)
coarser_bands = ['sst_mean_c', 'sst_gradient_deg_km', 'thermal_front_flag', 'wind_speed_mean_m_s', 'wind_stress_tau_mag', 'ekman_w_e_m_s', 'precip_mm_day']
coarser_img = sst_img.addBands(cfs_img).select(coarser_bands)
coarser_vals = coarser_img.updateMask(inAoi)
coarser_valids = coarser_img.mask().updateMask(inAoi).rename(['v_' + b for b in coarser_bands])
coarser_stack = coarser_vals.addBands(coarser_valids)

t0 = time.time()
print("Starting 2-step aggregation on gridFC...")

# Step 1: Area mean for finer bands over polygons (1 pass!)
red1 = ee.Reducer.mean().combine(reducer2=ee.Reducer.count(), sharedInputs=True)
fc1 = finer_stack.reduceRegions(
    collection=gridFC,
    reducer=red1,
    scale=4638,
    tileScale=8
)

# Step 2: Centroid sampling for coarser bands (1 pass!)
cen = fc1.map(lambda f: ee.Feature(f.geometry().centroid(1), f.toDictionary()))
table = coarser_stack.reduceRegions(
    collection=cen,
    reducer=ee.Reducer.first(),
    scale=23191,
    tileScale=8
)

# Post-process properties for schema compatibility
def finalizeProps(f):
    d = {
        'agg_method_chla': 'AREA_MEAN_NATIVE_PIXELS',
        'agg_method_current': 'AREA_MEAN_NATIVE_PIXELS',
        'agg_method_bathy': 'AREA_MEAN_NATIVE_PIXELS',
        'agg_method_sst': 'NATIVE_PIXEL_AT_CELL_CENTROID',
        'agg_method_cfsv2': 'NATIVE_PIXEL_AT_CELL_CENTROID'
    }
    for b in finer_bands:
        valid = ee.Number(ee.Algorithms.If(f.get(b + '_count'), f.get(b + '_count'), 0))
        dom = ee.Number(ee.Algorithms.If(f.get('v_' + b + '_count'), f.get('v_' + b + '_count'), 0))
        d[b + '_cov'] = ee.Number(ee.Algorithms.If(dom.gt(0), valid.divide(dom), 0))
    for b in coarser_bands:
        v = f.get('v_' + b)
        d[b + '_cov'] = ee.Number(ee.Algorithms.If(v, v, 0))
        d[b + '_mean'] = f.get(b)
    chla_nd = ee.Number(1).subtract(ee.Number(ee.Algorithms.If(f.get('chla_modis_flag_mean'), f.get('chla_modis_flag_mean'), 0))).subtract(ee.Number(ee.Algorithms.If(f.get('chla_gcom_fallback_flag_mean'), f.get('chla_gcom_fallback_flag_mean'), 0)))
    d['chla_nodata_frac'] = chla_nd
    return f.set(d)

final_table = table.map(finalizeProps)

t1 = time.time()
print("Requesting limit(20)...")
lim20 = final_table.limit(20).getInfo()
print(f"limit(20) finished in {time.time()-t1:.2f}s! Count: {len(lim20['features'])}")
f0 = lim20['features'][0]['properties']
print("Row 0 properties:")
for k in ['cell_id', 'sst_mean_c_mean', 'sst_mean_c_cov', 'chla_mg_m3_mean', 'chla_mg_m3_cov', 'agg_method_cfsv2', 'agg_method_chla']:
    print(f"  {k}: {f0.get(k)}")

