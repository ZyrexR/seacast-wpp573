const fs = require('fs');
const prigiDir = 'C:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis';
const ocean132 = JSON.parse(fs.readFileSync(prigiDir + '/data/oceanographic/statistics/monthly/ocean_fisheries_master_132m.json', 'utf8'));
console.log('Sample record 0 keys:', Object.keys(ocean132[0]));
console.log('Sample record 0:', ocean132[0]);
