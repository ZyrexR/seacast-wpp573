import ee
import math

ee.Initialize(project='seca-513505')

P_DEG_M_EQ = 111319.49
P_METERS_PER_DEG_LAT = 111132.95
MERIDIAN_RATIO = P_METERS_PER_DEG_LAT / P_DEG_M_EQ

def geoProj(deg):
    return ee.Projection('EPSG:4326').scale(deg, deg)

# Try inverted KY: [[-1, -2, -1], [0, 0, 0], [1, 2, 1]]
KX = ee.Kernel.fixed(3, 3, [[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]], -1, -1, False)
KY_flipped = ee.Kernel.fixed(3, 3, [[-1, -2, -1], [0, 0, 0], [1, 2, 1]], -1, -1, False)

def nativeGradients(img):
    proj = img.projection()
    native = img.reproject(proj)
    scaleM = ee.Number(proj.nominalScale())
    latRad = ee.Image.pixelLonLat().select('latitude').reproject(proj).multiply(math.pi / 180.0)
    dxM = latRad.cos().multiply(scaleM)
    dyM = ee.Image.constant(scaleM.multiply(MERIDIAN_RATIO))
    return {
        'native': native,
        'latRad': latRad,
        'ddx': native.convolve(KX).divide(dxM.multiply(8.0)),
        'ddy': native.convolve(KY_flipped).divide(dyM.multiply(8.0))
    }

def computeThermalFront(sstMean):
    g = nativeGradients(sstMean.select('sst_mean_c'))
    dx = g['ddx'].multiply(1000.0).rename('sst_dTdx_c_km')
    dy = g['ddy'].multiply(1000.0).rename('sst_dTdy_c_km')
    mag = dx.pow(2).add(dy.pow(2)).sqrt().rename('sst_gradient_deg_km')
    flag = mag.gte(0.05).rename('thermal_front_flag')
    return dx.addBands([dy, mag, flag])

proj = geoProj(0.25)
ll = ee.Image.pixelLonLat().reproject(proj)
s_lat = ll.select('latitude')
P0 = [111.7275, -8.2833]

# Case north: lat * 0.5
img_north = s_lat.multiply(0.5).rename('sst_mean_c').reproject(proj)
g_north = computeThermalFront(img_north)
r_north = g_north.addBands(s_lat.rename('lat_probe')).reduceRegion(
    reducer=ee.Reducer.first(), geometry=ee.Geometry.Point(P0), crs=proj, scale=proj.nominalScale()
).getInfo()

expY = 0.5 / (P_METERS_PER_DEG_LAT / 1000)
print(f"With flipped KY: got dy={r_north['sst_dTdy_c_km']}, exp dy={expY}")
print("Match?", abs(r_north['sst_dTdy_c_km'] - expY) < 1e-6)

