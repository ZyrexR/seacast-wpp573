import ee

ee.Initialize(project="seca-513505")
grid_fc = ee.FeatureCollection("projects/seca-513505/assets/GRID_010_REGIONAL_8129")


def aoi_km2_prop(f):
  frac = ee.Number(
      ee.Algorithms.If(
          f.get("aoi_fract"),
          f.get("aoi_fract"),
          ee.Algorithms.If(f.get("aoi_fraction"), f.get("aoi_fraction"), 0),
      )
  )
  ar = ee.Number(ee.Algorithms.If(f.get("cell_km2"), f.get("cell_km2"), 0))
  return f.set("_aoi_km2", frac.multiply(ar))


s = grid_fc.map(aoi_km2_prop).aggregate_sum("_aoi_km2").getInfo()
print("Aggregate AOI km2 with aoi_fract:", s)
baseline = 933749.49
rel_diff = abs(s - baseline) / baseline
print(f"Rel diff vs 933,749.49 km2: {rel_diff:.6f} ({rel_diff*100:.4f}%)")

