import ee
import time

ee.Initialize(project="seca-513505")

print("Initialized EE", flush=True)

# 1. Inspect grid feature properties directly without heavy operations
grid_fc = ee.FeatureCollection("projects/seca-513505/assets/GRID_010_REGIONAL_8129")
f1 = grid_fc.first()
props = f1.propertyNames().getInfo()
print("Grid property names:", props, flush=True)
prop_dict = {p: f1.get(p).getInfo() for p in props if not p.startswith("system:")}
print("First feature properties:", prop_dict, flush=True)

# 2. Check AOI unpacking
aoi_fc = ee.FeatureCollection("projects/seca-513505/assets/AOI_WPP573_MASTER")
raw_geom = aoi_fc.first().geometry()
geoms = raw_geom.geometries()
polys = geoms.map(lambda g: ee.Algorithms.If(ee.Geometry(g).type().equals("Polygon"), g, None)).removeAll([None])
poly_coords = polys.map(lambda p: ee.Geometry(p).coordinates())
clean_multipoly = ee.Geometry.MultiPolygon(poly_coords)

t0 = time.time()
holes = clean_multipoly.coordinates().map(lambda p: ee.List(p).size().subtract(1)).reduce(ee.Reducer.sum()).getInfo()
print(f"Holes: {holes} (took {time.time()-t0:.2f}s)", flush=True)

t0 = time.time()
area_km2 = clean_multipoly.area(1).divide(1e6).getInfo()
print(f"Geodesic area km2: {area_km2} (took {time.time()-t0:.2f}s)", flush=True)

# 3. Check sum of aoi_fraction * cell_km2
# Notice cell_km2 or similar: let's see if grid features already have cell_km2 or cell_area
if 'cell_km2' in props:
    t0 = time.time()
    def aoi_km2_prop(f):
        frac = ee.Number(ee.Algorithms.If(f.get('aoi_fraction'), f.get('aoi_fraction'), 0))
        return f.set('_aoi_km2', frac.multiply(ee.Number(f.get('cell_km2'))))
    grid_sum = grid_fc.map(aoi_km2_prop).aggregate_sum('_aoi_km2').getInfo()
    print(f"Aggregate aoi_km2 from property: {grid_sum} (took {time.time()-t0:.2f}s)", flush=True)

