// Update PHASE_4_READINESS_GATE.json with exact refined Protocols 1, 2, 3
const fs = require('fs');
const path = require('path');

const prigiDir = 'C:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis';
const gatePath = path.join(prigiDir, 'PHASE_4_READINESS_GATE.json');
const gateData = JSON.parse(fs.readFileSync(gatePath, 'utf8'));

gateData.updated_at = '2026-11-01T00:38:00Z';

gateData.mandatory_protocols = {
  protocol_1: {
    code: 'PROT-01',
    title: 'Relative Habitat Suitability and Uncertainty-Penalized Advisory Scoring',
    rhsi_definition: 'Scale 0.00 - 1.00 relative suitability index (NOT absolute catch probability or fishing success)',
    display_rule: 'RHSI and model uncertainty (sigma) must be displayed separately',
    composite_score_formula: 'PFG Advisory Score = RHSI - lambda * sigma',
    variables: {
      rhsi: 'Relative Habitat Suitability Index [0.00, 1.00]',
      sigma: 'Model disagreement / uncertainty measure defined explicitly per cell',
      lambda: 'Penalty coefficient documented and tested via sensitivity analysis (range 0.0 - 1.0, baseline 0.5)'
    },
    official_naming: 'Uncertainty-Penalized Advisory Score (NOT confidence interval or catch success probability)',
    metadata_logging_requirements: [
      'normalization_method',
      'uncertainty_calculation_formula',
      'penalty_coefficient_lambda_value',
      'classification_thresholds',
      'out_of_range_handling_clipping'
    ],
    status_label: 'Advisory Screening (NOT actual coordinates of fish presence or fishing grounds)'
  },
  protocol_2: {
    code: 'PROT-02',
    title: 'Tiered Maritime Risk Screening',
    parameters_monitored: [
      'significant_wave_height_hs',
      'wave_direction_and_period_tp',
      'sustained_wind_speed',
      'wind_direction',
      'wind_gust',
      'vessel_characteristics_and_hull',
      'load_condition_and_draft',
      'trip_profile_day_vs_multi_day'
    ],
    rules: [
      'Wave categories must strictly follow BMKG product legend being integrated, recording product ID and legend version',
      'Phase 4 internal classification is an exploratory risk screening instrument, NOT official BMKG classification',
      'Average wind speed and wind gust must be stored and displayed as distinct parameters',
      'Risk evaluation must consider vessel characteristics and trip profile; GT cannot be sole determinant of safety',
      'Highest relevant risk indicator must be displayed alongside trigger factor without conflating different physical units',
      'Strict prohibition of label AMAN as a safety guarantee (use Low Risk / Relatively Conducive)',
      'Strict prohibition of automated sea bans or overriding captain and harbormaster authority',
      'If BMKG data fails, expires, or disconnects: display DATA KEDALUWARSA, FEED TERPUTUS, or TIDAK TERSEDIA; never preserve previous status as actual'
    ]
  },
  protocol_3: {
    code: 'PROT-03',
    title: 'Voluntary Shark Bycatch Mitigation Screening',
    layer_official_name: 'Candidate Bathymetric Screening Polygons for Voluntary Shark Bycatch Review',
    total_polygons: 123,
    rules: [
      'Spatial screening instrument based on bathymetric and oceanographic parameters with documented sources, definitions, and computation methods',
      'Depth range 150-1200m is an exploratory criterion accompanied by scientific justification, measurement definition, and polygon generation method version',
      'Thermocline and upwelling parameters must be defined separately; thermocline depth, vertical temp gradient, and upwelling indicators cannot be interchanged without methodological justification',
      'Polygons are NOT shark distribution maps, NOT verified bycatch hotspots, NOT validated critical habitats, and NOT no-take zones',
      'Circle hooks, line configuration, operating depth, and release procedures must be specific to gear, species, and operating conditions with scientific literature support',
      'Circle hooks cannot be claimed to automatically reduce all types of shark bycatch',
      'Purse seine non-entangling FADs and safe shark release are displayed as voluntary mitigation educational materials based on relevant technical guidelines with crew safety priority',
      'CITES compliance must be applied based on species actually listed in CITES Appendices and applicable regulations, not generalized to all shark species',
      'Until empirical bycatch data with species, time, location, gear, and fishing effort is available, all 123 polygons strictly maintain status as candidate bathymetric screening polygons'
    ]
  },
  protocol_4: {
    code: 'PROT-04',
    title: 'Supremacy of Regulation and Official Maritime Authority',
    harbormaster_statute: 'Peraturan Menteri Kelautan dan Perikanan Nomor 7 Tahun 2026 tentang Kesyahbandaran di Pelabuhan Perikanan',
    meteorological_authority: 'Badan Meteorologi, Klimatologi, dan Geofisika (BMKG)',
    legal_status: 'Academic decision-support information only; no licensing, navigation regulation, or conservation designation legal force'
  },
  protocol_5: {
    code: 'PROT-05',
    title: 'Data Provenance, Freshness, and Validity Transparency',
    mandatory_fields: [
      'data_source',
      'observation_timestamp',
      'processing_timestamp',
      'spatial_temporal_resolution',
      'freshness_latency_status',
      'interpolation_flag',
      'model_version',
      'validity_boundaries'
    ],
    reanalysis_rule: 'Historical reanalysis (ERA5/GLORYS) must not be treated as operational real-time forecast',
    stale_rule: 'Visual stale tagging (DATA KEDALUWARSA / FEED TERPUTUS / TIDAK TERSEDIA) if data passes operational validity period'
  }
};

fs.writeFileSync(gatePath, JSON.stringify(gateData, null, 2), 'utf8');
console.log('Successfully updated PHASE_4_READINESS_GATE.json with full Protocol 1-3 details.');
