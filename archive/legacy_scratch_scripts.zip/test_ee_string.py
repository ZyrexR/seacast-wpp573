import ee

ee.Initialize(project="seca-513505")
s = ee.String("Polygon")
print("Has equals:", hasattr(s, "equals"))
try:
  res = ee.Algorithms.IsEqual(s, "Polygon")
  print("IsEqual res:", res.getInfo())
except Exception as e:
  print("IsEqual error:", e)

# What about in JS:
# In JS, does ee.String have .equals?
# Let's check:
try:
  eq = s.compareTo("Polygon")
  print("compareTo:", eq.getInfo())
except Exception as e:
  print("compareTo error:", e)

