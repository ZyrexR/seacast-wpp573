// Task 9 Dashboard Consistency Scanner
const fs = require('fs');
const path = require('path');

const prigiDir = 'C:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis';

const filesToScan = [
  'html/index.html',
  'html/sdm_data.js',
  'html/oceanographic_data.js',
  'models/sdm/ensemble/model_evaluations_summary.json',
  'data/sdm/predictors/predictor_stack_metadata.json'
];

const prohibitedPatterns = [
  { name: 'Actual fishing location', regex: /actual\s+(fishing\s+location|catch\s+coordinate|presence)/i },
  { name: 'Biologically validated', regex: /biologically\s+validated/i },
  { name: 'Confirmed nursery/spawning', regex: /confirmed\s+(nursery|spawning)/i },
  { name: 'Confirmed bycatch hotspot', regex: /confirmed\s+bycatch|verified\s+bycatch\s+hotspot/i },
  { name: 'Absolute fishing probability', regex: /absolute\s+(fishing\s+probability|occurrence\s+probability)/i },
  { name: 'Verified operational safety', regex: /verified\s+operational\s+safety/i }
];

console.log('=== AUDITING SCIENTIFIC CONSISTENCY ACROSS FILES ===');

filesToScan.forEach(relPath => {
  const fullPath = path.join(prigiDir, relPath);
  if (!fs.existsSync(fullPath)) {
    console.log(`File not found: ${relPath}`);
    return;
  }
  const content = fs.readFileSync(fullPath, 'utf8');
  console.log(`\nScanning: ${relPath} (${(content.length / 1024).toFixed(1)} KB)`);
  
  let issuesFound = 0;
  prohibitedPatterns.forEach(pat => {
    const matches = content.match(pat.regex);
    if (matches) {
      console.log(`  [VIOLATION] Found prohibited pattern "${pat.name}": "${matches[0]}"`);
      issuesFound++;
    }
  });

  if (issuesFound === 0) {
    console.log('  [PASS] Clean! No prohibited claims found.');
  }
});
