const fs = require('fs');
const brainScratch = 'C:/Users/ThinkPad/.gemini/antigravity/brain/cc088fc0-e16d-416d-8247-15acc089a9e9/scratch';

console.log('--- re_audit_production.js ---');
if (fs.existsSync(brainScratch + '/re_audit_production.js')) {
  console.log(fs.readFileSync(brainScratch + '/re_audit_production.js', 'utf8').substring(0, 1000));
}

console.log('\n--- compare_sheet3_4.js ---');
if (fs.existsSync(brainScratch + '/compare_sheet3_4.js')) {
  console.log(fs.readFileSync(brainScratch + '/compare_sheet3_4.js', 'utf8').substring(0, 1000));
}
