import ee

ee.Initialize(project="seca-513505")

l = ee.List(["A", "B", "C"])
c1 = l.contains("A")
c2 = l.contains("D")

# In Python:
print("type of c1:", type(c1))
n1 = ee.Number(c1)
n2 = ee.Number(c2)
res = n1.Or(n2)
print("n1.Or(n2):", res.getInfo())

# What about framesStatus.equals?
framesStatus = ee.String("FULL")
eq = framesStatus.equals("PARTIAL_FRAMES")
print("type of eq:", type(eq))
neq = ee.Number(eq)
print("neq:", neq.getInfo())
res2 = n1.Or(neq)
print("res2:", res2.getInfo())

