// Script to update legal citations in FINAL_PHASE_1_TO_3_VALIDATION_REPORT.md
const fs = require('fs');
const path = require('path');

const prigiDir = 'C:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis';
const reportPath = path.join(prigiDir, 'FINAL_PHASE_1_TO_3_VALIDATION_REPORT.md');
let report = fs.readFileSync(reportPath, 'utf8');

// Update Pilar D-04 description
report = report.replace(
  '|D-04| Penegasan Supremasi Syahbandar     | VERIFIED           | Disclaimer hukum resmi tercantum pada dasbor.    |',
  '|D-04| Penegasan Supremasi Syahbandar     | VERIFIED           | Merujuk Permen-KP 7/2026, UU 6/2023, & UU 66/2024.|'
);

// Update section on legal framework
const legalSection = `

### Catatan Khusus Rujukan Peraturan Perundang-undangan Terbaru:
Seluruh kerangka tata kelola operasional dan keselamatan pelayaran merujuk secara sah pada:
1. **Permen-KP No. 7 Tahun 2026** tentang Kesyahbandaran di Pelabuhan Perikanan (penerbitan SPB & kelaiklautan).
2. **UU No. 31 Tahun 2004** tentang Perikanan sebagaimana telah diubah, termasuk melalui **UU No. 45 Tahun 2009** dan **UU No. 6 Tahun 2023** (Penetapan Perppu Cipta Kerja).
3. **UU No. 17 Tahun 2008** tentang Pelayaran sebagaimana telah diubah terakhir dengan **UU No. 66 Tahun 2024** (Perubahan Ketiga atas UU Pelayaran).
4. **Appendices CITES yang berlaku sejak 5 Maret 2026** (membedakan *Carcharhinus longimanus* di Appendix I dan *Carcharhinidae spp.* di Appendix II).
`;

if (!report.includes('Permen-KP No. 7 Tahun 2026')) {
  report = report.replace('## 3. KALKULASI SKOR KESIAPAN AKADEMIK TERBOBOT', legalSection + '\n## 3. KALKULASI SKOR KESIAPAN AKADEMIK TERBOBOT');
}

fs.writeFileSync(reportPath, report, 'utf8');
console.log('Successfully updated FINAL_PHASE_1_TO_3_VALIDATION_REPORT.md');
