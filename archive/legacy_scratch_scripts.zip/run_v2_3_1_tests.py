import ee
import json
import math

ee.Initialize(project='seca-513505')

SYN = ee.Geometry.Rectangle([111.0, -10.0, 113.0, -8.0], 'EPSG:4326', False)
P_DEG_M_EQ = 111319.49
P_METERS_PER_DEG_LAT = 111132.95
MERIDIAN_RATIO = P_METERS_PER_DEG_LAT / P_DEG_M_EQ
P_RHO_SEAWATER = 1025.0
P_OMEGA = 7.2921e-5
P_R_EARTH = 6371000.0

def geoProj(deg):
    return ee.Image.pixelLonLat().projection().scale(deg, deg)

def bundle(raw, bands):
    zeros = [0] * len(bands)
    dummy = ee.Image.constant(zeros).rename(bands).updateMask(0)
    safe = ee.ImageCollection(ee.Algorithms.If(raw.size().gt(0), raw, ee.ImageCollection([dummy])))
    return {'raw': raw, 'rawCount': raw.size(), 'safe': safe}

def nativeProjection(raw, fallback):
    dummy = ee.Image.constant(0).setDefaultProjection(fallback)
    first = ee.Image(ee.Algorithms.If(raw.size().gt(0), raw.first(), dummy))
    return first.projection()

# Test T11 with homogeneous band names AND explicit casts
def test_t11():
    # 2023-04
    modisRaw = ee.ImageCollection("NASA/OCEANDATA/MODIS-Aqua/L3SMI").filterDate('2023-04-01', '2023-05-01').filterBounds(SYN).select('chlor_a')
    mb = bundle(modisRaw, ['chlor_a'])
    target = nativeProjection(modisRaw, geoProj(1/24))
    modis = mb['safe'].map(lambda img: img.updateMask(img.gte(0.01).And(img.lte(30.0))))
    modisCount = modis.count().rename('modis_valid_count').setDefaultProjection(target)
    modisMean = modis.mean().rename('modis_mean').setDefaultProjection(target)
    modisValid = modisCount.gt(0).And(modisMean.mask()).rename('modis_valid')

    gcomRaw = ee.ImageCollection("JAXA/GCOM-C/L3/OCEAN/CHLA/V3").filterDate('2023-04-01', '2023-05-01').filterBounds(SYN).select('CHLA_AVE')
    gb = bundle(gcomRaw, ['CHLA_AVE'])
    gProj = nativeProjection(gcomRaw, target)
    gcom = gb['safe'].map(lambda img: img.multiply(0.0016).updateMask(img.multiply(0.0016).gte(0.01).And(img.multiply(0.0016).lte(30.0))))
    gcomCount = gcom.count().rename('gcom_valid_count').setDefaultProjection(gProj).reproject(target)
    gcomMean = gcom.mean().rename('gcom_mean').setDefaultProjection(gProj).reproject(target)
    gcomValid = gcomCount.gt(0).And(gcomMean.mask()).rename('gcom_valid')

    fallback = gcomValid.And(modisValid.Not())
    # RENAME BOTH TO 'chla_mg_m3' and cast toFloat() SO COLLECTION IS HOMOGENEOUS:
    value = ee.ImageCollection([
        gcomMean.rename('chla_mg_m3').toFloat().updateMask(gcomValid),
        modisMean.rename('chla_mg_m3').toFloat().updateMask(modisValid)
    ]).mosaic().rename('chla_mg_m3').reproject(target)
    
    # Cast constants toByte() so mismatched Byte<2,2> vs Byte<1,1> does not occur:
    source = ee.ImageCollection([
        ee.Image.constant(2).toByte().updateMask(fallback),
        ee.Image.constant(1).toByte().updateMask(modisValid)
    ]).mosaic().unmask(0).rename('chla_source_code').reproject(target)
    
    validAny = modisValid.Or(gcomValid).rename('chla_valid_flag').reproject(target)
    modisFlag = modisValid.rename('chla_modis_flag').reproject(target)
    gcomFlag = fallback.rename('chla_gcom_fallback_flag').reproject(target)

    img = value.addBands([source, modisFlag, gcomFlag, validAny])
    src = img.select('chla_source_code')
    bad = src.eq(1).neq(img.select('chla_modis_flag')).Or(src.eq(2).neq(img.select('chla_gcom_fallback_flag'))).Or(img.select('chla_mg_m3').mask().neq(img.select('chla_valid_flag'))).rename('bad')
    bad_sum = bad.reduceRegion(reducer=ee.Reducer.sum(), geometry=SYN, crs=target, scale=target.nominalScale(), maxPixels=1e9).get('bad')
    o = ee.Dictionary({'bad': bad_sum}).getInfo()
    print("T11:", o, "PASS" if o['bad'] == 0 else "FAIL")

# Test T12
def test_t12():
    modisRaw = ee.ImageCollection("NASA/OCEANDATA/MODIS-Aqua/L3SMI").filterDate('2023-04-01', '2023-05-01').filterBounds(SYN).select('chlor_a')
    target = nativeProjection(modisRaw, geoProj(1/24))
    nom = target.nominalScale().getInfo()
    print(f"T12: MODIS nominal scale = {nom} PASS")

# Test T13 (Thermal with corrected KY)
def test_t13():
    proj = geoProj(0.25)
    scaleM = proj.nominalScale()
    ll = ee.Image.pixelLonLat().reproject(proj)
    s_lon = ll.select('longitude')
    s_lat = ll.select('latitude')
    latRad = s_lat.multiply(math.pi / 180.0)
    dxM = latRad.cos().multiply(scaleM)
    dyM = ee.Image.constant(scaleM.multiply(MERIDIAN_RATIO))
    
    KX = ee.Kernel.fixed(3, 3, [[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]], -1, -1, False)
    # Corrected KY:
    KY = ee.Kernel.fixed(3, 3, [[-1, -2, -1], [0, 0, 0], [1, 2, 1]], -1, -1, False)
    
    def compute(sstMean):
        native = sstMean.reproject(proj)
        ddx = native.convolve(KX).divide(dxM.multiply(8.0))
        ddy = native.convolve(KY).divide(dyM.multiply(8.0))
        dx = ddx.multiply(1000.0).rename('sst_dTdx_c_km')
        dy = ddy.multiply(1000.0).rename('sst_dTdy_c_km')
        mag = dx.pow(2).add(dy.pow(2)).sqrt().rename('sst_gradient_deg_km')
        return dx.addBands([dy, mag])

    P0 = [111.7275, -8.2833]
    # Test north:
    img_n = s_lat.multiply(0.5).rename('sst_mean_c').reproject(proj)
    gn = compute(img_n)
    pt = ee.Geometry.Point(P0)
    res = gn.addBands(s_lat.rename('lat_probe')).reduceRegion(reducer=ee.Reducer.first(), geometry=pt, crs=proj, scale=scaleM).getInfo()
    expY = 0.5 / (P_METERS_PER_DEG_LAT / 1000)
    pass_t13 = abs(res['sst_dTdy_c_km'] - expY) < 1e-4
    print(f"T13 North: got {res['sst_dTdy_c_km']}, expected {expY}, PASS: {pass_t13}")

# Test T14 (Ekman)
def test_t14():
    proj = geoProj(0.2)
    scaleM = proj.nominalScale()
    ll = ee.Image.pixelLonLat().reproject(proj)
    s_lon = ll.select('longitude')
    s_lat = ll.select('latitude')
    latRad = s_lat.multiply(math.pi / 180.0)
    dxM = latRad.cos().multiply(scaleM)
    dyM = ee.Image.constant(scaleM.multiply(MERIDIAN_RATIO))
    KX = ee.Kernel.fixed(3, 3, [[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]], -1, -1, False)
    KY = ee.Kernel.fixed(3, 3, [[-1, -2, -1], [0, 0, 0], [1, 2, 1]], -1, -1, False)
    
    def fromTau(tauX, tauY):
        gx_ddy = tauX.reproject(proj).convolve(KY).divide(dyM.multiply(8.0))
        gy_ddx = tauY.reproject(proj).convolve(KX).divide(dxM.multiply(8.0))
        curl = gy_ddx.subtract(gx_ddy).rename('wind_stress_curl')
        f = latRad.sin().multiply(2.0 * P_OMEGA).rename('coriolis_f')
        safeF = f.updateMask(f.abs().gte(1.0e-5))
        beta = latRad.cos().multiply(2.0 * P_OMEGA / P_R_EARTH).rename('beta_param')
        termCurl = curl.divide(safeF.multiply(P_RHO_SEAWATER))
        termBeta = beta.multiply(tauX).divide(safeF.pow(2).multiply(P_RHO_SEAWATER))
        w = termCurl.add(termBeta).rename('ekman_w_e_m_s')
        return curl.addBands([f, beta, w])
        
    k = 0.01
    zero = s_lon.multiply(0)
    # linear tau_x(lat): tau_x = k*lat -> curl = -k/111132.95
    ty = fromTau(s_lat.multiply(k), zero)
    pt = ee.Geometry.Point([111.7, -8.28])
    res = ty.reduceRegion(reducer=ee.Reducer.first(), geometry=pt, crs=proj, scale=scaleM).getInfo()
    expCy = -k / P_METERS_PER_DEG_LAT
    pass_t14 = abs(res['wind_stress_curl'] - expCy) < 1e-10
    print(f"T14 Curl: got {res['wind_stress_curl']}, expected {expCy}, PASS: {pass_t14}")

def test_t04():
    raw = ee.ImageCollection('NOAA/CDR/OISST/V2_1').filterDate('1900-01-01', '1900-02-01').filterBounds(SYN).select('sst')
    b = bundle(raw, ['sst'])
    proj = nativeProjection(raw, geoProj(0.25))
    coll = b['safe'].map(lambda img: img.multiply(0.01).updateMask(img.multiply(0.01).gte(18.0).And(img.multiply(0.01).lte(35.0))))
    img = ee.Image.cat([
        coll.mean().rename('sst_mean_c'),
        coll.reduce(ee.Reducer.stdDev()).rename('sst_stddev_c'),
        coll.count().rename('sst_obs_count')
    ]).setDefaultProjection(proj)
    v = img.select('sst_mean_c').mask().reduceRegion(reducer=ee.Reducer.sum(), geometry=SYN, crs=proj, scale=proj.nominalScale(), maxPixels=1e8).get('sst_mean_c')
    o = ee.Dictionary({'n': b['rawCount'], 'v': v}).getInfo()
    print('T04:', o, 'PASS' if o['n'] == 0 and o['v'] == 0 else 'FAIL')

def test_t10():
    proj = geoProj(0.08)
    policy = 'CMEMS_ASSET_PENDING'
    m = lambda name: ee.Image.constant(0).updateMask(0).rename(name).toFloat()
    img = m('u_current_m_s').addBands([m('v_current_m_s'), m('current_speed_m_s'), ee.Image.constant(0).rename('current_obs_count')]).setDefaultProjection(proj)
    v = img.select('current_speed_m_s').mask().reduceRegion(reducer=ee.Reducer.sum(), geometry=SYN, crs=proj, scale=proj.nominalScale(), maxPixels=1e8).get('current_speed_m_s')
    meta = ee.Dictionary({'actual_source': 'NONE', 'source_status': policy, 'observation_count': 0})
    o = ee.Dictionary({'meta': meta, 'valid_px': v}).getInfo()
    pass_t10 = o['meta']['actual_source'] == 'NONE' and o['meta']['source_status'] == 'CMEMS_ASSET_PENDING' and o['meta']['observation_count'] == 0 and o['valid_px'] == 0
    print('T10:', o, 'PASS' if pass_t10 else 'FAIL')

test_t04()
test_t10()
test_t11()
test_t12()
test_t13()
test_t14()

