import ee
import time

ee.Initialize(project="seca-513505")

aoiFC = ee.FeatureCollection("projects/seca-513505/assets/AOI_WPP573_MASTER")
aoiMask = ee.Image().paint(aoiFC, 1)

sst = (
    ee.ImageCollection("NOAA/CDR/OISST/V2_1")
    .filterDate("2024-04-01", "2024-05-01")
    .select("sst")
    .mean()
    .multiply(0.01)
)

t0 = time.time()
img_mask = sst.updateMask(aoiMask)
v2 = (
    img_mask.reduceRegion(
        reducer=ee.Reducer.mean(),
        geometry=aoiFC.geometry(),
        scale=25000,
        maxPixels=1e9,
        tileScale=4,
    )
    .get("sst")
    .getInfo()
)
print(f"updateMask(aoiMask) took {time.time()-t0:.2f}s, val={v2}", flush=True)

