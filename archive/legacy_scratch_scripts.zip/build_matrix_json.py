import json
from pathlib import Path

# Compute scores
# 12 checks:
# PASS: PG-01, PG-02, PG-03, PG-06, PG-10, PG-11 (6 checks)
# PARTIAL: PG-04, PG-05, PG-07, PG-08, PG-12 (5 checks)
# NEEDS_VERIFICATION: PG-09 (1 check)

# Documentation scoring:
# PASS = 1.0, PARTIAL = 0.88 (specifications, formulas, and mockups fully documented), NEEDS_VERIFICATION = 0.80 (taxonomic schema and uncertainty boundaries documented)
doc_pass = 6 * 1.0
doc_partial = 5 * 0.88
doc_needs_verif = 1 * 0.80
doc_total = doc_pass + doc_partial + doc_needs_verif # 6.0 + 4.40 + 0.80 = 11.20
doc_score = (doc_total / 12.0) * 10.0 # 9.333...

# Implementation scoring:
# PASS = 1.0 (verified in workspace/code/dataset), PARTIAL = 0.50 (formula unit tested or protocol drafted, app integration scheduled), NEEDS_VERIFICATION = 0.0 (no biological specimens)
impl_pass = 6 * 1.0
impl_partial = 5 * 0.50
impl_needs_verif = 1 * 0.0
impl_total = impl_pass + impl_partial + impl_needs_verif # 6.0 + 2.5 + 0.0 = 8.5
impl_score = (impl_total / 12.0) * 10.0 # 7.0833...

composite_score = (doc_score * 0.5) + (impl_score * 0.5) # 8.208...

data = {
    "document_version": "2.1.0",
    "project_title": "Sistem Intelijen Geospasial Perikanan Pelagis PPN Prigi — WPPNRI 573",
    "evaluation_gate": "PHASE 3.1 FINAL SCIENTIFIC VALIDATION GATE (PRE-PHASE 4 AUDIT CORRECTION)",
    "evaluation_date": "2026-11-01T01:15:00Z",
    "evaluator": "Senior Scientific Auditor, Marine Geospatial Data Scientist, Physical Oceanographer, and Systems Architect",
    "readiness_verdict": {
        "prototype_development": "GO",
        "operational_deployment": "NO_GO",
        "summary": "GO FOR PROTOTYPE DEVELOPMENT (DOM-DSS ARCHITECTURE) / STRICT NO-GO FOR OPERATIONAL REGULATORY DEPLOYMENT"
    },
    "score_transparency": {
        "documentation_readiness_score": round(doc_score, 2),
        "implementation_readiness_score": round(impl_score, 2),
        "composite_audit_score": round(composite_score, 2),
        "score_scale": "0.00 - 10.00",
        "methodology": {
            "documentation_formula": "Score_doc = ((6 * 1.00 + 5 * 0.88 + 1 * 0.80) / 12) * 10 = 9.33 / 10.00",
            "implementation_formula": "Score_impl = ((6 * 1.00 + 5 * 0.50 + 1 * 0.00) / 12) * 10 = 7.08 / 10.00",
            "composite_formula": "Score_comp = (Score_doc * 0.50) + (Score_impl * 0.50) = 8.21 / 10.00",
            "weights": {
                "documentation_readiness_weight": 0.50,
                "implementation_readiness_weight": 0.50
            },
            "status_credits": {
                "PASS": { "documentation": 1.00, "implementation": 1.00, "description": "Fully verified in repository and codebase" },
                "PARTIAL": { "documentation": 0.88, "implementation": 0.50, "description": "Formulas/specifications complete, execution/integration scheduled in Phase 4" },
                "NEEDS_VERIFICATION": { "documentation": 0.80, "implementation": 0.00, "description": "Schema established, primary biological specimens not available in port records" },
                "FAIL": { "documentation": 0.00, "implementation": 0.00, "description": "Non-compliant or fabricated" }
            },
            "disclaimer": "Scores represent academic readiness metrics and must NEVER be construed as objective operational deployment safety guarantees."
        }
    },
    "sub_aoi_spatial_metrics": {
        "bounding_box": {
            "min_longitude_east": 111.0,
            "max_longitude_east": 113.0,
            "min_latitude_south": -10.45,
            "max_latitude_south": -8.0
        },
        "exact_wgs84_ellipsoidal_area_km2": 59550.43,
        "spherical_approximation_area_km2": 59796.99,
        "legacy_planar_approximation_km2": 59206.0,
        "wppnri_573_total_area_km2": 1423238.0,
        "exact_sub_aoi_percentage_of_wpp573": 4.1842,
        "legacy_sub_aoi_percentage_of_wpp573": 4.16,
        "reconciliation_explanation": "Legacy 59,206 km2 (4.16%) was an unprojected planar approximation; 59,550.43 km2 (4.18%) represents the exact geodesic ellipsoidal WGS84 surface area calculated via authalic latitude integrals."
    },
    "synchronized_parameters": {
        "raw_advisory_score_definition": "Unclipped raw result of (RHSI_bar_w - lambda * sigma_w), can be negative; preserved for mathematical audit trail",
        "visualization_score_definition": "Clipped score max(0.00, min(1.00, PFG_advisory)) for map symbology and user interface rendering",
        "bathymetric_depth_band_nomenclature": "Exploratory Bathymetric Screening Band (150–1,200 m)",
        "bycatch_mitigation_layer_nomenclature": "Candidate Bathymetric Screening Polygons for Voluntary Shark Bycatch Review",
        "taxonomic_attributes_count": 8,
        "taxonomic_attributes_list": [
            "identified_taxon_name",
            "taxonomic_resolution_level",
            "taxonomic_uncertainty_notes",
            "identification_verification_status",
            "cites_appendix",
            "cites_taxonomic_scope",
            "cites_reference_date",
            "cites_verification_source"
        ],
        "provenance_attributes_count": 16,
        "provenance_attributes_list": [
            "data_source",
            "source_institution",
            "product_id",
            "product_version",
            "observation_timestamp",
            "publication_timestamp",
            "processing_timestamp",
            "spatial_resolution",
            "temporal_resolution",
            "data_type",
            "freshness_latency_status",
            "interpolation_flag",
            "model_version",
            "processing_method",
            "validity_boundaries",
            "quality_control_status"
        ],
        "cites_metadata": {
            "effective_appendices_date": "2026-03-05",
            "family_carcharhinidae_status": "Appendix II (Family-level listing)",
            "oceanic_whitetip_status": "Appendix I (Carcharhinus longimanus)",
            "port_landing_cucut_rule": "Carcharhinus spp. must NOT be automatically assigned species-level Appendix I or II status without morphology or DNA barcoding"
        },
        "fisheries_reconciled_statistics": {
            "audited_cumulative_production_kg": 18405261,
            "audited_study_period_trips": 189334,
            "all_inclusive_historical_trips_2012_2025": 249257,
            "temporal_coverage_months": 132
        }
    },
    "validation_checks": [
        {
            "id": "PG-01",
            "name": "No synthetic fishing GPS",
            "requirement": "Zero synthetic or fabricated GPS catch coordinates generated from port landing data.",
            "status": "PASS",
            "documentation_status": "PASS",
            "implementation_status": "PASS",
            "evidence": "Static code review confirms presence-proxies extracted from satellite raster heuristics without artificial vessel tracks; landing statistics strictly aggregated at port level.",
            "validation_method": "Static code analysis, dataset inspection, and GPS coordinate generation audit.",
            "last_checked": "2026-11-01"
        },
        {
            "id": "PG-02",
            "name": "RHSI relative interpretation",
            "requirement": "Model outputs labeled as Relative Habitat Suitability Index (RHSI) on scale [0.00, 1.00], decoupling relative suitability from absolute catch probability.",
            "status": "PASS",
            "documentation_status": "PASS",
            "implementation_status": "PASS",
            "evidence": "html/index.html (lines 1350-1420), html/sdm_data.js, and model evaluation files verified using RHSI terminology and scale [0, 1].",
            "validation_method": "UI string inspection, JS bundle audit, and model metadata verification.",
            "last_checked": "2026-11-01"
        },
        {
            "id": "PG-03",
            "name": "Ensemble weight normalization",
            "requirement": "Individual model weights w_i strictly normalized such that w_i >= 0 and sum(w_i) = 1.0000 across all M models.",
            "status": "PASS",
            "documentation_status": "PASS",
            "implementation_status": "PASS",
            "evidence": "models/sdm/ensemble/model_evaluations_summary.json confirms normalized ensemble weights (Random Forest, MaxEnt, GLM, GAM) sum exactly to 1.0000.",
            "validation_method": "Mathematical coefficient verification and JSON schema numerical assertion.",
            "last_checked": "2026-11-01"
        },
        {
            "id": "PG-04",
            "name": "Weighted disagreement formula",
            "requirement": "Weighted ensemble disagreement sigma_w computed as sqrt(sum(w_i * (RHSI_i - RHSI_bar_w)^2)), formally defined as weighted ensemble disagreement.",
            "status": "PARTIAL",
            "documentation_status": "PASS",
            "implementation_status": "PARTIAL",
            "evidence": "Mathematical formula unit-tested via scratch/test_weighted_disagreement.py with RHSI=[0.8, 0.6, 0.4] and w=[0.5, 0.3, 0.2]; actual disagreement 0.156205 matches expected 0.1562 (diff: 4.99e-6). Status PARTIAL retained because function is not yet integrated into app.py / utils.py.",
            "validation_method": "Unit test execution with numerical tolerance assertion and application codebase inspection.",
            "last_checked": "2026-11-01"
        },
        {
            "id": "PG-05",
            "name": "Lambda and threshold sensitivity",
            "requirement": "Penalty coefficient lambda bounded to [0.0, 1.0], baseline lambda=0.5, mandatory sensitivity testing across {0.00, 0.25, 0.50, 0.75, 1.00}, exploratory classification thresholds documented with sensitivity.",
            "status": "PARTIAL",
            "documentation_status": "PASS",
            "implementation_status": "PARTIAL",
            "evidence": "Mathematical formulation and 5 sensitivity scenarios formalized in documentation; automated computational sweep engine scheduled for Phase 4 prototype development.",
            "validation_method": "Specification audit and DSS roadmap alignment check.",
            "last_checked": "2026-11-01"
        },
        {
            "id": "PG-06",
            "name": "Internal maritime risk classification",
            "requirement": "Tiered maritime risk screening (Levels 1-4) without 'AMAN' safety guarantee, avoiding automated sea bans, and incorporating multivariate parameters with worst-case trigger.",
            "status": "PASS",
            "documentation_status": "PASS",
            "implementation_status": "PASS",
            "evidence": "html/index.html (lines 1450-1550) and FINAL_FISHING_SAFETY_ADVISORY_AUDIT.md confirm removal of 'AMAN' and automated ban; 4-tier advisory matrix verified.",
            "validation_method": "UI audit, automated regex search for forbidden terms, and logic table review.",
            "last_checked": "2026-11-01"
        },
        {
            "id": "PG-07",
            "name": "BMKG feed freshness",
            "requirement": "System detects stale or disconnected weather data, displaying DATA KEDALUWARSA, FEED TERPUTUS, or TIDAK TERSEDIA without retaining obsolete status.",
            "status": "PARTIAL",
            "documentation_status": "PASS",
            "implementation_status": "PARTIAL",
            "evidence": "Data freshness protocols, latency monitor rules, and UI warning banners specified; live operational API polling connection scheduled in Phase 4.",
            "validation_method": "Architecture specification review and UI state handling audit.",
            "last_checked": "2026-11-01"
        },
        {
            "id": "PG-08",
            "name": "123 polygon geometry validation",
            "requirement": "Validation of 123 polygons: feature count, simple geometry, empty/invalid geometries, self-intersections, duplicates, overlaps, CRS, area, Sub-AOI intersection, and depth consistency.",
            "status": "PARTIAL",
            "documentation_status": "PASS",
            "implementation_status": "PARTIAL",
            "evidence": "Empirical inspection of outputs/sdm/zones/dynamic_bycatch_mitigation_zones.geojson: 123 features, 100% Polygon, 0 empty, 0 self-intersections, 0 overlapping pairs, 30.57 km2 uniform cell area, depth -242 to -950 m. However, 6 boundary features overhang Sub-AOI boundary (110.975 deg to 113.025 deg E) by 0.025 deg (half pixel) due to unclipped raster cell boundaries; clipping scheduled in Phase 4.",
            "validation_method": "Geometric topological validation, Shoelace area calculation, and boundary intersection test.",
            "last_checked": "2026-11-01"
        },
        {
            "id": "PG-09",
            "name": "CITES taxonomy verification",
            "requirement": "CITES Appendices effective 5 March 2026 compliance, distinguishing Carcharhinidae spp. (App II) from C. longimanus (App I), 8 structured taxonomic fields implemented, landing Cucut not auto-classified to species.",
            "status": "NEEDS_VERIFICATION",
            "documentation_status": "PASS",
            "implementation_status": "NEEDS_VERIFICATION",
            "evidence": "Tripartite audit: (1) CITES reference validation = PASS; (2) Taxonomic metadata schema (8 fields) = PASS; (3) Species-level landing assignment = NEEDS_VERIFICATION. Port landing records for 'Cucut' lack morphological measurements or DNA barcoding.",
            "validation_method": "Taxonomic provenance audit against CITES 2026 Appendices and port statistics review.",
            "last_checked": "2026-11-01"
        },
        {
            "id": "PG-10",
            "name": "Current legal references",
            "requirement": "Updated statutory citations (Permen-KP 7/2026, UU 31/2004 jo UU 6/2023, UU 17/2008 jo UU 66/2024) and exact nomenclature 'Syahbandar di Pelabuhan Perikanan yang berwenang sesuai peraturan perundang-undangan'.",
            "status": "PASS",
            "documentation_status": "PASS",
            "implementation_status": "PASS",
            "evidence": "Verified across documentation Section 3.4, html/index.html (footer legal citations), and FINAL_DASHBOARD_SCIENTIFIC_CONSISTENCY_AUDIT.md.",
            "validation_method": "Legal citation cross-referencing and statutory concordance check.",
            "last_checked": "2026-11-01"
        },
        {
            "id": "PG-11",
            "name": "Historical/reanalysis/forecast separation",
            "requirement": "Reanalysis data (ERA5, GLORYS) permitted for retrospective/climatology/training, strictly separated from operational forecasts; 4 explicit data_type labels.",
            "status": "PASS",
            "documentation_status": "PASS",
            "implementation_status": "PASS",
            "evidence": "FINAL_OCEANOGRAPHIC_PROVENANCE_AUDIT.md, html/oceanographic_data.js metadata, and PROT-05 provenance specifications enforce retrospective-forecast boundaries.",
            "validation_method": "Data provenance audit and time-series metadata schema check.",
            "last_checked": "2026-11-01"
        },
        {
            "id": "PG-12",
            "name": "Geographic and environmental validity",
            "requirement": "Domain strictly bounded to Sub-AOI Prigi (111.0°-113.0° E, -8.00° to -10.45° S, 4.18% WPPNRI 573) with geometric verification of all spatial layers.",
            "status": "PARTIAL",
            "documentation_status": "PASS",
            "implementation_status": "PARTIAL",
            "evidence": "Geometric intersection audit of all 5 GeoJSON layers reveals boundary pixel overhang across layers (123-zone: 6 features; ecological zones: 134 features; albakor: 28 features; cakalang: 134 features; madidihang: 131 features) extending by 0.025 deg (2.7 km) outside strict bounding box lines; polygon clipping scheduled in Phase 4 GIS pipeline.",
            "validation_method": "Geometric bounding box calculation and GIS boundary intersection test across all spatial layers.",
            "last_checked": "2026-11-01"
        }
    ]
}

out_path = Path(r"C:\Users\ThinkPad\.gemini\antigravity\scratch\prigi-pelagis\PHASE_4_FINAL_READINESS_MATRIX.json")
with open(out_path, "w", encoding="utf-8") as f:
    json.dump(data, f, indent=2)

print(f"Written valid JSON to {out_path}")
print(f"Documentation Score: {data['score_transparency']['documentation_readiness_score']}")
print(f"Implementation Score: {data['score_transparency']['implementation_readiness_score']}")
print(f"Composite Score: {data['score_transparency']['composite_audit_score']}")
