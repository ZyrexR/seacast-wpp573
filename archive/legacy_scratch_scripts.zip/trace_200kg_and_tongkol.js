const fs = require('fs');

const dir = 'C:\\Users\\ThinkPad\\.gemini\\antigravity\\brain\\cc088fc0-e16d-416d-8247-15acc089a9e9\\scratch\\unzipped_excel';
const ssXml = fs.readFileSync(dir + '\\xl\\sharedStrings.xml', 'utf8');
const siRegex = /<si>([\s\S]*?)<\/si>/g;
let match;
const sharedStrings = [];
while ((match = siRegex.exec(ssXml)) !== null) {
  const textMatches = match[1].match(/<t[^>]*>([\s\S]*?)<\/t>/g);
  sharedStrings.push(textMatches ? textMatches.map(t => t.replace(/<t[^>]*>|<\/t>/g, '')).join('') : '');
}

// Parse Sheet 5 exactly
const s5Xml = fs.readFileSync(dir + '\\xl\\worksheets\\sheet5.xml', 'utf8');
const rowRegex = /<row[^>]+r="(\d+)"[^>]*>([\s\S]*?)<\/row>/g;
let rMatch;

const speciesHeaders = [
  { col: 'D', key: 'madidihang_kg', name: 'Yellowfin Tuna' },
  { col: 'E', key: 'tongkol_kenyar_kg', name: 'Striped Bonito' },
  { col: 'F', key: 'cakalang_kg', name: 'Skipjack Tuna' },
  { col: 'G', key: 'tongkol_krai_kg', name: 'Frigate Tuna' },
  { col: 'H', key: 'tongkol_como_kg', name: 'Eastern Little Tuna' },
  { col: 'I', key: 'gulamah_kg', name: 'Croakers' },
  { col: 'J', key: 'tenggiri_kg', name: 'Narrow Barred Spanish Mackerel' },
  { col: 'K', key: 'cucut_kg', name: 'Requiem Shark' },
  { col: 'L', key: 'marlin_kg', name: 'Black Marlin' },
  { col: 'M', key: 'julung_kg', name: 'Garfish & Halfbeaks' },
  { col: 'N', key: 'tuna_mata_besar_kg', name: 'Bigeye Tuna' },
  { col: 'O', key: 'albakor_kg', name: 'Albacore' }
];

let curYear = null;
const sheet5Monthly = [];

while ((rMatch = rowRegex.exec(s5Xml)) !== null) {
  const rNum = parseInt(rMatch[1]);
  const rowContent = rMatch[2];
  const cRegex = /<c[^>]+r="([A-Z]+)\d+"(?:[^>]+t="([^"]+)")?[^>]*>(?:<v>([\s\S]*?)<\/v>)?<\/c>/g;
  let cMatch;
  const rowData = {};
  while ((cMatch = cRegex.exec(rowContent)) !== null) {
    let val = cMatch[3];
    if (val !== undefined && cMatch[2] === 's') val = sharedStrings[parseInt(val)];
    rowData[cMatch[1]] = val;
  }

  // Detect Year
  if (rowData['B'] && !isNaN(parseFloat(rowData['B'])) && parseFloat(rowData['B']) >= 2015 && parseFloat(rowData['B']) <= 2025 && !rowData['C']) {
    curYear = parseInt(rowData['B']);
  }

  // Detect Month Row
  if (rowData['C'] && rowData['C'] !== 'Bulan' && rowData['B'] && !isNaN(parseFloat(rowData['B']))) {
    const month = parseInt(rowData['B']);
    const record = { year: curYear, month: month, row_total: parseFloat(rowData['P']) || 0, sum_calc: 0 };
    speciesHeaders.forEach(sp => {
      const val = parseFloat(rowData[sp.col]) || 0;
      record[sp.key] = val;
      record.sum_calc += val;
    });
    sheet5Monthly.push(record);
  }
}

// Compare with master_prigi_all_inclusive.csv
const prigiDir = 'C:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis';
const csvLines = fs.readFileSync(prigiDir + '/data/master_prigi_all_inclusive.csv', 'utf8').trim().split('\n');
const header = csvLines[0].split(',');

console.log(`Sheet 5 records: ${sheet5Monthly.length}, CSV records: ${csvLines.length - 1}`);

let diffTotal = 0;
const diffBySpecies = {};
speciesHeaders.forEach(sp => diffBySpecies[sp.key] = 0);

for (let i = 0; i < sheet5Monthly.length; i++) {
  const s5 = sheet5Monthly[i];
  const csvRow = csvLines[i + 1].split(',');
  const ym = csvRow[0];
  const csvTot = parseFloat(csvRow[header.indexOf('total_pelagis_kg')]);
  
  const diffRow = csvTot - s5.sum_calc;
  if (Math.abs(diffRow) > 0.001) {
    console.log(`Diff at row ${i+1} (${ym}): CSV=${csvTot}, S5=${s5.sum_calc}, Diff=${diffRow}`);
    speciesHeaders.forEach(sp => {
      const cVal = parseFloat(csvRow[header.indexOf(sp.key)]) || 0;
      const sVal = s5[sp.key];
      if (Math.abs(cVal - sVal) > 0.001) {
        console.log(`  Species ${sp.key}: CSV=${cVal}, S5=${sVal}, Diff=${cVal - sVal}`);
      }
    });
  }

  speciesHeaders.forEach(sp => {
    const cVal = parseFloat(csvRow[header.indexOf(sp.key)]) || 0;
    diffBySpecies[sp.key] += (cVal - s5[sp.key]);
  });
  diffTotal += diffRow;
}

console.log('\n--- TOTAL DIFFERENCES BY SPECIES (CSV - Sheet 5) ---');
console.log('Total Pelagis Difference:', diffTotal);
for (let k in diffBySpecies) {
  console.log(`${k}: ${diffBySpecies[k]}`);
}

console.log('\n--- SUMS IN CSV ---');
speciesHeaders.forEach(sp => {
  let colSum = 0;
  const colIdx = header.indexOf(sp.key);
  for (let i = 1; i < csvLines.length; i++) {
    colSum += parseFloat(csvLines[i].split(',')[colIdx]) || 0;
  }
  console.log(`${sp.name} (${sp.key}): CSV=${colSum.toLocaleString()} kg | Sheet5=${sheet5Monthly.reduce((a,r)=>a+r[sp.key],0).toLocaleString()} kg`);
});
