import ee
import time

ee.Initialize(project="seca-513505")

aoiFC = ee.FeatureCollection("projects/seca-513505/assets/AOI_WPP573_MASTER")
gridFC = ee.FeatureCollection("projects/seca-513505/assets/GRID_010_REGIONAL_8129")
firstProps = gridFC.first().propertyNames().getInfo()
aoiFracProp = "aoi_fract" if "aoi_fract" in firstProps else "aoi_fraction"

# 1. Test GRID_AOI_SUM
t0 = time.time()


def with_area_fn(f):
  km2 = ee.Algorithms.If(
      f.get("cell_km2"),
      f.get("cell_km2"),
      ee.Algorithms.If(
          f.get("cell_area_km2"),
          f.get("cell_area_km2"),
          f.geometry().area(1).divide(1e6),
      ),
  )
  return f.set("_cell_km2", ee.Number(km2))


withArea = gridFC.map(with_area_fn)


def rec_fn(f):
  frac = ee.Number(
      ee.Algorithms.If(
          f.get(aoiFracProp),
          f.get(aoiFracProp),
          ee.Algorithms.If(
              f.get("aoi_fract"),
              f.get("aoi_fract"),
              ee.Algorithms.If(f.get("aoi_fraction"), f.get("aoi_fraction"), 0),
          ),
      )
  )
  return f.set("_aoi_km2", frac.multiply(ee.Number(f.get("_cell_km2"))))


rec_val = withArea.map(rec_fn).aggregate_sum("_aoi_km2").getInfo()
rel_r = abs(rec_val - 933749.49) / 933749.49
print(
    f"GRID_AOI_SUM: sum={rec_val:.2f} rel_diff={rel_r:.6f} took"
    f" {time.time()-t0:.2f}s",
    flush=True,
)

# 2. Test GRID_AOI_SAMPLE
t0 = time.time()
sampleLimit = 10
samp = withArea.sort("cell_id").limit(sampleLimit)


def check_sample(f):
  frac = ee.Number(
      ee.Algorithms.If(
          f.get(aoiFracProp),
          f.get(aoiFracProp),
          ee.Algorithms.If(
              f.get("aoi_fract"),
              f.get("aoi_fract"),
              ee.Algorithms.If(f.get("aoi_fraction"), f.get("aoi_fraction"), 0),
          ),
      )
  )
  geom_area = f.geometry().area(1).divide(1e6)
  cell_km2 = ee.Number(f.get("_cell_km2"))
  area_rel_diff = geom_area.subtract(cell_km2).abs().divide(cell_km2)
  bounds_diff = ee.Number(
      ee.Algorithms.If(
          frac.lt(0), frac.abs(), ee.Algorithms.If(frac.gt(1), frac.subtract(1), 0)
      )
  )
  diff = area_rel_diff.max(bounds_diff)
  return f.set("_diff", diff)


sd_val = samp.map(check_sample).aggregate_max("_diff").getInfo()
print(
    f"GRID_AOI_SAMPLE: max_diff={sd_val:.6f} took {time.time()-t0:.2f}s",
    flush=True,
)

