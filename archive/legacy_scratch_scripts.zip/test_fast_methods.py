import ee
import time

ee.Initialize(project="seca-513505")

aoiFC = ee.FeatureCollection("projects/seca-513505/assets/AOI_WPP573_MASTER")
rawGeom = aoiFC.first().geometry()
polys = rawGeom.geometries().map(
    lambda g: ee.Algorithms.If(
        ee.Geometry(g).type().equals("Polygon"), g, None
    )
).removeAll([None])
polyCoords = polys.map(lambda p: ee.Geometry(p).coordinates())
geom = ee.Geometry(ee.Geometry.MultiPolygon(polyCoords))

gridFC = ee.FeatureCollection("projects/seca-513505/assets/GRID_010_REGIONAL_8129")
first_cell = gridFC.first()

t0 = time.time()
it = first_cell.geometry().intersects(geom).getInfo()
print(f"intersects took: {time.time()-t0:.2f}s, result={it}", flush=True)

# What about filterBounds?
t0 = time.time()
fb = aoiFC.filterBounds(first_cell.geometry()).size().getInfo()
print(f"filterBounds took: {time.time()-t0:.2f}s, size={fb}", flush=True)

# What about reduceRegion with an aoi image?
aoi_mask = ee.Image.constant(1).clip(geom)
t0 = time.time()
mean_val = (
    aoi_mask.reduceRegion(
        reducer=ee.Reducer.mean(),
        geometry=first_cell.geometry(),
        scale=1000,
        maxPixels=1e6,
    )
    .get("constant")
    .getInfo()
)
print(f"raster reduceRegion took: {time.time()-t0:.2f}s, val={mean_val}")

