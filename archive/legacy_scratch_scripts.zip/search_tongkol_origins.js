const fs = require('fs');
const prigiDir = 'C:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis';

function searchInFiles(dir, terms) {
  const files = fs.readdirSync(dir);
  files.forEach(f => {
    const full = dir + '/' + f;
    const stat = fs.statSync(full);
    if (stat.isDirectory() && f !== 'scratch' && f !== '.git') {
      searchInFiles(full, terms);
    } else if (stat.isFile() && (f.endsWith('.json') || f.endsWith('.txt') || f.endsWith('.md') || f.endsWith('.csv'))) {
      const content = fs.readFileSync(full, 'utf8');
      terms.forEach(term => {
        if (content.includes(term)) {
          console.log(`Found "${term}" in ${full}`);
        }
      });
    }
  });
}

searchInFiles(prigiDir, ['2378077', '2.378.077', '1503220', '1.503.220', '3094621', '3.094.621', '2412039', '2.412.039']);
