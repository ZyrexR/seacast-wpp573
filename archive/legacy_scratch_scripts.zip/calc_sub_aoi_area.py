import math

# WGS84 parameters
a = 6378137.0  # semi-major axis (meters)
f = 1 / 298.257223563  # flattening
b = a * (1 - f)  # semi-minor axis
e2 = 2 * f - f * f  # eccentricity squared
e = math.sqrt(e2)

def authalic_area_box(lon1, lon2, lat1, lat2):
    """
    Exact ellipsoidal surface area of a latitude-longitude quadrangle on WGS84.
    Formula:
    S(lat) = 2 * pi * b^2 * [ sin(lat)/(2*(1 - e^2*sin^2(lat))) + (1/(4*e)) * ln((1 + e*sin(lat))/(1 - e*sin(lat))) ]
    Area = (delta_lon / (2*pi)) * (S(lat2) - S(lat1))
    """
    def S(phi_rad):
        s = math.sin(phi_rad)
        term1 = s / (2.0 * (1.0 - e2 * s * s))
        term2 = (1.0 / (4.0 * e)) * math.log((1.0 + e * s) / (1.0 - e * s))
        return 2.0 * math.pi * (b ** 2) * (term1 + term2)

    phi1 = math.radians(lat1)
    phi2 = math.radians(lat2)
    lam1 = math.radians(lon1)
    lam2 = math.radians(lon2)

    d_lam = abs(lam2 - lam1)
    # Area in m^2
    area_m2 = (d_lam / (2.0 * math.pi)) * abs(S(phi2) - S(phi1))
    return area_m2

lon1, lon2 = 111.0, 113.0
lat1, lat2 = -10.45, -8.00

area_m2 = authalic_area_box(lon1, lon2, lat1, lat2)
area_km2 = area_m2 / 1e6
print(f"Sub-AOI exact WGS84 ellipsoidal area: {area_km2:.2f} km^2")

# Let's check spherical approximation with R = 6371 km
R = 6371.0
d_lon_rad = math.radians(2.0)
sin_diff = abs(math.sin(math.radians(-8.00)) - math.sin(math.radians(-10.45)))
sphere_km2 = (R ** 2) * d_lon_rad * sin_diff
print(f"Spherical area (R=6371km): {sphere_km2:.2f} km^2")

# Total WPPNRI 573 area often quoted: 1,423,238 km^2
wpp573 = 1423238.0
pct = (area_km2 / wpp573) * 100
print(f"Percentage of WPPNRI 573: {pct:.4f}% ({pct:.2f}%)")

# Let's check if lat2 was -10.27 or -10.45:
# In previous document: "-8° 00' S s/d -10° 27' S (-8.00° s/d -10.45° S)"
# Note: 10° 27' = 10 + 27/60 = 10.45°! Exactly 10.45°!
