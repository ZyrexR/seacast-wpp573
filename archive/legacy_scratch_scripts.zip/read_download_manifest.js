const fs = require('fs');
const prigiDir = 'C:/Users/ThinkPad/.gemini/antigravity/scratch/prigi-pelagis';
console.log(fs.readFileSync(prigiDir + '/data/manifests/download_manifest.json', 'utf8'));
