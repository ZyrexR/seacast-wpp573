import ee
import json

ee.Initialize(project="seca-513505")

CFG = {
    "SPATIAL": {
        "MASTER_AOI_AREA_EPSG6933_KM2": 933749.49,
        "AREA_TOLERANCE_REL": 0.005,  # 0.5% allows 937,538 km2 geodesic vs 933,749 km2 planar
        "EXPECTED_ISLAND_HOLES": 1400,
        "HOLE_TOLERANCE_ABS": 10,
        "GRID": {
            "TOTAL": 8129,
            "CLASS_COUNTS": {
                "PURE_OCEAN": 7166,
                "COASTAL_BOUNDARY": 501,
                "OUTER_AOI_BOUNDARY": 462,
            },
            "ID_PROPERTY": "cell_id",
            "CLASS_PROPERTY": "cell_class",
            "AOI_FRACTION_PROPERTY": "aoi_fract",
            "RECON_SAMPLE_CELLS": 10,
            "RECON_SAMPLE_TOL_ABS": 0.02,
            "RECON_SUM_TOL_REL": 0.01,
        },
    },
    "ASSETS": {
        "MASTER_AOI": "projects/seca-513505/assets/AOI_WPP573_MASTER",
        "CANONICAL_GRID": "projects/seca-513505/assets/GRID_010_REGIONAL_8129",
    },
}

S = CFG["SPATIAL"]
G = S["GRID"]
checks = []


def check(cid, name, status, detail):
  checks.append({"id": cid, "name": name, "status": status, "detail": detail})
  print(f"[{status}] {cid}: {name} -> {detail}", flush=True)


aoiFC = ee.FeatureCollection(CFG["ASSETS"]["MASTER_AOI"])
gridFC = ee.FeatureCollection(CFG["ASSETS"]["CANONICAL_GRID"])

# 1. AOI LOAD
n = aoiFC.size().getInfo()
check("AOI_LOAD", "Master AOI asset accessible", "PASS", f"features={n}")

# 2. Extract and unpack geometry
raw_geom = aoiFC.first().geometry()
polys = raw_geom.geometries().map(
    lambda g: ee.Algorithms.If(
        ee.Geometry(g).type().equals("Polygon"), g, None
    )
).removeAll([None])
polyCoords = polys.map(lambda p: ee.Geometry(p).coordinates())
geom = ee.Geometry(
    ee.Algorithms.If(
        raw_geom.type().equals("GeometryCollection"),
        ee.Algorithms.If(
            polys.size().gt(1),
            ee.Geometry.MultiPolygon(polyCoords),
            ee.Algorithms.If(polys.size().eq(1), polys.get(0), raw_geom),
        ),
        raw_geom,
    )
)

# 3. AOI AREA
area_km2 = geom.area(1).divide(1e6).getInfo()
rel_area = (
    abs(area_km2 - S["MASTER_AOI_AREA_EPSG6933_KM2"])
    / S["MASTER_AOI_AREA_EPSG6933_KM2"]
)
check(
    "AOI_AREA",
    "AOI area (geodesic WGS84 vs EPSG:6933 baseline)",
    "PASS" if rel_area <= S["AREA_TOLERANCE_REL"] else "FAIL",
    f"area_km2={area_km2:.2f} rel_diff={rel_area:.6f}",
)

# 4. AOI GEOM & HOLES
holes = (
    ee.Number(
        ee.Algorithms.If(
            geom.type().equals("Polygon"),
            ee.List(geom.coordinates()).size().subtract(1),
            ee.List(geom.coordinates())
            .map(lambda p: ee.List(p).size().subtract(1))
            .reduce(ee.Reducer.sum()),
        )
    )
    .getInfo()
)
geom_type = geom.type().getInfo()
is_unbounded = geom.isUnbounded().getInfo()
okType = (geom_type in ["Polygon", "MultiPolygon"]) and (not is_unbounded)
check(
    "AOI_GEOM",
    "Geometry type/non-empty",
    "PASS" if okType else "FAIL",
    f"type={geom_type} empty={is_unbounded}",
)
holes_ok = (holes == S["EXPECTED_ISLAND_HOLES"]) or (
    abs(holes - S["EXPECTED_ISLAND_HOLES"]) <= S["HOLE_TOLERANCE_ABS"]
)
check(
    "AOI_HOLES",
    f"Interior rings (island holes) == {S['EXPECTED_ISLAND_HOLES']}",
    "PASS" if holes_ok else "FAIL",
    f"holes={holes}",
)

# 5. GRID COUNT
gn = gridFC.size().getInfo()
check(
    "GRID_COUNT",
    f"Grid count == {G['TOTAL']}",
    "PASS" if gn == G["TOTAL"] else "FAIL",
    f"count={gn}",
)

# 6. GRID IDS & CLASSES
ids_info = ee.Dictionary({
    "n_ids": gridFC.aggregate_array(G["ID_PROPERTY"]).size(),
    "n_unique": gridFC.aggregate_array(G["ID_PROPERTY"]).distinct().size(),
    "classes": gridFC.aggregate_histogram(G["CLASS_PROPERTY"]),
}).getInfo()
check(
    "GRID_IDS",
    "Unique non-null cell IDs",
    (
        "PASS"
        if ids_info["n_ids"] == G["TOTAL"]
        and ids_info["n_unique"] == G["TOTAL"]
        else "FAIL"
    ),
    f"ids={ids_info['n_ids']} unique={ids_info['n_unique']}",
)

cls_counts = ids_info["classes"]
cls_ok = all(
    cls_counts.get(k) == G["CLASS_COUNTS"][k] for k in G["CLASS_COUNTS"]
)
check(
    "GRID_CLASSES",
    "Class distribution 7166/501/462",
    "PASS" if cls_ok else "FAIL",
    json.dumps(cls_counts),
)

# 7. GRID AOI SUM
first_props = gridFC.first().propertyNames().getInfo()
aoi_frac_prop = (
    "aoi_fract"
    if "aoi_fract" in first_props
    else (
        "aoi_fraction"
        if "aoi_fraction" in first_props
        else G["AOI_FRACTION_PROPERTY"]
    )
)


def with_area_fn(f):
  km2 = ee.Algorithms.If(
      f.get("cell_km2"),
      f.get("cell_km2"),
      ee.Algorithms.If(
          f.get("cell_area_km2"),
          f.get("cell_area_km2"),
          f.geometry().area(1).divide(1e6),
      ),
  )
  return f.set("_cell_km2", ee.Number(km2))


withArea = gridFC.map(with_area_fn)


def aoi_sum_fn(f):
  frac = ee.Number(
      ee.Algorithms.If(f.get(aoi_frac_prop), f.get(aoi_frac_prop), 0)
  )
  return f.set("_aoi_km2", frac.multiply(ee.Number(f.get("_cell_km2"))))


sum_km2 = withArea.map(aoi_sum_fn).aggregate_sum("_aoi_km2").getInfo()
rel_sum = (
    abs(sum_km2 - S["MASTER_AOI_AREA_EPSG6933_KM2"])
    / S["MASTER_AOI_AREA_EPSG6933_KM2"]
)
check(
    "GRID_AOI_SUM",
    "sum(aoi_fraction*cell_area) vs AOI area",
    "PASS" if rel_sum <= G["RECON_SUM_TOL_REL"] else "FAIL",
    f"sum_km2={sum_km2:.2f} rel={rel_sum:.6f}",
)

# 8. GRID AOI SAMPLE
sample_cells = withArea.sort(G["ID_PROPERTY"]).limit(G["RECON_SAMPLE_CELLS"])


def sample_diff_fn(f):
  inter = f.geometry().intersection(geom, 10).area(10).divide(1e6)
  frac = inter.divide(ee.Number(f.get("_cell_km2")))
  prop_val = ee.Number(
      ee.Algorithms.If(f.get(aoi_frac_prop), f.get(aoi_frac_prop), 0)
  )
  return f.set("_diff", frac.subtract(prop_val).abs())


max_diff = sample_cells.map(sample_diff_fn).aggregate_max("_diff").getInfo()
check(
    "GRID_AOI_SAMPLE",
    f"Direct cell∩AOI fraction vs property (sample of {G['RECON_SAMPLE_CELLS']})",
    "PASS" if max_diff <= G["RECON_SAMPLE_TOL_ABS"] else "FAIL",
    f"max_abs_diff={max_diff:.6f}",
)

all_pass = all(c["status"] == "PASS" for c in checks)
print(f"\nOVERALL PREFLIGHT RESULT: {'ALL PASS' if all_pass else 'FAILURES'}")

